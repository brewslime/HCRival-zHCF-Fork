package com.hcrival.hcf.util;

public class StringUtils
{
    public static String stringBuilder(final String[] message, final int startingPoint, final boolean trim) {
        final StringBuilder sb = new StringBuilder();
        for (int i = startingPoint; i < message.length; ++i) {
            sb.append(message[i]).append(" ");
        }
        return trim ? sb.toString().trim() : sb.toString();
    }
}
