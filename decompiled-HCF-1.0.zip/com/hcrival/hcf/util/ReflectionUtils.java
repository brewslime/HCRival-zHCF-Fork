package com.hcrival.hcf.util;

import org.bukkit.entity.*;
import org.bukkit.plugin.*;
import org.bukkit.metadata.*;
import java.util.*;
import org.bukkit.*;
import java.lang.reflect.*;

public final class ReflectionUtils
{
    private ReflectionUtils() {
    }
    
    public static MetadataValue getPlayerMetadata(final Player subject, final String metadataKey, final Plugin owningPlugin) {
        try {
            final Method getPlayerMetadata = owningPlugin.getServer().getClass().getDeclaredMethod("getPlayerMetadata", (Class<?>[])new Class[0]);
            getPlayerMetadata.setAccessible(true);
            final Object metadata = getPlayerMetadata.invoke(owningPlugin.getServer(), new Object[0]);
            final Field metadataMapField = metadata.getClass().getSuperclass().getDeclaredField("metadataMap");
            metadataMapField.setAccessible(true);
            final Map<String, Map<Plugin, MetadataValue>> metadataMap = (Map<String, Map<Plugin, MetadataValue>>)metadataMapField.get(metadata);
            final Method disambiguate = metadata.getClass().getDeclaredMethod("disambiguate", OfflinePlayer.class, String.class);
            disambiguate.setAccessible(true);
            final String key = (String)disambiguate.invoke(metadata, subject, metadataKey);
            final Map<Plugin, MetadataValue> values = metadataMap.get(key);
            return (values == null) ? null : values.get(owningPlugin);
        }
        catch (NoSuchFieldException | NoSuchMethodException | IllegalAccessException | InvocationTargetException ex2) {
            final ReflectiveOperationException ex;
            final ReflectiveOperationException e = ex;
            e.printStackTrace();
            return null;
        }
    }
}
