package com.hcrival.hcf.util;

public final class NameUtils
{
    private NameUtils() {
    }
    
    public static String getPrettyName(final String str) {
        final char[] chars = str.trim().toCharArray();
        for (int i = 0; i < chars.length; ++i) {
            if (i == 0) {
                chars[i] = Character.toUpperCase(chars[i]);
            }
            else if (chars[i] == '_') {
                chars[i] = ' ';
            }
            else if (chars[i - 1] == ' ') {
                chars[i] = Character.toUpperCase(chars[i]);
            }
            else {
                chars[i] = Character.toLowerCase(chars[i]);
            }
        }
        return String.valueOf(chars);
    }
}
