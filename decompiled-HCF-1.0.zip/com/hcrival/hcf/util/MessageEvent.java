package com.hcrival.hcf.util;

import org.bukkit.event.*;
import org.bukkit.entity.*;
import java.util.*;
import com.google.common.collect.*;
import com.google.common.base.*;
import com.hcrival.hcf.*;
import us.hcrealms.chronium.*;
import org.bukkit.*;
import com.hcrival.hcf.user.*;

public class MessageEvent extends Event implements Cancellable
{
    private static final HandlerList handlers;
    private final Player sender;
    private final Player recipient;
    private final String message;
    private final boolean isReply;
    private boolean cancelled;
    
    public MessageEvent(final Player sender, final Set<Player> recipients, final String message, final boolean isReply) {
        this.cancelled = false;
        this.sender = sender;
        this.recipient = Iterables.getFirst(recipients, (Player)null);
        this.message = message;
        this.isReply = isReply;
    }
    
    public static HandlerList getHandlerList() {
        return MessageEvent.handlers;
    }
    
    public Player getSender() {
        return this.sender;
    }
    
    public Player getRecipient() {
        return this.recipient;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public boolean isReply() {
        return this.isReply;
    }
    
    public void send() {
        Preconditions.checkNotNull(this.sender, (Object)"The sender cannot be null");
        Preconditions.checkNotNull(this.recipient, (Object)"The recipient cannot be null");
        if (this.message.equalsIgnoreCase("IP")) {}
        final HCF plugin = HCF.getPlugin();
        final FactionUser sendingUser = plugin.getUserManager().getUser(this.sender.getUniqueId());
        final FactionUser recipientUser = plugin.getUserManager().getUser(this.recipient.getUniqueId());
        sendingUser.setLastRepliedTo(recipientUser.getUserUUID());
        recipientUser.setLastRepliedTo(sendingUser.getUserUUID());
        final long millis = System.currentTimeMillis();
        recipientUser.setLastReceivedMessageMillis(millis);
        final String rank = ChatColor.translateAlternateColorCodes('&', "&f" + ChroniumAPI.getRankOfPlayer(this.sender).getPrefix()).replace("_", " ");
        final String displayName = rank + this.sender.getDisplayName();
        final String rank2 = ChatColor.translateAlternateColorCodes('&', "&f" + ChroniumAPI.getRankOfPlayer(this.recipient).getPrefix()).replace("_", " ");
        final String displayName2 = rank2 + this.recipient.getDisplayName();
        this.sender.sendMessage(ChatColor.GRAY + "(To " + ChatColor.GRAY + displayName2 + ChatColor.GRAY + ") " + ChatColor.GRAY + this.message);
        this.recipient.sendMessage(ChatColor.GRAY + "(From " + ChatColor.GRAY + displayName + ChatColor.GRAY + ") " + ChatColor.GRAY + this.message);
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    public HandlerList getHandlers() {
        return MessageEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
