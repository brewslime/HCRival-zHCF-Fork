package com.hcrival.hcf.loggers.type;

import org.bukkit.entity.*;
import org.bukkit.craftbukkit.v1_7_R4.*;
import net.minecraft.util.com.mojang.authlib.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import com.hcrival.hcf.loggers.event.*;
import net.minecraft.server.v1_7_R4.*;

public class LoggerEntityHuman extends EntityPlayer implements LoggerEntity
{
    private BukkitTask removalTask;
    
    public LoggerEntityHuman(final Player player, final World world) {
        this(player, ((CraftWorld)world).getHandle());
    }
    
    private LoggerEntityHuman(final Player player, final WorldServer world) {
        super(MinecraftServer.getServer(), world, new GameProfile(player.getUniqueId(), player.getName()), new PlayerInteractManager((net.minecraft.server.v1_7_R4.World)world));
        final Location location = player.getLocation();
        final double x = location.getX();
        final double y = location.getY();
        final double z = location.getZ();
        final float yaw = location.getYaw();
        final float pitch = location.getPitch();
        new FakePlayerConnection((EntityPlayer)this);
        this.playerConnection.a(x, y, z, yaw, pitch);
        final EntityPlayer originPlayer = ((CraftPlayer)player).getHandle();
        this.lastDamager = originPlayer.lastDamager;
        this.invulnerableTicks = originPlayer.invulnerableTicks;
        this.combatTracker = originPlayer.combatTracker;
    }
    
    protected boolean d(final DamageSource source, final float amount) {
        if (this.dead) {
            return false;
        }
        final boolean flag = super.d(source, amount);
        if (!flag || this.dead || this.getHealth() <= 0.0f) {
            return flag;
        }
        super.die(source);
        this.dead = true;
        this.setHealth(0.0f);
        MinecraftServer.getServer().getPlayerList().playerFileData.save((EntityHuman)this);
        return true;
    }
    
    public void postSpawn(final HCF plugin) {
        if (this.world.addEntity((Entity)this)) {
            Bukkit.getConsoleSender().sendMessage(String.format(ChatColor.GOLD + "Combat logger of " + this.getName() + " has spawned at %.2f, %.2f, %.2f", this.locX, this.locY, this.locZ));
            MinecraftServer.getServer().getPlayerList().playerFileData.load((EntityHuman)this);
        }
        else {
            Bukkit.getConsoleSender().sendMessage(String.format(ChatColor.RED + "Combat logger of " + this.getName() + " failed to spawned at %.2f, %.2f, %.2f", this.locX, this.locY, this.locZ));
        }
        final LoggerEntityHuman finalLogger = this;
        this.removalTask = new BukkitRunnable() {
            public void run() {
                final PacketPlayOutPlayerInfo packet = PacketPlayOutPlayerInfo.removePlayer(finalLogger.getBukkitEntity().getHandle());
                MinecraftServer.getServer().getPlayerList().sendAll((Packet)packet);
                finalLogger.destroy();
            }
        }.runTaskLater((Plugin)plugin, 600L);
    }
    
    public void closeInventory() {
    }
    
    private void cancelTask() {
        if (this.removalTask != null) {
            this.removalTask.cancel();
            this.removalTask = null;
        }
    }
    
    public void die(final DamageSource damageSource) {
        if (!this.dead) {
            super.die(damageSource);
            Bukkit.getPluginManager().callEvent((Event)new LoggerDeathEvent(this));
            MinecraftServer.getServer().getPlayerList().playerFileData.save((EntityHuman)this);
            this.cancelTask();
        }
    }
    
    public void destroy() {
        if (!this.dead) {
            this.cancelTask();
            Bukkit.getPluginManager().callEvent((Event)new LoggerRemovedEvent(this));
            this.dead = true;
        }
    }
    
    public void b(final int i) {
    }
    
    public void dropDeathLoot(final boolean flag, final int i) {
    }
    
    public boolean a(final EntityHuman entityHuman) {
        return super.a(entityHuman);
    }
    
    public void collide(final Entity entity) {
    }
    
    private static class FakePlayerConnection extends PlayerConnection
    {
        private FakePlayerConnection(final EntityPlayer entityplayer) {
            super(MinecraftServer.getServer(), (NetworkManager)new FakeNetworkManager(), entityplayer);
        }
        
        public void disconnect(final String s) {
        }
        
        public void sendPacket(final Packet packet) {
        }
    }
    
    private static class FakeNetworkManager extends NetworkManager
    {
        private FakeNetworkManager() {
            super(false);
        }
        
        public int getVersion() {
            return super.getVersion();
        }
    }
}
