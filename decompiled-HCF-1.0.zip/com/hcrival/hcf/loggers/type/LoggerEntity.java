package com.hcrival.hcf.loggers.type;

import com.hcrival.hcf.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;
import java.util.*;

public interface LoggerEntity
{
    void postSpawn(final HCF p0);
    
    CraftPlayer getBukkitEntity();
    
    UUID getUniqueID();
    
    void destroy();
}
