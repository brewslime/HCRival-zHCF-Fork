package com.hcrival.hcf.loggers.event;

import org.bukkit.event.*;
import com.hcrival.hcf.loggers.type.*;

public class LoggerSpawnEvent extends Event implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final LoggerEntity loggerEntity;
    
    public LoggerSpawnEvent(final LoggerEntity loggerEntity) {
        this.loggerEntity = loggerEntity;
    }
    
    public LoggerEntity getLoggerEntity() {
        return this.loggerEntity;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    public static HandlerList getHandlerList() {
        return LoggerSpawnEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return LoggerSpawnEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
