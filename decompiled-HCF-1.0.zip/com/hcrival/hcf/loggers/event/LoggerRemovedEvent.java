package com.hcrival.hcf.loggers.event;

import org.bukkit.event.*;
import com.hcrival.hcf.loggers.type.*;

public class LoggerRemovedEvent extends Event
{
    private static final HandlerList handlers;
    private final LoggerEntity loggerEntity;
    
    public LoggerRemovedEvent(final LoggerEntity loggerEntity) {
        this.loggerEntity = loggerEntity;
    }
    
    public LoggerEntity getLoggerEntity() {
        return this.loggerEntity;
    }
    
    public static HandlerList getHandlerList() {
        return LoggerRemovedEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return LoggerRemovedEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
