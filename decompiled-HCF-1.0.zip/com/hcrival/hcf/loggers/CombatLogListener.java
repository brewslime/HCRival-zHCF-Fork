package com.hcrival.hcf.loggers;

import com.hcrival.hcf.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.event.player.*;
import com.hcrival.hcf.loggers.type.*;
import com.hcrival.hcf.loggers.event.*;
import org.bukkit.event.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import org.bukkit.*;

public class CombatLogListener implements Listener
{
    private static final int NEARBY_SPAWN_RADIUS = 64;
    private final Set<UUID> safelyDisconnected;
    private final Map<UUID, LoggerEntity> loggers;
    private final HCF plugin;
    
    public CombatLogListener(final HCF plugin) {
        this.safelyDisconnected = new HashSet<UUID>();
        this.loggers = new HashMap<UUID, LoggerEntity>();
        this.plugin = plugin;
    }
    
    public void safelyDisconnect(final Player player, final String reason) {
        if (this.safelyDisconnected.add(player.getUniqueId())) {
            player.kickPlayer(reason);
        }
    }
    
    public void removeCombatLoggers() {
        final Iterator<LoggerEntity> iterator = this.loggers.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().destroy();
            iterator.remove();
        }
        this.safelyDisconnected.clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onLoggerRemoved(final LoggerRemovedEvent event) {
        this.loggers.remove(event.getLoggerEntity().getUniqueID());
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerLogin(final PlayerLoginEvent event) {
        final LoggerEntity currentLogger = this.loggers.remove(event.getPlayer().getUniqueId());
        if (currentLogger != null) {
            currentLogger.destroy();
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final Player player = event.getPlayer();
        final UUID uuid = player.getUniqueId();
        final boolean result = this.safelyDisconnected.remove(uuid);
        if (player.getGameMode() != GameMode.CREATIVE && !player.isDead() && !result) {
            if (this.plugin.getTimerManager().getInvincibilityTimer().getRemaining(uuid) > 0L) {
                return;
            }
            if (this.plugin.getTimerManager().getTeleportTimer().getNearbyEnemies(player, 64) <= 0 || this.plugin.getSotwTimer().getSotwRunnable() != null) {
                return;
            }
            final Location location = player.getLocation();
            if (this.plugin.getFactionManager().getFactionAt(location).isSafezone()) {
                return;
            }
            if (this.loggers.containsKey(player.getUniqueId())) {
                return;
            }
            if (player.hasPermission("modmode.player.staff")) {
                return;
            }
            final LoggerEntity loggerEntity = new LoggerEntityHuman(player, location.getWorld());
            final LoggerSpawnEvent calledEvent = new LoggerSpawnEvent(loggerEntity);
            Bukkit.getPluginManager().callEvent((Event)calledEvent);
            if (!calledEvent.isCancelled()) {
                this.loggers.put(player.getUniqueId(), loggerEntity);
                new BukkitRunnable() {
                    public void run() {
                        if (!player.isOnline()) {
                            loggerEntity.postSpawn(CombatLogListener.this.plugin);
                        }
                    }
                }.runTaskLater((Plugin)this.plugin, 1L);
            }
        }
    }
    
    public Map<UUID, LoggerEntity> getLoggers() {
        return this.loggers;
    }
}
