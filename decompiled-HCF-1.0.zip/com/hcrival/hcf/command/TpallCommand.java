package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;

public class TpallCommand implements CommandExecutor
{
    public boolean isDouble(final String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!cmd.getName().equalsIgnoreCase("tpall")) {
            return false;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        final Player p = (Player)sender;
        if (!sender.hasPermission("hcf.command.teleportall") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length > 0) {
            sender.sendMessage("�c/teleportall");
            return true;
        }
        for (final Player online : Bukkit.getOnlinePlayers()) {
            if (online != p) {
                online.teleport((Entity)p);
                online.sendMessage("�eYou have been teleported to �c" + p.getName() + "�e.");
            }
        }
        p.sendMessage("�eYou have teleported �call players online �eto �cyou�e.");
        return true;
    }
}
