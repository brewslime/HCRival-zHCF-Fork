package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.*;
import org.bukkit.entity.*;

public class KillCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Usage: /kill <player>");
        }
        else {
            final Player target = HCF.getPlugin().getServer().getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "That player doesn't exist!");
                return true;
            }
            target.setHealth(0.0);
            sender.sendMessage(ChatColor.YELLOW + "Killed player " + ChatColor.RED + args[0] + ChatColor.YELLOW + ".");
        }
        return true;
    }
}
