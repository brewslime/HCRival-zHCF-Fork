package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import java.util.*;

public class TestMSgs implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String s, final String[] strings) {
        final Player player = (Player)sender;
        final List<String> configList = (List<String>)HCF.getPlugin().getConfig().getStringList("TEST");
        final List<String> msg = new ArrayList<String>();
        for (int i = 0; i < configList.size(); ++i) {
            final String string = configList.get(i);
            msg.add(string);
        }
        sender.sendMessage(configList.toString());
        return false;
    }
}
