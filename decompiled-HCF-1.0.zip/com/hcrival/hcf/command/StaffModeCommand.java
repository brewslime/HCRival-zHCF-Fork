package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import java.util.*;

public class StaffModeCommand implements CommandExecutor, TabCompleter
{
    private final HCF staffMode;
    
    public StaffModeCommand() {
        this.staffMode = HCF.getPlugin();
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] arguments) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            if (player.hasPermission("hcf.command.staffmode")) {
                if (arguments.length > 0) {
                    player.sendMessage(Color.translate("&cUsage: /" + label));
                }
                else if (this.staffMode.getStaffModeListener().isStaffModeActive(player)) {
                    this.staffMode.getStaffModeListener().setStaffMode(player, false);
                    player.sendMessage(Color.translate("&cYou have disabled your staff mode."));
                }
                else {
                    this.staffMode.getStaffModeListener().setStaffMode(player, true);
                    player.sendMessage(Color.translate("&aYou have enabled your staff mode."));
                }
            }
            else {
                sender.sendMessage(ChatColor.RED + "No permission.");
            }
        }
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] arguments) {
        if (arguments.length > 1) {
            return Collections.emptyList();
        }
        return null;
    }
}
