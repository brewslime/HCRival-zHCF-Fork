package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import org.bukkit.enchantments.*;
import java.util.regex.*;
import com.hcrival.util.chat.*;
import org.bukkit.potion.*;
import org.apache.commons.lang3.text.*;
import com.hcrival.util.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.command.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.*;
import org.bukkit.event.server.*;
import org.bukkit.entity.*;
import java.util.*;

public class MapKitCommand implements CommandExecutor, TabCompleter, Listener
{
    private Inventory mapkitInventory;
    private final HCF plugin;
    
    public MapKitCommand(final HCF plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.reloadMapKitInventory();
    }
    
    private void reloadMapKitInventory() {
        final List<ItemStack> items = new ArrayList<ItemStack>();
        for (final Enchantment enchantment : Enchantment.values()) {
            final String ench = enchantment.getName();
            int maxLevel = enchantment.getMaxLevel();
            for (final String s : this.plugin.getConfig().getStringList("settings.enchantmentLimits")) {
                final String[] part = s.split(Pattern.quote(";"));
                if (part[0].equalsIgnoreCase(ench)) {
                    maxLevel = Integer.valueOf(part[1]);
                }
            }
            final ItemBuilder builder = new ItemBuilder(Material.ENCHANTED_BOOK);
            builder.displayName(ChatColor.YELLOW + Lang.fromEnchantment(enchantment) + ": " + ChatColor.GREEN + ((maxLevel == 0) ? "Disabled" : Integer.valueOf(maxLevel)));
            items.add(builder.build());
        }
        for (final PotionType potionType : PotionType.values()) {
            final String ench = potionType.name();
            int maxLevel = potionType.getMaxLevel();
            for (final String s : this.plugin.getConfig().getStringList("settings.potionLimits")) {
                final String[] part = s.split(Pattern.quote(";"));
                if (part[0].equalsIgnoreCase(ench)) {
                    maxLevel = Integer.valueOf(part[1]);
                }
            }
            final ItemBuilder builder = new ItemBuilder(new Potion(potionType).toItemStack(1));
            builder.displayName(ChatColor.YELLOW + WordUtils.capitalizeFully(potionType.name().replace('_', ' ')) + ": " + ChatColor.GREEN + ((maxLevel == 0) ? "Disabled" : Integer.valueOf(maxLevel)));
            items.add(builder.build());
        }
        this.mapkitInventory = Bukkit.createInventory((InventoryHolder)null, InventoryUtils.getSafestInventorySize(items.size()), "Map Kit");
        for (final ItemStack item : items) {
            this.mapkitInventory.addItem(new ItemStack[] { item });
        }
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        ((Player)sender).openInventory(this.mapkitInventory);
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onInventoryClick(final InventoryClickEvent event) {
        if (this.mapkitInventory.equals(event.getInventory())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPluginDisable(final PluginDisableEvent event) {
        for (final HumanEntity viewer : new HashSet<HumanEntity>(this.mapkitInventory.getViewers())) {
            viewer.closeInventory();
        }
    }
}
