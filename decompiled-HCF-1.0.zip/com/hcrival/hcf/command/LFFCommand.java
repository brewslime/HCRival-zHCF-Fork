package com.hcrival.hcf.command;

import java.util.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import com.hcrival.hcf.faction.type.*;

public class LFFCommand implements CommandExecutor
{
    private List<UUID> cooldown;
    
    public LFFCommand() {
        this.cooldown = new ArrayList<UUID>();
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String s, final String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = HCF.getPlugin().getFactionManager().getPlayerFaction(player);
        if (this.cooldown.contains(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "You're on cooldown! Please try again later!");
            return false;
        }
        if (playerFaction != null) {
            player.sendMessage(ChatColor.RED + "You're already in a faction.");
            return true;
        }
        Bukkit.broadcastMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.lff")).replace("%player%", player.getName()));
        this.cooldown.add(player.getUniqueId());
        final long seconds = 1200L;
        new BukkitRunnable() {
            public void run() {
                LFFCommand.this.cooldown.remove(player.getUniqueId());
            }
        }.runTaskLater((Plugin)HCF.getPlugin(), 24000L);
        return false;
    }
}
