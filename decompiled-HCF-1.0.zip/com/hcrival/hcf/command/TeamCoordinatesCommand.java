package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class TeamCoordinatesCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String s, final String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = HCF.getPlugin().getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            player.sendMessage(ChatColor.RED + "You don't have a faction.");
            return true;
        }
        final int x = player.getLocation().getBlockX();
        final int y = player.getLocation().getBlockY();
        final int z = player.getLocation().getBlockZ();
        String name = "None";
        switch (player.getWorld().getEnvironment()) {
            case THE_END: {
                name = "End";
                break;
            }
            case NETHER: {
                name = "Nether";
                break;
            }
            case NORMAL: {
                name = "Overworld";
                break;
            }
            default: {
                throw new IllegalArgumentException("Unrecognised environment");
            }
        }
        final String msg = HCF.getPlugin().getMessageConfig().getConfig().getString("messages.tl").replace("%x%", Integer.toString(x)).replace("%y%", Integer.toString(y)).replace("%z%", Integer.toString(z)).replace("%environment%", name).replace("%player%", player.getName());
        for (final Player loop : playerFaction.getOnlinePlayers()) {
            loop.sendMessage(Color.translate(msg));
        }
        return true;
    }
}
