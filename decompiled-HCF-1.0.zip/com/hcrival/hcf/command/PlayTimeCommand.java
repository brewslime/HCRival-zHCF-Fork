package com.hcrival.hcf.command;

public class PlayTimeCommand
{
}
