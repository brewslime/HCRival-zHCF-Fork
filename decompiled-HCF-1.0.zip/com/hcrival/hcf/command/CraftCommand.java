package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class CraftCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players.");
            return true;
        }
        final Player player = (Player)sender;
        if (player.hasPermission("hcf.command.craft")) {
            player.openWorkbench(player.getLocation(), true);
        }
        else {
            player.sendMessage(ChatColor.RED + "Sorry you don't have permission.");
        }
        return false;
    }
}
