package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.user.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import org.bukkit.event.*;

public class ToggleSoundsCommand implements CommandExecutor, Listener
{
    private final HCF plugin;
    
    public ToggleSoundsCommand(final HCF plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final FactionUser baseUser = this.plugin.getUserManager().getUser(player.getUniqueId());
        final boolean newMessagingSounds = !baseUser.isMessagingSounds() || (args.length >= 2 && Boolean.parseBoolean(args[1]));
        baseUser.setMessagingSounds(newMessagingSounds);
        sender.sendMessage(ChatColor.YELLOW + "Messaging sounds are now " + (newMessagingSounds ? (ChatColor.GREEN + "on") : (ChatColor.RED + "off")) + ChatColor.YELLOW + '.');
        return true;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerMessage(final MessageEvent event) {
        final Player recipient = event.getRecipient();
        final FactionUser recipientUser = this.plugin.getUserManager().getUser(recipient.getUniqueId());
        if (recipientUser.isMessagingSounds()) {
            recipient.playSound(recipient.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
        }
    }
}
