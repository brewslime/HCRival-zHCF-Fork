package com.hcrival.hcf.command;

import org.bukkit.command.*;
import com.hcrival.hcf.*;
import com.hcrival.util.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.timer.type.*;

public class AutoRestartCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!sender.hasPermission("")) {
            sender.sendMessage(ChatColor.RED + "You don't have enough permissions.");
            return true;
        }
        if (args.length == 0 || args.length < 2 || args.length > 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /autorestart schedule <time>");
            return true;
        }
        final long duration = JavaUtils.parse(args[1]);
        if (duration == -1L) {
            sender.sendMessage(ChatColor.RED + "'" + args[0] + "' is an invalid duration.");
            return true;
        }
        final AutoRestartTimer.AutoRestartRunnable restart = HCF.getPlugin().getTimerManager().getAutoRestartTimer().getAutoRestartRunnable();
        if (restart != null) {
            sender.sendMessage(ChatColor.RED + "There is already auto restart timer going on!");
            return true;
        }
        HCF.getPlugin().getTimerManager().getAutoRestartTimer().start(duration);
        Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', "&7" + BukkitUtils.STRAIGHT_LINE_DEFAULT));
        Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', "&c&lSERVER REBOOTING IN &c" + DurationFormatter.getRemaining(duration, true)));
        Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', "&7" + BukkitUtils.STRAIGHT_LINE_DEFAULT));
        return true;
    }
}
