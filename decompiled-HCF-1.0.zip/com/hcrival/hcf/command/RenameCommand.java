package com.hcrival.hcf.command;

import java.util.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;

public class RenameCommand implements CommandExecutor
{
    private Map<UUID, Long> cooldown;
    
    public RenameCommand() {
        this.cooldown = new HashMap<UUID, Long>();
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("rename")) {
            if (!sender.hasPermission("hcf.command.rename") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length == 0) {
                sender.sendMessage("�cUsage: /rename <name>");
                return true;
            }
            if (p.getItemInHand().getType() == Material.AIR) {
                sender.sendMessage("�cInvalid Item.");
                return true;
            }
            if (this.cooldown.containsKey(p.getUniqueId()) && !p.hasPermission("hcf.command.rename")) {
                sender.sendMessage(ChatColor.RED + "You still have rename cooldown!");
                return true;
            }
            final StringBuilder str = new StringBuilder();
            for (int i = 0; i < args.length; ++i) {
                str.append(args[i] + " ");
            }
            final String name = str.toString();
            final ItemStack j = p.getItemInHand();
            final ItemMeta im = j.getItemMeta();
            im.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            j.setItemMeta(im);
            p.setItemInHand(j);
            p.sendMessage(ChatColor.RED + "You have successfully renamed item to " + name);
            this.cooldown.put(p.getUniqueId(), System.currentTimeMillis());
        }
        return true;
    }
}
