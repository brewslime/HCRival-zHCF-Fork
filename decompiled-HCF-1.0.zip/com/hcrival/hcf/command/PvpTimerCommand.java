package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import com.google.common.collect.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.timer.type.*;
import com.hcrival.util.*;
import java.util.*;

public class PvpTimerCommand implements CommandExecutor, TabCompleter
{
    private final HCF plugin;
    private static final ImmutableList<String> COMPLETIONS;
    
    public PvpTimerCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final InvincibilityTimer pvpTimer = this.plugin.getTimerManager().getInvincibilityTimer();
        if (args.length < 1) {
            this.printUsage(sender, label, pvpTimer);
            return true;
        }
        if (args[0].equalsIgnoreCase("enable") || args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("off")) {
            if (pvpTimer.getRemaining(player) <= 0L) {
                sender.sendMessage(ChatColor.RED + "Your " + pvpTimer.getName() + ChatColor.RED + " timer is currently not active.");
                return true;
            }
            sender.sendMessage(ChatColor.YELLOW + "Your " + pvpTimer.getName() + ChatColor.YELLOW + " timer is now off.");
            pvpTimer.clearCooldown(player);
            return true;
        }
        else {
            if (!args[0].equalsIgnoreCase("remaining") && !args[0].equalsIgnoreCase("time") && !args[0].equalsIgnoreCase("left") && !args[0].equalsIgnoreCase("check")) {
                this.printUsage(sender, label, pvpTimer);
                return true;
            }
            final long remaining = pvpTimer.getRemaining(player);
            if (remaining <= 0L) {
                sender.sendMessage(ChatColor.RED + "Your " + pvpTimer.getName() + ChatColor.RED + " timer is currently not active.");
                return true;
            }
            sender.sendMessage(ChatColor.YELLOW + "Your " + pvpTimer.getName() + ChatColor.YELLOW + " timer is active for another " + ChatColor.BOLD + DurationFormatter.getRemaining(remaining, true, false) + ChatColor.YELLOW + (pvpTimer.isPaused(player) ? " and is currently paused" : "") + '.');
            return true;
        }
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 1) ? BukkitUtils.getCompletions(args, PvpTimerCommand.COMPLETIONS) : Collections.emptyList();
    }
    
    private void printUsage(final CommandSender sender, final String label, final InvincibilityTimer pvpTimer) {
        sender.sendMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(ChatColor.WHITE + "");
        sender.sendMessage(ChatColor.YELLOW + "/pvp enable - Revokes your PvP Timer!");
        sender.sendMessage(ChatColor.YELLOW + "/pvp time - Shows your current remaining timer.");
        sender.sendMessage(ChatColor.WHITE + "");
        sender.sendMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
    }
    
    static {
        COMPLETIONS = ImmutableList.of("enable", "time");
    }
}
