package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import java.util.*;

public class VanishCommand implements CommandExecutor, TabCompleter
{
    private final HCF vanish;
    
    public VanishCommand() {
        this.vanish = HCF.getPlugin();
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            if (player.hasPermission("hcf.command.vanish")) {
                if (args.length > 0) {
                    player.sendMessage(Color.translate("&cUsage: /" + label));
                }
                else if (this.vanish.getStaffModeListener().isVanished(player)) {
                    this.vanish.getStaffModeListener().setVanished(player, false);
                    player.sendMessage(Color.translate("&eYour vanish has been &cdisabled&e."));
                }
                else {
                    this.vanish.getStaffModeListener().setVanished(player, true);
                    player.sendMessage(Color.translate("&eYour vanish has been &aenabled&e."));
                }
            }
            else {
                sender.sendMessage(ChatColor.RED + "No permission.");
            }
        }
        else {
            sender.sendMessage(Color.translate("&cYou can not execute this command on console."));
        }
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length > 1) {
            return Collections.emptyList();
        }
        return null;
    }
}
