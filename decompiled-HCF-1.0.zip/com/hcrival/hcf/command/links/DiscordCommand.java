package com.hcrival.hcf.command.links;

import org.bukkit.command.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;

public class DiscordCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        sender.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.discord")));
        return true;
    }
}
