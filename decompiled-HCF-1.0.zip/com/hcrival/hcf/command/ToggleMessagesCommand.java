package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.user.*;

public class ToggleMessagesCommand implements CommandExecutor
{
    private final HCF plugin;
    
    public ToggleMessagesCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable for players.");
            return true;
        }
        final Player player = (Player)sender;
        final FactionUser baseUser = this.plugin.getUserManager().getUser(player.getUniqueId());
        final boolean newToggled = !baseUser.isMessagesVisible();
        baseUser.setMessagesVisible(newToggled);
        sender.sendMessage(ChatColor.YELLOW + "You have turned private messages " + (newToggled ? (ChatColor.GREEN + "on") : (ChatColor.RED + "off")) + ChatColor.YELLOW + '.');
        return true;
    }
}
