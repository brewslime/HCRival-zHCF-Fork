package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;
import java.util.*;

public class DeathCommand implements CommandExecutor, TabCompleter
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length > 0) {
            sender.sendMessage("Currently unimplemented.");
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Usage: /" + label + " <playerName>");
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
