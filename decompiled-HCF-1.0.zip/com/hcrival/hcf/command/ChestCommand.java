package com.hcrival.hcf.command;

import org.bukkit.command.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import org.bukkit.entity.*;

public class ChestCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String s, final String[] strings) {
        if (!HCF.getPlugin().getConfig().getBoolean("server.kitmap")) {
            sender.sendMessage(ChatColor.RED + "You can only use this in kitmap.");
            return false;
        }
        final Player player = (Player)sender;
        player.openInventory(player.getEnderChest());
        player.sendMessage(ChatColor.YELLOW + "Opening up the chest...");
        return false;
    }
}
