package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class SpawnCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (cmd.getName().equalsIgnoreCase("spawn")) {
            if (!(sender instanceof Player)) {
                return true;
            }
            if (!sender.hasPermission("hcf.command.spawn")) {
                sender.sendMessage(ChatColor.RED + "You must travel to" + ChatColor.GREEN + " Spawn " + ChatColor.RED + "Coordinates: " + ChatColor.GRAY + "(0 | 0)");
                return true;
            }
            if (args.length == 0) {
                final Player player = (Player)sender;
                final World world = player.getWorld();
                final Location spon = world.getSpawnLocation().clone().add(0.5, 0.5, 0.5);
                player.teleport(spon);
                player.sendMessage(ChatColor.RED + "You have been teleported to spawn.");
            }
            if (args.length == 1) {
                final Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "That player is currently offline.");
                    return true;
                }
                final World world = target.getWorld();
                final Location spon = world.getSpawnLocation().clone().add(0.5, 0.5, 0.5);
                target.teleport(spon);
                sender.sendMessage(ChatColor.RED + target.getName() + " has been teleported to spawn.");
            }
        }
        return false;
    }
}
