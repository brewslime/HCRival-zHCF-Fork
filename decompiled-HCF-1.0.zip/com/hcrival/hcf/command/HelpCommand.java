package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;

public class HelpCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            HCF.getPlugin().getMessageConfig().getConfig().getStringList("messages.help_command").forEach(s -> player.sendMessage(Color.translate(s)));
        }
        else {
            sender.sendMessage("You can't use this command");
        }
        return true;
    }
}
