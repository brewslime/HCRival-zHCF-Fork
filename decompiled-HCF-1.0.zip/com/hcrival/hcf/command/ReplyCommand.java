package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.apache.commons.lang.*;
import com.google.common.collect.*;
import com.hcrival.hcf.util.*;
import org.bukkit.event.*;
import com.hcrival.hcf.user.*;
import java.util.*;
import java.util.concurrent.*;

public class ReplyCommand implements CommandExecutor
{
    private static final long VANISH_REPLY_TIMEOUT;
    private final HCF plugin;
    
    public ReplyCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable for players.");
            return true;
        }
        final Player player = (Player)sender;
        final UUID uuid = player.getUniqueId();
        final FactionUser baseUser = this.plugin.getUserManager().getUser(uuid);
        final UUID lastReplied = baseUser.getLastRepliedTo();
        final Player target = (lastReplied == null) ? null : Bukkit.getPlayer(lastReplied);
        if (args.length < 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /reply <text>");
            if (lastReplied != null && player.canSee(target)) {
                sender.sendMessage(ChatColor.RED + "You are in a conversation with " + target.getName() + '.');
            }
            return true;
        }
        final long millis = System.currentTimeMillis();
        if (target == null || (!player.canSee(target) && millis - baseUser.getLastReceivedMessageMillis() > ReplyCommand.VANISH_REPLY_TIMEOUT)) {
            sender.sendMessage(ChatColor.GOLD + "There is no player to reply to.");
            return true;
        }
        final String message = StringUtils.join((Object[])args, ' ');
        final HashSet<Player> recipients = Sets.newHashSet(target);
        final MessageEvent playerMessageEvent = new MessageEvent(player, recipients, message, false);
        Bukkit.getPluginManager().callEvent((Event)playerMessageEvent);
        if (!playerMessageEvent.isCancelled()) {
            playerMessageEvent.send();
        }
        return true;
    }
    
    static {
        VANISH_REPLY_TIMEOUT = TimeUnit.SECONDS.toMillis(45L);
    }
}
