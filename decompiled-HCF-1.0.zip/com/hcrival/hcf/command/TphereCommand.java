package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;

public class TphereCommand implements CommandExecutor
{
    public boolean isDouble(final String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!cmd.getName().equalsIgnoreCase("tphere")) {
            return false;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (!sender.hasPermission("hcf.command.teleport") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage("�c/tphere <player>");
            return true;
        }
        final Player p = (Player)sender;
        final Player t = Bukkit.getPlayer(args[0]);
        if (t == null) {
            sender.sendMessage(ChatColor.RED + "That player is currently offline");
            return true;
        }
        t.teleport((Entity)p);
        p.sendMessage("�eYou have teleported �c" + t.getName() + " �eto your location.");
        t.sendMessage("�eYou have been teleported to �c" + p.getName() + "�e.");
        return true;
    }
}
