package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;

public class GamemodeCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (cmd.getName().equalsIgnoreCase("gamemode")) {
            if (!sender.hasPermission("hcf.command.gamemode") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length != 0) {
                if (args[0].equalsIgnoreCase("survival") || args[0].equalsIgnoreCase("s") || args[0].equalsIgnoreCase("0")) {
                    if (args.length == 1) {
                        if (!(sender instanceof Player)) {
                            sender.sendMessage(ChatColor.RED + "No permission.");
                            return true;
                        }
                        final Player p = (Player)sender;
                        p.setGameMode(GameMode.SURVIVAL);
                        sender.sendMessage("�eYou have set your gamemode to �cSurvival�e.");
                        return true;
                    }
                    else if (args.length == 2) {
                        final Player t = Bukkit.getPlayer(args[1]);
                        if (t == null) {
                            sender.sendMessage(ChatColor.RED + "That player is currently offline");
                            return true;
                        }
                        t.setGameMode(GameMode.SURVIVAL);
                        sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cSurvival�e.");
                        return true;
                    }
                }
                if (args[0].equalsIgnoreCase("creative") || args[0].equalsIgnoreCase("c") || args[0].equalsIgnoreCase("1")) {
                    if (args.length == 1) {
                        if (!(sender instanceof Player)) {
                            sender.sendMessage(ChatColor.RED + "No permission.");
                            return true;
                        }
                        final Player p = (Player)sender;
                        p.setGameMode(GameMode.CREATIVE);
                        sender.sendMessage("�eYou have set your gamemode to �cCreative�e.");
                        return true;
                    }
                    else if (args.length == 2) {
                        final Player t = Bukkit.getPlayer(args[1]);
                        if (t == null) {
                            sender.sendMessage(ChatColor.RED + "That player is currently offline");
                            return true;
                        }
                        t.setGameMode(GameMode.CREATIVE);
                        sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cCreative�e.");
                        return true;
                    }
                }
                if (args[0].equalsIgnoreCase("adventure") || args[0].equalsIgnoreCase("a") || args[0].equalsIgnoreCase("2")) {
                    if (args.length == 1) {
                        if (!(sender instanceof Player)) {
                            sender.sendMessage(ChatColor.RED + "No permission.");
                            return true;
                        }
                        final Player p = (Player)sender;
                        p.setGameMode(GameMode.ADVENTURE);
                        sender.sendMessage("�eYou have set your gamemode to �cAdventure�e.");
                        return true;
                    }
                    else if (args.length == 2) {
                        final Player t = Bukkit.getPlayer(args[1]);
                        if (t == null) {
                            sender.sendMessage(ChatColor.RED + "That player is currently offline");
                            return true;
                        }
                        t.setGameMode(GameMode.ADVENTURE);
                        sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cAdventure�e.");
                        return true;
                    }
                }
            }
            sender.sendMessage("�c/gamemode <mode> <player>");
        }
        if (cmd.getName().equalsIgnoreCase("gamemodes")) {
            if (!sender.hasPermission("hcf.command.gamemode") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length == 0) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ChatColor.RED + "No permission.");
                    return true;
                }
                final Player p = (Player)sender;
                p.setGameMode(GameMode.SURVIVAL);
                sender.sendMessage(Color.translate("&eChanged your gamemode to &aSurvival"));
                return true;
            }
            else if (args.length == 1) {
                final Player t = Bukkit.getPlayer(args[0]);
                if (t == null) {
                    sender.sendMessage(ChatColor.RED + "That player is currently offline");
                    return true;
                }
                t.setGameMode(GameMode.SURVIVAL);
                sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cSurvival�e.");
                return true;
            }
            else {
                sender.sendMessage("�c/gms <player>");
            }
        }
        if (cmd.getName().equalsIgnoreCase("gamemodec")) {
            if (!sender.hasPermission("hcf.command.gamemode") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length == 0) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ChatColor.RED + "No permission.");
                    return true;
                }
                final Player p = (Player)sender;
                p.setGameMode(GameMode.CREATIVE);
                sender.sendMessage(Color.translate("&eChanged your gamemode to &aCreative"));
                return true;
            }
            else if (args.length == 1) {
                final Player t = Bukkit.getPlayer(args[0]);
                if (t == null) {
                    sender.sendMessage(ChatColor.RED + "That player is currently offline");
                    return true;
                }
                t.setGameMode(GameMode.CREATIVE);
                sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cCreative�e.");
                return true;
            }
            else {
                sender.sendMessage("�c/gmc <player>");
            }
        }
        if (cmd.getName().equalsIgnoreCase("gamemodea")) {
            if (!sender.hasPermission("hcf.command.gamemode") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length == 0) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ChatColor.RED + "No permission.");
                    return true;
                }
                final Player p = (Player)sender;
                p.setGameMode(GameMode.ADVENTURE);
                sender.sendMessage(Color.translate("&eChanged your gamemode to &aAdventure."));
                return true;
            }
            else if (args.length == 1) {
                final Player t = Bukkit.getPlayer(args[0]);
                if (t == null) {
                    sender.sendMessage(ChatColor.RED + "That player is currently offline");
                    return true;
                }
                t.setGameMode(GameMode.ADVENTURE);
                sender.sendMessage("�eYou have set the gamemode of �c" + t.getName() + " �eto �cAdventure�e.");
                return true;
            }
            else {
                sender.sendMessage("�c/gma <player>");
            }
        }
        return true;
    }
}
