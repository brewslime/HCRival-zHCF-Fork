package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.struct.*;
import java.util.*;

public class RegenCommand implements CommandExecutor, TabCompleter
{
    private final HCF plugin;
    
    public RegenCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final RegenStatus regenStatus = playerFaction.getRegenStatus();
        switch (regenStatus) {
            case FULL: {
                sender.sendMessage(ChatColor.RED + "Your faction currently has full DTR.");
                return true;
            }
            case PAUSED: {
                sender.sendMessage(ChatColor.BLUE + "Your faction is currently on DTR freeze for another " + ChatColor.WHITE + DurationFormatUtils.formatDurationWords(playerFaction.getRemainingRegenerationTime(), true, true) + ChatColor.BLUE + '.');
                return true;
            }
            case REGENERATING: {
                sender.sendMessage(ChatColor.BLUE + "Your faction currently has " + ChatColor.YELLOW + regenStatus.getSymbol() + ' ' + playerFaction.getDeathsUntilRaidable() + ChatColor.BLUE + " DTR and is regenerating");
                return true;
            }
            default: {
                sender.sendMessage(ChatColor.RED + "Unrecognised regen status, please inform an Administrator.");
                return true;
            }
        }
    }
    
    public long getRemainingRegenMillis(final PlayerFaction faction) {
        final long millisPassedSinceLastUpdate = System.currentTimeMillis() - faction.getLastDtrUpdateTimestamp();
        final double dtrRequired = faction.getMaximumDeathsUntilRaidable() - faction.getDeathsUntilRaidable();
        return (long)(20.0 * dtrRequired) - millisPassedSinceLastUpdate;
    }
    
    public List<String> onTabComplete(final CommandSender commandSender, final Command command, final String s, final String[] strings) {
        return Collections.emptyList();
    }
}
