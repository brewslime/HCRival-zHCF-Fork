package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;

public class FeedCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            player.setFoodLevel(20);
            player.setSaturation(20.0f);
            player.sendMessage(Color.translate("&6You have fed yourself!"));
        }
        else {
            sender.sendMessage("You can't use this command as console!");
        }
        return true;
    }
}
