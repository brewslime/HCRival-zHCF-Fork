package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.*;
import org.bukkit.inventory.*;

public class InvRestoreCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player p = (Player)sender;
            if (!p.hasPermission("hcf.command.invrestore")) {
                p.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length != 1) {
                p.sendMessage(ChatColor.RED + "Usage: /invrestore <player>");
                return true;
            }
            final Player target = Bukkit.getServer().getPlayer(args[0]);
            if (target == null) {
                p.sendMessage(ChatColor.RED + "Usage: /invrestore <player>");
                return true;
            }
            if (HCF.getPlugin().getInventoryRestore().containsKey(target.getUniqueId())) {
                final PlayerInventory inventory = (PlayerInventory)HCF.getPlugin().getInventoryRestore().get(target.getUniqueId());
                target.getInventory().setContents(inventory.getContents());
                target.getInventory().setArmorContents(inventory.getArmorContents());
            }
            else {
                p.sendMessage(ChatColor.RED + "No inventories saved.");
            }
        }
        else {
            sender.sendMessage("Players only");
        }
        return true;
    }
}
