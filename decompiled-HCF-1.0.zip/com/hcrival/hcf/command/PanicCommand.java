package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;
import java.util.*;

public class PanicCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] args) {
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            HCF.getPlugin().getFreezeListener().setFreeze((CommandSender)player, player, true);
            for (final Player online : HCF.getPlugin().getServer().getOnlinePlayers()) {
                if (online.hasPermission("hcf.command.panic.notify")) {
                    online.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.panic").replace("%player%", commandSender.getName())));
                }
            }
        }
        else {
            commandSender.sendMessage("You can't use this as console!");
        }
        return true;
    }
}
