package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;

public class SaveDataCommand implements CommandExecutor
{
    private final HCF plugin;
    
    public SaveDataCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command comamnd, final String label, final String[] args) {
        if (!sender.hasPermission("hcf.command.savedata")) {
            return false;
        }
        try {
            this.saveData();
            sender.sendMessage(ChatColor.GREEN + "All data has been saved successfully");
        }
        catch (Exception exception) {
            exception.printStackTrace();
            sender.sendMessage(ChatColor.RED + "Error occured while trying to save data.");
        }
        return false;
    }
    
    private void saveData() {
        this.plugin.getEconomyManager().saveEconomyData();
        this.plugin.getFactionManager().saveFactionData();
        this.plugin.getKeyManager().saveKeyData();
        this.plugin.getTimerManager().saveTimerData();
        this.plugin.getUserManager().saveUserData();
    }
}
