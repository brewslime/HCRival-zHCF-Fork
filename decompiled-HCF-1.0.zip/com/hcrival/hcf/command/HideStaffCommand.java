package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.listener.*;
import org.bukkit.*;
import java.util.*;

public class HideStaffCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender player, final Command cmd, final String label, final String[] args) {
        final Player sender = (Player)player;
        HideStaffListener.getStaff();
        if (!(player instanceof Player)) {
            player.sendMessage(ChatColor.RED + "You must be a player to use this commad.");
        }
        else if (!player.hasPermission("hcf.command.hidestaff")) {
            player.sendMessage(ChatColor.RED + "No permission.");
        }
        else if (HideStaffListener.showStaffEnabled(sender)) {
            HideStaffListener.showStaff.put(sender, false);
            for (final Player staff : HideStaffListener.staff) {
                sender.hidePlayer(staff);
            }
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6All staff users have been hidden to you."));
        }
        else {
            HideStaffListener.showStaff.put(sender, true);
            for (final Player staff : HideStaffListener.staff) {
                sender.showPlayer(staff);
            }
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6All staff users have been shown to you."));
        }
        return true;
    }
}
