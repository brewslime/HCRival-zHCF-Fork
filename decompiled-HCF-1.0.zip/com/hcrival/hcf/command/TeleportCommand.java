package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;

public class TeleportCommand implements CommandExecutor
{
    public boolean isDouble(final String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!cmd.getName().equalsIgnoreCase("teleport")) {
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (!sender.hasPermission("hcf.command.teleport") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length == 1) {
            final Player p = (Player)sender;
            final Player t = Bukkit.getPlayer(args[0]);
            if (t == null) {
                sender.sendMessage(ChatColor.RED + "That player is currently offline");
                return true;
            }
            p.teleport((Entity)t);
            sender.sendMessage("�eYou have been teleported to �c" + t.getName() + "�e.");
            return true;
        }
        else {
            if (args.length != 2) {
                sender.sendMessage("�c/teleport <player> <player>");
                return true;
            }
            if (!sender.hasPermission("hcf.command.teleport.others") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            final Player p = Bukkit.getPlayer(args[0]);
            final Player t = Bukkit.getPlayer(args[1]);
            if (p == null) {
                sender.sendMessage("�cPlayer " + args[0] + " offline.");
                return true;
            }
            if (t == null) {
                sender.sendMessage("�cPlayer " + args[1] + " offline.");
                return true;
            }
            p.teleport((Entity)t);
            sender.sendMessage("�eYou have teleported �c" + p.getName() + " �eto �c" + t.getName() + "�e.");
            return true;
        }
    }
}
