package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;

public class FreezeCommand implements CommandExecutor, TabCompleter
{
    private final HCF staffMode;
    
    public FreezeCommand() {
        this.staffMode = HCF.getPlugin();
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length == 0 || args.length > 1) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&cUsage: /" + label + " <playerName>"));
        }
        else {
            final Player target = Bukkit.getServer().getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&cPlayer named '" + args[0] + "' not found."));
            }
            else if (target.equals(sender)) {
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&cYou can not freeze yourself."));
            }
            else if (sender instanceof Player) {
                if (target.hasPermission("hcf.command.freeze") || target.isOp()) {
                    if (this.staffMode.getFreezeListener().isFrozen(target)) {
                        this.staffMode.getFreezeListener().setFreeze(sender, target, false);
                    }
                    else {
                        Bukkit.dispatchCommand(sender, "msg " + args[0] + " Join teamspeak, you have 3 minutes. Admit for a shorter ban.");
                        this.staffMode.getFreezeListener().setFreeze(sender, target, true);
                    }
                }
                else if (this.staffMode.getFreezeListener().isFrozen(target)) {
                    this.staffMode.getFreezeListener().setFreeze(sender, target, false);
                }
                else {
                    Bukkit.dispatchCommand(sender, "msg " + args[0] + " Join teamspeak, you have 3 minutes. Admit for a shorter ban.");
                    this.staffMode.getFreezeListener().setFreeze(sender, target, true);
                }
            }
            else if (this.staffMode.getFreezeListener().isFrozen(target)) {
                this.staffMode.getFreezeListener().setFreeze(sender, target, false);
            }
            else {
                Bukkit.dispatchCommand(sender, "msg " + args[0] + " Join teamspeak, you have 3 minutes. Admit for a shorter ban.");
                this.staffMode.getFreezeListener().setFreeze(sender, target, true);
            }
        }
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length > 1) {
            return Collections.emptyList();
        }
        return null;
    }
}
