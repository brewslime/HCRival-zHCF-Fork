package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class TpposCommand implements CommandExecutor
{
    public boolean isDouble(final String s) {
        try {
            Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!cmd.getName().equalsIgnoreCase("tppos")) {
            return false;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (!sender.hasPermission("hcf.command.teleport") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        final Player p = (Player)sender;
        if (args.length < 3 || args.length > 3) {
            sender.sendMessage("�c/tppos [x] [y] [z]");
            return true;
        }
        if (!this.isDouble(args[0]) || !this.isDouble(args[1]) || !this.isDouble(args[2])) {
            sender.sendMessage("�c/tppos [x] [y] [z]");
            return true;
        }
        final double x = Double.parseDouble(args[0]) + 0.5;
        final double y = Double.parseDouble(args[1]) + 0.5;
        final double z = Double.parseDouble(args[2]) + 0.5;
        final Location loc = new Location(p.getWorld(), x, y, z, p.getLocation().getYaw(), p.getLocation().getPitch());
        p.teleport(loc);
        p.sendMessage("�eYou have been teleported to the coordinates �c" + x + "�e, �c" + y + "�e, �c" + z + "�e.");
        return true;
    }
}
