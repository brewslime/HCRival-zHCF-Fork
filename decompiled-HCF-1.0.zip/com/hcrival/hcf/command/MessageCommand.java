package com.hcrival.hcf.command;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.util.*;
import org.apache.commons.lang.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import org.bukkit.event.*;
import com.hcrival.hcf.user.*;
import java.util.*;

public class MessageCommand implements CommandExecutor
{
    public MessageCommand(final HCF plugin) {
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable for players.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "/message <player> <text>");
            return true;
        }
        final Player player = (Player)sender;
        final Player target = BukkitUtils.playerWithNameOrUUID(args[0]);
        if (target == null || !player.canSee(target)) {
            sender.sendMessage("Player not found");
            return true;
        }
        final FactionUser user = HCF.getPlugin().getUserManager().getUser(target.getUniqueId());
        if (!user.isMessagesVisible() && !player.hasPermission("hcf.command.staffmode")) {
            sender.sendMessage(ChatColor.RED + "You cannot private message that player as it has messages toggled.");
            return true;
        }
        final String message = StringUtils.join((Object[])args, ' ', 1, args.length);
        final Set<Player> recipients = Collections.singleton(target);
        final MessageEvent playerMessageEvent = new MessageEvent(player, recipients, message, false);
        Bukkit.getPluginManager().callEvent((Event)playerMessageEvent);
        if (!playerMessageEvent.isCancelled()) {
            playerMessageEvent.send();
        }
        return true;
    }
}
