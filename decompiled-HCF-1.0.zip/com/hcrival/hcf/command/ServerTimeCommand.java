package com.hcrival.hcf.command;

import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import java.util.*;

public class ServerTimeCommand implements CommandExecutor, TabCompleter
{
    private final FastDateFormat format;
    
    public ServerTimeCommand(final HCF plugin) {
        this.format = FastDateFormat.getInstance("E MMM dd h:mm:ssa z yyyy", TimeZone.getTimeZone(plugin.getConfig().getString("settings.timezone")), Locale.ENGLISH);
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        sender.sendMessage(ChatColor.GREEN + "The server time is " + ChatColor.LIGHT_PURPLE + this.format.format(System.currentTimeMillis()) + ChatColor.GREEN + '.');
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
