package com.hcrival.hcf.command;

import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.command.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import com.google.common.collect.*;

public class CobbleCommand implements Listener, CommandExecutor
{
    public static Set<Player> disabled;
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can execute this command.");
            return true;
        }
        final Player player = (Player)sender;
        if (CobbleCommand.disabled.contains(player)) {
            CobbleCommand.disabled.remove(player);
            player.sendMessage(ChatColor.GREEN + "You will now pickup cobblestone.");
        }
        else {
            CobbleCommand.disabled.add(player);
            player.sendMessage(ChatColor.RED + "You will not pickup cobblestone anymore.");
        }
        return true;
    }
    
    @EventHandler
    public void onPlayerPickup(final PlayerQuitEvent event) {
        CobbleCommand.disabled.remove(event.getPlayer());
    }
    
    @EventHandler
    public void onPlayerPickup(final PlayerPickupItemEvent event) {
        final Material type = event.getItem().getItemStack().getType();
        if ((type == Material.STONE || type == Material.COBBLESTONE) && CobbleCommand.disabled.contains(event.getPlayer())) {
            event.setCancelled(true);
        }
    }
    
    static {
        CobbleCommand.disabled = (Set<Player>)Sets.newHashSet();
    }
}
