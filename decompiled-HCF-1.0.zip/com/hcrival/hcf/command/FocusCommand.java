package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import java.util.*;
import net.frozenorb.qlib.nametag.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.faction.type.*;

public class FocusCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            final PlayerFaction faction = HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId());
            if (faction == null) {
                player.sendMessage(ChatColor.RED + "You are not in a faction.");
                return true;
            }
            if (args.length < 1) {
                player.sendMessage(ChatColor.RED + "Usage: /focus <player>");
                return true;
            }
            final Player target = Bukkit.getServer().getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "That player was not found.");
                return true;
            }
            if (faction.getFocused() != null && faction.getFocused().equals(target.getUniqueId())) {
                faction.setFocused(null);
                FrozenNametagHandler.reloadPlayer(target);
                faction.getOnlinePlayers().forEach(factionMember -> factionMember.sendMessage(Color.translate("&d" + target.getName() + "&e has been unfocused by &d" + player.getName() + "&e.")));
                return true;
            }
            final PlayerFaction targetFaction = HCF.getPlugin().getFactionManager().getPlayerFaction(target.getUniqueId());
            if (targetFaction != null && targetFaction.getName().equalsIgnoreCase(faction.getName())) {
                player.sendMessage(ChatColor.RED + "You cannot focus a faction member.");
                return true;
            }
            faction.setFocused(target.getUniqueId());
            FrozenNametagHandler.reloadPlayer(target);
            faction.getOnlinePlayers().forEach(factionMember -> factionMember.sendMessage(Color.translate("&d" + target.getName() + "&e has been focused by &d" + player.getName() + "&e.")));
        }
        return true;
    }
}
