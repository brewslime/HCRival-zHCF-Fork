package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.*;

public class InvseeCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can be used only by players.");
            return true;
        }
        final Player p = (Player)sender;
        if (!p.hasPermission("hcf.command.invsee") && !p.hasPermission("hcf.command.*") && !p.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length == 0 || args.length > 1) {
            p.sendMessage(ChatColor.RED + "Usage: /invsee [player]");
            return true;
        }
        final Player t = Bukkit.getPlayer(args[0]);
        if (t == null) {
            p.sendMessage(ChatColor.RED + "Player not found.");
            return true;
        }
        p.openInventory((Inventory)t.getInventory());
        return true;
    }
}
