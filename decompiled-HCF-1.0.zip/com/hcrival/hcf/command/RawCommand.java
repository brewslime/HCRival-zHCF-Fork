package com.hcrival.hcf.command;

import org.bukkit.command.*;
import org.bukkit.*;

public class RawCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!sender.hasPermission("hcf.command.broadcast") && !sender.hasPermission("hcf.command.*") && !sender.hasPermission("*")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("�cUsage: /broadcast <msg>");
            return true;
        }
        final StringBuilder str = new StringBuilder();
        for (int i = 0; i < args.length; ++i) {
            str.append(args[i] + " ");
        }
        final String msg = str.toString();
        Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', msg.toString()));
        return true;
    }
}
