package com.hcrival.hcf.visualise;

import org.bukkit.*;
import java.beans.*;

public class VisualBlock
{
    private final VisualType visualType;
    private final VisualBlockData blockData;
    private final Location location;
    
    public VisualType getVisualType() {
        return this.visualType;
    }
    
    public VisualBlockData getBlockData() {
        return this.blockData;
    }
    
    public Location getLocation() {
        return this.location;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof VisualBlock)) {
            return false;
        }
        final VisualBlock other = (VisualBlock)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$visualType = this.getVisualType();
        final Object other$visualType = other.getVisualType();
        Label_0065: {
            if (this$visualType == null) {
                if (other$visualType == null) {
                    break Label_0065;
                }
            }
            else if (this$visualType.equals(other$visualType)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$blockData = this.getBlockData();
        final Object other$blockData = other.getBlockData();
        Label_0102: {
            if (this$blockData == null) {
                if (other$blockData == null) {
                    break Label_0102;
                }
            }
            else if (this$blockData.equals(other$blockData)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$location = this.getLocation();
        final Object other$location = other.getLocation();
        if (this$location == null) {
            if (other$location == null) {
                return true;
            }
        }
        else if (this$location.equals(other$location)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof VisualBlock;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $visualType = this.getVisualType();
        result = result * 59 + (($visualType == null) ? 43 : $visualType.hashCode());
        final Object $blockData = this.getBlockData();
        result = result * 59 + (($blockData == null) ? 43 : $blockData.hashCode());
        final Object $location = this.getLocation();
        result = result * 59 + (($location == null) ? 43 : $location.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "VisualBlock(visualType=" + this.getVisualType() + ", blockData=" + this.getBlockData() + ", location=" + this.getLocation() + ")";
    }
    
    @ConstructorProperties({ "visualType", "blockData", "location" })
    public VisualBlock(final VisualType visualType, final VisualBlockData blockData, final Location location) {
        this.visualType = visualType;
        this.blockData = blockData;
        this.location = location;
    }
}
