package com.hcrival.hcf.visualise;

import org.bukkit.entity.*;
import org.bukkit.material.*;
import org.bukkit.*;
import com.google.common.collect.*;
import java.util.*;
import org.bukkit.craftbukkit.v1_7_R4.*;
import java.io.*;
import org.spigotmc.*;
import com.google.common.base.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;
import net.minecraft.server.v1_7_R4.*;

public class VisualiseUtil
{
    public static void handleBlockChanges(final Player player, final Map<Location, MaterialData> input) throws IOException {
        if (input.isEmpty()) {
            return;
        }
        if (input.size() == 1) {
            final Map.Entry<Location, MaterialData> entry = input.entrySet().iterator().next();
            final MaterialData materialData = entry.getValue();
            player.sendBlockChange((Location)entry.getKey(), materialData.getItemType(), materialData.getData());
            return;
        }
        final Table<Chunk, Location, MaterialData> table = (Table<Chunk, Location, MaterialData>)HashBasedTable.create();
        for (final Map.Entry<Location, MaterialData> entry2 : input.entrySet()) {
            final Location location = entry2.getKey();
            if (location.getWorld().isChunkLoaded((int)location.getX() >> 4, (int)location.getZ() >> 4)) {
                table.row(entry2.getKey().getChunk()).put(location, entry2.getValue());
            }
        }
        for (final Map.Entry<Chunk, Map<Location, MaterialData>> entry3 : table.rowMap().entrySet()) {
            sendBulk(player, entry3.getKey(), entry3.getValue());
        }
    }
    
    private static void sendBulk(final Player player, final Chunk chunk, final Map<Location, MaterialData> input) throws IOException {
        Objects.requireNonNull(chunk, "Chunk cannot be null");
        final PacketPlayOutMultiBlockChange packet = new PacketPlayOutMultiBlockChange();
        packet.chunk = ((CraftChunk)chunk).getHandle();
        final ChunkCoordIntPair intPair = new ChunkCoordIntPair(chunk.getX(), chunk.getZ());
        final int numberOfRecords = input.size();
        packet.b = intPair;
        packet.d = numberOfRecords;
        final ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(input.size());
        final DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);
        packet.ashort = new short[input.size()];
        packet.blocks = new int[input.size()];
        int i = 0;
        for (final Map.Entry<Location, MaterialData> entry : input.entrySet()) {
            final Location location = entry.getKey();
            final int blockID = entry.getValue().getItemTypeId();
            int data = entry.getValue().getData();
            data = SpigotDebreakifier.getCorrectedData(blockID, data);
            packet.blocks[i] = ((blockID & 0xFFF) << 4 | (data & 0xF));
            dataoutputstream.writeShort(packet.ashort[i] = (short)((location.getBlockX() & 0xF) << 12 | (location.getBlockZ() & 0xF) << 8 | location.getBlockY()));
            dataoutputstream.writeShort(packet.blocks[i]);
            ++i;
        }
        final int expectedSize = input.size() * 4;
        final byte[] bulk = bytearrayoutputstream.toByteArray();
        Preconditions.checkArgument(bulk.length == expectedSize, (Object)("Expected length: '" + expectedSize + "' doesn't match the generated length: '" + bulk.length + "'"));
        packet.c = bulk;
        ((CraftPlayer)player).getHandle().playerConnection.sendPacket((Packet)packet);
    }
}
