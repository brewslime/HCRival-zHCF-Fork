package com.hcrival.hcf.visualise;

import com.hcrival.hcf.*;
import org.bukkit.scheduler.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import java.util.function.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.util.*;
import com.hcrival.util.cuboid.*;
import org.bukkit.command.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.timer.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class WallBorderListener implements Listener
{
    private static final int BORDER_PURPOSE_INFORM_THRESHOLD = 66;
    private static final int WALL_BORDER_HEIGHT_BELOW_DIFF = 3;
    private static final int WALL_BORDER_HEIGHT_ABOVE_DIFF = 4;
    private static final int WALL_BORDER_HORIZONTAL_DISTANCE = 7;
    private final HCF plugin;
    
    public WallBorderListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerJoin(final PlayerJoinEvent event) {
        event.setJoinMessage((String)null);
        final Player player = event.getPlayer();
        final Location now = player.getLocation().clone();
        new BukkitRunnable() {
            public void run() {
                final Location location = player.getLocation();
                if (now.equals((Object)location)) {
                    WallBorderListener.this.handlePositionChanged(player, location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
                }
            }
        }.runTaskLater((Plugin)this.plugin, 4L);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerMove(final PlayerMoveEvent event) {
        final Location to = event.getTo();
        final int toX = to.getBlockX();
        final int toY = to.getBlockY();
        final int toZ = to.getBlockZ();
        final Location from = event.getFrom();
        if (from.getBlockX() != toX || from.getBlockY() != toY || from.getBlockZ() != toZ) {
            this.handlePositionChanged(event.getPlayer(), to.getWorld(), toX, toY, toZ);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerTeleport(final PlayerTeleportEvent event) {
        this.onPlayerMove((PlayerMoveEvent)event);
    }
    
    private void handlePositionChanged(final Player player, final World toWorld, final int toX, final int toY, final int toZ) {
        final boolean flag;
        VisualType visualType;
        Timer relevantTimer;
        if (flag = (this.plugin.getTimerManager().getCombatTimer().getRemaining(player) > 0L)) {
            visualType = VisualType.SPAWN_BORDER;
            relevantTimer = this.plugin.getTimerManager().getCombatTimer();
        }
        else {
            if (this.plugin.getTimerManager().getInvincibilityTimer().getRemaining(player) <= 0L) {
                return;
            }
            visualType = VisualType.CLAIM_BORDER;
            relevantTimer = this.plugin.getTimerManager().getInvincibilityTimer();
        }
        this.plugin.getVisualiseHandler().clearVisualBlocks(player, visualType, new Predicate<VisualBlock>() {
            @Override
            public boolean test(final VisualBlock visualBlock) {
                final Location other = visualBlock.getLocation();
                return other.getWorld().equals(toWorld) && (Math.abs(toX - other.getBlockX()) > 7 || Math.abs(toY - other.getBlockY()) > 4 || Math.abs(toZ - other.getBlockZ()) > 7);
            }
        });
        final int minHeight = toY - 3;
        final int maxHeight = toY + 4;
        final int minX = toX - 7;
        final int maxX = toX + 7;
        final int minZ = toZ - 7;
        final int maxZ = toZ + 7;
        final Collection<Claim> added = new HashSet<Claim>();
        for (int x = minX; x < maxX; ++x) {
            for (int z = minZ; z < maxZ; ++z) {
                final Faction faction = this.plugin.getFactionManager().getFactionAt(toWorld, x, z);
                if (faction instanceof ClaimableFaction) {
                    if (flag) {
                        if (!faction.isSafezone()) {
                            continue;
                        }
                    }
                    else {
                        if (faction instanceof RoadFaction) {
                            continue;
                        }
                        if (faction.isSafezone()) {
                            continue;
                        }
                    }
                    final Collection<Claim> claims = ((ClaimableFaction)faction).getClaims();
                    for (final Claim claim : claims) {
                        if (toWorld.equals(claim.getWorld())) {
                            added.add(claim);
                        }
                    }
                }
            }
        }
        if (!added.isEmpty()) {
            int generated = 0;
            final Iterator<Claim> iterator = added.iterator();
            while (iterator.hasNext()) {
                final Claim claim2 = iterator.next();
                final Collection<Vector> edges = claim2.edges();
                for (final Vector edge : edges) {
                    if (Math.abs(edge.getBlockX() - toX) > 7) {
                        continue;
                    }
                    if (Math.abs(edge.getBlockZ() - toZ) > 7) {
                        continue;
                    }
                    final Location location = edge.toLocation(toWorld);
                    if (location == null) {
                        continue;
                    }
                    final Location first = location.clone();
                    first.setY((double)minHeight);
                    final Location second = location.clone();
                    second.setY((double)maxHeight);
                    generated += this.plugin.getVisualiseHandler().generate(player, new Cuboid(first, second), visualType, false).size();
                }
                if (generated >= 66) {
                    player.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.wall_prevent_timer").replace("%faction%", claim2.getFaction().getDisplayName((CommandSender)player)).replace("%timer%", relevantTimer.getDisplayName())));
                }
                iterator.remove();
            }
        }
    }
}
