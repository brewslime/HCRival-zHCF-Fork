package com.hcrival.hcf.visualise;

import org.bukkit.entity.*;
import com.google.common.base.*;
import com.google.common.collect.*;
import com.hcrival.util.cuboid.*;
import org.bukkit.material.*;
import java.io.*;
import org.bukkit.block.*;
import org.bukkit.*;
import org.spigotmc.*;
import java.util.*;
import javax.annotation.*;

public class VisualiseHandler
{
    private final Table<UUID, Location, VisualBlock> storedVisualises;
    
    public VisualiseHandler() {
        this.storedVisualises = (Table<UUID, Location, VisualBlock>)HashBasedTable.create();
    }
    
    public VisualBlock getVisualBlockAt(final Player player, final Location location) throws NullPointerException {
        Objects.requireNonNull(player, "Player cannot be null");
        Objects.requireNonNull(location, "Location cannot be null");
        return this.storedVisualises.get(player.getUniqueId(), location);
    }
    
    public Map<Location, VisualBlock> getVisualBlocks(final Player player) {
        return new HashMap<Location, VisualBlock>(this.storedVisualises.row(player.getUniqueId()));
    }
    
    public Map<Location, VisualBlock> getVisualBlocks(final Player player, final VisualType visualType) {
        return Maps.filterValues(this.getVisualBlocks(player), new Predicate<VisualBlock>() {
            @Override
            public boolean apply(final VisualBlock visualBlock) {
                return visualType == visualBlock.getVisualType();
            }
        });
    }
    
    public LinkedHashMap<Location, VisualBlockData> generate(final Player player, final Cuboid cuboid, final VisualType visualType, final boolean canOverwrite) {
        final Collection<Location> locations = new HashSet<Location>(cuboid.getSizeX() * cuboid.getSizeY() * cuboid.getSizeZ());
        final Iterator<Location> iterator = cuboid.locationIterator();
        while (iterator.hasNext()) {
            locations.add(iterator.next());
        }
        return this.generate(player, locations, visualType, canOverwrite);
    }
    
    public LinkedHashMap<Location, VisualBlockData> generate(final Player player, final Iterable<Location> locations, final VisualType visualType, final boolean canOverwrite) {
        final LinkedHashMap<Location, VisualBlockData> results = new LinkedHashMap<Location, VisualBlockData>();
        final ArrayList<VisualBlockData> filled = visualType.blockFiller().bulkGenerate(player, locations);
        if (filled != null) {
            int count = 0;
            final Map<Location, MaterialData> updatedBlocks = new HashMap<Location, MaterialData>();
            for (final Location location : locations) {
                if (!canOverwrite && this.storedVisualises.contains(player.getUniqueId(), location)) {
                    continue;
                }
                final Material previousType = location.getBlock().getType();
                if (previousType.isSolid()) {
                    continue;
                }
                if (previousType != Material.AIR) {
                    continue;
                }
                final VisualBlockData visualBlockData = filled.get(count++);
                results.put(location, visualBlockData);
                updatedBlocks.put(location, visualBlockData);
                this.storedVisualises.put(player.getUniqueId(), location, new VisualBlock(visualType, visualBlockData, location));
            }
            try {
                VisualiseUtil.handleBlockChanges(player, updatedBlocks);
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return results;
    }
    
    public void clearVisualBlock(final Player player, final Location location) {
        this.clearVisualBlock(player, location, true);
    }
    
    public void clearVisualBlock(final Player player, final Location location, final boolean sendRemovalPacket) {
        final VisualBlock visualBlock = this.storedVisualises.remove(player.getUniqueId(), location);
        if (sendRemovalPacket && visualBlock != null) {
            final Block block = location.getBlock();
            final VisualBlockData visualBlockData = visualBlock.getBlockData();
            if (visualBlockData.getBlockType() != block.getType() || visualBlockData.getData() != block.getData()) {
                player.sendBlockChange(location, block.getType(), block.getData());
            }
        }
    }
    
    public void clearVisualBlocks(final Chunk chunk) {
        AsyncCatcher.catchOp("Chunk operation");
        if (!this.storedVisualises.isEmpty()) {
            final Set<Location> keys = this.storedVisualises.columnKeySet();
            for (final Location location : new HashSet<Location>(keys)) {
                if (location.getWorld().equals(chunk.getWorld()) && chunk.getX() == (int)location.getX() >> 4 && chunk.getZ() == (int)location.getZ() >> 4) {
                    keys.remove(location);
                }
            }
        }
    }
    
    public void clearVisualBlocks(final Player player) {
        this.clearVisualBlocks(player, null, null);
    }
    
    public void clearVisualBlocks(final Player player, @Nullable final VisualType visualType, @Nullable final java.util.function.Predicate<VisualBlock> predicate) {
        this.clearVisualBlocks(player, visualType, predicate, true);
    }
    
    @Deprecated
    public void clearVisualBlocks(final Player player, @Nullable final VisualType visualType, @Nullable final java.util.function.Predicate<VisualBlock> predicate, final boolean sendRemovalPackets) {
        if (!this.storedVisualises.containsRow(player.getUniqueId())) {
            return;
        }
        final Map<Location, VisualBlock> results = new HashMap<Location, VisualBlock>(this.storedVisualises.row(player.getUniqueId()));
        final Map<Location, VisualBlock> removed = new HashMap<Location, VisualBlock>();
        for (final Map.Entry<Location, VisualBlock> entry : results.entrySet()) {
            final VisualBlock visualBlock = entry.getValue();
            if ((predicate == null || predicate.test(visualBlock)) && (visualType == null || visualBlock.getVisualType() == visualType)) {
                final Location location = entry.getKey();
                if (removed.put(location, visualBlock) != null) {
                    continue;
                }
                this.clearVisualBlock(player, location, sendRemovalPackets);
            }
        }
    }
}
