package com.hcrival.hcf.visualise;

import org.bukkit.entity.*;
import org.bukkit.*;
import com.google.common.collect.*;
import java.util.*;

abstract class BlockFiller
{
    abstract VisualBlockData generate(final Player p0, final Location p1);
    
    ArrayList<VisualBlockData> bulkGenerate(final Player player, final Iterable<Location> locations) {
        final ArrayList<VisualBlockData> data = new ArrayList<VisualBlockData>(Iterables.size(locations));
        for (final Location location : locations) {
            data.add(this.generate(player, location));
        }
        return data;
    }
}
