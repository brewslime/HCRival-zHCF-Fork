package com.hcrival.hcf.visualise;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import com.hcrival.hcf.util.*;
import com.comphenix.protocol.reflect.*;
import org.bukkit.entity.*;
import com.comphenix.protocol.events.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;
import org.bukkit.*;
import net.minecraft.server.v1_7_R4.*;
import com.comphenix.protocol.*;

public final class ProtocolLibHook
{
    private static final int STARTED_DIGGING = 0;
    private static final int FINISHED_DIGGING = 2;
    
    private ProtocolLibHook() {
    }
    
    public static void hook(final HCF hcf) {
        final ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();
        protocolManager.addPacketListener((PacketListener)new PacketAdapter(hcf, ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.BLOCK_PLACE }) {
            public void onPacketReceiving(final PacketEvent event) {
                final StructureModifier<Integer> modifier = (StructureModifier<Integer>)event.getPacket().getIntegers();
                final Player player = event.getPlayer();
                try {
                    final int face = (int)modifier.read(3);
                    if (face == 255) {
                        return;
                    }
                    final Location clickedBlock = new Location(player.getWorld(), (double)(int)modifier.read(0), (double)(int)modifier.read(1), (double)(int)modifier.read(2));
                    if (hcf.getVisualiseHandler().getVisualBlockAt(player, clickedBlock) != null) {
                        final Location placedLocation = clickedBlock.clone();
                        switch (face) {
                            case 2: {
                                placedLocation.add(0.0, 0.0, -1.0);
                                break;
                            }
                            case 3: {
                                placedLocation.add(0.0, 0.0, 1.0);
                                break;
                            }
                            case 4: {
                                placedLocation.add(-1.0, 0.0, 0.0);
                                break;
                            }
                            case 5: {
                                placedLocation.add(1.0, 0.0, 0.0);
                                break;
                            }
                            default: {
                                return;
                            }
                        }
                        if (hcf.getVisualiseHandler().getVisualBlockAt(player, placedLocation) == null) {
                            event.setCancelled(true);
                            player.sendBlockChange(placedLocation, Material.AIR, (byte)0);
                            NmsUtils.resendHeldItemPacket(player);
                        }
                    }
                }
                catch (FieldAccessException ex) {
                    ex.printStackTrace();
                }
            }
        });
        protocolManager.addPacketListener((PacketListener)new PacketAdapter(hcf, ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.BLOCK_DIG }) {
            public void onPacketReceiving(final PacketEvent event) {
                final StructureModifier<Integer> modifier = (StructureModifier<Integer>)event.getPacket().getIntegers();
                try {
                    final int status = (int)modifier.read(4);
                    if (status == 0 || status == 2) {
                        final Player player = event.getPlayer();
                        final int x = (int)modifier.read(0);
                        final int y = (int)modifier.read(1);
                        final int z = (int)modifier.read(2);
                        final Location location = new Location(player.getWorld(), (double)x, (double)y, (double)z);
                        final VisualBlock visualBlock = hcf.getVisualiseHandler().getVisualBlockAt(player, location);
                        if (visualBlock != null) {
                            event.setCancelled(true);
                            final VisualBlockData data = visualBlock.getBlockData();
                            if (status == 2) {
                                player.sendBlockChange(location, data.getBlockType(), data.getData());
                            }
                            else if (status == 0) {
                                final EntityPlayer entityPlayer = ((CraftPlayer)player).getHandle();
                                if (player.getGameMode() == GameMode.CREATIVE || entityPlayer.world.getType(x, y, z).getDamage((EntityHuman)entityPlayer, entityPlayer.world, x, y, z) >= 1.0f) {
                                    player.sendBlockChange(location, data.getBlockType(), data.getData());
                                }
                            }
                        }
                    }
                }
                catch (FieldAccessException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}
