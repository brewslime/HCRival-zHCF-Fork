package com.hcrival.hcf.economy;

import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.base.*;
import com.hcrival.util.*;
import org.bukkit.*;
import java.util.*;

public class EconomyCommand implements CommandExecutor
{
    private final HCF plugin;
    
    public EconomyCommand(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        OfflinePlayer target;
        if (args.length > 0 && sender.hasPermission(command.getPermission() + ".staff")) {
            target = BukkitUtils.offlinePlayerWithNameOrUUID(args[0]);
        }
        else {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + " <playerName>");
                return true;
            }
            target = (OfflinePlayer)sender;
        }
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(String.format(BaseConstants.PLAYER_WITH_NAME_OR_UUID_NOT_FOUND, args[0]));
            return true;
        }
        final UUID uuid = target.getUniqueId();
        final int balance = this.plugin.getEconomyManager().getBalance(uuid);
        if (args.length < 2) {
            sender.sendMessage(ChatColor.YELLOW + (sender.equals(target) ? "Your balance" : ("Balance of " + target.getName())) + " is " + ChatColor.AQUA + '$' + balance + ChatColor.YELLOW + '.');
            return true;
        }
        if (args[1].equalsIgnoreCase("give") || args[1].equalsIgnoreCase("add")) {
            if (args.length < 3) {
                if (!sender.hasPermission("hcf.command.eco.staff")) {
                    sender.sendMessage(ChatColor.RED + "No permission.");
                    return true;
                }
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + ' ' + target.getName() + ' ' + args[1] + " <amount>");
                return true;
            }
            else {
                if (!sender.hasPermission(command.getPermission() + ".staff")) {
                    return true;
                }
                final Integer amount = JavaUtils.tryParseInt(args[2]);
                if (amount == null) {
                    sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a valid number.");
                    return true;
                }
                final int newBalance = this.plugin.getEconomyManager().addBalance(uuid, amount);
                sender.sendMessage(new String[] { "" + ChatColor.YELLOW + "Added " + ChatColor.AQUA + '$' + JavaUtils.format(amount) + ChatColor.YELLOW + " to balance of " + target.getName() + '.', ChatColor.YELLOW + "Balance of " + ChatColor.AQUA + target.getName() + " is now " + ChatColor.AQUA + '$' + newBalance + ChatColor.YELLOW + '.' });
                return true;
            }
        }
        else if (args[1].equalsIgnoreCase("take") || args[1].equalsIgnoreCase("negate") || args[1].equalsIgnoreCase("minus") || args[1].equalsIgnoreCase("subtract")) {
            if (!sender.hasPermission("hcf.command.eco.staff")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + ' ' + target.getName() + ' ' + args[1] + " <amount>");
                return true;
            }
            final Integer amount = JavaUtils.tryParseInt(args[2]);
            if (amount == null) {
                sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a valid number.");
                return true;
            }
            final int newBalance = this.plugin.getEconomyManager().subtractBalance(uuid, amount);
            sender.sendMessage(new String[] { "" + ChatColor.YELLOW + "Taken " + ChatColor.AQUA + '$' + JavaUtils.format(amount) + ChatColor.YELLOW + " from balance of " + ChatColor.AQUA + target.getName() + ChatColor.YELLOW + '.', ChatColor.YELLOW + "Balance of " + ChatColor.AQUA + target.getName() + " is now " + ChatColor.AQUA + '$' + newBalance + ChatColor.YELLOW + '.' });
            return true;
        }
        else {
            if (!args[1].equalsIgnoreCase("set")) {
                sender.sendMessage(ChatColor.YELLOW + (sender.equals(target) ? "Your balance" : ("Balance of " + ChatColor.AQUA + target.getName())) + ChatColor.YELLOW + " is " + ChatColor.AQUA + '$' + balance + ChatColor.YELLOW + '.');
                return true;
            }
            if (!sender.hasPermission("hcf.command.eco.staff")) {
                sender.sendMessage(ChatColor.RED + "No permission.");
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Usage: /" + label + ' ' + target.getName() + ' ' + args[1] + " <amount>");
                return true;
            }
            final Integer amount = JavaUtils.tryParseInt(args[2]);
            if (amount == null) {
                sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a valid number.");
                return true;
            }
            final int newBalance = this.plugin.getEconomyManager().setBalance(uuid, amount);
            sender.sendMessage(ChatColor.YELLOW + "Set balance of " + target.getName() + " to " + '$' + JavaUtils.format(newBalance) + '.');
            return true;
        }
    }
}
