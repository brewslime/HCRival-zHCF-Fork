package com.hcrival.hcf.economy;

import java.util.regex.*;
import com.hcrival.hcf.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import com.hcrival.hcf.listener.*;
import com.hcrival.util.*;
import org.bukkit.inventory.*;
import com.hcrival.hcf.util.*;
import org.bukkit.block.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.event.*;

public class ShopSignListener implements Listener
{
    private static final long SIGN_TEXT_REVERT_TICKS = 100L;
    private static final Pattern ALPHANUMERIC_PATTERN;
    private final HCF plugin;
    
    public ShopSignListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.HIGH)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            final Block block = event.getClickedBlock();
            final BlockState state = block.getState();
            if (state instanceof Sign) {
                final Sign sign = (Sign)state;
                final String[] lines = sign.getLines();
                boolean parsed = true;
                Integer quantity = null;
                Integer price = null;
                try {
                    quantity = Integer.parseInt(lines[2]);
                    price = Integer.parseInt(ShopSignListener.ALPHANUMERIC_PATTERN.matcher(lines[3]).replaceAll(""));
                }
                catch (IllegalArgumentException ex) {
                    parsed = false;
                }
                if (parsed) {
                    ItemStack stack;
                    if (lines[1].equalsIgnoreCase("Crowbar")) {
                        stack = new Crowbar().getItemIfPresent();
                    }
                    else if ((stack = HCF.getPlugin().getItemDb().getItem(ShopSignListener.ALPHANUMERIC_PATTERN.matcher(lines[1]).replaceAll(""), quantity)) == null) {
                        return;
                    }
                    final Player player = event.getPlayer();
                    final String[] fakeLines = Arrays.copyOf(sign.getLines(), 4);
                    if (lines[0].contains("Sell") && lines[0].contains(ChatColor.RED.toString())) {
                        final int sellQuantity = Math.min(quantity, InventoryUtils.countAmount((Inventory)player.getInventory(), stack.getType(), stack.getDurability()));
                        if (sellQuantity <= 0) {
                            fakeLines[0] = ChatColor.RED + "Not carrying any";
                            fakeLines[2] = ChatColor.RED + "on you.";
                            fakeLines[3] = "";
                        }
                        else {
                            final int newPrice = (int)(price / (double)quantity * sellQuantity);
                            fakeLines[0] = ChatColor.GREEN + "Sold " + sellQuantity;
                            fakeLines[3] = ChatColor.GREEN + "for " + '$' + newPrice;
                            this.plugin.getEconomyManager().addBalance(player.getUniqueId(), newPrice);
                            InventoryUtils.removeItem((Inventory)player.getInventory(), stack.getType(), stack.getData().getData(), sellQuantity);
                            player.updateInventory();
                        }
                    }
                    else {
                        if (!lines[0].contains("Buy") || !lines[0].contains(ChatColor.GREEN.toString())) {
                            return;
                        }
                        if (price > this.plugin.getEconomyManager().getBalance(player.getUniqueId())) {
                            fakeLines[0] = ChatColor.RED + "Cannot afford";
                        }
                        else {
                            fakeLines[0] = ChatColor.GREEN + "Item bought";
                            fakeLines[3] = ChatColor.GREEN + "for " + '$' + price;
                            this.plugin.getEconomyManager().subtractBalance(player.getUniqueId(), price);
                            final World world = player.getWorld();
                            final Location location = player.getLocation();
                            final Map<Integer, ItemStack> excess = (Map<Integer, ItemStack>)player.getInventory().addItem(new ItemStack[] { stack });
                            for (final Map.Entry<Integer, ItemStack> excessItemStack : excess.entrySet()) {
                                world.dropItemNaturally(location, (ItemStack)excessItemStack.getValue());
                            }
                            NmsUtils.resendHeldItemPacket(player);
                            player.updateInventory();
                        }
                    }
                    event.setCancelled(true);
                    HCF.getPlugin().getSignHandler().showLines(player, sign, fakeLines, 100L, true);
                }
            }
        }
    }
    
    static {
        ALPHANUMERIC_PATTERN = Pattern.compile("[^A-Za-z0-9]");
    }
}
