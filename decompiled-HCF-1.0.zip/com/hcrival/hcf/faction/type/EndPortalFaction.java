package com.hcrival.hcf.faction.type;

import org.bukkit.configuration.serialization.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.command.*;
import org.bukkit.*;
import java.util.*;

public class EndPortalFaction extends ClaimableFaction implements ConfigurationSerializable
{
    public EndPortalFaction() {
        super("EndPortal");
        final World overworld = Bukkit.getWorld("world");
        final int maxHeight = 256;
        final int min = 480;
        final int max = 520;
        this.addClaim(new Claim(this, new Location(overworld, (double)min, 0.0, (double)min), new Location(overworld, (double)max, (double)maxHeight, (double)max)), null);
        this.addClaim(new Claim(this, new Location(overworld, (double)(-max), (double)maxHeight, (double)(-max)), new Location(overworld, (double)(-min), 0.0, (double)(-min))), null);
        this.addClaim(new Claim(this, new Location(overworld, (double)(-max), 0.0, (double)min), new Location(overworld, (double)(-min), (double)maxHeight, (double)max)), null);
        this.addClaim(new Claim(this, new Location(overworld, (double)min, 0.0, (double)(-max)), new Location(overworld, (double)max, (double)maxHeight, (double)(-min))), null);
        this.safezone = true;
    }
    
    public EndPortalFaction(final Map<String, Object> map) {
        super(map);
    }
    
    public boolean isDeathban() {
        return false;
    }
}
