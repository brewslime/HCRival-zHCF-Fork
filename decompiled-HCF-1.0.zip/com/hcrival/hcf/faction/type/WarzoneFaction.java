package com.hcrival.hcf.faction.type;

import java.util.*;
import org.bukkit.command.*;
import com.hcrival.hcf.*;
import org.bukkit.*;

public class WarzoneFaction extends Faction
{
    public WarzoneFaction() {
        super("Warzone");
    }
    
    public WarzoneFaction(final Map<String, Object> map) {
        super(map);
    }
    
    @Override
    public String getDisplayName(final CommandSender sender) {
        return ChatColor.valueOf(HCF.getPlugin().getConfig().getString("settings.colors.warzone")) + this.getName();
    }
}
