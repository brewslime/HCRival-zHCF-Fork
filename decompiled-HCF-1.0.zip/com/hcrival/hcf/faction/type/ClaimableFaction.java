package com.hcrival.hcf.faction.type;

import com.hcrival.hcf.faction.claim.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.google.common.collect.*;
import javax.annotation.*;
import java.util.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.event.cause.*;
import org.bukkit.event.*;
import com.hcrival.hcf.faction.event.*;
import com.hcrival.hcf.*;
import com.hcrival.util.cuboid.*;

public class ClaimableFaction extends Faction
{
    protected final List<Claim> claims;
    protected static final ImmutableMap<World.Environment, String> ENVIRONMENT_MAPPINGS;
    
    public ClaimableFaction(final String name) {
        super(name);
        this.claims = new ArrayList<Claim>();
    }
    
    public ClaimableFaction(final Map<String, Object> map) {
        super(map);
        (this.claims = new ArrayList<Claim>()).addAll(GenericUtils.createList(map.get("claims"), Claim.class));
    }
    
    @Override
    public Map<String, Object> serialize() {
        final Map<String, Object> map = super.serialize();
        map.put("claims", new ArrayList(this.claims));
        return map;
    }
    
    @Override
    public void printDetails(final CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(' ' + this.getDisplayName(sender));
        for (final Claim claim : this.claims) {
            final Location location = claim.getCenter();
            sender.sendMessage(ChatColor.YELLOW + "  Location: " + ChatColor.RED + '(' + ClaimableFaction.ENVIRONMENT_MAPPINGS.get(location.getWorld().getEnvironment()) + ", " + location.getBlockX() + " | " + location.getBlockZ() + ')');
        }
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
    }
    
    public List<Claim> getClaims() {
        return (List<Claim>)ImmutableList.copyOf((Collection<?>)this.claims);
    }
    
    public List<Claim> getClaims(final World world) {
        final List<Claim> ret = new ArrayList<Claim>();
        for (final Claim claim : this.claims) {
            if (world.equals(claim.getWorld())) {
                ret.add(claim);
            }
        }
        return (List<Claim>)ImmutableList.copyOf((Collection<?>)ret);
    }
    
    public boolean addClaim(final Claim claim, @Nullable final CommandSender sender) {
        return this.addClaims(Collections.singleton(claim), sender);
    }
    
    public boolean addClaims(final Collection<Claim> adding, @Nullable CommandSender sender) {
        if (sender == null) {
            sender = (CommandSender)Bukkit.getConsoleSender();
        }
        final FactionClaimChangeEvent event = new FactionClaimChangeEvent(sender, ClaimChangeCause.CLAIM, adding, this);
        Bukkit.getPluginManager().callEvent((Event)event);
        if (event.isCancelled() || !this.claims.addAll(adding)) {
            return false;
        }
        Bukkit.getPluginManager().callEvent((Event)new FactionClaimChangedEvent(sender, ClaimChangeCause.CLAIM, adding));
        return true;
    }
    
    public boolean removeClaim(final Claim claim, @Nullable final CommandSender sender) {
        return this.removeClaims(Collections.singleton(claim), sender);
    }
    
    public boolean removeClaims(final Collection<Claim> toRemove, @Nullable CommandSender sender) {
        if (sender == null) {
            sender = (CommandSender)Bukkit.getConsoleSender();
        }
        int expected = this.claims.size() - toRemove.size();
        final FactionClaimChangeEvent event = new FactionClaimChangeEvent(sender, ClaimChangeCause.UNCLAIM, new ArrayList<Claim>(toRemove), this);
        Bukkit.getPluginManager().callEvent((Event)event);
        if (event.isCancelled() || !this.claims.removeAll(toRemove)) {
            return false;
        }
        if (expected != this.claims.size()) {
            return false;
        }
        if (this instanceof PlayerFaction) {
            final PlayerFaction playerFaction = (PlayerFaction)this;
            final Location home = playerFaction.getHome();
            final HCF plugin = HCF.getPlugin();
            int refund = 0;
            for (final Claim claim : toRemove) {
                refund += plugin.getClaimHandler().calculatePrice(claim, expected, true);
                if (expected > 0) {
                    --expected;
                }
                if (home != null && claim.contains(home)) {
                    playerFaction.setHome(null);
                    playerFaction.broadcast(ChatColor.RED.toString() + ChatColor.BOLD + "Your factions' home was unset as its residing claim was removed.");
                    break;
                }
            }
            plugin.getEconomyManager().addBalance(playerFaction.getLeader().getUniqueId(), refund);
            playerFaction.broadcast(ChatColor.YELLOW + "Faction leader was refunded " + ChatColor.GREEN + '$' + refund + ChatColor.YELLOW + " due to a land unclaim.");
        }
        Bukkit.getPluginManager().callEvent((Event)new FactionClaimChangedEvent(sender, ClaimChangeCause.UNCLAIM, toRemove));
        return true;
    }
    
    static {
        ENVIRONMENT_MAPPINGS = ImmutableMap.of(World.Environment.NETHER, "Nether", World.Environment.NORMAL, "Overworld", World.Environment.THE_END, "The End");
    }
}
