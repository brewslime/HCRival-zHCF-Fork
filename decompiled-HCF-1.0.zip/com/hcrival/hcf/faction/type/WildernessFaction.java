package com.hcrival.hcf.faction.type;

import java.util.*;
import org.bukkit.command.*;
import com.hcrival.hcf.*;
import org.bukkit.*;

public class WildernessFaction extends Faction
{
    public WildernessFaction() {
        super("Wilderness");
    }
    
    public WildernessFaction(final Map<String, Object> map) {
        super(map);
    }
    
    @Override
    public String getDisplayName(final CommandSender sender) {
        return ChatColor.valueOf(HCF.getPlugin().getConfig().getString("settings.colors.wilderness")) + this.getName();
    }
}
