package com.hcrival.hcf.faction.type;

import org.bukkit.configuration.serialization.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.command.*;
import java.util.*;

public class SpawnFaction extends ClaimableFaction implements ConfigurationSerializable
{
    public SpawnFaction() {
        super("Spawn");
        this.safezone = true;
        for (final World world : Bukkit.getWorlds()) {
            final int radius = ConfigurationService.SPAWN_RADIUS_MAP.get(world.getEnvironment());
            if (radius > 0) {
                this.addClaim(new Claim(this, new Location(world, (double)radius, 0.0, (double)radius), new Location(world, (double)(-radius), (double)world.getMaxHeight(), (double)(-radius))), null);
            }
        }
    }
    
    public SpawnFaction(final Map<String, Object> map) {
        super(map);
    }
    
    public boolean isDeathban() {
        return false;
    }
}
