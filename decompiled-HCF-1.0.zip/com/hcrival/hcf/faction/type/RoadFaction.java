package com.hcrival.hcf.faction.type;

import org.bukkit.configuration.serialization.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.claim.*;
import java.util.*;

public class RoadFaction extends ClaimableFaction implements ConfigurationSerializable
{
    public static final int ROAD_EDGE_DIFF = 1000;
    public static final int ROAD_WIDTH_LEFT = 3;
    public static final int ROAD_WIDTH_RIGHT = 3;
    public static final int ROAD_MIN_HEIGHT = 0;
    public static final int ROAD_MAX_HEIGHT = 256;
    
    public RoadFaction(final String name) {
        super(name);
    }
    
    public RoadFaction(final Map<String, Object> map) {
        super(map);
    }
    
    public String getDisplayName(final CommandSender sender) {
        return ChatColor.valueOf(HCF.getPlugin().getConfig().getString("settings.colors.road")) + this.getName();
    }
    
    @Override
    public void printDetails(final CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(' ' + this.getDisplayName(sender));
        sender.sendMessage(ChatColor.YELLOW + "  Location: " + ChatColor.RED + "None");
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
    }
    
    public static class NorthRoadFaction extends RoadFaction implements ConfigurationSerializable
    {
        public NorthRoadFaction() {
            super("NorthRoad");
            for (final World world : Bukkit.getWorlds()) {
                final World.Environment environment = world.getEnvironment();
                if (environment != World.Environment.THE_END) {
                    final int roadLength = ConfigurationService.ROAD_LENGTHS.get(environment);
                    final int offset = ConfigurationService.SPAWN_RADIUS_MAP.get(environment) + 1;
                    this.addClaim(new Claim(this, new Location(world, -3.0, 0.0, (double)(-offset)), new Location(world, 3.0, 256.0, (double)(-roadLength + 1000))), null);
                }
            }
        }
        
        public NorthRoadFaction(final Map<String, Object> map) {
            super(map);
        }
    }
    
    public static class EastRoadFaction extends RoadFaction implements ConfigurationSerializable
    {
        public EastRoadFaction() {
            super("EastRoad");
            for (final World world : Bukkit.getWorlds()) {
                final World.Environment environment = world.getEnvironment();
                if (environment != World.Environment.THE_END) {
                    final int roadLength = ConfigurationService.ROAD_LENGTHS.get(environment);
                    final int offset = ConfigurationService.SPAWN_RADIUS_MAP.get(environment) + 1;
                    this.addClaim(new Claim(this, new Location(world, (double)offset, 0.0, -3.0), new Location(world, (double)(roadLength - 1000), 256.0, 3.0)), null);
                }
            }
        }
        
        public EastRoadFaction(final Map<String, Object> map) {
            super(map);
        }
    }
    
    public static class SouthRoadFaction extends RoadFaction implements ConfigurationSerializable
    {
        public SouthRoadFaction() {
            super("SouthRoad");
            for (final World world : Bukkit.getWorlds()) {
                final World.Environment environment = world.getEnvironment();
                if (environment != World.Environment.THE_END) {
                    final int roadLength = ConfigurationService.ROAD_LENGTHS.get(environment);
                    final int offset = ConfigurationService.SPAWN_RADIUS_MAP.get(environment) + 1;
                    this.addClaim(new Claim(this, new Location(world, 3.0, 0.0, (double)offset), new Location(world, -3.0, 256.0, (double)(roadLength - 1000))), null);
                }
            }
        }
        
        public SouthRoadFaction(final Map<String, Object> map) {
            super(map);
        }
    }
    
    public static class WestRoadFaction extends RoadFaction implements ConfigurationSerializable
    {
        public WestRoadFaction() {
            super("WestRoad");
            for (final World world : Bukkit.getWorlds()) {
                final World.Environment environment = world.getEnvironment();
                if (environment != World.Environment.THE_END) {
                    final int roadLength = ConfigurationService.ROAD_LENGTHS.get(environment);
                    final int offset = ConfigurationService.SPAWN_RADIUS_MAP.get(environment) + 1;
                    this.addClaim(new Claim(this, new Location(world, (double)(-offset), 0.0, 3.0), new Location(world, (double)(-roadLength + 1000), 256.0, -3.0)), null);
                }
            }
        }
        
        public WestRoadFaction(final Map<String, Object> map) {
            super(map);
        }
    }
}
