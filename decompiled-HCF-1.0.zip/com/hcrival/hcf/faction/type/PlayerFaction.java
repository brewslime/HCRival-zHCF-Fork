package com.hcrival.hcf.faction.type;

import com.hcrival.hcf.faction.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import javax.annotation.*;
import org.bukkit.event.*;
import com.hcrival.hcf.faction.event.cause.*;
import com.google.common.base.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.hcf.timer.type.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.event.*;
import com.hcrival.hcf.deathban.*;
import com.hcrival.util.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.user.*;
import java.util.*;
import com.google.common.collect.*;
import com.hcrival.hcf.util.*;

public class PlayerFaction extends ClaimableFaction implements Raidable
{
    protected final Map<UUID, Relation> requestedRelations;
    protected final Map<UUID, Relation> relations;
    protected final Map<UUID, FactionMember> members;
    protected final Set<String> invitedPlayerNames;
    protected PersistableLocation home;
    protected String announcement;
    protected boolean open;
    protected int balance;
    protected double deathsUntilRaidable;
    protected long regenCooldownTimestamp;
    protected int points;
    private transient UUID focused;
    private long lastDtrUpdateTimestamp;
    private static final Joiner INFO_JOINER;
    private static final UUID[] EMPTY_UUID_ARRAY;
    
    public PlayerFaction(final String name) {
        super(name);
        this.requestedRelations = new HashMap<UUID, Relation>();
        this.relations = new HashMap<UUID, Relation>();
        this.members = new HashMap<UUID, FactionMember>();
        this.invitedPlayerNames = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        this.deathsUntilRaidable = 1.0;
        this.points = 0;
    }
    
    public PlayerFaction(final Map<String, Object> map) {
        super(map);
        this.requestedRelations = new HashMap<UUID, Relation>();
        this.relations = new HashMap<UUID, Relation>();
        this.members = new HashMap<UUID, FactionMember>();
        this.invitedPlayerNames = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        this.deathsUntilRaidable = 1.0;
        this.points = 0;
        for (final Map.Entry<String, FactionMember> entry : GenericUtils.castMap(map.get("members"), String.class, FactionMember.class).entrySet()) {
            if (entry.getValue() != null) {
                this.members.put(UUID.fromString(entry.getKey()), entry.getValue());
            }
        }
        this.invitedPlayerNames.addAll(GenericUtils.createList(map.get("invitedPlayerNames"), String.class));
        Object object = map.get("home");
        if (object != null) {
            this.home = (PersistableLocation)object;
        }
        object = map.get("announcement");
        if (object != null) {
            this.announcement = (String)object;
        }
        for (final Map.Entry<String, String> entry2 : GenericUtils.castMap(map.get("relations"), String.class, String.class).entrySet()) {
            this.relations.put(UUID.fromString(entry2.getKey()), Relation.valueOf(entry2.getValue()));
        }
        for (final Map.Entry<String, String> entry2 : GenericUtils.castMap(map.get("requestedRelations"), String.class, String.class).entrySet()) {
            this.requestedRelations.put(UUID.fromString(entry2.getKey()), Relation.valueOf(entry2.getValue()));
        }
        this.open = map.get("open");
        this.balance = map.get("balance");
        this.deathsUntilRaidable = map.get("deathsUntilRaidable");
        this.regenCooldownTimestamp = Long.parseLong(map.get("regenCooldownTimestamp"));
        this.lastDtrUpdateTimestamp = Long.parseLong(map.get("lastDtrUpdateTimestamp"));
        this.points = map.get("points");
    }
    
    @Override
    public Map<String, Object> serialize() {
        final Map<String, Object> map = super.serialize();
        final Map<String, String> relationSaveMap = new HashMap<String, String>(this.relations.size());
        for (final Map.Entry<UUID, Relation> entry : this.relations.entrySet()) {
            relationSaveMap.put(entry.getKey().toString(), entry.getValue().name());
        }
        map.put("relations", relationSaveMap);
        final Map<String, String> requestedRelationsSaveMap = new HashMap<String, String>(this.requestedRelations.size());
        for (final Map.Entry<UUID, Relation> entry2 : this.requestedRelations.entrySet()) {
            requestedRelationsSaveMap.put(entry2.getKey().toString(), entry2.getValue().name());
        }
        map.put("requestedRelations", requestedRelationsSaveMap);
        final Set<Map.Entry<UUID, FactionMember>> entrySet = this.members.entrySet();
        final Map<String, FactionMember> saveMap = new LinkedHashMap<String, FactionMember>(this.members.size());
        for (final Map.Entry<UUID, FactionMember> entry3 : entrySet) {
            saveMap.put(entry3.getKey().toString(), entry3.getValue());
        }
        map.put("members", saveMap);
        map.put("invitedPlayerNames", new ArrayList(this.invitedPlayerNames));
        if (this.home != null) {
            map.put("home", this.home);
        }
        if (this.announcement != null) {
            map.put("announcement", this.announcement);
        }
        map.put("open", this.open);
        map.put("balance", this.balance);
        map.put("deathsUntilRaidable", this.deathsUntilRaidable);
        map.put("regenCooldownTimestamp", Long.toString(this.regenCooldownTimestamp));
        map.put("lastDtrUpdateTimestamp", Long.toString(this.lastDtrUpdateTimestamp));
        map.put("points", this.points);
        return map;
    }
    
    public boolean addMember(final CommandSender sender, @Nullable final Player player, final UUID playerUUID, final FactionMember factionMember) {
        if (this.members.containsKey(playerUUID)) {
            return false;
        }
        final PlayerJoinFactionEvent eventPre = new PlayerJoinFactionEvent(sender, player, playerUUID, this);
        Bukkit.getPluginManager().callEvent((Event)eventPre);
        if (eventPre.isCancelled()) {
            return false;
        }
        this.lastDtrUpdateTimestamp = System.currentTimeMillis();
        this.invitedPlayerNames.remove(factionMember.getName());
        this.members.put(playerUUID, factionMember);
        Bukkit.getPluginManager().callEvent((Event)new PlayerJoinedFactionEvent(sender, player, playerUUID, this));
        return true;
    }
    
    public boolean removeMember(final CommandSender sender, @Nullable final Player player, final UUID playerUUID, final boolean kick, final boolean force) {
        if (!this.members.containsKey(playerUUID)) {
            return true;
        }
        final PlayerLeaveFactionEvent preEvent = new PlayerLeaveFactionEvent(sender, player, playerUUID, this, FactionLeaveCause.LEAVE, kick, force);
        Bukkit.getPluginManager().callEvent((Event)preEvent);
        if (preEvent.isCancelled()) {
            return false;
        }
        this.members.remove(playerUUID);
        this.setDeathsUntilRaidable(Math.min(this.deathsUntilRaidable, this.getMaximumDeathsUntilRaidable()));
        if (force) {
            this.setDeathsUntilRaidable(this.getDeathsUntilRaidable() - 1.0);
        }
        final PlayerLeftFactionEvent event = new PlayerLeftFactionEvent(sender, player, playerUUID, this, FactionLeaveCause.LEAVE, kick, false);
        Bukkit.getPluginManager().callEvent((Event)event);
        return true;
    }
    
    public Collection<UUID> getAllied() {
        return Maps.filterValues(this.relations, new Predicate<Relation>() {
            @Override
            public boolean apply(@Nullable final Relation relation) {
                return relation == Relation.ALLY;
            }
        }).keySet();
    }
    
    public List<PlayerFaction> getAlliedFactions() {
        final Collection<UUID> allied = this.getAllied();
        final Iterator<UUID> iterator = allied.iterator();
        final List<PlayerFaction> results = new ArrayList<PlayerFaction>(allied.size());
        while (iterator.hasNext()) {
            final Faction faction = HCF.getPlugin().getFactionManager().getFaction(iterator.next());
            if (faction instanceof PlayerFaction) {
                results.add((PlayerFaction)faction);
            }
            else {
                iterator.remove();
            }
        }
        return results;
    }
    
    public Map<UUID, Relation> getRequestedRelations() {
        return this.requestedRelations;
    }
    
    public Map<UUID, Relation> getRelations() {
        return this.relations;
    }
    
    public Map<UUID, FactionMember> getMembers() {
        return (Map<UUID, FactionMember>)ImmutableMap.copyOf((Map<?, ?>)this.members);
    }
    
    public Set<Player> getOnlinePlayers() {
        return this.getOnlinePlayers(null);
    }
    
    public Set<Player> getOnlinePlayers(final CommandSender sender) {
        final Set<Map.Entry<UUID, FactionMember>> entrySet = this.getOnlineMembers(sender).entrySet();
        final Set<Player> results = new HashSet<Player>(entrySet.size());
        for (final Map.Entry<UUID, FactionMember> entry : entrySet) {
            results.add(Bukkit.getPlayer((UUID)entry.getKey()));
        }
        return results;
    }
    
    public Map<UUID, FactionMember> getOnlineMembers() {
        return this.getOnlineMembers(null);
    }
    
    public Map<UUID, FactionMember> getOnlineMembers(final CommandSender sender) {
        final Player senderPlayer = (sender instanceof Player) ? sender : null;
        final Map<UUID, FactionMember> results = new HashMap<UUID, FactionMember>();
        for (final Map.Entry<UUID, FactionMember> entry : this.members.entrySet()) {
            final Player target = Bukkit.getPlayer((UUID)entry.getKey());
            if (target != null) {
                if (senderPlayer != null && !senderPlayer.canSee(target)) {
                    continue;
                }
                results.put(entry.getKey(), entry.getValue());
            }
        }
        return results;
    }
    
    public FactionMember getLeader() {
        final Map<UUID, FactionMember> members = this.members;
        for (final Map.Entry<UUID, FactionMember> entry : members.entrySet()) {
            if (entry.getValue().getRole() == Role.LEADER) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    @Deprecated
    public FactionMember getMember(final String memberName) {
        final UUID uuid = Bukkit.getOfflinePlayer(memberName).getUniqueId();
        return (uuid == null) ? null : this.members.get(uuid);
    }
    
    public FactionMember getMember(final Player player) {
        return this.getMember(player.getUniqueId());
    }
    
    public FactionMember getMember(final UUID memberUUID) {
        return this.members.get(memberUUID);
    }
    
    public Set<String> getInvitedPlayerNames() {
        return this.invitedPlayerNames;
    }
    
    public Location getHome() {
        return (this.home == null) ? null : this.home.getLocation();
    }
    
    public void setHome(@Nullable final Location home) {
        if (home == null && this.home != null) {
            final TeleportTimer timer = HCF.getPlugin().getTimerManager().getTeleportTimer();
            for (final Player player : this.getOnlinePlayers()) {
                final Location destination = timer.getDestination(player);
                if (Objects.equals(destination, this.home.getLocation())) {
                    timer.clearCooldown(player);
                    player.sendMessage(ChatColor.RED + "Your home was unset, so your " + timer.getName() + ChatColor.RED + " timer has been cancelled");
                }
            }
        }
        this.home = ((home == null) ? null : new PersistableLocation(home));
    }
    
    public String getAnnouncement() {
        return this.announcement;
    }
    
    public void setAnnouncement(@Nullable final String announcement) {
        this.announcement = announcement;
    }
    
    public boolean isOpen() {
        return this.open;
    }
    
    public void setOpen(final boolean open) {
        this.open = open;
    }
    
    public int getBalance() {
        return this.balance;
    }
    
    public void setBalance(final int balance) {
        this.balance = balance;
    }
    
    @Override
    public boolean isRaidable() {
        return this.deathsUntilRaidable <= 0.0;
    }
    
    @Override
    public double getDeathsUntilRaidable() {
        return this.getDeathsUntilRaidable(true);
    }
    
    @Override
    public double getMaximumDeathsUntilRaidable() {
        if (this.members.size() == 1) {
            return 1.1;
        }
        return Math.min(6.5, this.members.size() * 0.9);
    }
    
    public double getDeathsUntilRaidable(final boolean updateLastCheck) {
        if (updateLastCheck) {
            this.updateDeathsUntilRaidable();
        }
        return this.deathsUntilRaidable;
    }
    
    public ChatColor getDtrColour() {
        this.updateDeathsUntilRaidable();
        if (this.deathsUntilRaidable < 0.0) {
            return ChatColor.RED;
        }
        if (this.deathsUntilRaidable < 1.0) {
            return ChatColor.YELLOW;
        }
        return ChatColor.GREEN;
    }
    
    private void updateDeathsUntilRaidable() {
        if (this.getRegenStatus() == RegenStatus.REGENERATING) {
            final long now = System.currentTimeMillis();
            final long millisPassed = now - this.lastDtrUpdateTimestamp;
            final long millisBetweenUpdates = 5L;
            if (millisPassed >= millisBetweenUpdates) {
                final long remainder = millisPassed % millisBetweenUpdates;
                final int multiplier = (int)((millisPassed + (double)remainder) / millisBetweenUpdates);
                this.lastDtrUpdateTimestamp = now - remainder;
                this.setDeathsUntilRaidable(this.deathsUntilRaidable + multiplier * millisBetweenUpdates);
            }
        }
    }
    
    @Override
    public double setDeathsUntilRaidable(final double deathsUntilRaidable) {
        return this.setDeathsUntilRaidable(deathsUntilRaidable, true);
    }
    
    private double setDeathsUntilRaidable(double deathsUntilRaidable, final boolean limit) {
        deathsUntilRaidable = Math.round(deathsUntilRaidable * 100.0) / 100.0;
        if (limit) {
            deathsUntilRaidable = Math.min(deathsUntilRaidable, this.getMaximumDeathsUntilRaidable());
        }
        if (Math.abs(deathsUntilRaidable - this.deathsUntilRaidable) != 0.0) {
            final FactionDtrChangeEvent event = new FactionDtrChangeEvent(FactionDtrChangeEvent.DtrUpdateCause.REGENERATION, this, this.deathsUntilRaidable, deathsUntilRaidable);
            Bukkit.getPluginManager().callEvent((Event)event);
            if (!event.isCancelled()) {
                deathsUntilRaidable = Math.round(event.getNewDtr() * 100.0) / 100.0;
                if (deathsUntilRaidable > 0.0 && this.deathsUntilRaidable <= 0.0) {
                    HCF.getPlugin().getLogger().info("Faction " + this.getName() + " is now raidable.");
                    this.setPoints(this.getPoints() / 2);
                }
                this.lastDtrUpdateTimestamp = System.currentTimeMillis();
                return this.deathsUntilRaidable = deathsUntilRaidable;
            }
        }
        return this.deathsUntilRaidable;
    }
    
    protected long getRegenCooldownTimestamp() {
        return this.regenCooldownTimestamp;
    }
    
    @Override
    public long getRemainingRegenerationTime() {
        return (this.regenCooldownTimestamp == 0L) ? 0L : (this.regenCooldownTimestamp - System.currentTimeMillis());
    }
    
    @Override
    public void setRemainingRegenerationTime(final long millis) {
        final long systemMillis = System.currentTimeMillis();
        this.regenCooldownTimestamp = systemMillis + millis;
        this.lastDtrUpdateTimestamp = systemMillis + 10L;
    }
    
    @Override
    public RegenStatus getRegenStatus() {
        if (this.getRemainingRegenerationTime() > 0L) {
            return RegenStatus.PAUSED;
        }
        if (this.getMaximumDeathsUntilRaidable() > this.deathsUntilRaidable) {
            return RegenStatus.REGENERATING;
        }
        return RegenStatus.FULL;
    }
    
    @Override
    public void printDetails(final CommandSender sender) {
        String leaderName = null;
        final Set<String> allyNames = new HashSet<String>();
        for (final Map.Entry<UUID, Relation> entry : this.relations.entrySet()) {
            final Faction faction = HCF.getPlugin().getFactionManager().getFaction(entry.getKey());
            if (faction instanceof PlayerFaction) {
                final PlayerFaction ally = (PlayerFaction)faction;
                allyNames.add(ally.getDisplayName(sender) + ChatColor.DARK_GRAY + '[' + ChatColor.WHITE + ally.getOnlinePlayers(sender).size() + ChatColor.GRAY + '/' + ChatColor.WHITE + ally.members.size() + ChatColor.GOLD + ']');
            }
        }
        int combinedKills = 0;
        final Set<String> memberNames = new HashSet<String>();
        final Set<String> captainNames = new HashSet<String>();
        for (final Map.Entry<UUID, FactionMember> entry2 : this.members.entrySet()) {
            final FactionMember factionMember = entry2.getValue();
            final Player target = factionMember.toOnlinePlayer();
            final FactionUser user = HCF.getPlugin().getUserManager().getUser(entry2.getKey());
            final int kills = user.getKills();
            combinedKills += kills;
            ChatColor colour;
            if (DeathbanUser.getDeathbanUserFromUUID(user.getUserUUID()).isDeathbanned()) {
                colour = ChatColor.RED;
            }
            else if (target == null || (sender instanceof Player && !((Player)sender).canSee(target))) {
                colour = ChatColor.GRAY;
            }
            else {
                colour = ChatColor.GREEN;
            }
            final String memberName = colour + factionMember.getName() + ChatColor.WHITE + '[' + ChatColor.GREEN + kills + ChatColor.WHITE + ']';
            switch (factionMember.getRole()) {
                case LEADER: {
                    leaderName = memberName;
                    continue;
                }
                case CAPTAIN: {
                    captainNames.add(memberName);
                    continue;
                }
                case MEMBER: {
                    memberNames.add(memberName);
                    continue;
                }
            }
        }
        sender.sendMessage(ChatColor.DARK_GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(ChatColor.WHITE + " " + this.getDisplayName(sender) + ChatColor.DARK_GRAY + ChatColor.DARK_GRAY.toString() + " [" + ChatColor.GRAY + this.getOnlinePlayers(sender).size() + ChatColor.GRAY + " Online" + ChatColor.DARK_GRAY + ChatColor.DARK_GRAY.toString() + "] ");
        sender.sendMessage(ChatColor.WHITE + "  Home " + ChatColor.DARK_GRAY + "� " + ChatColor.GRAY + ((this.home == null) ? "N/A" : ("(" + this.home.getLocation().getBlockX() + " | " + this.home.getLocation().getBlockZ() + ')')));
        if (!allyNames.isEmpty()) {
            sender.sendMessage(ChatColor.WHITE + "  Alliances " + ChatColor.DARK_GRAY + "� " + PlayerFaction.INFO_JOINER.join(allyNames));
        }
        if (leaderName != null) {
            sender.sendMessage(ChatColor.WHITE + "  Leader " + ChatColor.DARK_GRAY + "� " + ChatColor.RED + leaderName);
        }
        if (!captainNames.isEmpty()) {
            sender.sendMessage(ChatColor.WHITE + "  Captains " + ChatColor.DARK_GRAY + "� " + ChatColor.RED + PlayerFaction.INFO_JOINER.join(captainNames));
        }
        if (!memberNames.isEmpty()) {
            sender.sendMessage(ChatColor.WHITE + "  Members " + ChatColor.DARK_GRAY + "� " + ChatColor.RED + PlayerFaction.INFO_JOINER.join(memberNames));
        }
        if (sender instanceof Player) {
            final Faction playerFaction = HCF.getPlugin().getFactionManager().getPlayerFaction((Player)sender);
            if (playerFaction != null && playerFaction.equals(this) && this.announcement != null) {
                sender.sendMessage(ChatColor.WHITE + "  Announcement " + ChatColor.DARK_GRAY + "� " + ChatColor.RED + this.announcement);
            }
        }
        sender.sendMessage(ChatColor.WHITE + "  Balance " + ChatColor.DARK_GRAY + "� " + ChatColor.GRAY + '$' + this.balance);
        sender.sendMessage(ChatColor.WHITE + "  Kills " + ChatColor.DARK_GRAY + "� " + ChatColor.GRAY + combinedKills);
        sender.sendMessage(ChatColor.WHITE + "  DTR " + ChatColor.DARK_GRAY + "� " + this.getRegenStatus().getSymbol() + this.getDtrColour() + JavaUtils.format(this.getDeathsUntilRaidable(false)) + ChatColor.GRAY + '/' + ChatColor.GREEN + JavaUtils.format(this.getMaximumDeathsUntilRaidable()));
        sender.sendMessage(ChatColor.WHITE + "  Points " + ChatColor.DARK_GRAY + "� " + ChatColor.GRAY + this.points);
        final long dtrRegenRemaining = this.getRemainingRegenerationTime();
        if (dtrRegenRemaining > 0L) {
            sender.sendMessage(ChatColor.WHITE + "  Regen " + ChatColor.DARK_GRAY + "� " + ChatColor.WHITE + DurationFormatUtils.formatDurationWords(dtrRegenRemaining, true, true));
        }
        sender.sendMessage(ChatColor.DARK_GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
    }
    
    public void broadcast(final String message) {
        this.broadcast(message, PlayerFaction.EMPTY_UUID_ARRAY);
    }
    
    public void broadcast(final String[] messages) {
        this.broadcast(messages, PlayerFaction.EMPTY_UUID_ARRAY);
    }
    
    public void broadcast(final String message, @Nullable final UUID... ignore) {
        this.broadcast(new String[] { message }, ignore);
    }
    
    public void broadcast(final String[] messages, final UUID... ignore) {
        Objects.requireNonNull(messages, "Messages cannot be null");
        Objects.requireNonNull(messages.length > 0, "Message array cannot be empty");
        final Collection<Player> players = this.getOnlinePlayers();
        final Collection<UUID> ignores = (Collection<UUID>)((ignore.length == 0) ? Collections.emptySet() : Sets.newHashSet(ignore));
        for (final Player player : players) {
            if (!ignores.contains(player.getUniqueId())) {
                for (final String s : messages) {
                    player.sendMessage(Color.translate(s));
                }
            }
        }
    }
    
    public int getPoints() {
        return this.points;
    }
    
    public UUID getFocused() {
        return this.focused;
    }
    
    public void setRegenCooldownTimestamp(final long regenCooldownTimestamp) {
        this.regenCooldownTimestamp = regenCooldownTimestamp;
    }
    
    public void setPoints(final int points) {
        this.points = points;
    }
    
    public void setFocused(final UUID focused) {
        this.focused = focused;
    }
    
    public void setLastDtrUpdateTimestamp(final long lastDtrUpdateTimestamp) {
        this.lastDtrUpdateTimestamp = lastDtrUpdateTimestamp;
    }
    
    public long getLastDtrUpdateTimestamp() {
        return this.lastDtrUpdateTimestamp;
    }
    
    static {
        INFO_JOINER = Joiner.on(ChatColor.GRAY + ", ");
        EMPTY_UUID_ARRAY = new UUID[0];
    }
}
