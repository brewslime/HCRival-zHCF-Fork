package com.hcrival.hcf.faction;

import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.*;
import java.util.concurrent.*;
import org.bukkit.plugin.*;
import org.bukkit.entity.*;
import net.frozenorb.qlib.nametag.*;
import com.google.common.collect.*;
import org.bukkit.craftbukkit.v1_7_R4.util.*;
import org.bukkit.block.*;
import com.hcrival.util.*;
import org.bukkit.command.*;
import com.hcrival.hcf.faction.struct.*;
import org.bukkit.event.*;
import com.hcrival.hcf.faction.event.cause.*;
import org.bukkit.plugin.java.*;
import org.bukkit.configuration.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.*;
import java.util.*;
import com.hcrival.hcf.faction.event.*;

public class FlatFileFactionManager implements Listener, FactionManager
{
    private final WarzoneFaction warzone;
    private final WildernessFaction wilderness;
    private final Table<String, Long, Claim> claimPositionMap;
    private final ConcurrentMap<UUID, UUID> factionPlayerUuidMap;
    private final ConcurrentMap<UUID, Faction> factionUUIDMap;
    private final Map<String, UUID> factionNameMap;
    private Config config;
    private final HCF plugin;
    
    public FlatFileFactionManager(final HCF plugin) {
        this.claimPositionMap = (Table<String, Long, Claim>)HashBasedTable.create();
        this.factionPlayerUuidMap = new ConcurrentHashMap<UUID, UUID>();
        this.factionUUIDMap = new ConcurrentHashMap<UUID, Faction>();
        this.factionNameMap = new TreeMap<String, UUID>(String.CASE_INSENSITIVE_ORDER);
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.warzone = new WarzoneFaction();
        this.wilderness = new WildernessFaction();
        this.reloadFactionData();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerJoinedFaction(final PlayerJoinedFactionEvent event) {
        this.factionPlayerUuidMap.put(event.getPlayerUUID(), event.getFaction().getUniqueID());
        FrozenNametagHandler.reloadPlayer((Player)event.getPlayer().get());
        for (final Player player : event.getFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerLeftFaction(final PlayerLeftFactionEvent event) {
        this.factionPlayerUuidMap.remove(event.getUniqueID());
        FrozenNametagHandler.reloadPlayer((Player)event.getPlayer().get());
        for (final Player player : event.getFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionRename(final FactionRenameEvent event) {
        this.factionNameMap.remove(event.getOriginalName());
        this.factionNameMap.put(event.getNewName(), event.getFaction().getUniqueID());
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionClaim(final FactionClaimChangedEvent event) {
        for (final Claim claim : event.getAffectedClaims()) {
            this.cacheClaim(claim, event.getCause());
        }
    }
    
    @Deprecated
    public Map<String, UUID> getFactionNameMap() {
        return this.factionNameMap;
    }
    
    public ImmutableList<Faction> getFactions() {
        return ImmutableList.copyOf(this.factionUUIDMap.values());
    }
    
    public Claim getClaimAt(final World world, final int x, final int z) {
        return this.claimPositionMap.get(world.getName(), LongHash.toLong(x, z));
    }
    
    public Claim getClaimAt(final Location location) {
        return this.getClaimAt(location.getWorld(), location.getBlockX(), location.getBlockZ());
    }
    
    public Faction getFactionAt(final World world, final int x, final int z) {
        final World.Environment environment = world.getEnvironment();
        final Claim claim = this.getClaimAt(world, x, z);
        if (claim != null) {
            final Faction faction = claim.getFaction();
            if (faction != null) {
                return faction;
            }
        }
        if (environment == World.Environment.THE_END) {
            return this.warzone;
        }
        final int warzoneRadius = (environment == World.Environment.NETHER) ? this.plugin.getConfig().getInt("settings.warzone_radius_nether") : this.plugin.getConfig().getInt("settings.warzone_radius");
        return (Math.abs(x) > warzoneRadius || Math.abs(z) > warzoneRadius) ? this.wilderness : this.warzone;
    }
    
    public Faction getFactionAt(final Location location) {
        return this.getFactionAt(location.getWorld(), location.getBlockX(), location.getBlockZ());
    }
    
    public Faction getFactionAt(final Block block) {
        return this.getFactionAt(block.getLocation());
    }
    
    public Faction getFaction(final String factionName) {
        final UUID uuid = this.factionNameMap.get(factionName);
        return (uuid == null) ? null : this.factionUUIDMap.get(uuid);
    }
    
    public Faction getFaction(final UUID factionUUID) {
        return this.factionUUIDMap.get(factionUUID);
    }
    
    public PlayerFaction getPlayerFaction(final UUID playerUUID) {
        final UUID uuid = this.factionPlayerUuidMap.get(playerUUID);
        final Faction faction = (uuid == null) ? null : this.factionUUIDMap.get(uuid);
        return (faction instanceof PlayerFaction) ? ((PlayerFaction)faction) : null;
    }
    
    public PlayerFaction getPlayerFaction(final Player player) {
        return this.getPlayerFaction(player.getUniqueId());
    }
    
    public PlayerFaction getContainingPlayerFaction(final String search) {
        final OfflinePlayer target = JavaUtils.isUUID(search) ? Bukkit.getOfflinePlayer(UUID.fromString(search)) : Bukkit.getOfflinePlayer(search);
        return (target.hasPlayedBefore() || target.isOnline()) ? this.getPlayerFaction(target.getUniqueId()) : null;
    }
    
    public Faction getContainingFaction(final String search) {
        final Faction faction = this.getFaction(search);
        if (faction != null) {
            return faction;
        }
        final UUID playerUUID = Bukkit.getOfflinePlayer(search).getUniqueId();
        if (playerUUID != null) {
            return this.getPlayerFaction(playerUUID);
        }
        return null;
    }
    
    public boolean containsFaction(final Faction faction) {
        return this.factionNameMap.containsKey(faction.getName());
    }
    
    public boolean createFaction(final Faction faction) {
        return this.createFaction(faction, (CommandSender)Bukkit.getConsoleSender());
    }
    
    public boolean createFaction(final Faction faction, final CommandSender sender) {
        if (faction instanceof PlayerFaction && sender instanceof Player) {
            final Player player = (Player)sender;
            final PlayerFaction playerFaction = (PlayerFaction)faction;
            if (!playerFaction.addMember(sender, player, player.getUniqueId(), new FactionMember(player, ChatChannel.PUBLIC, Role.LEADER))) {
                return false;
            }
        }
        if (this.factionUUIDMap.putIfAbsent(faction.getUniqueID(), faction) != null) {
            return false;
        }
        this.factionNameMap.put(faction.getName(), faction.getUniqueID());
        final FactionCreateEvent createEvent = new FactionCreateEvent(faction, sender);
        Bukkit.getPluginManager().callEvent((Event)createEvent);
        return !createEvent.isCancelled();
    }
    
    public boolean removeFaction(final Faction faction, final CommandSender sender) {
        if (!this.factionUUIDMap.containsKey(faction.getUniqueID())) {
            return false;
        }
        final FactionRemoveEvent removeEvent = new FactionRemoveEvent(faction, sender);
        Bukkit.getPluginManager().callEvent((Event)removeEvent);
        if (removeEvent.isCancelled()) {
            return false;
        }
        this.factionUUIDMap.remove(faction.getUniqueID());
        this.factionNameMap.remove(faction.getName());
        if (faction instanceof ClaimableFaction) {
            Bukkit.getPluginManager().callEvent((Event)new FactionClaimChangedEvent(sender, ClaimChangeCause.UNCLAIM, ((ClaimableFaction)faction).getClaims()));
        }
        if (faction instanceof PlayerFaction) {
            final PlayerFaction playerFaction = (PlayerFaction)faction;
            for (final PlayerFaction ally : playerFaction.getAlliedFactions()) {
                ally.getRelations().remove(faction.getUniqueID());
            }
            for (final UUID uuid : playerFaction.getMembers().keySet()) {
                playerFaction.removeMember(sender, null, uuid, true, true);
            }
        }
        return true;
    }
    
    private void cacheClaim(final Claim claim, final ClaimChangeCause cause) {
        Objects.requireNonNull(claim, "Claim cannot be null");
        Objects.requireNonNull(cause, "Cause cannot be null");
        Objects.requireNonNull(cause != ClaimChangeCause.RESIZE, "Cannot cache claims of resize type");
        final World world = claim.getWorld();
        if (world == null) {
            return;
        }
        final int minX = Math.min(claim.getX1(), claim.getX2());
        final int maxX = Math.max(claim.getX1(), claim.getX2());
        final int minZ = Math.min(claim.getZ1(), claim.getZ2());
        final int maxZ = Math.max(claim.getZ1(), claim.getZ2());
        for (int x = minX; x <= maxX; ++x) {
            for (int z = minZ; z <= maxZ; ++z) {
                if (cause == ClaimChangeCause.CLAIM) {
                    this.claimPositionMap.put(world.getName(), LongHash.toLong(x, z), claim);
                }
                else if (cause == ClaimChangeCause.UNCLAIM) {
                    this.claimPositionMap.remove(world.getName(), LongHash.toLong(x, z));
                }
            }
        }
    }
    
    private void cacheFaction(final Faction faction) {
        this.factionNameMap.put(faction.getName(), faction.getUniqueID());
        this.factionUUIDMap.put(faction.getUniqueID(), faction);
        if (faction instanceof ClaimableFaction) {
            for (final Claim claim : ((ClaimableFaction)faction).getClaims()) {
                this.cacheClaim(claim, ClaimChangeCause.CLAIM);
            }
        }
        if (faction instanceof PlayerFaction) {
            for (final FactionMember factionMember : ((PlayerFaction)faction).getMembers().values()) {
                this.factionPlayerUuidMap.put(factionMember.getUniqueId(), faction.getUniqueID());
            }
        }
    }
    
    public void reloadFactionData() {
        this.factionNameMap.clear();
        this.config = new Config(this.plugin, "factions");
        final Object object = this.config.get("factions");
        if (object instanceof MemorySection) {
            final MemorySection section = (MemorySection)object;
            for (final String factionName : section.getKeys(false)) {
                final Object next = this.config.get(section.getCurrentPath() + '.' + factionName);
                if (next instanceof Faction) {
                    this.cacheFaction((Faction)next);
                }
            }
        }
        else if (object instanceof List) {
            final List<?> list = (List<?>)object;
            for (final Object next2 : list) {
                if (next2 instanceof Faction) {
                    this.cacheFaction((Faction)next2);
                }
            }
        }
        final Set<Faction> adding = new HashSet<Faction>();
        if (!this.factionNameMap.containsKey("NorthRoad")) {
            adding.add(new RoadFaction.NorthRoadFaction());
            adding.add(new RoadFaction.EastRoadFaction());
            adding.add(new RoadFaction.SouthRoadFaction());
            adding.add(new RoadFaction.WestRoadFaction());
        }
        if (!this.factionNameMap.containsKey("Spawn")) {
            adding.add(new SpawnFaction());
        }
        if (!this.factionNameMap.containsKey("EndPortal")) {
            adding.add(new EndPortalFaction());
        }
        for (final Faction added : adding) {
            this.cacheFaction(added);
            Bukkit.getConsoleSender().sendMessage(ChatColor.BLUE + "Faction " + added.getName() + " not found, created.");
        }
    }
    
    public void saveFactionData() {
        this.config.set("factions", (Object)new ArrayList(this.factionUUIDMap.values()));
        this.config.save();
    }
    
    @EventHandler
    public void onFactionRelationCreate(final FactionRelationCreateEvent e) {
        for (final Player player : e.getTargetFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
        for (final Player player : e.getSenderFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
    }
    
    @EventHandler
    public void onFactionRelationRemove(final FactionRelationRemoveEvent e) {
        for (final Player player : e.getTargetFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
        for (final Player player : e.getSenderFaction().getOnlinePlayers()) {
            FrozenNametagHandler.reloadPlayer(player);
        }
    }
}
