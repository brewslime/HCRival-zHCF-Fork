package com.hcrival.hcf.faction;

import com.google.common.collect.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.*;
import org.bukkit.block.*;
import java.util.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.entity.*;
import org.bukkit.command.*;
import java.util.concurrent.*;
import org.apache.commons.lang3.time.*;

public interface FactionManager
{
    public static final long MAX_DTR_REGEN_MILLIS = TimeUnit.HOURS.toMillis(3L);
    public static final String MAX_DTR_REGEN_WORDS = DurationFormatUtils.formatDurationWords(FactionManager.MAX_DTR_REGEN_MILLIS, true, true);
    
    Map<String, ?> getFactionNameMap();
    
    ImmutableList<Faction> getFactions();
    
    Claim getClaimAt(final Location p0);
    
    Claim getClaimAt(final World p0, final int p1, final int p2);
    
    Faction getFactionAt(final Location p0);
    
    Faction getFactionAt(final Block p0);
    
    Faction getFactionAt(final World p0, final int p1, final int p2);
    
    Faction getFaction(final String p0);
    
    Faction getFaction(final UUID p0);
    
    @Deprecated
    PlayerFaction getContainingPlayerFaction(final String p0);
    
    @Deprecated
    PlayerFaction getPlayerFaction(final Player p0);
    
    PlayerFaction getPlayerFaction(final UUID p0);
    
    Faction getContainingFaction(final String p0);
    
    boolean containsFaction(final Faction p0);
    
    boolean createFaction(final Faction p0);
    
    boolean createFaction(final Faction p0, final CommandSender p1);
    
    boolean removeFaction(final Faction p0, final CommandSender p1);
    
    void reloadFactionData();
    
    void saveFactionData();
}
