package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import com.hcrival.hcf.events.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class CaptureZoneLeaveEvent extends FactionEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final CaptureZone captureZone;
    private final Player player;
    
    public CaptureZoneLeaveEvent(final Player player, final CapturableFaction capturableFaction, final CaptureZone captureZone) {
        super(capturableFaction);
        Objects.requireNonNull(player, "Player cannot be null");
        Objects.requireNonNull(captureZone, "Capture zone cannot be null");
        this.captureZone = captureZone;
        this.player = player;
    }
    
    @Override
    public CapturableFaction getFaction() {
        return (CapturableFaction)super.getFaction();
    }
    
    public CaptureZone getCaptureZone() {
        return this.captureZone;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    public HandlerList getHandlers() {
        return CaptureZoneLeaveEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return CaptureZoneLeaveEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
