package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.hcf.faction.struct.*;
import java.util.*;
import org.bukkit.command.*;
import com.hcrival.hcf.faction.type.*;

public class FactionChatEvent extends FactionEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final Player player;
    private final FactionMember factionMember;
    private final ChatChannel chatChannel;
    private final String message;
    private final Collection<? extends CommandSender> recipients;
    private final String fallbackFormat;
    
    public FactionChatEvent(final boolean async, final PlayerFaction faction, final Player player, final ChatChannel chatChannel, final Collection<? extends CommandSender> recipients, final String message) {
        super(faction, async);
        this.player = player;
        this.factionMember = faction.getMember(player.getUniqueId());
        this.chatChannel = chatChannel;
        this.recipients = recipients;
        this.message = message;
        this.fallbackFormat = chatChannel.getRawFormat(player);
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public FactionMember getFactionMember() {
        return this.factionMember;
    }
    
    public ChatChannel getChatChannel() {
        return this.chatChannel;
    }
    
    public Collection<? extends CommandSender> getRecipients() {
        return this.recipients;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public String getFallbackFormat() {
        return this.fallbackFormat;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancel) {
        this.cancelled = cancel;
    }
    
    public static HandlerList getHandlerList() {
        return FactionChatEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return FactionChatEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
