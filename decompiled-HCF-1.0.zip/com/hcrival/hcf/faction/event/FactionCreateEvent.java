package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import org.bukkit.command.*;
import com.hcrival.hcf.faction.type.*;

public class FactionCreateEvent extends FactionEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final CommandSender sender;
    
    public FactionCreateEvent(final Faction faction, final CommandSender sender) {
        super(faction);
        this.sender = sender;
    }
    
    public CommandSender getSender() {
        return this.sender;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    public static HandlerList getHandlerList() {
        return FactionCreateEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return FactionCreateEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
