package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.event.cause.*;
import org.bukkit.command.*;
import javax.annotation.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;
import org.bukkit.*;

public class PlayerLeftFactionEvent extends FactionEvent
{
    private static final HandlerList handlers;
    private Optional<Player> player;
    private final UUID uniqueID;
    private final FactionLeaveCause cause;
    private final CommandSender sender;
    private final boolean isKick;
    private final boolean force;
    
    public PlayerLeftFactionEvent(final CommandSender sender, @Nullable final Player player, final UUID playerUUID, final PlayerFaction playerFaction, final FactionLeaveCause cause, final boolean isKick, final boolean force) {
        super(playerFaction);
        Objects.requireNonNull(sender, "Sender cannot be null");
        Objects.requireNonNull(playerUUID, "Player UUID cannot be null");
        Objects.requireNonNull(playerFaction, "Player faction cannot be null");
        Objects.requireNonNull(cause, "Cause cannot be null");
        this.sender = sender;
        if (player != null) {
            this.player = Optional.of(player);
        }
        this.uniqueID = playerUUID;
        this.cause = cause;
        this.isKick = isKick;
        this.force = force;
    }
    
    public Optional<Player> getPlayer() {
        if (this.player == null) {
            this.player = Optional.ofNullable(Bukkit.getPlayer(this.uniqueID));
        }
        return this.player;
    }
    
    public static HandlerList getHandlerList() {
        return PlayerLeftFactionEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return PlayerLeftFactionEvent.handlers;
    }
    
    @Override
    public PlayerFaction getFaction() {
        return (PlayerFaction)super.getFaction();
    }
    
    public UUID getUniqueID() {
        return this.uniqueID;
    }
    
    public FactionLeaveCause getCause() {
        return this.cause;
    }
    
    public CommandSender getSender() {
        return this.sender;
    }
    
    public boolean isKick() {
        return this.isKick;
    }
    
    public boolean isForce() {
        return this.force;
    }
    
    static {
        handlers = new HandlerList();
    }
}
