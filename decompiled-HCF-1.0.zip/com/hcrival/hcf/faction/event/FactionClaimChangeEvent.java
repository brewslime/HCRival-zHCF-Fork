package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import com.hcrival.hcf.faction.event.cause.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import java.util.*;

public class FactionClaimChangeEvent extends Event implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final ClaimChangeCause cause;
    private final Collection<Claim> affectedClaims;
    private final ClaimableFaction claimableFaction;
    private final CommandSender sender;
    
    public FactionClaimChangeEvent(final CommandSender sender, final ClaimChangeCause cause, final Collection<Claim> affectedClaims, final ClaimableFaction claimableFaction) {
        Objects.requireNonNull(sender, "CommandSender cannot be null");
        Objects.requireNonNull(cause, "Cause cannot be null");
        Objects.requireNonNull(affectedClaims, "Affected claims cannot be null");
        Objects.requireNonNull(affectedClaims.isEmpty(), "Affected claims cannot be empty");
        Objects.requireNonNull(claimableFaction, "ClaimableFaction cannot be null");
        this.sender = sender;
        this.cause = cause;
        this.affectedClaims = affectedClaims;
        this.claimableFaction = claimableFaction;
    }
    
    public CommandSender getSender() {
        return this.sender;
    }
    
    public ClaimChangeCause getCause() {
        return this.cause;
    }
    
    public Collection<Claim> getAffectedClaims() {
        return this.affectedClaims;
    }
    
    public ClaimableFaction getClaimableFaction() {
        return this.claimableFaction;
    }
    
    public static HandlerList getHandlerList() {
        return FactionClaimChangeEvent.handlers;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    public HandlerList getHandlers() {
        return FactionClaimChangeEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
