package com.hcrival.hcf.faction.event;

import org.bukkit.event.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public abstract class FactionEvent extends Event
{
    protected final Faction faction;
    
    public FactionEvent(final Faction faction) {
        this.faction = Objects.requireNonNull(faction, "Faction cannot be null");
    }
    
    FactionEvent(final Faction faction, final boolean async) {
        super(async);
        this.faction = Objects.requireNonNull(faction, "Faction cannot be null");
    }
    
    public Faction getFaction() {
        return this.faction;
    }
}
