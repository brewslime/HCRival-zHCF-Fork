package com.hcrival.hcf.faction.event.cause;

public enum FactionLeaveCause
{
    KICK, 
    LEAVE, 
    DISBAND;
}
