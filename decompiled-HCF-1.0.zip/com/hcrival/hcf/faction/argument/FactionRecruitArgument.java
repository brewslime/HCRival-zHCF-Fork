package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import java.util.*;

public class FactionRecruitArgument extends CommandArgument
{
    private final HCF plugin;
    private Set<PlayerFaction> cooldown;
    
    public FactionRecruitArgument(final HCF plugin) {
        super("recruit", "Announce to the server that your faction is recruiting!", new String[] { "r" });
        this.cooldown = new HashSet<PlayerFaction>();
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <factionName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final Player p = (Player)sender;
        final PlayerFaction faction = this.plugin.getFactionManager().getPlayerFaction(p);
        if (faction == null) {
            p.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (this.cooldown.contains(faction)) {
            p.sendMessage(ChatColor.RED + "Your faction is currently on cooldown for that.");
            return true;
        }
        for (final String s : this.plugin.getMessageConfig().getConfig().getStringList("messages.faction_recruitment")) {
            for (final Player loop : Bukkit.getServer().getOnlinePlayers()) {
                loop.sendMessage(Color.translate(s).replace("%faction%", faction.getName()));
            }
        }
        this.cooldown.add(faction);
        new BukkitRunnable() {
            public void run() {
                FactionRecruitArgument.this.cooldown.remove(faction);
            }
        }.runTaskLaterAsynchronously((Plugin)this.plugin, 100L);
        return false;
    }
}
