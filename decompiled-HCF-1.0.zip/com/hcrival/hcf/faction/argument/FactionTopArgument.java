package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.util.*;
import java.util.stream.*;
import java.util.*;
import com.hcrival.hcf.faction.type.*;

public class FactionTopArgument extends CommandArgument implements TabCompleter
{
    private final HCF plugin;
    public static final Comparator<PlayerFaction> POINT_COMPARATOR;
    
    public FactionTopArgument(final HCF plugin) {
        super("top", "Show top factions.", new String[] { "topfac", "topfaction" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <points>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        if (args[1].equalsIgnoreCase("points")) {
            sender.sendMessage(ChatColor.DARK_GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
            sender.sendMessage(ChatColor.DARK_RED + ChatColor.BOLD.toString() + "Faction Top");
            sender.sendMessage(ChatColor.DARK_GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
            final List<PlayerFaction> PlayerFactions = new ArrayList<PlayerFaction>((Collection<? extends PlayerFaction>)this.plugin.getFactionManager().getFactions().stream().filter(x -> x instanceof PlayerFaction).map(x -> x).filter(x -> x.getPoints() > 0).collect((Collector<? super Object, ?, Set<? super Object>>)Collectors.toSet()));
            if (PlayerFactions.isEmpty()) {
                sender.sendMessage(ChatColor.RED + "No factions currently have points.");
            }
            Collections.sort(PlayerFactions, FactionTopArgument.POINT_COMPARATOR);
            Collections.reverse(PlayerFactions);
            for (int i = 0; i < 10; ++i) {
                if (i >= PlayerFactions.size()) {
                    break;
                }
                final PlayerFaction next = PlayerFactions.get(i);
                sender.sendMessage("" + ChatColor.WHITE + (i + 1) + ". " + ChatColor.WHITE + next.getName() + ChatColor.DARK_GRAY + " � " + ChatColor.GREEN + next.getPoints());
            }
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        final List<String> list = new ArrayList<String>(Arrays.asList("points"));
        if (args.length == 2) {
            return list;
        }
        return Collections.emptyList();
    }
    
    static {
        POINT_COMPARATOR = ((faction1, faction2) -> Integer.compare(faction1.getPoints(), faction2.getPoints()));
    }
}
