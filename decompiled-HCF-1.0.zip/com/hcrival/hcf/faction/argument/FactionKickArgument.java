package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.*;
import java.util.*;
import org.bukkit.*;

public class FactionKickArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionKickArgument(final HCF plugin) {
        super("kick", "Kick a player from the faction.");
        this.plugin = plugin;
        this.aliases = new String[] { "kickmember", "kickplayer" };
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can kick from a faction.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (playerFaction.isRaidable() && !this.plugin.getEotwHandler().isEndOfTheWorld()) {
            sender.sendMessage(ChatColor.RED + "You cannot kick players whilst your faction is raidable.");
            return true;
        }
        final FactionMember targetMember = playerFaction.getMember(args[1]);
        if (targetMember == null) {
            sender.sendMessage(ChatColor.RED + "Your faction does not have a member named '" + args[1] + "'.");
            return true;
        }
        final Role selfRole = playerFaction.getMember(player.getUniqueId()).getRole();
        if (selfRole == Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction officer to kick members.");
            return true;
        }
        final Role targetRole = targetMember.getRole();
        if (targetRole == Role.LEADER) {
            sender.sendMessage(ChatColor.RED + "You cannot kick the faction leader.");
            return true;
        }
        if (targetRole == Role.CAPTAIN && selfRole == Role.CAPTAIN) {
            sender.sendMessage(ChatColor.RED + "You must be a faction leader to kick captains.");
            return true;
        }
        final Player onlineTarget = targetMember.toOnlinePlayer();
        if (playerFaction.removeMember(sender, onlineTarget, targetMember.getUniqueId(), true, true)) {
            if (onlineTarget != null) {
                onlineTarget.sendMessage(ChatColor.RED.toString() + ChatColor.BOLD + "You were kicked from the faction by " + sender.getName() + '.');
            }
            playerFaction.broadcast(ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.enemy")) + targetMember.getName() + ChatColor.YELLOW + " has been kicked by " + ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + playerFaction.getMember(player).getRole().getAstrix() + sender.getName() + ChatColor.YELLOW + '.');
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2 || !(sender instanceof Player)) {
            return Collections.emptyList();
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            return Collections.emptyList();
        }
        final Role memberRole = playerFaction.getMember(player.getUniqueId()).getRole();
        if (memberRole == Role.MEMBER) {
            return Collections.emptyList();
        }
        final List<String> results = new ArrayList<String>();
        for (final UUID entry : playerFaction.getMembers().keySet()) {
            final Role targetRole = playerFaction.getMember(entry).getRole();
            if (targetRole != Role.LEADER) {
                if (targetRole == Role.CAPTAIN && memberRole != Role.LEADER) {
                    continue;
                }
                final OfflinePlayer target = Bukkit.getOfflinePlayer(entry);
                final String targetName = target.getName();
                if (targetName == null || results.contains(targetName)) {
                    continue;
                }
                results.add(targetName);
            }
        }
        return results;
    }
}
