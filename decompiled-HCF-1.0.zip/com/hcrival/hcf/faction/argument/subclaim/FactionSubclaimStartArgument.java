package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.inventory.*;
import java.util.*;

public class FactionSubclaimStartArgument extends CommandArgument
{
    public FactionSubclaimStartArgument() {
        super("start", "Receive the subclaim wand", new String[] { "begin", "claim", "wand" });
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final PlayerInventory inventory = ((Player)sender).getInventory();
        if (inventory.contains(ClaimHandler.SUBCLAIM_WAND)) {
            sender.sendMessage(ChatColor.RED + "You already have a subclaim wand in your inventory.");
            return true;
        }
        if (inventory.contains(ClaimHandler.CLAIM_WAND)) {
            sender.sendMessage(ChatColor.RED + "You cannot have a subclaim wand whilst you have a claiming wand in your inventory.");
            return true;
        }
        if (!inventory.addItem(new ItemStack[] { ClaimHandler.SUBCLAIM_WAND }).isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Your inventory is full.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Subclaim wand added to inventory. Read the item to understand how to create a subclaim.");
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
