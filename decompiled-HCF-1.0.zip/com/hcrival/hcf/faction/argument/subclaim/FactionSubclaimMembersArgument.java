package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import java.util.*;
import com.hcrival.util.cuboid.*;
import java.util.function.*;
import java.util.stream.*;

public class FactionSubclaimMembersArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSubclaimMembersArgument(final HCF plugin) {
        super("listmembers", "List members of a subclaim", new String[] { "listplayers" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName() + " <subclaimName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        Subclaim subclaim = null;
        for (final Claim claim : playerFaction.getClaims()) {
            if ((subclaim = claim.getSubclaim(args[2])) != null) {
                break;
            }
        }
        if (subclaim == null) {
            sender.sendMessage(ChatColor.RED + "Your faction does not have a subclaim named " + args[2] + '.');
            return true;
        }
        final List<String> memberNames = new ArrayList<String>();
        for (final UUID accessibleUUID : subclaim.getAccessibleMembers()) {
            final OfflinePlayer target = Bukkit.getOfflinePlayer(accessibleUUID);
            final String name = target.getName();
            if (name != null) {
                memberNames.add(target.getName());
            }
        }
        sender.sendMessage(ChatColor.YELLOW + "Non-officers accessible of subclaim " + subclaim.getName() + " (" + memberNames.size() + "): " + ChatColor.AQUA + HCF.COMMA_JOINER.join(memberNames));
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 3 || !(sender instanceof Player)) {
            return Collections.emptyList();
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null || playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            return Collections.emptyList();
        }
        final List<String> results = new ArrayList<String>();
        for (final Claim claim : playerFaction.getClaims()) {
            results.addAll(claim.getSubclaims().stream().map((Function<? super Subclaim, ?>)NamedCuboid::getName).collect((Collector<? super Object, ?, Collection<? extends String>>)Collectors.toList()));
        }
        return results;
    }
}
