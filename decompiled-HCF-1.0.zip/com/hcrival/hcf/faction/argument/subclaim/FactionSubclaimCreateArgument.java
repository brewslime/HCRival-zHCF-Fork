package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class FactionSubclaimCreateArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSubclaimCreateArgument(final HCF plugin) {
        super("create", "Create a subclaim with a selection", new String[] { "make", "build" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName() + " <subclaimName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final UUID uuid = player.getUniqueId();
        if (playerFaction.getMember(uuid).getRole() == Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction officer to create subclaims.");
            return true;
        }
        if (args[2].length() < 3) {
            sender.sendMessage(ChatColor.RED + "Subclaim names must have at least " + this.plugin.getConfig().getInt("FACTION.MINIMUMNAMECHARACTERS") + " characters.");
            return true;
        }
        if (args[2].length() > 16) {
            sender.sendMessage(ChatColor.RED + "Subclaim names cannot be longer than " + this.plugin.getConfig().getInt("FACTION.MAXNAMECHARACTERS") + " characters.");
            return true;
        }
        if (!JavaUtils.isAlphanumeric(args[2])) {
            sender.sendMessage(ChatColor.RED + "Subclaim names may only be alphanumeric.");
            return true;
        }
        for (final Claim claim : playerFaction.getClaims()) {
            if (claim.getSubclaim(args[2]) != null) {
                sender.sendMessage(ChatColor.RED + "Your faction already has a subclaim named " + args[2] + '.');
                return true;
            }
        }
        final Map<UUID, ClaimSelection> selectionMap = this.plugin.getClaimHandler().claimSelectionMap;
        final ClaimSelection claimSelection = selectionMap.get(uuid);
        if (claimSelection == null || !claimSelection.hasBothPositionsSet()) {
            sender.sendMessage(ChatColor.RED + "You have not set both positions of this subclaim.");
            return true;
        }
        final Subclaim subclaim = new Subclaim(playerFaction, claimSelection.getPos1(), claimSelection.getPos2());
        subclaim.setY1(0);
        subclaim.setY2(256);
        subclaim.setName(args[2]);
        if (this.plugin.getClaimHandler().tryCreatingSubclaim(player, subclaim)) {
            this.plugin.getVisualiseHandler().clearVisualBlock(player, subclaim.getMinimumPoint());
            this.plugin.getVisualiseHandler().clearVisualBlock(player, subclaim.getMaximumPoint());
            selectionMap.remove(uuid);
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
