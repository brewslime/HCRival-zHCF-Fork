package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;
import com.hcrival.util.cuboid.*;
import java.util.function.*;
import java.util.stream.*;

public class FactionSubclaimDeleteArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSubclaimDeleteArgument(final HCF plugin) {
        super("delete", "Remove a subclaim", new String[] { "del", "remove" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName() + " <subclaimName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction officer to edit subclaims.");
            return true;
        }
        for (final Claim claim : playerFaction.getClaims()) {
            final Iterator<Subclaim> iterator = claim.getSubclaims().iterator();
            while (iterator.hasNext()) {
                final Subclaim subclaim = iterator.next();
                if (subclaim.getName().equalsIgnoreCase(args[2])) {
                    iterator.remove();
                    sender.sendMessage(ChatColor.AQUA + "Removed subclaim named " + subclaim.getName() + '.');
                    return true;
                }
            }
        }
        sender.sendMessage(ChatColor.RED + "Your faction does not have a subclaim named " + args[2] + '.');
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 3 || !(sender instanceof Player)) {
            return Collections.emptyList();
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null || playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            return Collections.emptyList();
        }
        final List<String> results = new ArrayList<String>();
        for (final Claim claim : playerFaction.getClaims()) {
            results.addAll(claim.getSubclaims().stream().map((Function<? super Subclaim, ?>)NamedCuboid::getName).collect((Collector<? super Object, ?, Collection<? extends String>>)Collectors.toList()));
        }
        return results;
    }
}
