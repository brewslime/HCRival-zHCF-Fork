package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.util.cuboid.*;
import java.util.function.*;
import com.hcrival.hcf.faction.claim.*;
import java.util.stream.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class FactionSubclaimListArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSubclaimListArgument(final HCF plugin) {
        super("list", "List subclaims in this faction", new String[] { "listsubs" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final List<String> subclaimNames = new ArrayList<String>();
        for (final Claim claim : playerFaction.getClaims()) {
            subclaimNames.addAll(claim.getSubclaims().stream().map((Function<? super Subclaim, ?>)NamedCuboid::getName).collect((Collector<? super Object, ?, Collection<? extends String>>)Collectors.toList()));
        }
        if (subclaimNames.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Your faction does not own any subclaims.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Factions' Subclaims (" + subclaimNames.size() + "): " + ChatColor.AQUA + HCF.COMMA_JOINER.join(subclaimNames));
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
