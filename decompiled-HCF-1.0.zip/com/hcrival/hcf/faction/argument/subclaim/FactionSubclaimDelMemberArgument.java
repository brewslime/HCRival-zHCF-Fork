package com.hcrival.hcf.faction.argument.subclaim;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.*;
import java.util.*;
import com.hcrival.util.cuboid.*;
import java.util.function.*;
import java.util.stream.*;

public class FactionSubclaimDelMemberArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSubclaimDelMemberArgument(final HCF plugin) {
        super("delmember", "Removes a member from a subclaim", new String[] { "addplayer", "deleteplayer", "removeplayer", "delplayer", "revoke" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + " subclaim " + this.getName() + " <subclaimName> <memberName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction officer to edit subclaims.");
            return true;
        }
        Subclaim subclaim = null;
        for (final Claim claim : playerFaction.getClaims()) {
            if ((subclaim = claim.getSubclaim(args[2])) != null) {
                break;
            }
        }
        if (subclaim == null) {
            sender.sendMessage(ChatColor.RED + "Your faction does not have a subclaim named " + args[2] + '.');
            return true;
        }
        final FactionMember factionTarget = playerFaction.getMember(args[3]);
        if (factionTarget == null) {
            sender.sendMessage(ChatColor.RED + "Your faction does not have a member named " + args[3] + '.');
            return true;
        }
        if (factionTarget.getRole() != Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "Faction officers already bypass subclaim protection.");
            return true;
        }
        if (!subclaim.getAccessibleMembers().remove(factionTarget.getUniqueId())) {
            sender.sendMessage(ChatColor.RED + factionTarget.getName() + " will continue to not have access to subclaim " + subclaim.getName() + '.');
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Removed member " + factionTarget.getName() + " from subclaim " + subclaim.getName() + '.');
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            return Collections.emptyList();
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            return Collections.emptyList();
        }
        switch (args.length) {
            case 3: {
                if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
                    return Collections.emptyList();
                }
                final List<String> results = new ArrayList<String>();
                for (final Claim claim : playerFaction.getClaims()) {
                    results.addAll(claim.getSubclaims().stream().map((Function<? super Subclaim, ?>)NamedCuboid::getName).collect((Collector<? super Object, ?, Collection<? extends String>>)Collectors.toList()));
                }
                return results;
            }
            case 4: {
                Subclaim subclaim = null;
                for (final Claim claim2 : playerFaction.getClaims()) {
                    final Subclaim next = claim2.getSubclaim(args[2]);
                    if (next != null) {
                        subclaim = next;
                        break;
                    }
                }
                if (subclaim == null) {
                    return Collections.emptyList();
                }
                return playerFaction.getMembers().values().stream().filter(factionMember -> factionMember.getRole() == Role.MEMBER).map((Function<? super FactionMember, ?>)FactionMember::getName).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
            }
            default: {
                return null;
            }
        }
    }
}
