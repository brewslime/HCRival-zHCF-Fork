package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.base.*;
import com.hcrival.hcf.faction.*;
import java.util.function.*;
import com.hcrival.hcf.visualise.*;
import com.hcrival.hcf.user.*;
import java.util.*;

public class FactionMapArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionMapArgument(final HCF plugin) {
        super("map", "View all claims around your chunk.");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " [factionName]";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final UUID uuid = player.getUniqueId();
        final FactionUser factionUser = this.plugin.getUserManager().getUser(uuid);
        VisualType visualType;
        if (args.length < 2) {
            visualType = VisualType.CLAIM_MAP;
        }
        else if ((visualType = GuavaCompat.getIfPresent(VisualType.class, args[1]).orNull()) == null) {
            player.sendMessage(ChatColor.RED + "Visual type " + args[1] + " not found.");
            return true;
        }
        final boolean newShowingMap = !factionUser.isShowClaimMap();
        if (newShowingMap) {
            if (!LandMap.updateMap(player, this.plugin, visualType, true)) {
                return true;
            }
        }
        else {
            this.plugin.getVisualiseHandler().clearVisualBlocks(player, visualType, null);
            sender.sendMessage(ChatColor.RED + "Claim pillars are no longer shown.");
        }
        factionUser.setShowClaimMap(newShowingMap);
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2 || !(sender instanceof Player)) {
            return Collections.emptyList();
        }
        final VisualType[] values = VisualType.values();
        final List<String> results = new ArrayList<String>(values.length);
        for (final VisualType visualType : values) {
            results.add(visualType.name());
        }
        return results;
    }
}
