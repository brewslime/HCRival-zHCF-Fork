package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.*;
import org.bukkit.*;
import java.util.*;

public class FactionSetHomeArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSetHomeArgument(final HCF plugin) {
        super("sethome", "Sets the faction home location.");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        if (this.plugin.getConfig().getInt("settings.maxheight") != -1 && player.getLocation().getY() > this.plugin.getConfig().getInt("settings.maxheight")) {
            sender.sendMessage(ChatColor.RED + "You can not set your faction home above y " + this.plugin.getConfig().getInt("settings.maxheight") + ".");
            return true;
        }
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final FactionMember factionMember = playerFaction.getMember(player);
        if (factionMember.getRole() == Role.MEMBER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction officer to set the home.");
            return true;
        }
        final Location location = player.getLocation();
        boolean insideTerritory = false;
        for (final Claim claim : playerFaction.getClaims()) {
            if (claim.contains(location)) {
                insideTerritory = true;
                break;
            }
        }
        if (!insideTerritory) {
            player.sendMessage(ChatColor.RED + "You may only set your home in your territory.");
            return true;
        }
        playerFaction.setHome(location);
        playerFaction.broadcast(ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + factionMember.getRole().getAstrix() + sender.getName() + ChatColor.YELLOW + " has updated the faction home.");
        return true;
    }
}
