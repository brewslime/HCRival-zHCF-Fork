package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import com.google.common.collect.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.*;
import org.bukkit.*;
import java.util.*;

public class FactionUnclaimArgument extends CommandArgument
{
    private final HCF plugin;
    private static final ImmutableList<String> COMPLETIONS;
    
    public FactionUnclaimArgument(final HCF plugin) {
        super("unclaim", "Unclaims land from your faction.");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " [all]";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can un-claim land from a faction.");
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final FactionMember factionMember = playerFaction.getMember(player);
        if (factionMember.getRole() != Role.LEADER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction leader to unclaim land.");
            return true;
        }
        final Collection<Claim> factionClaims = playerFaction.getClaims();
        if (factionClaims.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Your faction does not own any claims.");
            return true;
        }
        Collection<Claim> removingClaims;
        if (args.length > 1 && args[1].equalsIgnoreCase("all")) {
            removingClaims = new ArrayList<Claim>(factionClaims);
        }
        else {
            final Location location = player.getLocation();
            final Claim claimAt = this.plugin.getFactionManager().getClaimAt(location);
            if (claimAt == null || !factionClaims.contains(claimAt)) {
                sender.sendMessage(ChatColor.RED + "Your faction does not own a claim here.");
                return true;
            }
            removingClaims = Collections.singleton(claimAt);
        }
        if (!playerFaction.removeClaims(removingClaims, (CommandSender)player)) {
            sender.sendMessage(ChatColor.RED + "Error when removing claims, please contact an Administrator.");
            return true;
        }
        final int removingAmount = removingClaims.size();
        playerFaction.broadcast(ChatColor.RED + ChatColor.BOLD.toString() + factionMember.getRole().getAstrix() + sender.getName() + " has removed " + removingAmount + " claim" + ((removingAmount > 1) ? "s" : "") + '.');
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 2) ? FactionUnclaimArgument.COMPLETIONS : Collections.emptyList();
    }
    
    static {
        COMPLETIONS = ImmutableList.of("all");
    }
}
