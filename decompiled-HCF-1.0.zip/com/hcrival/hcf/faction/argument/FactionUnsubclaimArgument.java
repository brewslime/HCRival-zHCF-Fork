package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import com.google.common.collect.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.*;
import java.util.*;

public class FactionUnsubclaimArgument extends CommandArgument
{
    private final HCF plugin;
    private static final ImmutableList<String> COMPLETIONS;
    
    public FactionUnsubclaimArgument(final HCF plugin) {
        super("unsubclaim", "Removes subclaims from your faction.");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " [all]";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can un-claim land from a faction.");
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final FactionMember factionMember = playerFaction.getMember(player);
        if (factionMember.getRole() != Role.LEADER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction leader to delete subclaims.");
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Please use /" + label + " <subclaim> <remove> for now.");
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 2) ? FactionUnsubclaimArgument.COMPLETIONS : Collections.emptyList();
    }
    
    static {
        COMPLETIONS = ImmutableList.of("all");
    }
}
