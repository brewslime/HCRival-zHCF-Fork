package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.faction.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.*;
import org.bukkit.entity.*;
import com.hcrival.util.*;
import org.bukkit.plugin.*;
import java.util.*;
import com.google.common.collect.*;

public class FactionHelpArgument extends CommandArgument
{
    private static final int HELP_PER_PAGE = 10;
    private ImmutableMultimap<Integer, String> pages;
    private final FactionExecutor executor;
    
    public FactionHelpArgument(final FactionExecutor executor) {
        super("help", "View help on how to use factions.");
        this.executor = executor;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            this.showPage(sender, label, 1);
            return true;
        }
        final Integer page = JavaUtils.tryParseInt(args[1]);
        if (page == null) {
            sender.sendMessage(ChatColor.RED + "'" + args[1] + "' is not a valid number.");
            return true;
        }
        this.showPage(sender, label, page);
        return true;
    }
    
    private void showPage(final CommandSender sender, final String label, final int pageNumber) {
        boolean isPlayer;
        int val;
        int count;
        ArrayListMultimap<Object, Object> pages;
        final Iterator<CommandArgument> iterator;
        CommandArgument argument;
        String permission;
        final int totalPageCount;
        final Iterator<String> iterator2;
        String message;
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)HCF.getPlugin(), () -> {
            if (this.pages == null) {
                isPlayer = (sender instanceof Player);
                val = 1;
                count = 0;
                pages = ArrayListMultimap.create();
                this.executor.getArguments().iterator();
                while (iterator.hasNext()) {
                    argument = iterator.next();
                    if (argument == this) {
                        continue;
                    }
                    else {
                        permission = argument.getPermission();
                        if (permission != null && !sender.hasPermission(permission)) {
                            continue;
                        }
                        else if (argument.isPlayerOnly() && !isPlayer) {
                            continue;
                        }
                        else {
                            ++count;
                            pages.get(Integer.valueOf(val)).add(ChatColor.YELLOW + "/" + label + ' ' + ChatColor.GOLD + argument.getName() + " � " + ChatColor.WHITE + argument.getDescription());
                            if (count % 10 == 0) {
                                ++val;
                            }
                            else {
                                continue;
                            }
                        }
                    }
                }
                this.pages = ImmutableMultimap.copyOf((Multimap<? extends Integer, ? extends String>)pages);
            }
            totalPageCount = this.pages.size() / 10 + 1;
            if (pageNumber < 1) {
                sender.sendMessage(ChatColor.RED + "You cannot view a page less than 1.");
            }
            else if (pageNumber > totalPageCount) {
                sender.sendMessage(ChatColor.RED + "There are only " + totalPageCount + " pages.");
            }
            else {
                sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
                sender.sendMessage(ChatColor.YELLOW + " Faction Help " + ChatColor.GOLD + "[Page " + pageNumber + '/' + totalPageCount + ']');
                this.pages.get(pageNumber).iterator();
                while (iterator2.hasNext()) {
                    message = iterator2.next();
                    sender.sendMessage("  " + message);
                }
                sender.sendMessage(ChatColor.YELLOW + " You are currently on " + ChatColor.WHITE + "Page " + pageNumber + '/' + totalPageCount + ChatColor.GOLD + '.');
                sender.sendMessage(ChatColor.YELLOW + " To view other pages, use " + ChatColor.WHITE + '/' + label + ' ' + this.getName() + " <page#>" + ChatColor.GOLD + '.');
                sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
            }
        });
    }
}
