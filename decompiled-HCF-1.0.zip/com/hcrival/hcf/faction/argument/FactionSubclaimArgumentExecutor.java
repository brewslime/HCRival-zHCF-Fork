package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.faction.argument.subclaim.*;
import org.bukkit.command.*;
import org.bukkit.*;
import java.util.*;

public class FactionSubclaimArgumentExecutor extends CommandArgument
{
    private final List<CommandArgument> arguments;
    
    public FactionSubclaimArgumentExecutor(final HCF plugin) {
        super("subclaim", "Shows the subclaim help page.", new String[] { "sub", "subland", "subclaimland" });
        (this.arguments = new ArrayList<CommandArgument>(8)).add(new FactionSubclaimAddMemberArgument(plugin));
        this.arguments.add(new FactionSubclaimCreateArgument(plugin));
        this.arguments.add(new FactionSubclaimDeleteArgument(plugin));
        this.arguments.add(new FactionSubclaimDelMemberArgument(plugin));
        this.arguments.add(new FactionSubclaimListArgument(plugin));
        this.arguments.add(new FactionSubclaimMembersArgument(plugin));
        this.arguments.add(new FactionSubclaimRenameArgument(plugin));
        this.arguments.add(new FactionSubclaimStartArgument());
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.AQUA + "*** Faction Subclaim Help ***");
            for (final CommandArgument argument : this.arguments) {
                final String permission = argument.getPermission();
                if (permission == null || sender.hasPermission(permission)) {
                    sender.sendMessage(ChatColor.GRAY + argument.getUsage(label) + " - " + argument.getDescription() + '.');
                }
            }
            sender.sendMessage(ChatColor.GRAY + "/" + label + " map subclaim - Shows the faction subclaim map.");
            return true;
        }
        final CommandArgument argument2 = getArgument(this.arguments, args[1]);
        final String permission2 = (argument2 == null) ? null : argument2.getPermission();
        if (argument2 == null || (permission2 != null && !sender.hasPermission(permission2))) {
            sender.sendMessage(ChatColor.RED + "Faction subclaim sub-command " + args[1] + " not found.");
            return true;
        }
        argument2.onCommand(sender, command, label, args);
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length == 2) {
            final List<String> results = new ArrayList<String>();
            for (final CommandArgument argument : this.arguments) {
                final String permission = argument.getPermission();
                if (permission == null || sender.hasPermission(permission)) {
                    results.add(argument.getName());
                }
            }
            return results;
        }
        final CommandArgument argument2 = getArgument(this.arguments, args[1]);
        if (argument2 != null) {
            final String permission2 = argument2.getPermission();
            if (permission2 == null || sender.hasPermission(permission2)) {
                return argument2.onTabComplete(sender, command, label, args);
            }
        }
        return Collections.emptyList();
    }
    
    private static CommandArgument getArgument(final Collection<CommandArgument> arguments, final String id) {
        for (final CommandArgument commandArgument : arguments) {
            if (commandArgument.getName().equalsIgnoreCase(id) || Arrays.asList(commandArgument.getAliases()).contains(id)) {
                return commandArgument;
            }
        }
        return null;
    }
}
