package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.util.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.faction.type.*;
import java.util.concurrent.*;

public class FactionRenameArgument extends CommandArgument
{
    private static final long FACTION_RENAME_DELAY_MILLIS;
    private static final String FACTION_RENAME_DELAY_WORDS;
    private final HCF plugin;
    
    public FactionRenameArgument(final HCF plugin) {
        super("rename", "Change the name of your faction.");
        this.plugin = plugin;
        this.aliases = new String[] { "changename", "setname" };
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <newFactionName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can create faction.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Player player = (Player)sender;
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() != Role.LEADER) {
            sender.sendMessage(ChatColor.RED + "You must be a faction leader to edit the name.");
            return true;
        }
        final String newName = args[1];
        int value = 3;
        if (newName.length() < value) {
            sender.sendMessage(ChatColor.RED + "Faction names must have at least " + value + " characters.");
            return true;
        }
        value = 16;
        if (newName.length() > value) {
            sender.sendMessage(ChatColor.RED + "Faction names cannot be longer than " + value + " characters.");
            return true;
        }
        if (!JavaUtils.isAlphanumeric(newName)) {
            sender.sendMessage(ChatColor.RED + "Faction names may only be alphanumeric.");
            return true;
        }
        if (this.plugin.getFactionManager().getFaction(newName) != null) {
            sender.sendMessage(ChatColor.RED + "Faction " + newName + ChatColor.RED + " already exists.");
            return true;
        }
        final long difference = playerFaction.lastRenameMillis - System.currentTimeMillis() + FactionRenameArgument.FACTION_RENAME_DELAY_MILLIS;
        if (!player.isOp() && difference > 0L) {
            player.sendMessage(ChatColor.RED + "There is a faction rename delay of " + FactionRenameArgument.FACTION_RENAME_DELAY_WORDS + ". Therefore you need to wait another " + DurationFormatUtils.formatDurationWords(difference, true, true) + " to rename your faction.");
            return true;
        }
        playerFaction.setName(args[1], sender);
        return true;
    }
    
    static {
        FACTION_RENAME_DELAY_MILLIS = TimeUnit.SECONDS.toMillis(15L);
        FACTION_RENAME_DELAY_WORDS = DurationFormatUtils.formatDurationWords(FactionRenameArgument.FACTION_RENAME_DELAY_MILLIS, true, true);
    }
}
