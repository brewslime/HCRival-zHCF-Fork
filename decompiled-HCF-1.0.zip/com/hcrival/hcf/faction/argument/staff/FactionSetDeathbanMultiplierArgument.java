package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;

public class FactionSetDeathbanMultiplierArgument extends CommandArgument
{
    private static final double MIN_MULTIPLIER = 0.0;
    private static final double MAX_MULTIPLIER = 5.0;
    private final HCF plugin;
    
    public FactionSetDeathbanMultiplierArgument(final HCF plugin) {
        super("setdeathbanmultiplier", "Sets the deathban multiplier of a faction.");
        this.plugin = plugin;
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName|factionName> <newMultiplier>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Faction faction = this.plugin.getFactionManager().getContainingFaction(args[1]);
        if (faction == null) {
            sender.sendMessage(ChatColor.RED + "Faction named or containing member with IGN or UUID " + args[1] + " not found.");
            return true;
        }
        final Double multiplier = JavaUtils.tryParseDouble(args[2]);
        if (multiplier == null) {
            sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a valid number.");
            return true;
        }
        if (multiplier < 0.0) {
            sender.sendMessage(ChatColor.RED + "Deathban multipliers may not be less than " + 0.0 + '.');
            return true;
        }
        if (multiplier > 5.0) {
            sender.sendMessage(ChatColor.RED + "Deathban multipliers may not be more than " + 5.0 + '.');
            return true;
        }
        final double previousMultiplier = faction.getDeathbanMultiplier();
        faction.setDeathbanMultiplier(multiplier);
        Command.broadcastCommandMessage(sender, ChatColor.YELLOW + "Set deathban multiplier of " + faction.getName() + " from " + previousMultiplier + " to " + multiplier + '.');
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        if (args[1].isEmpty()) {
            return null;
        }
        final List<String> results = new ArrayList<String>(this.plugin.getFactionManager().getFactionNameMap().keySet());
        final Player senderPlayer = (sender instanceof Player) ? sender : null;
        for (final Player player : Bukkit.getOnlinePlayers()) {
            if (senderPlayer == null || senderPlayer.canSee(player)) {
                results.add(player.getName());
            }
        }
        return results;
    }
}
