package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.scheduler.*;
import net.minecraft.util.com.google.common.primitives.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.plugin.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;

public class FactionAddPointsArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionAddPointsArgument(final HCF plugin) {
        super("addpoints", "Adds the points of a faction");
        this.plugin = plugin;
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <faction name> <points>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        new BukkitRunnable() {
            public void run() {
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Usage: " + FactionAddPointsArgument.this.getUsage(label));
                    return;
                }
                Integer newPoints = Ints.tryParse(args[2]);
                if (newPoints == null) {
                    sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a valid number.");
                    return;
                }
                final Faction faction2 = FactionAddPointsArgument.this.plugin.getFactionManager().getContainingFaction(args[1]);
                if (faction2 == null) {
                    sender.sendMessage(ChatColor.RED + "Faction named or containing member with IGN or UUID " + args[1] + " not found.");
                    return;
                }
                if (!(faction2 instanceof PlayerFaction)) {
                    sender.sendMessage(ChatColor.RED + "You can only set Points of player factions.");
                    return;
                }
                final PlayerFaction playerFaction = (PlayerFaction)faction2;
                final int previousPoints = playerFaction.getPoints();
                newPoints += previousPoints;
                playerFaction.setPoints(newPoints);
                Command.broadcastCommandMessage(sender, ChatColor.YELLOW + "Set Points of " + faction2.getName() + " from " + previousPoints + " to " + newPoints + '.');
            }
        }.runTaskAsynchronously((Plugin)this.plugin);
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2 || !(sender instanceof Player)) {
            return Collections.emptyList();
        }
        if (args[1].isEmpty()) {
            return null;
        }
        final Player player = (Player)sender;
        final List<String> results = new ArrayList<String>(this.plugin.getFactionManager().getFactionNameMap().keySet());
        for (final Player target : Bukkit.getOnlinePlayers()) {
            if (player.canSee(target) && !results.contains(target.getName())) {
                results.add(target.getName());
            }
        }
        return results;
    }
}
