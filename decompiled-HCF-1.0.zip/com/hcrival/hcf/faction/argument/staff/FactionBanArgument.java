package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import com.google.common.base.*;
import org.bukkit.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import java.util.*;

public class FactionBanArgument extends CommandArgument
{
    private final HCF plugin;
    public static final Joiner SPACE_JOIN;
    
    public FactionBanArgument(final HCF plugin) {
        super("ban", "Tempbans every faction member.");
        this.plugin = plugin;
        this.permission = String.valueOf("hcf.command.faction.argument.ban");
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <factionName> <reason>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Faction faction = this.plugin.getFactionManager().getContainingFaction(args[1]);
        if (!(faction instanceof PlayerFaction)) {
            sender.sendMessage(ChatColor.RED + "Player faction named or containing member with IGN or UUID " + args[1] + " not found.");
            return true;
        }
        final PlayerFaction playerFaction = (PlayerFaction)faction;
        final String extraArgs = FactionBanArgument.SPACE_JOIN.join(Arrays.copyOfRange(args, 2, args.length));
        final ConsoleCommandSender console = Bukkit.getConsoleSender();
        for (final UUID uuid : playerFaction.getMembers().keySet()) {
            final String commandLine = "ban " + uuid.toString() + " " + extraArgs;
            sender.sendMessage(ChatColor.YELLOW + "Executing commands " + commandLine);
            console.getServer().dispatchCommand(sender, commandLine);
        }
        Bukkit.broadcastMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        Bukkit.broadcastMessage("�eBanning the entire faction for " + playerFaction.getName() + ".");
        Bukkit.broadcastMessage("�eReason: " + extraArgs);
        Bukkit.broadcastMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        return true;
    }
    
    static {
        SPACE_JOIN = Joiner.on(' ');
    }
}
