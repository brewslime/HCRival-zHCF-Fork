package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import java.util.*;

public class FactionMuteArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionMuteArgument(final HCF plugin) {
        super("mute", "Mutes every member in this faction.");
        this.plugin = plugin;
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <factionName> <time:(e.g. 1h2s)> <reason>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Faction faction = this.plugin.getFactionManager().getContainingFaction(args[1]);
        if (!(faction instanceof PlayerFaction)) {
            sender.sendMessage(ChatColor.RED + "Player faction named or containing member with IGN or UUID " + args[1] + " not found.");
            return true;
        }
        final PlayerFaction playerFaction = (PlayerFaction)faction;
        final String extraArgs = HCF.SPACE_JOINER.join(Arrays.copyOfRange(args, 2, args.length));
        final ConsoleCommandSender console = Bukkit.getConsoleSender();
        for (final UUID uuid : playerFaction.getMembers().keySet()) {
            final String commandLine = "mute " + uuid.toString() + " " + extraArgs;
            sender.sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "Executing " + ChatColor.RED + commandLine);
            console.getServer().dispatchCommand(sender, commandLine);
        }
        sender.sendMessage(ChatColor.RED + ChatColor.BOLD.toString() + "Executed mute action on faction " + playerFaction.getName() + ".");
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 2) ? null : Collections.emptyList();
    }
}
