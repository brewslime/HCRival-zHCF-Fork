package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;

public class FactionSetDtrRegenArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionSetDtrRegenArgument(final HCF plugin) {
        super("setdtrregen", "Sets the DTR cooldown of a faction.", new String[] { "setdtrregeneration" });
        this.plugin = plugin;
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName|factionName> <newRegen>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final long newRegen = JavaUtils.parse(args[2]);
        if (newRegen < 0L) {
            sender.sendMessage(ChatColor.RED + "Faction DTR regeneration duration cannot be negative.");
            return true;
        }
        if (newRegen > FactionManager.MAX_DTR_REGEN_MILLIS) {
            sender.sendMessage(ChatColor.RED + "Cannot set factions DTR regen above " + FactionManager.MAX_DTR_REGEN_WORDS + ".");
            return true;
        }
        final Faction faction = this.plugin.getFactionManager().getContainingFaction(args[1]);
        if (faction == null) {
            sender.sendMessage(ChatColor.RED + "Faction named or containing member with IGN or UUID " + args[1] + " not found.");
            return true;
        }
        if (!(faction instanceof PlayerFaction)) {
            sender.sendMessage(ChatColor.RED + "This type of faction does not use DTR.");
            return true;
        }
        final PlayerFaction playerFaction = (PlayerFaction)faction;
        final long previousRegenRemaining = playerFaction.getRemainingRegenerationTime();
        playerFaction.setRemainingRegenerationTime(newRegen);
        Command.broadcastCommandMessage(sender, ChatColor.YELLOW + "Set DTR regen of " + faction.getName() + ((previousRegenRemaining > 0L) ? (" from " + DurationFormatUtils.formatDurationWords(previousRegenRemaining, true, true)) : "") + " to " + DurationFormatUtils.formatDurationWords(newRegen, true, true) + '.');
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        if (args[1].isEmpty()) {
            return null;
        }
        final List<String> results = new ArrayList<String>(this.plugin.getFactionManager().getFactionNameMap().keySet());
        final Player senderPlayer = (sender instanceof Player) ? sender : null;
        for (final Player player : Bukkit.getOnlinePlayers()) {
            if (senderPlayer == null || senderPlayer.canSee(player)) {
                results.add(player.getName());
            }
        }
        return results;
    }
}
