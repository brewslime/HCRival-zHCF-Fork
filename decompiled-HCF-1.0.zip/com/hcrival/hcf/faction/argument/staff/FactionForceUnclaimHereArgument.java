package com.hcrival.hcf.faction.argument.staff;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.claim.*;
import java.util.*;

public class FactionForceUnclaimHereArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionForceUnclaimHereArgument(final HCF plugin) {
        super("forceunclaimhere", "Forces land unclaim where you are standing.");
        this.plugin = plugin;
        this.permission = "hcf.command.faction.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can un-claim land from a faction.");
            return true;
        }
        final Player player = (Player)sender;
        final Claim claimAt = this.plugin.getFactionManager().getClaimAt(player.getLocation());
        if (claimAt == null) {
            sender.sendMessage(ChatColor.RED + "There is not a claim at your current position.");
            return true;
        }
        if (claimAt.getFaction().removeClaim(claimAt, sender)) {
            player.sendMessage(ChatColor.YELLOW + "Removed claim " + claimAt.getClaimUniqueID().toString() + " owned by " + claimAt.getFaction().getName() + ".");
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Failed to remove claim " + claimAt.getClaimUniqueID().toString());
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return Collections.emptyList();
    }
}
