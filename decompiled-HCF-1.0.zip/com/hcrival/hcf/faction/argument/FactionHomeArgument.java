package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.events.faction.*;
import java.util.concurrent.*;
import com.hcrival.hcf.util.*;
import org.bukkit.event.player.*;
import java.util.*;
import com.hcrival.hcf.timer.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.type.*;

public class FactionHomeArgument extends CommandArgument
{
    private final FactionExecutor factionExecutor;
    private final HCF plugin;
    
    public FactionHomeArgument(final FactionExecutor factionExecutor, final HCF plugin) {
        super("home", "Teleport to the faction home.");
        this.factionExecutor = factionExecutor;
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        if (args.length >= 2 && args[1].equalsIgnoreCase("set")) {
            this.factionExecutor.getArgument("sethome").onCommand(sender, command, label, args);
            return true;
        }
        final UUID uuid = player.getUniqueId();
        PlayerTimer timer = this.plugin.getTimerManager().getEnderPearlTimer();
        long remaining = timer.getRemaining(player);
        if (remaining > 0L) {
            sender.sendMessage(ChatColor.RED + "You cannot warp whilst your " + timer.getName() + ChatColor.RED + " timer is active.");
            return true;
        }
        if ((remaining = (timer = this.plugin.getTimerManager().getCombatTimer()).getRemaining(player)) > 0L) {
            sender.sendMessage(ChatColor.RED + "You cannot warp whilst your " + timer.getDisplayName() + ChatColor.RED + " timer is active.");
            return true;
        }
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(uuid);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        final Location home = playerFaction.getHome();
        if (home == null) {
            sender.sendMessage(ChatColor.RED + "Your faction does not have a home set.");
            return true;
        }
        if (this.plugin.getConfig().getInt("settings.maxheight") != -1 && home.getY() > this.plugin.getConfig().getInt("settings.maxheight")) {
            sender.sendMessage(ChatColor.RED + "Your faction home height is above the limit which is " + this.plugin.getConfig().getInt("settings.maxheight") + ", travel to your current home location at (x. " + home.getBlockX() + ", z. " + home.getBlockZ() + ") and re-set it at a lower height to fix this.");
            return true;
        }
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(player.getLocation());
        if (factionAt instanceof EventFaction) {
            sender.sendMessage(ChatColor.RED + "You cannot warp whilst in event zones.");
            return true;
        }
        if (factionAt != playerFaction && factionAt instanceof PlayerFaction && this.plugin.getConfig().getBoolean("timers.fhome_enemy_claim.length")) {
            player.sendMessage(ChatColor.RED + "You may not warp in enemy claims. Use " + ChatColor.YELLOW + '/' + label + " stuck" + ChatColor.RED + " if trapped.");
            return true;
        }
        long millis = 0L;
        if (factionAt.isSafezone()) {
            millis = 0L;
        }
        else {
            String name = null;
            switch (player.getWorld().getEnvironment()) {
                case THE_END: {
                    name = "End";
                    millis = TimeUnit.SECONDS.toMillis(this.plugin.getConfig().getInt("timers.teleport.length"));
                    break;
                }
                case NETHER: {
                    name = "Nether";
                    millis = TimeUnit.SECONDS.toMillis(this.plugin.getConfig().getInt("timers.teleport.length"));
                    break;
                }
                case NORMAL: {
                    name = "Overworld";
                    millis = TimeUnit.SECONDS.toMillis(this.plugin.getConfig().getInt("timers.teleport.length"));
                    break;
                }
                default: {
                    throw new IllegalArgumentException("Unrecognised environment");
                }
            }
            if (millis == -1L) {
                sender.sendMessage(ChatColor.RED + "Home teleports are disabled in the " + name + ".");
                return true;
            }
        }
        if (factionAt != playerFaction && factionAt instanceof PlayerFaction) {
            millis *= 2L;
        }
        this.plugin.getTimerManager().getTeleportTimer().teleport(player, home, millis, ChatColor.YELLOW + "Teleporting to your faction home in " + ChatColor.GOLD + ChatColor.BOLD + DurationFormatter.getRemaining(millis, true, false) + ChatColor.YELLOW + ". Do not move or take damage.", PlayerTeleportEvent.TeleportCause.COMMAND);
        return true;
    }
}
