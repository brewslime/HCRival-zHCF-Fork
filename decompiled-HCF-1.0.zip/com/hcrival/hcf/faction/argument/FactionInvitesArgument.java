package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.google.common.base.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.type.*;
import com.google.common.collect.*;
import java.util.*;

public class FactionInvitesArgument extends CommandArgument
{
    private static final Joiner JOINER;
    private final HCF plugin;
    
    public FactionInvitesArgument(final HCF plugin) {
        super("invites", "View faction invitations.");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can have faction invites.");
            return true;
        }
        final List<String> receivedInvites = new ArrayList<String>();
        for (final Faction faction : this.plugin.getFactionManager().getFactions()) {
            if (faction instanceof PlayerFaction) {
                final PlayerFaction targetPlayerFaction = (PlayerFaction)faction;
                if (!targetPlayerFaction.getInvitedPlayerNames().contains(sender.getName())) {
                    continue;
                }
                receivedInvites.add(targetPlayerFaction.getDisplayName(sender));
            }
        }
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction((Player)sender);
        if (playerFaction != null) {
            final Set<String> sentInvites = playerFaction.getInvitedPlayerNames();
            sender.sendMessage(ChatColor.AQUA + "Sent by " + playerFaction.getDisplayName(sender) + ChatColor.AQUA + " (" + sentInvites.size() + ')' + ChatColor.DARK_AQUA + ": " + ChatColor.GRAY + (sentInvites.isEmpty() ? "Your faction has not invited anyone." : (FactionInvitesArgument.JOINER.join(sentInvites) + '.')));
        }
        sender.sendMessage(ChatColor.AQUA + "Requested (" + receivedInvites.size() + ')' + ChatColor.DARK_AQUA + ": " + ChatColor.GRAY + (receivedInvites.isEmpty() ? "No factions have invited you." : (FactionInvitesArgument.JOINER.join(receivedInvites) + '.')));
        return true;
    }
    
    static {
        JOINER = Joiner.on(ChatColor.WHITE + ", " + ChatColor.GRAY);
    }
}
