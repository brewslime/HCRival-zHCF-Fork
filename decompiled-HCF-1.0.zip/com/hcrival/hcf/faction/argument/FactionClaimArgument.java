package com.hcrival.hcf.faction.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.claim.*;
import java.util.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.inventory.*;

public class FactionClaimArgument extends CommandArgument
{
    private final HCF plugin;
    
    public FactionClaimArgument(final HCF plugin) {
        super("claim", "Claim land in the Wilderness.", new String[] { "claimland" });
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        final Player player = (Player)sender;
        final UUID uuid = player.getUniqueId();
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(uuid);
        if (playerFaction == null) {
            sender.sendMessage(ChatColor.RED + "You are not in a faction.");
            return true;
        }
        if (playerFaction.isRaidable()) {
            sender.sendMessage(ChatColor.RED + "You cannot claim land for your faction while raidable.");
            return true;
        }
        final PlayerInventory inventory = player.getInventory();
        if (inventory.contains(ClaimHandler.CLAIM_WAND)) {
            sender.sendMessage(ChatColor.RED + "You already have a claiming wand in your inventory.");
            return true;
        }
        if (inventory.contains(ClaimHandler.SUBCLAIM_WAND)) {
            sender.sendMessage(ChatColor.RED + "You cannot have a claiming wand whilst you have a subclaim wand in your inventory.");
            return true;
        }
        if (!inventory.addItem(new ItemStack[] { ClaimHandler.CLAIM_WAND }).isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Your inventory is full.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Claiming wand added to inventory, read the item to understand how to claim. " + ChatColor.BOLD + "Alternatively" + ChatColor.YELLOW + " you can use " + ChatColor.AQUA + ChatColor.BOLD + '/' + label + " claimchunk" + ChatColor.YELLOW + '.');
        return true;
    }
}
