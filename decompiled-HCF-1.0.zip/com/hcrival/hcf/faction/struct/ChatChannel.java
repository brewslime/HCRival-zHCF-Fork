package com.hcrival.hcf.faction.struct;

import com.hcrival.hcf.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.entity.*;

public enum ChatChannel
{
    FACTION("Faction"), 
    ALLIANCE("Alliance"), 
    PUBLIC("Public");
    
    private final String name;
    
    private ChatChannel(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDisplayName() {
        final HCF plugin = HCF.getPlugin();
        String prefix = null;
        switch (this) {
            case FACTION: {
                prefix = ChatColor.valueOf(plugin.getConfig().getString("settings.colors.team_mate")).toString();
                break;
            }
            case ALLIANCE: {
                prefix = ChatColor.valueOf(plugin.getConfig().getString("settings.colors.ally")).toString();
                break;
            }
            default: {
                prefix = ChatColor.valueOf(plugin.getConfig().getString("settings.colors.enemy")).toString();
                break;
            }
        }
        return prefix + this.name;
    }
    
    public static ChatChannel parse(String id, final ChatChannel def) {
        final String lowerCase;
        id = (lowerCase = id.toLowerCase(Locale.ENGLISH));
        switch (lowerCase) {
            case "f":
            case "faction":
            case "fc":
            case "fac":
            case "fact": {
                return ChatChannel.FACTION;
            }
            case "a":
            case "alliance":
            case "ally":
            case "ac": {
                return ChatChannel.ALLIANCE;
            }
            case "p":
            case "pc":
            case "g":
            case "gc":
            case "global":
            case "pub":
            case "publi":
            case "public": {
                return ChatChannel.PUBLIC;
            }
            default: {
                return (def == null) ? null : def.getRotation();
            }
        }
    }
    
    public ChatChannel getRotation() {
        switch (this) {
            case FACTION: {
                return ChatChannel.PUBLIC;
            }
            case PUBLIC: {
                return (HCF.getPlugin().getConfig().getInt("settings.allies") > 0) ? ChatChannel.ALLIANCE : ChatChannel.FACTION;
            }
            case ALLIANCE: {
                return ChatChannel.FACTION;
            }
            default: {
                return ChatChannel.PUBLIC;
            }
        }
    }
    
    public String getRawFormat(final Player player) {
        final HCF plugin = HCF.getPlugin();
        switch (this) {
            case FACTION: {
                final ChatColor colour = ChatColor.valueOf(plugin.getConfig().getString("settings.colors.team_mate"));
                return colour + "(" + this.getDisplayName() + colour + ") " + player.getName() + ChatColor.GRAY + ": " + ChatColor.YELLOW + "%2$s";
            }
            case ALLIANCE: {
                final ChatColor colour = ChatColor.valueOf(plugin.getConfig().getString("settings.colors.team_mate"));
                return colour + "(" + this.getDisplayName() + colour + ") " + player.getName() + ChatColor.GRAY + ": " + ChatColor.YELLOW + "%2$s";
            }
            default: {
                throw new IllegalArgumentException("Cannot get the raw format for public chat channel");
            }
        }
    }
}
