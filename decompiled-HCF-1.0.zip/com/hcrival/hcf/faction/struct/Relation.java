package com.hcrival.hcf.faction.struct;

import com.hcrival.hcf.*;
import org.bukkit.*;
import com.hcrival.util.*;

public enum Relation
{
    MEMBER(3), 
    ALLY(2), 
    ENEMY(1);
    
    private final int value;
    
    private Relation(final int value) {
        this.value = value;
    }
    
    public int getValue() {
        return this.value;
    }
    
    public boolean isAtLeast(final Relation relation) {
        return this.value >= relation.value;
    }
    
    public boolean isAtMost(final Relation relation) {
        return this.value <= relation.value;
    }
    
    public boolean isMember() {
        return this == Relation.MEMBER;
    }
    
    public boolean isAlly() {
        return this == Relation.ALLY;
    }
    
    public boolean isEnemy() {
        return this == Relation.ENEMY;
    }
    
    public String getDisplayName() {
        switch (this) {
            case ALLY: {
                return this.toChatColour() + "alliance";
            }
            default: {
                return this.toChatColour() + this.name().toLowerCase();
            }
        }
    }
    
    public ChatColor toChatColour() {
        final HCF plugin = HCF.getPlugin();
        switch (this) {
            case MEMBER: {
                return ChatColor.valueOf(plugin.getConfig().getString("settings.colors.team_mate"));
            }
            case ALLY: {
                return ChatColor.valueOf(plugin.getConfig().getString("settings.colors.ally"));
            }
            default: {
                return ChatColor.valueOf(plugin.getConfig().getString("settings.colors.enemy"));
            }
        }
    }
    
    public DyeColor toDyeColour() {
        return BukkitUtils.toDyeColor(this.toChatColour());
    }
}
