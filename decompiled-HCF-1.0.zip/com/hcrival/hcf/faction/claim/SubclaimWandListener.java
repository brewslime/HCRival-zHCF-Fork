package com.hcrival.hcf.faction.claim;

import com.hcrival.hcf.*;
import org.bukkit.inventory.*;
import java.util.function.*;
import com.hcrival.hcf.visualise.*;
import org.bukkit.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import java.util.*;
import org.bukkit.block.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;

public class SubclaimWandListener implements Listener
{
    private final HCF plugin;
    
    public SubclaimWandListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.HIGH)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Action action = event.getAction();
        if (action == Action.PHYSICAL || !event.hasItem() || !this.isSubclaimWand(event.getItem())) {
            return;
        }
        final Player player = event.getPlayer();
        final UUID uuid = player.getUniqueId();
        if (action == Action.RIGHT_CLICK_AIR) {
            this.plugin.getClaimHandler().clearClaimSelection(player);
            player.setItemInHand(new ItemStack(Material.AIR, 1));
            player.sendMessage(ChatColor.RED + "You have cleared your subclaim selection.");
            return;
        }
        if (event.isCancelled()) {
            return;
        }
        if (action == Action.LEFT_CLICK_BLOCK || action == Action.RIGHT_CLICK_BLOCK) {
            final Block block = event.getClickedBlock();
            final Location blockLocation = event.getClickedBlock().getLocation();
            if (action == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
            }
            if (this.plugin.getClaimHandler().canSubclaimHere(player, blockLocation)) {
                final ClaimSelection revert;
                ClaimSelection claimSelection = this.plugin.getClaimHandler().claimSelectionMap.putIfAbsent(uuid, revert = new ClaimSelection(blockLocation.getWorld()));
                if (claimSelection == null) {
                    claimSelection = revert;
                }
                Location oldPosition = null;
                Location opposite = null;
                int selectionId = 0;
                switch (action) {
                    case LEFT_CLICK_BLOCK: {
                        oldPosition = claimSelection.getPos1();
                        opposite = claimSelection.getPos2();
                        selectionId = 1;
                        break;
                    }
                    case RIGHT_CLICK_BLOCK: {
                        oldPosition = claimSelection.getPos2();
                        opposite = claimSelection.getPos1();
                        selectionId = 2;
                        break;
                    }
                    default: {
                        return;
                    }
                }
                final int blockX = blockLocation.getBlockX();
                final int blockZ = blockLocation.getBlockZ();
                if (oldPosition != null && blockX == oldPosition.getBlockX() && blockZ == oldPosition.getBlockZ()) {
                    return;
                }
                if (System.currentTimeMillis() - claimSelection.getLastUpdateMillis() <= 200L) {
                    return;
                }
                if (opposite != null && (Math.abs(opposite.getBlockX() - blockX) <= ClaimHandler.MIN_SUBCLAIM_RADIUS || Math.abs(opposite.getBlockZ() - blockZ) <= ClaimHandler.MIN_SUBCLAIM_RADIUS)) {
                    player.sendMessage(ChatColor.RED + "Subclaim selections must be at least " + ClaimHandler.MIN_SUBCLAIM_RADIUS + 'x' + ClaimHandler.MIN_SUBCLAIM_RADIUS + " blocks.");
                    return;
                }
                if (oldPosition != null) {
                    this.plugin.getVisualiseHandler().clearVisualBlocks(player, VisualType.CREATE_CLAIM_SELECTION, new Predicate<VisualBlock>() {
                        @Override
                        public boolean test(final VisualBlock visualBlock) {
                            final Location location = visualBlock.getLocation();
                            return location.getBlockX() == oldPosition.getBlockX() && location.getBlockZ() == oldPosition.getBlockZ();
                        }
                    });
                }
                if (selectionId == 1) {
                    claimSelection.setPos1(blockLocation);
                }
                if (selectionId == 2) {
                    claimSelection.setPos2(blockLocation);
                }
                player.sendMessage(ChatColor.GREEN + "Set the location of subclaim selection " + ChatColor.YELLOW + selectionId + ChatColor.GREEN + " to: " + ChatColor.GOLD + '(' + ChatColor.YELLOW + blockX + ", " + blockZ + ChatColor.GOLD + ')');
                final int blockY = block.getY();
                final int maxHeight = player.getWorld().getMaxHeight();
                final List<Location> locations = new ArrayList<Location>(maxHeight);
                for (int i = blockY; i < maxHeight; ++i) {
                    final Location other = blockLocation.clone();
                    other.setY((double)i);
                    locations.add(other);
                }
                new BukkitRunnable() {
                    public void run() {
                        SubclaimWandListener.this.plugin.getVisualiseHandler().generate(player, locations, VisualType.CREATE_CLAIM_SELECTION, true);
                    }
                }.runTask((Plugin)this.plugin);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onBlockBreak(final BlockBreakEvent event) {
        if (this.isSubclaimWand(event.getPlayer().getItemInHand())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            final Player player = (Player)event.getDamager();
            if (this.isSubclaimWand(player.getItemInHand())) {
                player.setItemInHand(new ItemStack(Material.AIR, 1));
                this.plugin.getClaimHandler().clearClaimSelection(player);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onPlayerKick(final PlayerKickEvent event) {
        event.getPlayer().getInventory().remove(ClaimHandler.SUBCLAIM_WAND);
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        event.getPlayer().getInventory().remove(ClaimHandler.SUBCLAIM_WAND);
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onPlayerDrop(final PlayerDropItemEvent event) {
        final Item item = event.getItemDrop();
        if (this.isSubclaimWand(item.getItemStack())) {
            item.remove();
            this.plugin.getClaimHandler().clearClaimSelection(event.getPlayer());
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onPlayerPickup(final PlayerPickupItemEvent event) {
        final Item item = event.getItem();
        if (this.isSubclaimWand(item.getItemStack())) {
            item.remove();
            this.plugin.getClaimHandler().clearClaimSelection(event.getPlayer());
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        if (event.getDrops().remove(ClaimHandler.SUBCLAIM_WAND)) {
            this.plugin.getClaimHandler().clearClaimSelection(event.getEntity());
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.NORMAL)
    public void onInventoryOpen(final InventoryOpenEvent event) {
        final HumanEntity humanEntity = event.getPlayer();
        if (humanEntity instanceof Player) {
            final Player player = (Player)humanEntity;
            if (player.getInventory().contains(ClaimHandler.SUBCLAIM_WAND)) {
                this.plugin.getClaimHandler().clearClaimSelection(player);
            }
            player.getInventory().remove(ClaimHandler.SUBCLAIM_WAND);
        }
    }
    
    public boolean isSubclaimWand(final ItemStack stack) {
        return stack != null && stack.isSimilar(ClaimHandler.SUBCLAIM_WAND);
    }
}
