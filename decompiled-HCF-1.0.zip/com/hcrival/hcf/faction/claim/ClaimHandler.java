package com.hcrival.hcf.faction.claim;

import org.bukkit.inventory.*;
import com.hcrival.hcf.*;
import org.bukkit.entity.*;
import java.util.function.*;
import com.hcrival.hcf.visualise.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.util.cuboid.*;
import org.bukkit.command.*;
import java.util.*;
import org.bukkit.*;
import com.hcrival.util.*;

public class ClaimHandler
{
    public static final int MIN_CLAIM_HEIGHT = 0;
    public static final int MAX_CLAIM_HEIGHT = 256;
    public static final long PILLAR_BUFFER_DELAY_MILLIS = 200L;
    public static final ItemStack SUBCLAIM_WAND;
    public static final ItemStack CLAIM_WAND;
    private static final int NEXT_PRICE_MULTIPLIER_AREA = 250;
    private static final int NEXT_PRICE_MULTIPLIER_CLAIM = 500;
    public static final int MIN_SUBCLAIM_RADIUS;
    public static final int MIN_CLAIM_RADIUS;
    public static final int MAX_CHUNKS_PER_LIMIT;
    public static final int CLAIM_BUFFER_RADIUS;
    public final Map<UUID, ClaimSelection> claimSelectionMap;
    private final HCF plugin;
    private static final double CLAIM_SELL_MULTIPLIER = 0.8;
    private static final double CLAIM_PRICE_PER_BLOCK;
    
    public ClaimHandler(final HCF plugin) {
        this.plugin = plugin;
        this.claimSelectionMap = new HashMap<UUID, ClaimSelection>();
    }
    
    public int calculatePrice(final Cuboid claim, int currentClaims, final boolean selling) {
        if (currentClaims == -1 || !claim.hasBothPositionsSet()) {
            return 0;
        }
        int multiplier = 1;
        int remaining = claim.getArea();
        double price = 0.0;
        while (remaining > 0) {
            if (--remaining % 250 == 0) {
                ++multiplier;
            }
            price += ClaimHandler.CLAIM_PRICE_PER_BLOCK * multiplier;
        }
        if (currentClaims != 0) {
            currentClaims = Math.max(currentClaims + (selling ? -1 : 0), 0);
            price += currentClaims * 500;
        }
        if (selling) {
            price *= 0.8;
        }
        return (int)price;
    }
    
    public boolean clearClaimSelection(final Player player) {
        final ClaimSelection claimSelection = this.plugin.getClaimHandler().claimSelectionMap.remove(player.getUniqueId());
        if (claimSelection != null) {
            this.plugin.getVisualiseHandler().clearVisualBlocks(player, VisualType.CREATE_CLAIM_SELECTION, null);
            return true;
        }
        return false;
    }
    
    public boolean canSubclaimHere(final Player player, final Location location) {
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            player.sendMessage(ChatColor.RED + "You must be in a faction to subclaim land.");
            return false;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            player.sendMessage(ChatColor.RED + "You must be an officer to claim land.");
            return false;
        }
        if (this.plugin.getFactionManager().getFactionAt(location) != playerFaction) {
            player.sendMessage(ChatColor.RED + "This location is not part of your factions' territory.");
            return false;
        }
        return true;
    }
    
    public boolean tryCreatingSubclaim(final Player player, final Subclaim subclaim) {
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            player.sendMessage(ChatColor.RED + "You must be in a faction to subclaim land.");
            return false;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            player.sendMessage(ChatColor.RED + "You must be an officer to create subclaims.");
            return true;
        }
        final World world = subclaim.getWorld();
        final int minimumX = subclaim.getMinimumX();
        final int maximumX = subclaim.getMaximumX();
        final int minimumZ = subclaim.getMinimumZ();
        final int maximumZ = subclaim.getMaximumZ();
        Claim foundClaim = null;
        for (int x = minimumX; x < maximumX; ++x) {
            for (int z = minimumZ; z < maximumZ; ++z) {
                final Claim claimAt = this.plugin.getFactionManager().getClaimAt(world, x, z);
                final Faction factionAt;
                if (claimAt == null || (playerFaction == (factionAt = this.plugin.getFactionManager().getFactionAt(world, x, z)) && !(factionAt instanceof PlayerFaction))) {
                    player.sendMessage(ChatColor.RED + "This subclaim selection contains a location outside of your faction.");
                    return false;
                }
                if (playerFaction.getClaims().contains(claimAt)) {
                    for (final Subclaim claimAtSubclaims : claimAt.getSubclaims()) {
                        if (claimAtSubclaims.contains(world, x, z)) {
                            player.sendMessage(ChatColor.RED + "Subclaims cannot overlap each other.");
                            return false;
                        }
                    }
                }
                if (foundClaim == null) {
                    foundClaim = claimAt;
                }
                else if (claimAt != foundClaim) {
                    player.sendMessage(ChatColor.RED + "This subclaim selection is inside more than one of your faction claims.");
                    return false;
                }
            }
        }
        if (foundClaim == null) {
            player.sendMessage(ChatColor.RED + "This subclaim selection is not inside your faction territory.");
            return false;
        }
        foundClaim.getSubclaims().add(subclaim);
        subclaim.getAccessibleMembers().add(player.getUniqueId());
        player.sendMessage(ChatColor.GOLD + "You have created a subclaim named " + ChatColor.AQUA + subclaim.getName() + ChatColor.GOLD + '.');
        return true;
    }
    
    public boolean canClaimHere(final Player player, final Location location) {
        final World world = location.getWorld();
        if (world.getEnvironment() != World.Environment.NORMAL) {
            player.sendMessage(ChatColor.RED + "You can only claim land in the Overworld.");
            return false;
        }
        if (!(this.plugin.getFactionManager().getFactionAt(location) instanceof WildernessFaction)) {
            player.sendMessage(ChatColor.RED + "You can only claim land in the " + ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.wilderness")) + "Wilderness" + ChatColor.RED + ". Make sure you are past " + this.plugin.getConfig().getInt("settings.warzone_radius") + " blocks from spawn..");
            return false;
        }
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            player.sendMessage(ChatColor.RED + "You must be in a faction to claim land.");
            return false;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            player.sendMessage(ChatColor.RED + "You must be an officer to claim land.");
            return false;
        }
        if (playerFaction.getClaims().size() >= this.plugin.getConfig().getInt("settings.maxclaims")) {
            player.sendMessage(ChatColor.RED + "Your faction has maximum claims possible, which is " + this.plugin.getConfig().getInt("settings.maxclaims") + ".");
            return false;
        }
        final int locX = location.getBlockX();
        final int locZ = location.getBlockZ();
        final FactionManager factionManager = this.plugin.getFactionManager();
        final boolean flag = true;
        for (int x = locX - ClaimHandler.CLAIM_BUFFER_RADIUS; x < locX + ClaimHandler.CLAIM_BUFFER_RADIUS; ++x) {
            for (int z = locZ - ClaimHandler.CLAIM_BUFFER_RADIUS; z < locZ + ClaimHandler.CLAIM_BUFFER_RADIUS; ++z) {
                final Faction factionAtNew = factionManager.getFactionAt(world, x, z);
                if (!flag && factionAtNew instanceof ClaimableFaction && playerFaction != factionAtNew && !(factionAtNew instanceof RoadFaction)) {
                    player.sendMessage(ChatColor.RED + "This position contains enemy claims within a " + ClaimHandler.CLAIM_BUFFER_RADIUS + " block buffer radius.");
                    return false;
                }
            }
        }
        return true;
    }
    
    public boolean tryPurchasing(final Player player, final Claim claim) {
        Objects.requireNonNull(claim, "Claim is null");
        final World world = claim.getWorld();
        if (world.getEnvironment() != World.Environment.NORMAL) {
            player.sendMessage(ChatColor.RED + "You can only claim land in the Overworld.");
            return false;
        }
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction == null) {
            player.sendMessage(ChatColor.RED + "You must be in a faction to claim land.");
            return false;
        }
        if (playerFaction.getMember(player.getUniqueId()).getRole() == Role.MEMBER) {
            player.sendMessage(ChatColor.RED + "You must be an officer to claim land.");
            return false;
        }
        if (playerFaction.getClaims().size() >= this.plugin.getConfig().getInt("settings.maxclaims")) {
            player.sendMessage(ChatColor.RED + "Your faction has maximum claims possible, which is " + this.plugin.getConfig().getInt("settings.maxclaims") + ".");
            return false;
        }
        final int factionBalance = playerFaction.getBalance();
        final int claimPrice = this.calculatePrice(claim, playerFaction.getClaims().size(), false);
        if (claimPrice > factionBalance) {
            player.sendMessage(ChatColor.RED + "Your faction bank only has " + '$' + factionBalance + ", the price of this claim is " + '$' + claimPrice + '.');
            return false;
        }
        if (claim.getChunks().size() > ClaimHandler.MAX_CHUNKS_PER_LIMIT) {
            player.sendMessage(ChatColor.RED + "Claims cannot exceed " + ClaimHandler.MAX_CHUNKS_PER_LIMIT + " chunks.");
            return false;
        }
        if (claim.getWidth() < ClaimHandler.MIN_CLAIM_RADIUS || claim.getLength() < ClaimHandler.MIN_CLAIM_RADIUS) {
            player.sendMessage(ChatColor.RED + "Claims must be at least " + ClaimHandler.MIN_CLAIM_RADIUS + 'x' + ClaimHandler.MIN_CLAIM_RADIUS + " blocks.");
            return false;
        }
        final int minimumX = claim.getMinimumX();
        final int maximumX = claim.getMaximumX();
        final int minimumZ = claim.getMinimumZ();
        final int maximumZ = claim.getMaximumZ();
        final FactionManager factionManager = this.plugin.getFactionManager();
        for (int x = minimumX; x < maximumX; ++x) {
            for (int z = minimumZ; z < maximumZ; ++z) {
                final Faction factionAt = factionManager.getFactionAt(world, x, z);
                if (factionAt != null && !(factionAt instanceof WildernessFaction)) {
                    player.sendMessage(ChatColor.RED + "This claim contains a location not within the " + ChatColor.GRAY + "Wilderness" + ChatColor.RED + '.');
                    return false;
                }
            }
        }
        final boolean flag = true;
        for (int x2 = minimumX - ClaimHandler.CLAIM_BUFFER_RADIUS; x2 < maximumX + ClaimHandler.CLAIM_BUFFER_RADIUS; ++x2) {
            for (int z2 = minimumZ - ClaimHandler.CLAIM_BUFFER_RADIUS; z2 < maximumZ + ClaimHandler.CLAIM_BUFFER_RADIUS; ++z2) {
                final Faction factionAtNew = factionManager.getFactionAt(world, x2, z2);
                if (!flag && factionAtNew instanceof ClaimableFaction && playerFaction != factionAtNew && !(factionAtNew instanceof RoadFaction)) {
                    player.sendMessage(ChatColor.RED + "This claim contains enemy claims within a " + ClaimHandler.CLAIM_BUFFER_RADIUS + " block buffer radius.");
                    return false;
                }
            }
        }
        final Location minimum = claim.getMinimumPoint();
        final Location maximum = claim.getMaximumPoint();
        final Collection<Claim> otherClaims = playerFaction.getClaims();
        boolean conjoined = otherClaims.isEmpty();
        if (!conjoined) {
            for (final Claim otherClaim : otherClaims) {
                final Cuboid outset = otherClaim.clone().outset(CuboidDirection.HORIZONTAL, 1);
                if (outset.contains(minimum) || outset.contains(maximum)) {
                    conjoined = true;
                    break;
                }
            }
            if (!conjoined) {
                player.sendMessage(ChatColor.RED + "All claims in your faction must be conjoined.");
                return false;
            }
        }
        claim.setY1(0);
        claim.setY2(256);
        if (!playerFaction.addClaim(claim, (CommandSender)player)) {
            return false;
        }
        final Location center = claim.getCenter();
        player.sendMessage(ChatColor.AQUA + "Claim has been purchased for " + ChatColor.GREEN + '$' + claimPrice + ChatColor.AQUA + '.');
        playerFaction.setBalance(factionBalance - claimPrice);
        playerFaction.broadcast(ChatColor.GOLD + player.getName() + ChatColor.GREEN + " claimed land for your faction at " + ChatColor.GOLD + '(' + center.getBlockX() + ", " + center.getBlockZ() + ')' + ChatColor.GREEN + '.', player.getUniqueId());
        return true;
    }
    
    static {
        SUBCLAIM_WAND = new ItemBuilder(Material.GOLD_SPADE, 1).displayName(ChatColor.GOLD + "Subclaim Wand").lore(ChatColor.AQUA + "Left or Right Click " + ChatColor.GREEN + "a Block" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Set the first and second position of ", ChatColor.GRAY + "your Subclaim selection.", "", ChatColor.AQUA + "Right Click " + ChatColor.GREEN + "the Air" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Clear your current Subclaim selection.", "", ChatColor.AQUA + "Use " + ChatColor.YELLOW + "/faction subclaim create <name>" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Acquire your selected Subclaim.").build();
        CLAIM_WAND = new ItemBuilder(Material.DIAMOND_HOE).displayName(ChatColor.RED + "Claim Wand").lore(ChatColor.AQUA + "Left or Right Click " + ChatColor.GREEN + "a Block" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Set the first and second position of ", ChatColor.GRAY + "your Claim selection.", "", ChatColor.AQUA + "Right Click " + ChatColor.GREEN + "the Air" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Clear your current Claim selection.", "", ChatColor.YELLOW + "Shift " + ChatColor.AQUA + "Left Click " + ChatColor.GREEN + "the Air or a Block" + ChatColor.AQUA + " to:", ChatColor.GRAY + "Purchase your current Claim selection.").build();
        MIN_SUBCLAIM_RADIUS = HCF.getPlugin().getConfig().getInt("settings.min_subclaim_radius");
        MIN_CLAIM_RADIUS = HCF.getPlugin().getConfig().getInt("settings.min_claim_radius");
        MAX_CHUNKS_PER_LIMIT = HCF.getPlugin().getConfig().getInt("settings.max_chunks_per_limit");
        CLAIM_BUFFER_RADIUS = HCF.getPlugin().getConfig().getInt("settings.claim_buffer_radius");
        CLAIM_PRICE_PER_BLOCK = HCF.getPlugin().getConfig().getDouble("settings.claim_price_per_block");
    }
}
