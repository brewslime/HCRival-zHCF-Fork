package com.hcrival.hcf.faction;

import org.bukkit.configuration.serialization.*;
import com.hcrival.hcf.faction.struct.*;
import org.bukkit.entity.*;
import com.hcrival.base.*;
import org.bukkit.*;
import java.util.*;

public class FactionMember implements ConfigurationSerializable
{
    private final UUID uniqueID;
    private ChatChannel chatChannel;
    private Role role;
    
    public FactionMember(final Player player, final ChatChannel chatChannel, final Role role) {
        this.uniqueID = player.getUniqueId();
        this.chatChannel = chatChannel;
        this.role = role;
    }
    
    public FactionMember(final Map<String, Object> map) {
        this.uniqueID = UUID.fromString(map.get("uniqueID"));
        this.chatChannel = GuavaCompat.getIfPresent(ChatChannel.class, map.get("chatChannel")).or(ChatChannel.PUBLIC);
        this.role = GuavaCompat.getIfPresent(Role.class, map.get("role")).or(Role.MEMBER);
    }
    
    public Map<String, Object> serialize() {
        final Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("uniqueID", this.uniqueID.toString());
        map.put("chatChannel", this.chatChannel.name());
        map.put("role", this.role.name());
        return map;
    }
    
    public String getName() {
        final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(this.uniqueID);
        return (offlinePlayer.hasPlayedBefore() || offlinePlayer.isOnline()) ? offlinePlayer.getName() : null;
    }
    
    public UUID getUniqueId() {
        return this.uniqueID;
    }
    
    public ChatChannel getChatChannel() {
        return this.chatChannel;
    }
    
    public void setChatChannel(final ChatChannel chatChannel) {
        Objects.requireNonNull(chatChannel, "ChatChannel cannot be null");
        this.chatChannel = chatChannel;
    }
    
    public Role getRole() {
        return this.role;
    }
    
    public void setRole(final Role role) {
        this.role = role;
    }
    
    public Player toOnlinePlayer() {
        return Bukkit.getPlayer(this.uniqueID);
    }
}
