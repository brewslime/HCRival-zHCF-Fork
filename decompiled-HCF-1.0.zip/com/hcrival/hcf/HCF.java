package com.hcrival.hcf;

import org.bukkit.plugin.java.*;
import com.google.common.base.*;
import com.hcrival.hcf.configs.*;
import com.hcrival.hcf.loggers.*;
import com.hcrival.hcf.classes.bard.*;
import com.hcrival.hcf.events.crate.*;
import com.hcrival.hcf.classes.*;
import com.sk89q.worldedit.bukkit.*;
import org.bukkit.configuration.file.*;
import org.bukkit.inventory.*;
import com.hcrival.util.itemdb.*;
import com.hcrival.util.chat.*;
import java.io.*;
import com.hcrival.util.*;
import org.bukkit.configuration.serialization.*;
import com.hcrival.util.cuboid.*;
import java.util.concurrent.*;
import org.bukkit.scheduler.*;
import com.hcrival.hcf.nametags.*;
import net.frozenorb.qlib.nametag.*;
import com.hcrival.hcf.scoreboard.*;
import net.frozenorb.qlib.scoreboard.*;
import com.hcrival.hcf.tab.*;
import net.frozenorb.qlib.tab.*;
import us.hcrealms.chronium.*;
import java.util.function.*;
import java.util.stream.*;
import org.apache.commons.lang.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import com.hcrival.hcf.user.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.event.*;
import com.hcrival.hcf.deathban.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.hcf.visualise.*;
import com.hcrival.hcf.listener.*;
import com.hcrival.hcf.listener.fixes.*;
import org.bukkit.plugin.*;
import com.hcrival.hcf.events.conquest.*;
import com.hcrival.hcf.events.eotw.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.events.koth.*;
import com.hcrival.hcf.timer.sotw.*;
import com.hcrival.hcf.command.links.*;
import com.hcrival.hcf.reclaim.*;
import com.hcrival.hcf.deathban.commands.*;
import com.hcrival.hcf.deathban.commands.lives.*;
import com.hcrival.hcf.timer.custom.*;
import com.hcrival.hcf.command.*;
import java.util.*;
import org.bukkit.command.*;
import com.hcrival.hcf.economy.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.hcf.kit.*;
import com.hcrival.hcf.timer.*;

public class HCF extends JavaPlugin
{
    public static final Joiner SPACE_JOINER;
    public static final Joiner COMMA_JOINER;
    private static HCF plugin;
    private Random random;
    private MessageConfig messageConfig;
    private SecondaryConfigFile reclaimConfig;
    private Reclaim reclaim;
    private ClaimHandler claimHandler;
    private CombatLogListener combatLogListener;
    private EconomyManager economyManager;
    private EffectRestorer effectRestorer;
    private EotwHandler eotwHandler;
    private EventScheduler eventScheduler;
    private FactionManager factionManager;
    private ImageFolder imageFolder;
    private KeyManager keyManager;
    private PvpClassManager pvpClassManager;
    private SotwTimer sotwTimer;
    private TimerManager timerManager;
    private UserManager userManager;
    private KitManager kitManager;
    private VisualiseHandler visualiseHandler;
    private WorldEditPlugin worldEdit;
    private FreezeListener freezeListener;
    private StaffModeListener staffModeListener;
    private boolean paperPatch;
    private YamlConfiguration tabConfig;
    private ItemDb itemDb;
    private SignHandler signHandler;
    private MojangLang language;
    private SecondaryConfigFile deathbanConfig;
    private LicenseUtil licenseUtil;
    private HashMap<UUID, Inventory> inventoryRestore;
    public File tabFile;
    private boolean configurationLoaded;
    
    public HCF() {
        this.random = new Random();
        this.licenseUtil = new LicenseUtil();
        this.inventoryRestore = new HashMap<UUID, Inventory>();
        this.tabFile = new File(this.getDataFolder(), "tab.yml");
        this.configurationLoaded = true;
    }
    
    public void onEnable() {
        (HCF.plugin = this).registerConfiguration();
        this.saveDefaultConfig();
        if (getPlugin().getLicenseUtil().checkLicense(this.getConfig().getString("server.license_key"), "zHCF")) {
            if (!this.configurationLoaded) {
                this.getLogger().severe("Disabling plugin..");
                this.setEnabled(false);
                return;
            }
            this.itemDb = new SimpleItemDb(this);
            this.signHandler = new SignHandler(this);
            this.language = new HttpMojangLang();
            try {
                Lang.initialize("en_US");
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
            ConfigurationSerialization.registerClass((Class)PersistableLocation.class);
            ConfigurationSerialization.registerClass((Class)Cuboid.class);
            ConfigurationSerialization.registerClass((Class)NamedCuboid.class);
            DateTimeFormats.reload(TimeZone.getTimeZone(HCF.plugin.getConfig().getString("settings.timezone")));
            final Plugin wep = this.getServer().getPluginManager().getPlugin("WorldEdit");
            this.worldEdit = ((wep instanceof WorldEditPlugin && wep.isEnabled()) ? ((WorldEditPlugin)wep) : null);
            if (this.getServer().getPluginManager().getPlugin("Chronium") == null) {
                this.getLogger().severe("rCore dependency not found!");
                this.getLogger().severe("Disabling plugin...");
                this.getServer().getPluginManager().disablePlugin((Plugin)this);
            }
            if (this.getServer().getPluginManager().getPlugin("qLib") == null) {
                this.getLogger().severe("qLib dependency not found!");
                this.getLogger().severe("Disabling plugin...");
                this.getServer().getPluginManager().disablePlugin((Plugin)this);
            }
            this.registerSerialization();
            this.registerCommands();
            this.registerManagers();
            this.registerListeners();
            this.paperPatch = false;
            final long dataSaveInterval = TimeUnit.MINUTES.toMillis(20L);
            new BukkitRunnable() {
                public void run() {
                    HCF.this.saveData();
                }
            }.runTaskTimerAsynchronously((Plugin)this, dataSaveInterval, dataSaveInterval);
            ProtocolLibHook.hook(this);
            FrozenNametagHandler.registerProvider((NametagProvider)new HCFNametagsProvider());
            FrozenScoreboardHandler.setConfiguration(HCFScoreboardConfiguration.create());
            FrozenTabHandler.setLayoutProvider((LayoutProvider)new HCFTabLayoutProvider());
            new BukkitRunnable() {
                public void run() {
                    final List<String> onlineMythicUsers = HCF.this.getServer().getOnlinePlayers().stream().filter(o -> ChroniumAPI.getRankOfPlayer(o).getDisplayName().equalsIgnoreCase("King")).map((Function<? super Object, ?>)CommandSender::getName).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
                    if (!onlineMythicUsers.isEmpty()) {
                        HCF.this.getServer().broadcastMessage(ChatColor.GRAY + "");
                        HCF.this.getServer().broadcastMessage(Color.translate("&3&lOnline King Users � &f" + StringUtils.join((Collection)onlineMythicUsers, ", ")));
                        HCF.this.getServer().broadcastMessage(Color.translate("&7You can purchase the King rank at &7&ostore.hcrival.com"));
                        HCF.this.getServer().broadcastMessage(ChatColor.GRAY + "");
                    }
                }
            }.runTaskTimerAsynchronously((Plugin)this, 600L, 3600L);
            new Metrics((Plugin)this);
            System.out.println("-------------------------");
            System.out.println("License '" + this.getConfig().getString("server.license_key") + "' is valid!");
            System.out.println("Thank you for purchasing HCF!");
            System.out.println("Need help? Join the Alpha Development Discord - http://alphadev.pw/discord");
            System.out.println("-------------------------");
        }
        else {
            System.out.println("-------------------------");
            System.out.println("License '" + this.getConfig().getString("server.license_key") + "' is not valid!");
            System.out.println("If you believe this is an error, please contact the Alpha Development Team.");
            System.out.println("Discord - http://alphadev.pw/discord");
            System.out.println("Disabling plugin...");
            System.out.println("-------------------------");
            Bukkit.getServer().getPluginManager().disablePlugin((Plugin)this);
        }
    }
    
    public void saveData() {
        if (this.economyManager != null) {
            this.economyManager.saveEconomyData();
        }
        if (this.factionManager != null) {
            this.factionManager.saveFactionData();
        }
        if (this.keyManager != null) {
            this.keyManager.saveKeyData();
        }
        if (this.timerManager != null) {
            this.timerManager.saveTimerData();
        }
        if (this.userManager != null) {
            this.userManager.saveUserData();
        }
        if (this.kitManager != null) {
            this.kitManager.saveKitData();
        }
    }
    
    public void onDisable() {
        if (!this.configurationLoaded) {
            return;
        }
        if (this.combatLogListener != null) {
            this.combatLogListener.removeCombatLoggers();
        }
        if (this.pvpClassManager != null) {
            this.pvpClassManager.onDisable();
        }
        this.saveData();
        HCF.plugin = null;
    }
    
    private void registerConfiguration() {
        this.messageConfig = new MessageConfig();
        this.reclaimConfig = new SecondaryConfigFile(this, "reclaims", this.getDataFolder().getAbsolutePath());
        this.deathbanConfig = new SecondaryConfigFile(this, "deathbans", this.getDataFolder().getAbsolutePath());
        if (!this.tabFile.exists()) {
            this.saveResource("tab.yml", false);
        }
        if (!new File(this.getDataFolder(), "event-schedules.txt").exists()) {
            this.saveResource("event-schedules.txt", false);
        }
        this.tabConfig = YamlConfiguration.loadConfiguration(this.tabFile);
    }
    
    private void registerSerialization() {
        ConfigurationSerialization.registerClass((Class)CaptureZone.class);
        ConfigurationSerialization.registerClass((Class)Claim.class);
        ConfigurationSerialization.registerClass((Class)Subclaim.class);
        ConfigurationSerialization.registerClass((Class)Kit.class);
        ConfigurationSerialization.registerClass((Class)FactionUser.class);
        ConfigurationSerialization.registerClass((Class)ClaimableFaction.class);
        ConfigurationSerialization.registerClass((Class)ConquestFaction.class);
        ConfigurationSerialization.registerClass((Class)CapturableFaction.class);
        ConfigurationSerialization.registerClass((Class)KothFaction.class);
        ConfigurationSerialization.registerClass((Class)EndPortalFaction.class);
        ConfigurationSerialization.registerClass((Class)Faction.class);
        ConfigurationSerialization.registerClass((Class)FactionMember.class);
        ConfigurationSerialization.registerClass((Class)PlayerFaction.class);
        ConfigurationSerialization.registerClass((Class)RoadFaction.class);
        ConfigurationSerialization.registerClass((Class)SpawnFaction.class);
        ConfigurationSerialization.registerClass((Class)RoadFaction.NorthRoadFaction.class);
        ConfigurationSerialization.registerClass((Class)RoadFaction.EastRoadFaction.class);
        ConfigurationSerialization.registerClass((Class)RoadFaction.SouthRoadFaction.class);
        ConfigurationSerialization.registerClass((Class)RoadFaction.WestRoadFaction.class);
    }
    
    private void registerListeners() {
        final PluginManager manager = this.getServer().getPluginManager();
        this.freezeListener = new FreezeListener();
        this.staffModeListener = new StaffModeListener();
        manager.registerEvents((Listener)new CobbleCommand(), (Plugin)this);
        manager.registerEvents((Listener)new BlockJumpGlitchFixListener(), (Plugin)this);
        manager.registerEvents((Listener)new BoatGlitchFixListener(this), (Plugin)this);
        manager.registerEvents((Listener)new BookDisenchantListener(this), (Plugin)this);
        manager.registerEvents((Listener)new BottledExpListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ChatListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ClaimWandListener(this), (Plugin)this);
        manager.registerEvents((Listener)(this.combatLogListener = new CombatLogListener(this)), (Plugin)this);
        manager.registerEvents((Listener)new CoreListener(this), (Plugin)this);
        manager.registerEvents((Listener)new CrowbarListener(this), (Plugin)this);
        manager.registerEvents((Listener)new DeathListener(this), (Plugin)this);
        if (!getPlugin().getConfig().getBoolean("server.kitmap")) {
            manager.registerEvents((Listener)new DeathbanListener(), (Plugin)this);
        }
        manager.registerEvents((Listener)new EnchantLimitListener(this), (Plugin)this);
        manager.registerEvents((Listener)new EnderChestRemovalListener(this), (Plugin)this);
        manager.registerEvents((Listener)new EntityLimitListener(this), (Plugin)this);
        manager.registerEvents((Listener)new EotwListener(this), (Plugin)this);
        manager.registerEvents((Listener)new EventSignListener(), (Plugin)this);
        manager.registerEvents((Listener)new ElevatorListener(), (Plugin)this);
        manager.registerEvents((Listener)new FactionListener(this), (Plugin)this);
        manager.registerEvents((Listener)new FurnaceSmeltSpeedListener(this), (Plugin)this);
        if (this.getConfig().getBoolean("settings.enderpearl_glitch_listener")) {
            manager.registerEvents((Listener)new PearlGlitchListener(this), (Plugin)this);
        }
        manager.registerEvents((Listener)new PortalListener(this), (Plugin)this);
        manager.registerEvents((Listener)new PotionLimitListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ProtectionListener(this), (Plugin)this);
        manager.registerEvents((Listener)new SubclaimWandListener(this), (Plugin)this);
        manager.registerEvents((Listener)new SignSubclaimListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ShopSignListener(this), (Plugin)this);
        manager.registerEvents((Listener)new SkullListener(), (Plugin)this);
        manager.registerEvents((Listener)new SotwListener(this), (Plugin)this);
        manager.registerEvents((Listener)new BeaconStrengthFixListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ArmorDurabilityFix(), (Plugin)this);
        manager.registerEvents((Listener)new VoidGlitchFixListener(), (Plugin)this);
        manager.registerEvents((Listener)new WallBorderListener(this), (Plugin)this);
        manager.registerEvents((Listener)new WorldListener(), (Plugin)this);
        manager.registerEvents((Listener)new KitListener(this), (Plugin)this);
        manager.registerEvents((Listener)new DeathMessageListener(this), (Plugin)this);
        manager.registerEvents((Listener)new ColorSignListener(), (Plugin)this);
        manager.registerEvents((Listener)new SubclaimListener(this), (Plugin)this);
        manager.registerEvents((Listener)this.licenseUtil, (Plugin)this);
        if (this.getConfig().getBoolean("settings.strength_fix")) {
            manager.registerEvents((Listener)new StrengthFixListener(), (Plugin)this);
        }
    }
    
    private void registerCommands() {
        this.getCommand("chest").setExecutor((CommandExecutor)new ChestCommand());
        this.getCommand("conquest").setExecutor((CommandExecutor)new ConquestExecutor(this));
        this.getCommand("economy").setExecutor((CommandExecutor)new EconomyCommand(this));
        this.getCommand("eotw").setExecutor((CommandExecutor)new EotwCommand(this));
        this.getCommand("event").setExecutor((CommandExecutor)new EventExecutor(this));
        this.getCommand("faction").setExecutor((CommandExecutor)new FactionExecutor(this));
        this.getCommand("gopple").setExecutor((CommandExecutor)new GoppleCommand(this));
        this.getCommand("koth").setExecutor((CommandExecutor)new KothExecutor(this));
        this.getCommand("logout").setExecutor((CommandExecutor)new LogoutCommand(this));
        this.getCommand("mapkit").setExecutor((CommandExecutor)new MapKitCommand(this));
        this.getCommand("pay").setExecutor((CommandExecutor)new PayCommand(this));
        this.getCommand("pvptimer").setExecutor((CommandExecutor)new PvpTimerCommand(this));
        this.getCommand("regen").setExecutor((CommandExecutor)new RegenCommand(this));
        this.getCommand("servertime").setExecutor((CommandExecutor)new ServerTimeCommand(this));
        this.getCommand("sotw").setExecutor((CommandExecutor)new SotwCommand(this));
        this.getCommand("panic").setExecutor((CommandExecutor)new PanicCommand());
        this.getCommand("togglecapzoneentry").setExecutor((CommandExecutor)new ToggleCapzoneEntryCommand(this));
        this.getCommand("togglelightning").setExecutor((CommandExecutor)new ToggleLightningCommand(this));
        this.getCommand("savedata").setExecutor((CommandExecutor)new SaveDataCommand(this));
        this.getCommand("craft").setExecutor((CommandExecutor)new CraftCommand());
        this.getCommand("rename").setExecutor((CommandExecutor)new RenameCommand());
        this.getCommand("kit").setExecutor((CommandExecutor)new KitExecutor(this));
        this.getCommand("teleport").setExecutor((CommandExecutor)new TeleportCommand());
        this.getCommand("gamemode").setExecutor((CommandExecutor)new GamemodeCommand());
        this.getCommand("freeze").setExecutor((CommandExecutor)new FreezeCommand());
        this.getCommand("vanish").setExecutor((CommandExecutor)new VanishCommand());
        this.getCommand("staff").setExecutor((CommandExecutor)new StaffModeCommand());
        this.getCommand("broadcast").setExecutor((CommandExecutor)new BroadcastCommand());
        this.getCommand("sounds").setExecutor((CommandExecutor)new ToggleSoundsCommand(this));
        this.getCommand("togglemessages").setExecutor((CommandExecutor)new ToggleMessagesCommand(this));
        this.getCommand("reply").setExecutor((CommandExecutor)new ReplyCommand(this));
        this.getCommand("message").setExecutor((CommandExecutor)new MessageCommand(this));
        this.getCommand("tl").setExecutor((CommandExecutor)new TeamCoordinatesCommand());
        this.getCommand("spawn").setExecutor((CommandExecutor)new SpawnCommand());
        this.getCommand("cobble").setExecutor((CommandExecutor)new CobbleCommand());
        this.getCommand("invsee").setExecutor((CommandExecutor)new InvseeCommand());
        this.getCommand("hidestaff").setExecutor((CommandExecutor)new HideStaffCommand());
        this.getCommand("lff").setExecutor((CommandExecutor)new LFFCommand());
        this.getCommand("autorestart").setExecutor((CommandExecutor)new AutoRestartCommand());
        this.getCommand("teamspeak").setExecutor((CommandExecutor)new TeamspeakCommand());
        this.getCommand("discord").setExecutor((CommandExecutor)new DiscordCommand());
        this.getCommand("website").setExecutor((CommandExecutor)new WebsiteCommand());
        this.getCommand("panic").setExecutor((CommandExecutor)new PanicCommand());
        this.getCommand("rawbc").setExecutor((CommandExecutor)new RawCommand());
        this.getCommand("tpall").setExecutor((CommandExecutor)new TpallCommand());
        this.getCommand("tphere").setExecutor((CommandExecutor)new TphereCommand());
        this.getCommand("tppos").setExecutor((CommandExecutor)new TpposCommand());
        this.getCommand("timer").setExecutor((CommandExecutor)new TimerExecutor(this));
        this.getCommand("feed").setExecutor((CommandExecutor)new FeedCommand());
        this.getCommand("kill").setExecutor((CommandExecutor)new KillCommand());
        this.getCommand("reclaim").setExecutor((CommandExecutor)new ReclaimCommand());
        this.getCommand("help").setExecutor((CommandExecutor)new HelpCommand());
        this.getCommand("coords").setExecutor((CommandExecutor)new CoordsCommand());
        this.getCommand("staffrevive").setExecutor((CommandExecutor)new StaffRevive());
        this.getCommand("lives").setExecutor((CommandExecutor)new LivesExecutor(this));
        this.getCommand("customtimer").setExecutor((CommandExecutor)new CustomTimerCommand());
        this.getCommand("focus").setExecutor((CommandExecutor)new FocusCommand());
        final Map<String, Map<String, Object>> map = (Map<String, Map<String, Object>>)this.getDescription().getCommands();
        for (final Map.Entry<String, Map<String, Object>> entry : map.entrySet()) {
            if (!entry.getKey().equalsIgnoreCase("zhcf")) {
                final PluginCommand command = this.getCommand((String)entry.getKey());
                command.setPermission("hcf.command." + entry.getKey());
                command.setPermissionMessage(ChatColor.RED + "No permission.");
            }
        }
    }
    
    private void registerManagers() {
        this.claimHandler = new ClaimHandler(this);
        this.economyManager = new FlatFileEconomyManager(this);
        this.effectRestorer = new EffectRestorer(this);
        this.eotwHandler = new EotwHandler(this);
        this.eventScheduler = new EventScheduler(this);
        this.factionManager = new FlatFileFactionManager(this);
        this.imageFolder = new ImageFolder(this);
        this.keyManager = new KeyManager(this);
        this.kitManager = new FlatFileKitManager(this);
        this.pvpClassManager = new PvpClassManager(this);
        this.sotwTimer = new SotwTimer();
        this.timerManager = new TimerManager(this);
        this.userManager = new UserManager(this);
        this.visualiseHandler = new VisualiseHandler();
        this.reclaim = new Reclaim();
        for (final Timer timer : this.timerManager.getTimers()) {
            if (this.getConfig().getString("timers." + timer.getName()) == null) {
                this.getConfig().set("timers." + timer.getName(), (Object)("&a&l" + timer.getDisplayName() + "&7: &f%remaining%"));
                this.saveConfig();
                this.reloadConfig();
            }
        }
    }
    
    public HashMap<UUID, Inventory> getInventoryRestore() {
        return this.inventoryRestore;
    }
    
    public File getTabFile() {
        return this.tabFile;
    }
    
    public boolean isConfigurationLoaded() {
        return this.configurationLoaded;
    }
    
    public static HCF getPlugin() {
        return HCF.plugin;
    }
    
    public Random getRandom() {
        return this.random;
    }
    
    public MessageConfig getMessageConfig() {
        return this.messageConfig;
    }
    
    public SecondaryConfigFile getReclaimConfig() {
        return this.reclaimConfig;
    }
    
    public Reclaim getReclaim() {
        return this.reclaim;
    }
    
    public ClaimHandler getClaimHandler() {
        return this.claimHandler;
    }
    
    public CombatLogListener getCombatLogListener() {
        return this.combatLogListener;
    }
    
    public EconomyManager getEconomyManager() {
        return this.economyManager;
    }
    
    public EffectRestorer getEffectRestorer() {
        return this.effectRestorer;
    }
    
    public EotwHandler getEotwHandler() {
        return this.eotwHandler;
    }
    
    public EventScheduler getEventScheduler() {
        return this.eventScheduler;
    }
    
    public FactionManager getFactionManager() {
        return this.factionManager;
    }
    
    public ImageFolder getImageFolder() {
        return this.imageFolder;
    }
    
    public KeyManager getKeyManager() {
        return this.keyManager;
    }
    
    public PvpClassManager getPvpClassManager() {
        return this.pvpClassManager;
    }
    
    public SotwTimer getSotwTimer() {
        return this.sotwTimer;
    }
    
    public TimerManager getTimerManager() {
        return this.timerManager;
    }
    
    public UserManager getUserManager() {
        return this.userManager;
    }
    
    public KitManager getKitManager() {
        return this.kitManager;
    }
    
    public VisualiseHandler getVisualiseHandler() {
        return this.visualiseHandler;
    }
    
    public WorldEditPlugin getWorldEdit() {
        return this.worldEdit;
    }
    
    public FreezeListener getFreezeListener() {
        return this.freezeListener;
    }
    
    public StaffModeListener getStaffModeListener() {
        return this.staffModeListener;
    }
    
    public boolean isPaperPatch() {
        return this.paperPatch;
    }
    
    public YamlConfiguration getTabConfig() {
        return this.tabConfig;
    }
    
    public ItemDb getItemDb() {
        return this.itemDb;
    }
    
    public SignHandler getSignHandler() {
        return this.signHandler;
    }
    
    public MojangLang getLanguage() {
        return this.language;
    }
    
    public SecondaryConfigFile getDeathbanConfig() {
        return this.deathbanConfig;
    }
    
    public LicenseUtil getLicenseUtil() {
        return this.licenseUtil;
    }
    
    static {
        SPACE_JOINER = Joiner.on(' ');
        COMMA_JOINER = Joiner.on(", ");
    }
}
