package com.hcrival.hcf.listener;

import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.*;
import java.util.*;

public class HideStaffListener
{
    public static List<Player> staff;
    public static HashMap<Player, Boolean> showStaff;
    
    public static void getStaff() {
        for (final Player players : Bukkit.getOnlinePlayers()) {
            if (HCF.getPlugin().getStaffModeListener().isStaffModeActive(players)) {
                HideStaffListener.staff.add(players);
            }
        }
    }
    
    public static boolean showStaffEnabled(final Player player) {
        if (HideStaffListener.showStaff.containsKey(player)) {
            if (!HideStaffListener.showStaff.get(player)) {
                return false;
            }
            if (HideStaffListener.showStaff.get(player)) {}
        }
        return true;
    }
    
    static {
        HideStaffListener.staff = new ArrayList<Player>();
        HideStaffListener.showStaff = new HashMap<Player, Boolean>();
    }
}
