package com.hcrival.hcf.listener;

import org.bukkit.event.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;
import org.bukkit.block.*;

public class SkullListener implements Listener
{
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void dropPlayerSkull(final PlayerDeathEvent event) {
        final Player player = event.getEntity();
        final Player killer = player.getKiller();
        if (killer != null && killer.hasPermission("hcf.kill.behead")) {
            final ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
            final SkullMeta meta = (SkullMeta)skull.getItemMeta();
            meta.setOwner(player.getName());
            skull.setItemMeta((ItemMeta)meta);
            event.getDrops().add(skull);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void showPlayerSkullInformation(final PlayerInteractEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getClickedBlock();
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && block.getState() instanceof Skull) {
            final Skull skull = (Skull)block.getState();
            if (skull.getSkullType() == SkullType.PLAYER) {
                player.sendMessage(ChatColor.YELLOW + "This is the skull of " + skull.getOwner());
            }
        }
    }
}
