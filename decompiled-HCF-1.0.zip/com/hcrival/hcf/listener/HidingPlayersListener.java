package com.hcrival.hcf.listener;

import com.hcrival.hcf.faction.event.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

public class HidingPlayersListener implements Listener
{
    @EventHandler
    public void onClaimChange(final PlayerClaimEnterEvent e) {
        if (e.getFromFaction() != null && e.getFromFaction() instanceof SpawnFaction && !(e.getToFaction() instanceof SpawnFaction)) {
            final Player p = e.getPlayer();
            if (!HCF.getPlugin().getStaffModeListener().isVanished(p)) {
                for (final Player all : Bukkit.getOnlinePlayers()) {
                    all.showPlayer(p);
                }
            }
        }
        else if (e.getToFaction() != null && e.getToFaction() instanceof SpawnFaction && !(e.getFromFaction() instanceof SpawnFaction)) {
            final Player p = e.getPlayer();
            for (final Player all : Bukkit.getOnlinePlayers()) {
                all.hidePlayer(p);
            }
        }
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        boolean hide = false;
        if (HCF.getPlugin().getFactionManager().getClaimAt(p.getLocation()) != null && HCF.getPlugin().getFactionManager().getClaimAt(p.getLocation()).getFaction() instanceof SpawnFaction) {
            hide = true;
        }
        for (final Player all : Bukkit.getOnlinePlayers()) {
            if (hide) {
                all.hidePlayer(p);
            }
            if (HCF.getPlugin().getFactionManager().getClaimAt(all.getLocation()) != null && HCF.getPlugin().getFactionManager().getClaimAt(all.getLocation()).getFaction() instanceof SpawnFaction) {
                p.hidePlayer(all);
            }
        }
    }
}
