package com.hcrival.hcf.listener;

import org.bukkit.event.block.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class ColorSignListener implements Listener
{
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onSignCreate(final SignChangeEvent event) {
        final Player player = event.getPlayer();
        if (player != null && player.hasPermission("hcf.listener.sign.admin")) {
            final String[] lines = event.getLines();
            for (int i = 0; i < lines.length; ++i) {
                if (!player.hasPermission("hcf.listener.sign.admin") && (event.getLine(i).contains(ChatColor.translateAlternateColorCodes('&', "Sell")) || event.getLine(i).contains("Buy"))) {
                    player.sendMessage(ChatColor.RED + "Buy/Sell signs can only be placed by staff.");
                    event.setCancelled(true);
                }
                event.setLine(i, ChatColor.translateAlternateColorCodes('&', lines[i]));
            }
        }
    }
}
