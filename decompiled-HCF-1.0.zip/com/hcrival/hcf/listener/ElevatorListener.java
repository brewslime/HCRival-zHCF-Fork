package com.hcrival.hcf.listener;

import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.block.*;

public class ElevatorListener implements Listener
{
    String elevatorsign;
    
    public ElevatorListener() {
        this.elevatorsign = ChatColor.translateAlternateColorCodes('&', "&9[Elevator]");
    }
    
    @EventHandler
    public void signPlace(final SignChangeEvent event) {
        if (event.getLine(0).equalsIgnoreCase("[Elevator]") && event.getLine(1).equalsIgnoreCase("Up")) {
            event.setLine(0, ChatColor.translateAlternateColorCodes('&', "" + this.elevatorsign));
            event.setLine(1, ChatColor.translateAlternateColorCodes('&', "Up"));
        }
        if (event.getLine(0).equalsIgnoreCase("[Elevator]") && event.getLine(1).equalsIgnoreCase("Down")) {
            event.setLine(0, ChatColor.translateAlternateColorCodes('&', "" + this.elevatorsign));
            event.setLine(1, ChatColor.translateAlternateColorCodes('&', "Down"));
        }
    }
    
    @EventHandler
    public void onClick(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            final Player player = event.getPlayer();
            final Block block = event.getClickedBlock();
            if (block.getType() == Material.SIGN || block.getType() == Material.SIGN_POST || block.getType() == Material.WALL_SIGN) {
                final Sign sign = (Sign)block.getState();
                if (sign.getLine(0).equalsIgnoreCase(this.elevatorsign)) {
                    final Location loc = block.getLocation();
                    if (sign.getLine(1).equalsIgnoreCase("Up")) {
                        while (true) {
                            final Location location1 = loc.add(0.0, 1.0, 0.0);
                            final Location location2 = loc.add(0.0, 1.0, 0.0);
                            if (location1.getY() >= 250.0) {
                                break;
                            }
                            if (location1.getBlock().getType() == Material.AIR && location2.getBlock().getType() == Material.AIR) {
                                player.teleport(new Location(location1.getWorld(), location1.getBlockX() + 0.5, location1.getBlockY() - 1.0, location1.getBlockZ() + 0.5));
                                break;
                            }
                        }
                    }
                    if (sign.getLine(1).equalsIgnoreCase("Down")) {
                        while (true) {
                            final Location location1 = loc.subtract(0.0, 1.0, 0.0);
                            final Location location2 = loc.subtract(0.0, 1.0, 0.0);
                            if (location1.getY() <= 0.0) {
                                break;
                            }
                            if (location1.getBlock().getType() == Material.AIR && location2.getBlock().getType() == Material.AIR) {
                                player.teleport(new Location(location2.getWorld(), location2.getBlockX() + 0.5, location2.getBlockY() - 1.0, location2.getBlockZ() + 0.5));
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
}
