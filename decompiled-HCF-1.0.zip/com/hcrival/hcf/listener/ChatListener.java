package com.hcrival.hcf.listener;

import java.util.regex.*;
import com.hcrival.hcf.*;
import com.google.common.collect.*;
import org.bukkit.event.player.*;
import org.apache.commons.lang.*;
import com.hcrival.hcf.faction.struct.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.event.*;
import java.util.*;
import org.bukkit.command.*;
import org.bukkit.event.*;

public class ChatListener implements Listener
{
    private static String DOUBLE_POST_BYPASS_PERMISSION;
    private static Pattern PATTERN;
    private Map<UUID, String> messageHistory;
    private HCF plugin;
    
    public ChatListener(final HCF plugin) {
        this.plugin = plugin;
        this.messageHistory = (Map<UUID, String>)new MapMaker().makeMap();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerChat(final AsyncPlayerChatEvent event) {
        String message = event.getMessage();
        final Player player = event.getPlayer();
        final String lastMessage = this.messageHistory.get(player.getUniqueId());
        final String cleanedMessage = ChatListener.PATTERN.matcher(message).replaceAll("");
        if (lastMessage != null && (message.equals(lastMessage) || StringUtils.getLevenshteinDistance(cleanedMessage, lastMessage) <= 1) && !player.hasPermission(ChatListener.DOUBLE_POST_BYPASS_PERMISSION)) {
            player.sendMessage(ChatColor.RED + "Please, do not double post.");
            event.setCancelled(true);
            return;
        }
        this.messageHistory.put(player.getUniqueId(), cleanedMessage);
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        final ChatChannel chatChannel = (playerFaction == null) ? ChatChannel.PUBLIC : playerFaction.getMember(player).getChatChannel();
        final Set<Player> recipients = (Set<Player>)event.getRecipients();
        if (chatChannel == ChatChannel.FACTION || chatChannel == ChatChannel.ALLIANCE) {
            if (!this.isGlobalChannel(message)) {
                final Collection<Player> online = playerFaction.getOnlinePlayers();
                if (chatChannel == ChatChannel.ALLIANCE) {
                    final Collection<PlayerFaction> allies = playerFaction.getAlliedFactions();
                    for (final PlayerFaction ally : allies) {
                        online.addAll(ally.getOnlinePlayers());
                    }
                }
                recipients.retainAll(online);
                event.setFormat(chatChannel.getRawFormat(player));
                Bukkit.getPluginManager().callEvent((Event)new FactionChatEvent(true, playerFaction, player, chatChannel, (Collection<? extends CommandSender>)recipients, event.getMessage()));
                return;
            }
            message = message.substring(1, message.length()).trim();
            event.setMessage(message);
        }
        event.setCancelled(true);
        final ConsoleCommandSender console = Bukkit.getConsoleSender();
        console.sendMessage(this.getFormattedMessage(player, playerFaction, message, (CommandSender)console));
        for (final Player recipient : event.getRecipients()) {
            recipient.sendMessage(this.getFormattedMessage(player, playerFaction, message, (CommandSender)recipient));
        }
    }
    
    private String getFormattedMessage(final Player player, final PlayerFaction playerFaction, final String message, final CommandSender viewer) {
        final String displayName = player.getDisplayName();
        final String tag = (playerFaction == null) ? (ChatColor.RED + "*") : playerFaction.getDisplayName(viewer);
        return ChatColor.DARK_GRAY + "[" + tag + ChatColor.DARK_GRAY + "] " + displayName + ChatColor.GRAY + ": " + ChatColor.RESET + message;
    }
    
    private boolean isGlobalChannel(final String input) {
        final int length = input.length();
        if (length <= 1 || !input.startsWith("!")) {
            return false;
        }
        int i = 1;
        while (i < length) {
            final char character = input.charAt(i);
            if (character == ' ') {
                ++i;
            }
            else {
                if (character == '/') {
                    return false;
                }
                break;
            }
        }
        return true;
    }
    
    static {
        ChatListener.DOUBLE_POST_BYPASS_PERMISSION = "hcf.doublepost.bypass";
        ChatListener.PATTERN = Pattern.compile("\\W");
    }
}
