package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.inventory.*;
import org.bukkit.plugin.*;
import org.bukkit.inventory.*;
import org.bukkit.block.*;
import org.bukkit.event.*;
import org.bukkit.*;
import org.bukkit.potion.*;
import java.util.regex.*;
import java.util.*;

public class PotionLimitListener implements Listener
{
    private static final int EMPTY_BREW_TIME = 400;
    private final HCF plugin;
    
    public PotionLimitListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBrew(final BrewEvent event) {
        if (this.plugin.isPaperPatch()) {
            if (!this.testValidity(event.getContents().getContents())) {
                event.setCancelled(true);
                event.getContents().getHolder().setBrewingTime(400);
            }
            return;
        }
        final BrewerInventory inventory = event.getContents();
        final ItemStack[] contents = inventory.getContents();
        final int length = contents.length;
        final ItemStack[] cloned = new ItemStack[length];
        for (int i = 0; i < length; ++i) {
            final ItemStack previous = contents[i];
            cloned[i] = ((previous == null) ? null : previous.clone());
        }
        final BrewingStand stand = inventory.getHolder();
        final BrewerInventory brewerInventory;
        final BrewingStand brewingStand;
        final ItemStack[] contents2;
        Bukkit.getScheduler().runTask((Plugin)HCF.getPlugin(), () -> {
            if (!this.testValidity(brewerInventory.getContents())) {
                brewingStand.setBrewingTime(400);
                brewerInventory.setContents(contents2);
            }
        });
    }
    
    private boolean testValidity(final ItemStack[] contents) {
        for (final ItemStack stack : contents) {
            if (stack != null && stack.getType() == Material.POTION && stack.getDurability() != 0) {
                final Potion potion = Potion.fromItemStack(stack);
                if (potion != null) {
                    final PotionType type = potion.getType();
                    if (type != null) {
                        if (type != PotionType.POISON || potion.hasExtendedDuration() || potion.getLevel() != 1) {
                            final String ench = potion.getType().name();
                            int maxLevel = potion.getType().getMaxLevel();
                            for (final String s : this.plugin.getConfig().getStringList("settings.potionLimits")) {
                                final String[] part = s.split(Pattern.quote(";"));
                                if (part[0].equalsIgnoreCase(ench)) {
                                    maxLevel = Integer.valueOf(part[1]);
                                }
                            }
                            if (potion.getLevel() > maxLevel) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
}
