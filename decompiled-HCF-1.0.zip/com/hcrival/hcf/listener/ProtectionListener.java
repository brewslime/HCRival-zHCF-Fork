package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.faction.event.*;
import java.util.*;
import com.hcrival.util.cuboid.*;
import org.bukkit.event.*;
import org.bukkit.block.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import org.bukkit.potion.*;
import com.hcrival.hcf.faction.struct.*;
import org.bukkit.projectiles.*;
import org.bukkit.material.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.event.block.*;
import org.bukkit.event.hanging.*;
import org.bukkit.event.vehicle.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.*;
import javax.annotation.*;
import org.bukkit.*;
import com.google.common.collect.*;

public class ProtectionListener implements Listener
{
    public static final String PROTECTION_BYPASS_PERMISSION = "hcf.faction.protection.bypass";
    private static final ImmutableMultimap<Material, Material> ITEM_ON_BLOCK_RIGHT_CLICK_DENY;
    private static final ImmutableSet<Material> BLOCK_RIGHT_CLICK_DENY;
    private final HCF plugin;
    
    public ProtectionListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    private void handleMove(final PlayerMoveEvent event, final PlayerClaimEnterEvent.EnterCause enterCause) {
        final Location from = event.getFrom();
        final Location to = event.getTo();
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        final Player player = event.getPlayer();
        boolean cancelled = false;
        final Faction fromFaction = this.plugin.getFactionManager().getFactionAt(from);
        final Faction toFaction = this.plugin.getFactionManager().getFactionAt(to);
        if (fromFaction != toFaction) {
            final PlayerClaimEnterEvent calledEvent = new PlayerClaimEnterEvent(player, from, to, fromFaction, toFaction, enterCause);
            Bukkit.getPluginManager().callEvent((Event)calledEvent);
            cancelled = calledEvent.isCancelled();
        }
        else if (toFaction instanceof CapturableFaction) {
            final CapturableFaction capturableFaction = (CapturableFaction)toFaction;
            for (final CaptureZone captureZone : capturableFaction.getCaptureZones()) {
                final Cuboid cuboid = captureZone.getCuboid();
                if (cuboid == null) {
                    continue;
                }
                if (cuboid.contains(from)) {
                    if (!cuboid.contains(to)) {
                        final CaptureZoneLeaveEvent calledEvent2 = new CaptureZoneLeaveEvent(player, capturableFaction, captureZone);
                        Bukkit.getPluginManager().callEvent((Event)calledEvent2);
                        cancelled = calledEvent2.isCancelled();
                        break;
                    }
                    continue;
                }
                else {
                    if (cuboid.contains(to)) {
                        final CaptureZoneEnterEvent calledEvent3 = new CaptureZoneEnterEvent(player, capturableFaction, captureZone);
                        Bukkit.getPluginManager().callEvent((Event)calledEvent3);
                        cancelled = calledEvent3.isCancelled();
                        break;
                    }
                    continue;
                }
            }
        }
        if (cancelled) {
            if (enterCause == PlayerClaimEnterEvent.EnterCause.TELEPORT) {
                event.setCancelled(true);
            }
            else {
                from.setX(from.getBlockX() + 0.5);
                from.setZ(from.getBlockZ() + 0.5);
                event.setTo(from);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerMove(final PlayerMoveEvent event) {
        this.handleMove(event, PlayerClaimEnterEvent.EnterCause.MOVEMENT);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerMove(final PlayerTeleportEvent event) {
        this.handleMove((PlayerMoveEvent)event, PlayerClaimEnterEvent.EnterCause.TELEPORT);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockIgnite(final BlockIgniteEvent event) {
        switch (event.getCause()) {
            case FLINT_AND_STEEL:
            case ENDER_CRYSTAL: {}
            default: {
                final Faction factionAt = this.plugin.getFactionManager().getFactionAt(event.getBlock().getLocation());
                if (factionAt instanceof ClaimableFaction && !(factionAt instanceof PlayerFaction)) {
                    event.setCancelled(true);
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onStickyPistonExtend(final BlockPistonExtendEvent event) {
        final Block block = event.getBlock();
        final Block targetBlock = block.getRelative(event.getDirection(), event.getLength() + 1);
        if (targetBlock.isEmpty() || targetBlock.isLiquid()) {
            final Faction targetFaction = this.plugin.getFactionManager().getFactionAt(targetBlock.getLocation());
            if (targetFaction instanceof Raidable && !((Raidable)targetFaction).isRaidable() && targetFaction != this.plugin.getFactionManager().getFactionAt(block)) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onStickyPistonRetract(final BlockPistonRetractEvent event) {
        if (!event.isSticky()) {
            return;
        }
        final Location retractLocation = event.getRetractLocation();
        final Block retractBlock = retractLocation.getBlock();
        if (!retractBlock.isEmpty() && !retractBlock.isLiquid()) {
            final Block block = event.getBlock();
            final Faction targetFaction = this.plugin.getFactionManager().getFactionAt(retractLocation);
            if (targetFaction instanceof Raidable && !((Raidable)targetFaction).isRaidable() && targetFaction != this.plugin.getFactionManager().getFactionAt(block)) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockFromTo(final BlockFromToEvent event) {
        final Block fromBlock = event.getBlock();
        final Material fromType = fromBlock.getType();
        if ((fromType == Material.WATER || fromType == Material.STATIONARY_WATER || fromType == Material.LAVA || fromType == Material.STATIONARY_LAVA) && !canBuildAt(fromBlock.getLocation(), event.getToBlock().getLocation())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerTeleport(final PlayerTeleportEvent event) {
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            final Faction toFactionAt = this.plugin.getFactionManager().getFactionAt(event.getTo());
            if (toFactionAt.isSafezone() && !this.plugin.getFactionManager().getFactionAt(event.getFrom()).isSafezone()) {
                final Player player = event.getPlayer();
                player.sendMessage(ChatColor.RED + "You cannot Enderpearl into safe-zones, used Enderpearl has been refunded.");
                this.plugin.getTimerManager().getEnderPearlTimer().refund(player);
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerPortal(final PlayerPortalEvent event) {
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.NETHER_PORTAL) {
            final Location from = event.getFrom();
            final Location to = event.getTo();
            final Player player = event.getPlayer();
            final Faction fromFac = this.plugin.getFactionManager().getFactionAt(from);
            if (fromFac.isSafezone()) {
                event.setTo(to.getWorld().getSpawnLocation().add(0.5, 0.0, 0.5));
                event.useTravelAgent(false);
                player.sendMessage(ChatColor.YELLOW + "You were teleported to the spawn of target world as you were in a safe-zone.");
                return;
            }
            if (event.useTravelAgent() && to.getWorld().getEnvironment() == World.Environment.NORMAL) {
                final TravelAgent travelAgent = event.getPortalTravelAgent();
                if (!travelAgent.getCanCreatePortal()) {
                    return;
                }
                final Location foundPortal = travelAgent.findPortal(to);
                if (foundPortal != null) {
                    return;
                }
                final Faction factionAt = this.plugin.getFactionManager().getFactionAt(to);
                if (factionAt instanceof ClaimableFaction) {
                    final Faction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
                    if (playerFaction != factionAt) {
                        player.sendMessage(ChatColor.YELLOW + "Portal would have created portal in territory of " + factionAt.getDisplayName((CommandSender)player) + ChatColor.YELLOW + '.');
                        event.setCancelled(true);
                    }
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onCreatureSpawn(final CreatureSpawnEvent event) {
        final CreatureSpawnEvent.SpawnReason reason = event.getSpawnReason();
        if (reason == CreatureSpawnEvent.SpawnReason.SLIME_SPLIT) {
            return;
        }
        final Location location = event.getLocation();
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(location);
        if (factionAt.isSafezone() && reason == CreatureSpawnEvent.SpawnReason.SPAWNER) {
            return;
        }
        if (factionAt instanceof ClaimableFaction && (!(factionAt instanceof Raidable) || !((Raidable)factionAt).isRaidable()) && event.getEntity() instanceof Monster) {
            switch (reason) {
                case SPAWNER:
                case EGG:
                case CUSTOM:
                case BUILD_WITHER:
                case BUILD_IRONGOLEM:
                case BUILD_SNOWMAN: {}
                default: {
                    event.setCancelled(true);
                    break;
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityDamage(final EntityDamageEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Player) {
            final Player player = (Player)entity;
            final Faction playerFactionAt = this.plugin.getFactionManager().getFactionAt(player.getLocation());
            final EntityDamageEvent.DamageCause cause = event.getCause();
            if (playerFactionAt.isSafezone() && cause != EntityDamageEvent.DamageCause.SUICIDE && cause != EntityDamageEvent.DamageCause.VOID) {
                event.setCancelled(true);
            }
            final Player attacker = BukkitUtils.getFinalAttacker(event, true);
            if (attacker != null) {
                final Faction attackerFactionAt = this.plugin.getFactionManager().getFactionAt(attacker.getLocation());
                if (attackerFactionAt.isSafezone()) {
                    event.setCancelled(true);
                    attacker.sendMessage(ChatColor.RED + "You cannot attack players whilst in safe-zones.");
                    return;
                }
                if (playerFactionAt.isSafezone()) {
                    attacker.sendMessage(ChatColor.RED + "You cannot attack players that are in safe-zones.");
                    return;
                }
                final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
                final PlayerFaction attackerFaction;
                if (playerFaction != null && (attackerFaction = this.plugin.getFactionManager().getPlayerFaction(attacker)) != null) {
                    final Role role = playerFaction.getMember(player).getRole();
                    final String hiddenAstrixedName = role.getAstrix() + (player.hasPotionEffect(PotionEffectType.INVISIBILITY) ? "???" : player.getName());
                    if (attackerFaction == playerFaction) {
                        attacker.sendMessage(ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + hiddenAstrixedName + ChatColor.YELLOW + " is in your faction.");
                        event.setCancelled(true);
                    }
                    else if (attackerFaction.getAllied().contains(playerFaction.getUniqueID())) {
                        final ChatColor color = ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.ally"));
                        if (this.plugin.getConfig().getBoolean("settings.anti_ally_attack")) {
                            event.setCancelled(true);
                            attacker.sendMessage(color + hiddenAstrixedName + ChatColor.YELLOW + " is an ally.");
                        }
                        else {
                            attacker.sendMessage(ChatColor.YELLOW + "Careful! " + color + hiddenAstrixedName + ChatColor.YELLOW + " is an ally.");
                        }
                    }
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onFoodLevelChange(final FoodLevelChangeEvent event) {
        final Entity entity = (Entity)event.getEntity();
        if (entity instanceof Player && ((Player)entity).getFoodLevel() > event.getFoodLevel() && this.plugin.getFactionManager().getFactionAt(entity.getLocation()).isSafezone()) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPotionSplash(final PotionSplashEvent event) {
        final ThrownPotion potion = event.getEntity();
        if (!BukkitUtils.isDebuff(potion)) {
            return;
        }
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(potion.getLocation());
        if (factionAt.isSafezone()) {
            event.setCancelled(true);
            return;
        }
        final ProjectileSource source = potion.getShooter();
        if (source instanceof Player) {
            final Player player = (Player)source;
            for (final LivingEntity affected : event.getAffectedEntities()) {
                if (affected instanceof Player && !player.equals(affected)) {
                    final Player target = (Player)affected;
                    if (target.equals(source)) {
                        continue;
                    }
                    if (!this.plugin.getFactionManager().getFactionAt(target.getLocation()).isSafezone()) {
                        continue;
                    }
                    event.setIntensity(affected, 0.0);
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityTarget(final EntityTargetEvent event) {
        switch (event.getReason()) {
            case CLOSEST_PLAYER:
            case RANDOM_TARGET: {
                final Entity target = event.getTarget();
                if (event.getEntity() instanceof LivingEntity && target instanceof Player) {
                    final Faction factionAt = this.plugin.getFactionManager().getFactionAt(target.getLocation());
                    final Faction playerFaction;
                    if (factionAt.isSafezone() || ((playerFaction = this.plugin.getFactionManager().getPlayerFaction((Player)target)) != null && factionAt == playerFaction)) {
                        event.setCancelled(true);
                    }
                    break;
                }
                break;
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        if (!event.hasBlock()) {
            return;
        }
        final Block block = event.getClickedBlock();
        final Action action = event.getAction();
        if (action == Action.PHYSICAL) {
            if (!attemptBuild((Entity)event.getPlayer(), block.getLocation(), null)) {
                event.setCancelled(true);
            }
        }
        else if (action == Action.RIGHT_CLICK_BLOCK) {
            final Material blockType = block.getType();
            boolean canRightClick = !ProtectionListener.BLOCK_RIGHT_CLICK_DENY.contains(blockType);
            if (canRightClick) {
                final Material itemType = event.hasItem() ? event.getItem().getType() : null;
                if (Material.EYE_OF_ENDER == itemType && Material.ENDER_PORTAL_FRAME == blockType && block.getData() != 4) {
                    canRightClick = false;
                }
                else {
                    final MaterialData blockData;
                    if (Material.GLASS_BOTTLE == itemType && (blockData = block.getState().getData()) instanceof Cauldron && !((Cauldron)blockData).isEmpty()) {
                        canRightClick = false;
                    }
                    else if (itemType != null && ProtectionListener.ITEM_ON_BLOCK_RIGHT_CLICK_DENY.get(itemType).contains(block.getType())) {
                        canRightClick = false;
                    }
                }
            }
            else if (block.getType() == Material.WORKBENCH && this.plugin.getFactionManager().getFactionAt(block.getLocation()).isSafezone()) {
                canRightClick = true;
            }
            else if (block.getType() == Material.FENCE_GATE && event.getPlayer().getItemInHand() != null && event.getPlayer().getItemInHand().getType() == Material.ENDER_PEARL && event.getPlayer().isSneaking()) {
                canRightClick = true;
            }
            else if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getPlayer().getItemInHand().equals((Object)Material.ENDER_PEARL) && !event.getClickedBlock().getType().equals((Object)Material.GLASS)) {
                event.setCancelled(true);
            }
            if (!canRightClick && !attemptBuild((Entity)event.getPlayer(), block.getLocation(), ChatColor.YELLOW + "You cannot do this in the territory of %1$s" + ChatColor.YELLOW + '.', true)) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockBurn(final BlockBurnEvent event) {
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(event.getBlock().getLocation());
        if (factionAt instanceof WarzoneFaction || (factionAt instanceof Raidable && !((Raidable)factionAt).isRaidable())) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockFade(final BlockFadeEvent event) {
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(event.getBlock().getLocation());
        if (factionAt instanceof ClaimableFaction && !(factionAt instanceof PlayerFaction)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onLeavesDelay(final LeavesDecayEvent event) {
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(event.getBlock().getLocation());
        if (factionAt instanceof ClaimableFaction && !(factionAt instanceof PlayerFaction)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockForm(final BlockFormEvent event) {
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(event.getBlock().getLocation());
        if (factionAt instanceof ClaimableFaction && !(factionAt instanceof PlayerFaction)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityChangeBlock(final EntityChangeBlockEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof LivingEntity && !attemptBuild(entity, event.getBlock().getLocation(), null)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockBreak(final BlockBreakEvent event) {
        if (!attemptBuild((Entity)event.getPlayer(), event.getBlock().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockPlace(final BlockPlaceEvent event) {
        if (!attemptBuild((Entity)event.getPlayer(), event.getBlockPlaced().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBucketFill(final PlayerBucketFillEvent event) {
        if (!attemptBuild((Entity)event.getPlayer(), event.getBlockClicked().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBucketEmpty(final PlayerBucketEmptyEvent event) {
        if (!attemptBuild((Entity)event.getPlayer(), event.getBlockClicked().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onHangingBreakByEntity(final HangingBreakByEntityEvent event) {
        final Entity remover = event.getRemover();
        if (remover instanceof Player && !attemptBuild(remover, event.getEntity().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onHangingPlace(final HangingPlaceEvent event) {
        if (!attemptBuild((Entity)event.getPlayer(), event.getEntity().getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onVehicleEnter(final VehicleEnterEvent event) {
        final Entity entered = event.getEntered();
        if (entered instanceof Player) {
            final Vehicle vehicle = event.getVehicle();
            if (!attemptBuild(event.getEntered(), vehicle.getLocation(), ChatColor.YELLOW + "You cannot enter vehicles in the territory of %1$s" + ChatColor.YELLOW + '.')) {
                event.setCancelled(true);
                return;
            }
            if (vehicle instanceof Horse) {
                final Horse horse = (Horse)event.getVehicle();
                final AnimalTamer owner = horse.getOwner();
                if (owner != null && !owner.equals(entered)) {
                    ((Player)entered).sendMessage(ChatColor.YELLOW + "You cannot enter a Horse that belongs to " + ChatColor.RED + owner.getName() + ChatColor.YELLOW + '.');
                    event.setCancelled(true);
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onVehicleDamage(final VehicleDamageEvent event) {
        Player damager = null;
        final Entity attacker = event.getAttacker();
        if (attacker instanceof Player) {
            damager = (Player)attacker;
        }
        else if (attacker instanceof Projectile) {
            final ProjectileSource shooter = ((Projectile)attacker).getShooter();
            if (shooter instanceof Player) {
                damager = (Player)shooter;
            }
        }
        if (damager != null && !attemptBuild(attacker, damager.getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onHangingDamageByEntity(final EntityDamageByEntityEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Hanging) {
            final Player attacker = BukkitUtils.getFinalAttacker((EntityDamageEvent)event, false);
            if (attacker != null && !attemptBuild((Entity)attacker, entity.getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOW)
    public void onHangingInteractByPlayer(final PlayerInteractEntityEvent event) {
        final Entity entity = event.getRightClicked();
        if (entity instanceof Hanging && !attemptBuild((Entity)event.getPlayer(), entity.getLocation(), ChatColor.WHITE + "You cannot build in the territory of %1$s" + ChatColor.WHITE + '.')) {
            event.setCancelled(true);
        }
    }
    
    public static boolean attemptBuild(final Entity entity, final Location location, @Nullable final String denyMessage) {
        return attemptBuild(entity, location, denyMessage, false);
    }
    
    public static boolean attemptBuild(final Entity entity, final Location location, @Nullable final String denyMessage, final boolean isInteraction) {
        final Player player = (entity instanceof Player) ? entity : null;
        if (player != null && player.getGameMode() == GameMode.CREATIVE && player.hasPermission("hcf.faction.protection.bypass")) {
            return true;
        }
        if (player != null && player.getWorld().getEnvironment() == World.Environment.THE_END) {
            player.sendMessage(ChatColor.RED + "You cannot build in the end.");
            return false;
        }
        boolean result = false;
        final Faction factionAt = HCF.getPlugin().getFactionManager().getFactionAt(location);
        if (!(factionAt instanceof ClaimableFaction)) {
            result = true;
        }
        else if (factionAt instanceof Raidable && ((Raidable)factionAt).isRaidable()) {
            result = true;
        }
        if (player != null && factionAt instanceof PlayerFaction && HCF.getPlugin().getFactionManager().getPlayerFaction(player) == factionAt) {
            result = true;
        }
        if (result) {
            if (!isInteraction && factionAt instanceof WarzoneFaction) {
                if (denyMessage != null && player != null) {
                    player.sendMessage(ChatColor.YELLOW + "You cannot build in the " + factionAt.getDisplayName((CommandSender)player) + ChatColor.YELLOW + ".");
                }
                return false;
            }
        }
        else if (denyMessage != null && player != null) {
            player.sendMessage(String.format(denyMessage, factionAt.getDisplayName((CommandSender)player)));
        }
        return result;
    }
    
    public static boolean canBuildAt(final Location from, final Location to) {
        final Faction toFactionAt = HCF.getPlugin().getFactionManager().getFactionAt(to);
        return !(toFactionAt instanceof Raidable) || ((Raidable)toFactionAt).isRaidable() || toFactionAt == HCF.getPlugin().getFactionManager().getFactionAt(from);
    }
    
    static {
        ITEM_ON_BLOCK_RIGHT_CLICK_DENY = ImmutableMultimap.builder().put(Material.DIAMOND_HOE, Material.GRASS).put(Material.GOLD_HOE, Material.GRASS).put(Material.IRON_HOE, Material.GRASS).put(Material.STONE_HOE, Material.GRASS).put(Material.WOOD_HOE, Material.GRASS).build();
        BLOCK_RIGHT_CLICK_DENY = Sets.immutableEnumSet(Material.BED, Material.BED_BLOCK, Material.BEACON, Material.FENCE_GATE, Material.IRON_DOOR, Material.TRAP_DOOR, Material.WOOD_DOOR, Material.WOODEN_DOOR, Material.IRON_DOOR_BLOCK, Material.CHEST, Material.TRAPPED_CHEST, Material.FURNACE, Material.BURNING_FURNACE, Material.BREWING_STAND, Material.HOPPER, Material.DROPPER, Material.DISPENSER, Material.STONE_BUTTON, Material.WOOD_BUTTON, Material.ENCHANTMENT_TABLE, Material.WORKBENCH, Material.ANVIL, Material.LEVER, Material.FIRE);
    }
}
