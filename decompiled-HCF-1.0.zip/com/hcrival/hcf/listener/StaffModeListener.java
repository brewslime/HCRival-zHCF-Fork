package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.inventory.*;
import org.bukkit.scheduler.*;
import org.bukkit.potion.*;
import org.apache.commons.lang.*;
import org.bukkit.command.*;
import org.bukkit.event.*;
import java.util.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.block.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;

public class StaffModeListener implements Listener
{
    private final HCF modmode;
    private final Set<UUID> staffMode;
    private final Set<UUID> staffChat;
    private final Set<UUID> vanished;
    private final HashMap<UUID, UUID> inspectedPlayer;
    private final HashMap<UUID, ItemStack[]> contents;
    private final HashMap<UUID, ItemStack[]> armorContents;
    public Inventory inv;
    
    public StaffModeListener() {
        this.modmode = HCF.getPlugin();
        this.staffMode = new HashSet<UUID>();
        this.staffChat = new HashSet<UUID>();
        this.vanished = new HashSet<UUID>();
        this.inspectedPlayer = new HashMap<UUID, UUID>();
        this.contents = new HashMap<UUID, ItemStack[]>();
        this.armorContents = new HashMap<UUID, ItemStack[]>();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this.modmode);
    }
    
    public Player getInspectedPlayer(final Player player) {
        return Bukkit.getServer().getPlayer((UUID)this.inspectedPlayer.get(player.getUniqueId()));
    }
    
    public boolean isVanished(final Player player) {
        return this.vanished.contains(player.getUniqueId());
    }
    
    public boolean isStaffChatActive(final Player player) {
        return this.staffChat.contains(player.getUniqueId());
    }
    
    public boolean isStaffModeActive(final Player player) {
        return this.staffMode.contains(player.getUniqueId());
    }
    
    public boolean hasPreviousInventory(final Player player) {
        return this.contents.containsKey(player.getUniqueId()) && this.armorContents.containsKey(player.getUniqueId());
    }
    
    public void saveInventory(final Player player) {
        this.contents.put(player.getUniqueId(), player.getInventory().getContents());
        this.armorContents.put(player.getUniqueId(), player.getInventory().getArmorContents());
    }
    
    public void loadInventory(final Player player) {
        final PlayerInventory playerInventory = player.getInventory();
        playerInventory.setContents((ItemStack[])this.contents.get(player.getUniqueId()));
        playerInventory.setArmorContents((ItemStack[])this.armorContents.get(player.getUniqueId()));
        this.contents.remove(player.getUniqueId());
        this.armorContents.remove(player.getUniqueId());
    }
    
    public void setStaffChat(final Player player, final boolean status) {
        if (status) {
            if (player.hasPermission("modmode.player.staff")) {
                this.staffChat.add(player.getUniqueId());
            }
        }
        else {
            this.staffChat.remove(player.getUniqueId());
        }
    }
    
    public void setStaffMode(final Player player, final boolean status) {
        if (status) {
            if (player.hasPermission("modmode.player.staff")) {
                this.staffMode.add(player.getUniqueId());
                this.saveInventory(player);
                final PlayerInventory playerInventory = player.getInventory();
                playerInventory.setArmorContents(new ItemStack[] { new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR) });
                playerInventory.clear();
                this.setItems(player);
                this.setVanished(player, true);
                player.updateInventory();
                if (player.getGameMode() == GameMode.SURVIVAL) {
                    player.setGameMode(GameMode.CREATIVE);
                }
            }
            else {
                player.sendMessage(ChatColor.RED + "No permission.");
            }
        }
        else {
            this.staffMode.remove(player.getUniqueId());
            final PlayerInventory playerInventory = player.getInventory();
            playerInventory.setArmorContents(new ItemStack[] { new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR) });
            playerInventory.clear();
            this.setVanished(player, false);
            if (this.hasPreviousInventory(player)) {
                this.loadInventory(player);
            }
            player.updateInventory();
            player.setGameMode(GameMode.SURVIVAL);
        }
    }
    
    public void setVanished(final Player player, final boolean status) {
        if (status) {
            this.vanished.add(player.getUniqueId());
            for (final Player online : Bukkit.getServer().getOnlinePlayers()) {
                if (!online.hasPermission("modmode.player.staff")) {
                    online.hidePlayer(player);
                }
            }
            if (this.isStaffModeActive(player)) {
                final PlayerInventory playerInventory = player.getInventory();
                playerInventory.setItem(8, this.getVanishItemFor(player));
            }
        }
        else {
            this.vanished.remove(player.getUniqueId());
            for (final Player online : Bukkit.getServer().getOnlinePlayers()) {
                online.showPlayer(player);
            }
            if (this.isStaffModeActive(player)) {
                final PlayerInventory playerInventory = player.getInventory();
                playerInventory.setItem(8, this.getVanishItemFor(player));
            }
        }
    }
    
    public void setItems(final Player player) {
        final PlayerInventory playerInventory = player.getInventory();
        final ItemStack compass = new ItemStack(Material.COMPASS, 1);
        final ItemMeta compassMeta = compass.getItemMeta();
        compassMeta.setDisplayName(Color.translate("&bTeleport Compass"));
        compassMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Right click block: Move through", "&7Left click: Move to block in line of sight")));
        compass.setItemMeta(compassMeta);
        final ItemStack book = new ItemStack(Material.BOOK, 1);
        final ItemMeta bookMeta = book.getItemMeta();
        bookMeta.setDisplayName(Color.translate("&bInspection Tool"));
        bookMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Right click player to inspect inventory")));
        book.setItemMeta(bookMeta);
        final ItemStack betterView = new ItemStack(Material.CARPET, 1, (short)8);
        final ItemMeta betterViewMeta = betterView.getItemMeta();
        betterViewMeta.setDisplayName(Color.translate("&eBetter View"));
        betterViewMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7View better on 1.7")));
        betterView.setItemMeta(betterViewMeta);
        final ItemStack carpet = new ItemStack(Material.WOOD_AXE);
        final ItemMeta carpetMeta = carpet.getItemMeta();
        carpetMeta.setDisplayName(Color.translate("&bWorld Edit"));
        carpetMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7The normal worldedit wand")));
        carpet.setItemMeta(carpetMeta);
        final ItemStack xrayGui = new ItemStack(Material.DIAMOND_PICKAXE);
        final ItemMeta xrayGuiMeta = xrayGui.getItemMeta();
        xrayGuiMeta.setDisplayName(Color.translate("&bXrayer Gui"));
        xrayGuiMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Used to get a list of possible xrayers")));
        xrayGui.setItemMeta(xrayGuiMeta);
        final ItemStack randomTP = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final ItemMeta randomTPMeta = randomTP.getItemMeta();
        randomTPMeta.setDisplayName(Color.translate("&bRandom Teleportation"));
        randomTPMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Right click to teleport to a random player")));
        randomTP.setItemMeta(randomTPMeta);
        playerInventory.setItem(0, compass);
        playerInventory.setItem(1, book);
        playerInventory.setItem(2, betterView);
        playerInventory.setItem(7, randomTP);
        playerInventory.setItem(8, this.getVanishItemFor(player));
    }
    
    private ItemStack getVanishItemFor(final Player player) {
        ItemStack inkSack = null;
        if (this.isVanished(player)) {
            inkSack = new ItemStack(Material.INK_SACK, 1, (short)10);
            final ItemMeta inkSackMeta = inkSack.getItemMeta();
            inkSackMeta.setDisplayName(Color.translate("&bVanished: &aTrue"));
            inkSackMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Right click to update your vanish status.")));
            inkSack.setItemMeta(inkSackMeta);
        }
        else {
            inkSack = new ItemStack(Material.INK_SACK, 1, (short)8);
            final ItemMeta inkSackMeta = inkSack.getItemMeta();
            inkSackMeta.setDisplayName(Color.translate("&bVanished: &cFalse"));
            inkSackMeta.setLore((List)Color.translateFromArray(Arrays.asList("&7Right click to update your vanish status.")));
            inkSack.setItemMeta(inkSackMeta);
        }
        return inkSack;
    }
    
    public void openInspectionMenu(final Player player, final Player target) {
        final Inventory inventory = Bukkit.getServer().createInventory((InventoryHolder)null, 54, Color.translate("&eInspecting: &c" + target.getName()));
        new BukkitRunnable() {
            public void run() {
                StaffModeListener.this.inspectedPlayer.put(player.getUniqueId(), target.getUniqueId());
                final PlayerInventory playerInventory = target.getInventory();
                final ItemStack speckledMelon = new ItemStack(Material.SPECKLED_MELON, (int)target.getHealth());
                final ItemMeta speckledMelonMeta = speckledMelon.getItemMeta();
                speckledMelonMeta.setDisplayName(Color.translate("&aHealth"));
                speckledMelon.setItemMeta(speckledMelonMeta);
                final ItemStack cookedBeef = new ItemStack(Material.COOKED_BEEF, target.getFoodLevel());
                final ItemMeta cookedBeefMeta = cookedBeef.getItemMeta();
                cookedBeefMeta.setDisplayName(Color.translate("&aHunger"));
                cookedBeef.setItemMeta(cookedBeefMeta);
                final ItemStack brewingStand = new ItemStack(Material.BREWING_STAND_ITEM, target.getPlayer().getActivePotionEffects().size());
                final ItemMeta brewingStandMeta = brewingStand.getItemMeta();
                brewingStandMeta.setDisplayName(Color.translate("&aActive Potion Effects"));
                final ArrayList<String> brewingStandLore = new ArrayList<String>();
                for (final PotionEffect potionEffect : target.getPlayer().getActivePotionEffects()) {
                    final String effectName = potionEffect.getType().getName();
                    int effectLevel = potionEffect.getAmplifier();
                    ++effectLevel;
                    brewingStandLore.add(Color.translate("&e" + WordUtils.capitalizeFully(effectName).replace("_", " ") + " " + effectLevel));
                }
                brewingStandMeta.setLore((List)brewingStandLore);
                brewingStand.setItemMeta(brewingStandMeta);
                final ItemStack compass = new ItemStack(Material.COMPASS, 1);
                final ItemMeta compassMeta = compass.getItemMeta();
                compassMeta.setDisplayName(Color.translate("&aPlayer Location"));
                compassMeta.setLore((List)Color.translateFromArray(Arrays.asList("&eWorld&7: &a" + player.getWorld().getName(), "&eCoords", "  &eX&7: &c" + target.getLocation().getBlockX(), "  &eY&7: &c" + target.getLocation().getBlockY(), "  &eZ&7: &c" + target.getLocation().getBlockZ())));
                compass.setItemMeta(compassMeta);
                final ItemStack ice = new ItemStack(Material.ICE, 1);
                final ItemMeta iceMeta = ice.getItemMeta();
                if (StaffModeListener.this.modmode.getFreezeListener().isFrozen(target)) {
                    iceMeta.setDisplayName(Color.translate("&aFrozen&7: &aTrue"));
                }
                else {
                    iceMeta.setDisplayName(Color.translate("&aFrozen&7: &cFalse"));
                }
                iceMeta.setLore((List)Color.translateFromArray(Arrays.asList("&eClick to update freeze status")));
                ice.setItemMeta(iceMeta);
                final ItemStack orangeGlassPane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)1);
                inventory.setContents(playerInventory.getContents());
                inventory.setItem(36, playerInventory.getHelmet());
                inventory.setItem(37, playerInventory.getChestplate());
                inventory.setItem(38, playerInventory.getLeggings());
                inventory.setItem(39, playerInventory.getBoots());
                inventory.setItem(40, playerInventory.getItemInHand());
                for (int i = 41; i <= 46; ++i) {
                    inventory.setItem(i, orangeGlassPane);
                }
                inventory.setItem(47, speckledMelon);
                inventory.setItem(48, cookedBeef);
                inventory.setItem(49, brewingStand);
                inventory.setItem(50, compass);
                inventory.setItem(51, ice);
                for (int i = 52; i <= 53; ++i) {
                    inventory.setItem(i, orangeGlassPane);
                }
                if (!player.getOpenInventory().getTitle().equals(Color.translate("&eInspecting: &c" + target.getName()))) {
                    this.cancel();
                    StaffModeListener.this.inspectedPlayer.remove(player.getUniqueId());
                }
            }
        }.runTaskTimer((Plugin)this.modmode, 0L, 5L);
        player.openInventory(inventory);
    }
    
    @EventHandler
    public void onInventoryClick(final InventoryClickEvent event) {
        final Player player = (Player)event.getWhoClicked();
        final ItemStack clicked = event.getCurrentItem();
        final Inventory inventory = event.getInventory();
        if (inventory.getName() != null && inventory.getName().contains(Color.translate("&eInspecting: &c" + player.getName())) && event.getClickedInventory() != null) {
            if (this.isStaffModeActive(player)) {
                event.setCancelled(true);
            }
            if (this.isStaffModeActive(player) && event.getSlotType().equals((Object)InventoryType.SlotType.OUTSIDE)) {
                event.setCancelled(true);
                return;
            }
            if (inventory.getName().equals("Xrayer Gui") && clicked.getType() == Material.SKULL_ITEM) {
                Bukkit.dispatchCommand((CommandSender)player, "tp " + clicked.getItemMeta().getDisplayName());
            }
            if (event.getInventory().getTitle().contains(Color.translate("&eInspecting: "))) {
                final Player inspected = this.getInspectedPlayer(player);
                if (event.getRawSlot() == 51 && inspected != null) {
                    if (this.modmode.getFreezeListener().isFrozen(inspected)) {
                        this.modmode.getFreezeListener().setFreeze((CommandSender)player, inspected, false);
                    }
                    else if (inspected.hasPermission("modmode.player.staff") || inspected.isOp()) {
                        player.sendMessage(Color.translate("&cYou can not Freeze an Staff Member."));
                    }
                    else {
                        this.modmode.getFreezeListener().setFreeze((CommandSender)player, inspected, true);
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Action action = event.getAction();
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            final Player player = event.getPlayer();
            if (this.isStaffModeActive(player) && player.hasPermission("modmode.player.staff")) {
                final ItemStack itemStack = player.getItemInHand();
                if (itemStack != null) {
                    if (itemStack.getType() == Material.DIAMOND_PICKAXE) {
                        int Counter = 0;
                        this.inv = Bukkit.createInventory((InventoryHolder)null, 54, "Xrayer Gui");
                        for (final Player players : Bukkit.getOnlinePlayers()) {
                            if (++Counter < 54) {
                                if (players.getLocation().getBlockY() >= 20) {
                                    continue;
                                }
                                final ItemStack xSkull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
                                final ItemMeta xSkullMeta = xSkull.getItemMeta();
                                xSkullMeta.setDisplayName(players.getName());
                                xSkullMeta.setLore((List)Color.translateFromArray(Arrays.asList("&eThis player is mining on level &6&l" + players.getLocation().getBlockY())));
                                xSkull.setItemMeta(xSkullMeta);
                                this.inv.addItem(new ItemStack[] { xSkull });
                            }
                            else {
                                event.getPlayer().sendMessage(Color.translate("&cThere are too many players mining right now."));
                            }
                        }
                        player.openInventory(this.inv);
                    }
                    if (itemStack.getType() == Material.SKULL_ITEM) {
                        if (Bukkit.getServer().getOnlinePlayers().size() > 1) {
                            final Random random = new Random();
                            final int size = random.nextInt(Bukkit.getServer().getOnlinePlayers().size());
                            final Player online = (Player)Bukkit.getServer().getOnlinePlayers().toArray()[size];
                            if (online.equals(player)) {
                                random.nextInt();
                                this.onPlayerInteract(event);
                                return;
                            }
                            event.setCancelled(true);
                            player.teleport((Entity)online);
                            player.sendMessage(Color.translate("&eYou've been randomly teleported to &c" + online.getName() + "&e."));
                        }
                        else {
                            player.sendMessage(Color.translate("&cCould not find players to teleport."));
                        }
                    }
                    else if (itemStack.getType() == Material.INK_SACK) {
                        if (this.isVanished(player)) {
                            this.setVanished(player, false);
                        }
                        else {
                            this.setVanished(player, true);
                        }
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerInteractEntity(final PlayerInteractEntityEvent event) {
        if (event.getRightClicked() != null && event.getRightClicked() instanceof Player) {
            final Player player = event.getPlayer();
            if (this.isStaffModeActive(player) && player.hasPermission("modmode.player.staff")) {
                final ItemStack itemStack = player.getItemInHand();
                if (itemStack != null) {
                    final Player target = (Player)event.getRightClicked();
                    if (itemStack.getType() == Material.BOOK) {
                        if (target != null && !player.getName().equals(target.getName())) {
                            this.openInspectionMenu(player, target);
                            player.sendMessage(Color.translate("&eYou are now inspecting the inventory of &c" + target.getName() + "&e."));
                        }
                    }
                    else if (itemStack.getType() == Material.CARROT_STICK) {
                        if (target != null && !player.getName().equals(target.getName())) {
                            if (player.getVehicle() != null) {
                                player.getVehicle().eject();
                            }
                            target.setPassenger((Entity)player);
                        }
                    }
                    else if (itemStack.getType() == Material.ICE && target != null && !player.getName().equals(target.getName())) {
                        if (this.modmode.getFreezeListener().isFrozen(target)) {
                            this.modmode.getFreezeListener().setFreeze((CommandSender)player, target, false);
                        }
                        else if (target.hasPermission("modmode.player.staff") || target.isOp()) {
                            player.sendMessage(Color.translate("&cYou can not freeze a staff member."));
                        }
                        else {
                            this.modmode.getFreezeListener().setFreeze((CommandSender)player, target, true);
                        }
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        event.setJoinMessage((String)null);
        if (!player.hasPermission("hcf.command.creative") && player.getGameMode() == GameMode.CREATIVE) {
            player.setGameMode(GameMode.SURVIVAL);
        }
        if (!player.hasPermission("modmode.player.staff")) {
            if (this.vanished.size() > 0) {
                for (final UUID uuid : this.vanished) {
                    final Player vanishedPlayer = Bukkit.getServer().getPlayer(uuid);
                    if (vanishedPlayer != null) {
                        player.hidePlayer(vanishedPlayer);
                    }
                }
            }
        }
        else {
            this.setStaffMode(player, true);
        }
    }
    
    @EventHandler
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final Player player = event.getPlayer();
        event.setQuitMessage((String)null);
        if (this.isStaffModeActive(player)) {
            this.staffMode.remove(player.getUniqueId());
            this.inspectedPlayer.remove(player.getUniqueId());
            final PlayerInventory playerInventory = player.getInventory();
            playerInventory.setArmorContents(new ItemStack[] { new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR), new ItemStack(Material.AIR) });
            playerInventory.clear();
            this.setVanished(player, false);
            if (this.hasPreviousInventory(player)) {
                this.loadInventory(player);
            }
            if (!player.hasPermission("hcf.command.creative") && player.getGameMode() == GameMode.CREATIVE) {
                player.setGameMode(GameMode.SURVIVAL);
            }
        }
    }
    
    @EventHandler
    public void onPlayerDropItem(final PlayerDropItemEvent event) {
        final Player player = event.getPlayer();
        if (this.isStaffModeActive(player)) {
            player.sendMessage(ChatColor.RED + "You cannot drop items while you are in staff mode.");
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onInv(final InventoryClickEvent event) {
        final Player player = (Player)event.getWhoClicked();
        final ItemStack itemStack = event.getCurrentItem();
        final InventoryAction invAction = event.getAction();
        if (this.isVanished(player) || this.isStaffModeActive(player)) {
            if (event.getSlotType().equals((Object)InventoryType.SlotType.OUTSIDE)) {
                event.setCancelled(true);
                return;
            }
            if ((itemStack == null || itemStack.getType().equals((Object)Material.AIR)) && (invAction.equals((Object)InventoryAction.HOTBAR_SWAP) || invAction.equals((Object)InventoryAction.SWAP_WITH_CURSOR))) {
                event.setCancelled(true);
                return;
            }
            event.setCancelled(true);
            if (itemStack.hasItemMeta() && itemStack.getItemMeta().hasDisplayName()) {
                if (invAction.equals((Object)InventoryAction.HOTBAR_SWAP) || invAction.equals((Object)InventoryAction.SWAP_WITH_CURSOR)) {
                    event.setCancelled(true);
                }
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    public void onPlayerPickupItem(final PlayerPickupItemEvent event) {
        final Player player = event.getPlayer();
        if (this.isVanished(player) || this.isStaffModeActive(player)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getBlock();
        if ((this.isVanished(player) || this.isStaffModeActive(player)) && block != null) {
            player.sendMessage(ChatColor.RED + "You cannot place blocks while you are in staffmode.");
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onBlockBreak(final BlockBreakEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getBlock();
        if ((this.isVanished(player) || this.isStaffModeActive(player)) && block != null) {
            player.sendMessage(ChatColor.RED + "You cannot break blocks while you are in staffmode.");
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
            final Player player = (Player)event.getDamager();
            if (this.isVanished(player) || (this.isStaffModeActive(player) && player.hasPermission("modmode.player.staff"))) {
                event.setCancelled(true);
            }
        }
        else if (event.getEntity() instanceof LivingEntity && event.getDamager() instanceof Player) {
            final Player player = (Player)event.getDamager();
            if (this.isVanished(player) || (this.isStaffModeActive(player) && player.hasPermission("modmode.player.staff"))) {
                event.setCancelled(true);
            }
        }
    }
}
