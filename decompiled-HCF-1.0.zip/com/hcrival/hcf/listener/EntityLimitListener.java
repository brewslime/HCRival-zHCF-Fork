package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class EntityLimitListener implements Listener
{
    private static final int MAX_CHUNK_GENERATED_ENTITIES = 25;
    private static final int MAX_NATURAL_CHUNK_ENTITIES = 25;
    private final HCF plugin;
    
    public EntityLimitListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onCreatureSpawn(final CreatureSpawnEvent event) {
        final Entity entity = (Entity)event.getEntity();
        if (entity instanceof Squid) {
            event.setCancelled(true);
            return;
        }
        if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.SLIME_SPLIT) {
            switch (event.getSpawnReason()) {
                case NATURAL: {
                    if (event.getLocation().getChunk().getEntities().length > 25) {
                        event.setCancelled(true);
                        break;
                    }
                    break;
                }
                case CHUNK_GEN: {
                    if (event.getLocation().getChunk().getEntities().length > 25) {
                        event.setCancelled(true);
                        break;
                    }
                    break;
                }
            }
        }
    }
}
