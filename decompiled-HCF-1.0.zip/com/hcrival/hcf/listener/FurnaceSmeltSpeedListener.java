package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.block.*;
import org.bukkit.event.*;

public class FurnaceSmeltSpeedListener implements Listener
{
    private final HCF plugin;
    
    public FurnaceSmeltSpeedListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            final double multiplier = this.plugin.getConfig().getFloat("settings.furnace_speed");
            if (multiplier == 1.0) {
                return;
            }
            final Block block = event.getClickedBlock();
            final BlockState state = block.getState();
            if (state instanceof Furnace) {
                ((Furnace)state).setCookTime((short)(((Furnace)state).getCookTime() * multiplier));
            }
        }
    }
}
