package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;
import net.minecraft.server.v1_7_R4.*;
import org.bukkit.*;
import net.minecraft.util.com.google.common.base.*;
import org.bukkit.entity.*;
import net.minecraft.util.org.apache.commons.lang3.text.*;

public class DeathMessageListener implements Listener
{
    private HCF plugin;
    
    public DeathMessageListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public static String replaceLast(final String text, final String regex, final String replacement) {
        return text.replaceFirst("(?s)" + regex + "(?!.*?" + regex + ')', replacement);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        final String message = event.getDeathMessage();
        if (message == null || message.isEmpty()) {
            return;
        }
        event.setDeathMessage(this.getDeathMessage(message, (Entity)event.getEntity(), (Entity)this.getKiller(event)));
    }
    
    private CraftEntity getKiller(final PlayerDeathEvent event) {
        final EntityLiving lastAttacker = ((CraftPlayer)event.getEntity()).getHandle().aX();
        return (lastAttacker == null) ? null : lastAttacker.getBukkitEntity();
    }
    
    private String getDeathMessage(String input, final Entity entity, final Entity killer) {
        input = input.replaceFirst("\\[", "");
        input = replaceLast(input, "]", "");
        if (entity != null) {
            input = input.replaceFirst("(?i)" + this.getEntityName(entity), ChatColor.RED + this.getDisplayName(entity) + ChatColor.YELLOW);
        }
        if (killer != null && (entity == null || !killer.equals(entity))) {
            input = input.replaceFirst("(?i)" + this.getEntityName(killer), ChatColor.RED + this.getDisplayName(killer) + ChatColor.YELLOW);
        }
        return input;
    }
    
    private String getEntityName(final Entity entity) {
        Preconditions.checkNotNull((Object)entity, (Object)"Entity cannot be null");
        return (entity instanceof Player) ? ((Player)entity).getName() : ((CraftEntity)entity).getHandle().getName();
    }
    
    private String getDisplayName(final Entity entity) {
        Preconditions.checkNotNull((Object)entity, (Object)"Entity cannot be null");
        if (entity instanceof Player) {
            final Player player = (Player)entity;
            return player.getName() + ChatColor.GOLD + '[' + ChatColor.WHITE + this.plugin.getUserManager().getUser(player.getUniqueId()).getKills() + ChatColor.GOLD + ']';
        }
        return WordUtils.capitalizeFully(entity.getType().name().replace('_', ' '));
    }
}
