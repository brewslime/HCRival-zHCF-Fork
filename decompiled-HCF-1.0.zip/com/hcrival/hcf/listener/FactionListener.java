package com.hcrival.hcf.listener;

import org.bukkit.configuration.file.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.events.faction.*;
import org.bukkit.event.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;
import org.bukkit.plugin.*;
import org.bukkit.metadata.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.struct.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.faction.event.*;
import java.util.*;
import org.bukkit.event.player.*;
import java.util.concurrent.*;

public class FactionListener implements Listener
{
    private static final long FACTION_JOIN_WAIT_MILLIS;
    private static final String FACTION_JOIN_WAIT_WORDS;
    private static final String LAND_CHANGED_META_KEY = "landChangedMessage";
    private static final long LAND_CHANGE_MSG_THRESHOLD = 225L;
    YamlConfiguration mConfig;
    private final HCF plugin;
    
    public FactionListener(final HCF plugin) {
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionRenameMonitor(final FactionRenameEvent event) {
        final Faction faction = event.getFaction();
        if (faction instanceof KothFaction) {
            ((KothFaction)faction).getCaptureZone().setName(event.getNewName());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionCreate(final FactionCreateEvent event) {
        final Faction faction = event.getFaction();
        if (faction instanceof PlayerFaction) {
            final CommandSender sender = event.getSender();
            Bukkit.broadcastMessage(Color.translate(this.mConfig.getString("messages.faction_created").replace("%faction%", faction.getName()).replace("%player%", sender.getName())));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionRemove(final FactionRemoveEvent event) {
        final Faction faction = event.getFaction();
        if (faction instanceof PlayerFaction) {
            final CommandSender sender = event.getSender();
            Bukkit.broadcastMessage(Color.translate(this.mConfig.getString("messages.faction_disbanded").replace("%faction%", faction.getName()).replace("%player%", sender.getName())));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionRename(final FactionRenameEvent event) {
        final Faction faction = event.getFaction();
        if (faction instanceof PlayerFaction) {
            Bukkit.broadcastMessage(Color.translate(this.mConfig.getString("messages.faction_renamed").replace("%faction%", event.getOriginalName()).replace("%rename%", event.getNewName())));
        }
    }
    
    private long getLastLandChangedMeta(final Player player) {
        final MetadataValue value = ReflectionUtils.getPlayerMetadata(player, "landChangedMessage", (Plugin)this.plugin);
        final long millis = System.currentTimeMillis();
        final long remaining = (value == null) ? 0L : (value.asLong() - millis);
        if (remaining <= 0L) {
            player.setMetadata("landChangedMessage", (MetadataValue)new FixedMetadataValue((Plugin)this.plugin, (Object)(millis + 225L)));
        }
        return remaining;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onCaptureZoneEnter(final CaptureZoneEnterEvent event) {
        final Player player = event.getPlayer();
        if (this.getLastLandChangedMeta(player) > 0L) {
            return;
        }
        if (this.plugin.getUserManager().getUser(player.getUniqueId()).isCapzoneEntryAlerts()) {
            player.sendMessage(ChatColor.YELLOW + "Now entering capture zone: " + event.getCaptureZone().getDisplayName() + ChatColor.YELLOW + '(' + event.getFaction().getName() + ChatColor.YELLOW + ')');
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onCaptureZoneLeave(final CaptureZoneLeaveEvent event) {
        final Player player = event.getPlayer();
        if (this.getLastLandChangedMeta(player) > 0L) {
            return;
        }
        if (this.plugin.getUserManager().getUser(player.getUniqueId()).isCapzoneEntryAlerts()) {
            player.sendMessage(ChatColor.YELLOW + "Now leaving capture zone: " + event.getCaptureZone().getDisplayName() + ChatColor.YELLOW + '(' + event.getFaction().getName() + ChatColor.YELLOW + ')');
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    private void onPlayerClaimEnter(final PlayerClaimEnterEvent event) {
        final Faction toFaction = event.getToFaction();
        final Faction fromFaction = event.getFromFaction();
        if (toFaction.isSafezone()) {
            final Player player = event.getPlayer();
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setFireTicks(0);
            player.setSaturation(4.0f);
        }
        final Player player = event.getPlayer();
        if (this.getLastLandChangedMeta(player) <= 0L) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&eEntering " + toFaction.getDisplayName((CommandSender)player) + "&e, Leaving " + fromFaction.getDisplayName((CommandSender)player)));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerLeftFaction(final PlayerLeftFactionEvent event) {
        final Optional<Player> optionalPlayer = event.getPlayer();
        if (optionalPlayer.isPresent()) {
            this.plugin.getUserManager().getUser(optionalPlayer.get().getUniqueId()).setLastFactionLeaveMillis(System.currentTimeMillis());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerPreFactionJoin(final PlayerJoinFactionEvent event) {
        final PlayerFaction playerFaction = event.getFaction();
        final Optional<Player> optionalPlayer = event.getPlayer();
        if (optionalPlayer.isPresent()) {
            final Player player = optionalPlayer.get();
            if (!this.plugin.getEotwHandler().isEndOfTheWorld() && playerFaction.getRegenStatus() == RegenStatus.PAUSED) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "You cannot join factions that are not regenerating DTR.");
                return;
            }
            final long difference = this.plugin.getUserManager().getUser(player.getUniqueId()).getLastFactionLeaveMillis() - System.currentTimeMillis() + FactionListener.FACTION_JOIN_WAIT_MILLIS;
            if (difference > 0L && !player.hasPermission("hcf.faction.argument.staff.forcejoin")) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "You cannot join factions after just leaving within " + FactionListener.FACTION_JOIN_WAIT_WORDS + ". You gotta wait another " + DurationFormatUtils.formatDurationWords(difference, true, true) + '.');
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onFactionLeave(final PlayerLeaveFactionEvent event) {
        if (event.isForce() || event.isKick()) {
            return;
        }
        final PlayerFaction playerFaction = event.getFaction();
        final Optional<Player> optional = event.getPlayer();
        if (optional.isPresent()) {
            final Player player = optional.get();
            if (this.plugin.getFactionManager().getFactionAt(player.getLocation()) == playerFaction) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "You cannot leave your faction whilst you remain in its' territory.");
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerJoin(final PlayerJoinEvent event) {
        event.setJoinMessage((String)null);
        final Player player = event.getPlayer();
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction != null) {
            playerFaction.printDetails((CommandSender)player);
            playerFaction.broadcast(ChatColor.GOLD + "Member Online: " + ChatColor.GREEN + playerFaction.getMember(player).getRole().getAstrix() + player.getName() + ChatColor.GOLD + '.', player.getUniqueId());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final Player player = event.getPlayer();
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (playerFaction != null) {
            playerFaction.broadcast(ChatColor.GOLD + "Member Offline: " + ChatColor.GREEN + playerFaction.getMember(player).getRole().getAstrix() + player.getName() + ChatColor.GOLD + '.');
        }
    }
    
    static {
        FACTION_JOIN_WAIT_MILLIS = TimeUnit.SECONDS.toMillis(30L);
        FACTION_JOIN_WAIT_WORDS = DurationFormatUtils.formatDurationWords(FactionListener.FACTION_JOIN_WAIT_MILLIS, true, true);
    }
}
