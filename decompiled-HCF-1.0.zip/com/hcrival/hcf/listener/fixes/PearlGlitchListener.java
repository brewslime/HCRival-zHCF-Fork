package com.hcrival.hcf.listener.fixes;

import com.hcrival.hcf.*;
import java.util.*;
import org.bukkit.event.block.*;
import org.bukkit.inventory.*;
import org.bukkit.block.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.*;

public class PearlGlitchListener implements Listener
{
    private final Set<Material> blockedPearl;
    private final HCF plugin;
    
    public PearlGlitchListener(final HCF plugin) {
        this.blockedPearl = new HashSet<Material>();
        this.plugin = plugin;
        for (final String s : plugin.getConfig().getStringList("settings.blocked_pearl_types")) {
            try {
                this.blockedPearl.add(Material.valueOf(s));
            }
            catch (IllegalArgumentException e) {
                System.out.println(s + " isn't a valid material! Not adding to pearl exceptions.");
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.hasItem() && event.getItem().getType() == Material.ENDER_PEARL) {
            final Block block = event.getClickedBlock();
            if (block.getType().isSolid() && !(block.getState() instanceof InventoryHolder)) {
                final Faction factionAt = HCF.getPlugin().getFactionManager().getFactionAt(block.getLocation());
                if (factionAt instanceof ClaimableFaction) {
                    final Player player = event.getPlayer();
                    player.setItemInHand(event.getItem());
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onPearlClip(final PlayerTeleportEvent event) {
        if (!this.plugin.getConfig().getBoolean("enderpearl_glitch_listener")) {
            return;
        }
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            final Location to = event.getTo();
            if (this.blockedPearl.contains(to.getBlock().getType())) {
                final Player player = event.getPlayer();
                final boolean refund = this.plugin.getConfig().getBoolean("enderpearl_glitch_refund");
                player.sendMessage(ChatColor.YELLOW + "Pearl glitching detected" + (refund ? ", used Enderpearl has been refunded" : "") + ".");
                if (refund) {
                    this.plugin.getTimerManager().getEnderPearlTimer().refund(player);
                }
                event.setCancelled(true);
                return;
            }
            to.setX(to.getBlockX() + 0.5);
            to.setZ(to.getBlockZ() + 0.5);
            event.setTo(to);
        }
    }
}
