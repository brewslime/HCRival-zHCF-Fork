package com.hcrival.hcf.listener.fixes;

import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import org.bukkit.potion.*;
import java.util.*;
import org.bukkit.event.*;

public class StrengthFixListener implements Listener
{
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerDamage(final EntityDamageByEntityEvent evt) {
        if (evt.getDamager() instanceof Player) {
            final Player p = (Player)evt.getDamager();
            if (p.hasPotionEffect(PotionEffectType.INCREASE_DAMAGE)) {
                for (final PotionEffect eff : p.getActivePotionEffects()) {
                    if (eff.getType().equals((Object)PotionEffectType.INCREASE_DAMAGE)) {
                        final double div = (eff.getAmplifier() + 1) * 1.3 + 1.0;
                        int dmg;
                        if (evt.getDamage() / div <= 1.0) {
                            dmg = (eff.getAmplifier() + 1) * 3 + 1;
                        }
                        else {
                            final double flatdmg = 2.0;
                            dmg = (int)(evt.getDamage() / div) + (int)((eff.getAmplifier() + 1) * flatdmg);
                        }
                        evt.setDamage((double)dmg);
                        break;
                    }
                }
            }
        }
    }
}
