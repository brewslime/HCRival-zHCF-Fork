package com.hcrival.hcf.listener.fixes;

import com.hcrival.hcf.*;
import org.github.paperspigot.event.block.*;
import org.bukkit.potion.*;
import org.bukkit.event.*;

public class BeaconStrengthFixListener implements Listener
{
    private static final int VANILLA_BEACON_STRENGTH_LIMIT = 2;
    private final HCF plugin;
    
    public BeaconStrengthFixListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPotionEffectAdd(final BeaconEffectEvent event) {
        int limit = this.plugin.getConfig().getInt("settings.beacon_strength_limit");
        if (limit <= 0) {
            event.setCancelled(true);
            return;
        }
        if (--limit >= 2) {
            return;
        }
        final PotionEffect effect = event.getEffect();
        if (effect.getAmplifier() > limit && effect.getType().equals((Object)PotionEffectType.INCREASE_DAMAGE)) {
            event.getPlayer().addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(), limit, effect.isAmbient()));
            event.setCancelled(true);
        }
    }
}
