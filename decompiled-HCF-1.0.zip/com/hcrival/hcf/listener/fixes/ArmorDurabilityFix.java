package com.hcrival.hcf.listener.fixes;

import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class ArmorDurabilityFix implements Listener
{
    @EventHandler
    public void onDurLoss(final PlayerItemDamageEvent event) {
        final Player player = event.getPlayer();
        final int damage = event.getDamage();
        event.setDamage((int)Math.floor(damage / 3));
    }
}
