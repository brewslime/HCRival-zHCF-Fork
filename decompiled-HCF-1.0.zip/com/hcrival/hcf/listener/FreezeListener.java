package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import java.util.*;
import org.bukkit.event.block.*;
import org.bukkit.entity.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.*;
import com.hcrival.hcf.util.*;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.*;
import org.bukkit.potion.*;

public class FreezeListener implements Listener
{
    private final HCF utilities;
    public final Set<UUID> frozen;
    private AlertTask alertTask;
    
    public FreezeListener() {
        this.utilities = HCF.getPlugin();
        this.frozen = new HashSet<UUID>();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this.utilities);
    }
    
    public boolean isFrozen(final Player player) {
        return this.frozen.contains(player.getUniqueId());
    }
    
    public void setFreeze(final CommandSender sender, final Player target, final boolean status) {
        if (status) {
            this.frozen.add(target.getUniqueId());
            (this.alertTask = new AlertTask(target)).runTaskTimerAsynchronously((Plugin)this.utilities, 0L, 100L);
            if (sender instanceof Player) {
                Bukkit.getServer().getConsoleSender().sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis now frozen, frozen by &a" + sender.getName() + "&e."));
                for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                    if (staff.hasPermission("utilities.player.staff")) {
                        if (staff.equals(sender)) {
                            sender.sendMessage(Color.translate("&c" + target.getName() + " &eis now frozen."));
                        }
                        else {
                            staff.sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis now frozen, frozen by &a" + sender.getName() + "&e."));
                        }
                    }
                }
            }
            else {
                sender.sendMessage(Color.translate("&c" + target.getName() + " &eis now frozen."));
                for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                    if (staff.hasPermission("utilities.player.staff")) {
                        staff.sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis now frozen, frozen by &a" + sender.getName() + "&e."));
                    }
                }
            }
        }
        else {
            this.alertTask.cancel();
            this.frozen.remove(target.getUniqueId());
            target.sendMessage(Color.translate("&aYou are no longer frozen."));
            if (sender instanceof Player) {
                Bukkit.getServer().getConsoleSender().sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis no longer frozen, removed by &a" + sender.getName() + "&e."));
                for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                    if (staff.hasPermission("utilities.player.staff")) {
                        if (staff.equals(sender)) {
                            sender.sendMessage(Color.translate("&c" + target.getName() + " &eis no longer frozen."));
                        }
                        else {
                            staff.sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis no longer frozen, removed by &a" + sender.getName() + "&e."));
                        }
                    }
                }
            }
            else {
                sender.sendMessage(Color.translate("&c" + target.getName() + " &eis no longer frozen."));
                for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                    if (staff.hasPermission("utilities.player.staff")) {
                        staff.sendMessage(Color.translate("&7[Alert] &c" + target.getName() + " &eis no longer frozen, removed by &a" + sender.getName() + "&e."));
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerMove(final PlayerMoveEvent event) {
        final Player player = event.getPlayer();
        if (this.isFrozen(player) && (event.getFrom().getX() != event.getTo().getX() || event.getFrom().getZ() != event.getTo().getZ())) {
            event.getPlayer().teleport(event.getFrom());
        }
    }
    
    @EventHandler
    public void onPlayerCommandPreprocess(final PlayerCommandPreprocessEvent event) {
        final Player player = event.getPlayer();
        if (this.isFrozen(player) && !event.getMessage().startsWith("/helpop") && !event.getMessage().startsWith("/faction chat") && !event.getMessage().startsWith("/fac chat") && !event.getMessage().startsWith("/f chat") && !event.getMessage().startsWith("/faction c") && !event.getMessage().startsWith("/fac c") && !event.getMessage().startsWith("/f c") && !event.getMessage().startsWith("/helpop") && !event.getMessage().startsWith("/request") && !event.getMessage().startsWith("/msg") && !event.getMessage().startsWith("/panic") && !event.getMessage().startsWith("/tpm") && !event.getMessage().startsWith("/message") && !event.getMessage().startsWith("/reply")) {
            event.setCancelled(true);
            player.sendMessage(Color.translate("&cYou can not use commands while you are frozen."));
        }
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent event) {
        final Player player = event.getPlayer();
        if (event.getBlock() != null && this.isFrozen(player)) {
            event.setCancelled(true);
            player.sendMessage(Color.translate("&cYou can not place blocks while you are frozen."));
        }
    }
    
    @EventHandler
    public void onBlockBreak(final BlockBreakEvent event) {
        final Player player = event.getPlayer();
        if (event.getBlock() != null && this.isFrozen(player)) {
            event.setCancelled(true);
            player.sendMessage(Color.translate("&cYou can not break blocks while you are frozen."));
        }
    }
    
    @EventHandler
    public void onPlayerKick(final PlayerKickEvent event) {
        final Player player = event.getPlayer();
        if (this.isFrozen(player)) {
            this.alertTask.cancel();
            this.frozen.remove(player.getUniqueId());
        }
    }
    
    public Player getDamager(final Entity entity) {
        if (entity instanceof Player) {
            return (Player)entity;
        }
        if (entity instanceof Projectile) {
            final Projectile projectile = (Projectile)entity;
            if (projectile.getShooter() != null && projectile.getShooter() instanceof Player) {
                return (Player)projectile.getShooter();
            }
        }
        return null;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        final Player damager = this.getDamager(event.getDamager());
        final Player damaged = this.getDamager(event.getEntity());
        if (damager != null && damaged != null && damaged != damager) {
            if (this.utilities.getFreezeListener().isFrozen(damager)) {
                damager.sendMessage(Color.translate("&cYou can not attack players while frozen."));
                event.setCancelled(true);
            }
            if (this.utilities.getFreezeListener().isFrozen(damaged)) {
                damager.sendMessage(Color.translate("&cYou can not attack " + damaged.getName() + " because he is currently frozen."));
                event.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final Player player = event.getPlayer();
        if (this.isFrozen(player)) {
            for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                if (staff.hasPermission("utilities.player.staff") || staff.isOp()) {
                    final FancyMessage fancyMessage = new FancyMessage("");
                    fancyMessage.then(Color.translate("&7[Alert] &6" + player.getName() + " &chas disconnected while frozen. "));
                    fancyMessage.then(Color.translate("&7(Click here to ban)"));
                    fancyMessage.tooltip(Color.translate("&aClick to permanently ban " + player.getName()));
                    fancyMessage.command("/ban " + player.getName() + " Refusal to Screenshare.");
                    fancyMessage.send(staff);
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        if (this.isFrozen(player)) {
            (this.alertTask = new AlertTask(player)).runTaskTimerAsynchronously((Plugin)this.utilities, 0L, 100L);
            for (final Player staff : Bukkit.getServer().getOnlinePlayers()) {
                if (staff.hasPermission("utilities.player.staff")) {
                    final FancyMessage fancyMessage = new FancyMessage("");
                    fancyMessage.then(Color.translate("&7[Alert] &6" + player.getName() + " &chas joined but he is frozen. "));
                    fancyMessage.then(Color.translate("&7(Click here to ban)"));
                    fancyMessage.tooltip(Color.translate("&aClick to permanently ban " + player.getName()));
                    fancyMessage.command("/ban " + player.getName() + " Refusal to Screenshare.");
                    fancyMessage.send(staff);
                }
            }
        }
    }
    
    private class AlertTask extends BukkitRunnable
    {
        private final Player player;
        
        public AlertTask(final Player player) {
            this.player = player;
        }
        
        public void run() {
            if (FreezeListener.this.isFrozen(this.player)) {
                this.player.setHealth(this.player.getMaxHealth());
                this.player.setFireTicks(0);
                this.player.setFoodLevel(20);
                this.player.setSaturation(3.0f);
                for (final PotionEffect potionEffect : this.player.getActivePotionEffects()) {
                    this.player.removePotionEffect(potionEffect.getType());
                }
                for (final String s : HCF.getPlugin().getMessageConfig().getConfig().getStringList("messages.frozen")) {
                    this.player.sendMessage(Color.translate(s));
                }
            }
        }
    }
}
