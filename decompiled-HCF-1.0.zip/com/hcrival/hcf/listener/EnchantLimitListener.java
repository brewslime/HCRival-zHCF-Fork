package com.hcrival.hcf.listener;

import com.google.common.collect.*;
import org.bukkit.*;
import net.minecraft.server.v1_7_R4.*;
import com.hcrival.hcf.*;
import org.bukkit.event.enchantment.*;
import org.bukkit.enchantments.*;
import java.util.regex.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import java.util.*;

public class EnchantLimitListener implements Listener
{
    private final ImmutableMap<Material, EnumToolMaterial> ITEM_TOOL_MAPPING;
    private final ImmutableMap<Material, EnumArmorMaterial> ITEM_ARMOUR_MAPPING;
    private final HCF plugin;
    
    public EnchantLimitListener(final HCF plugin) {
        this.ITEM_TOOL_MAPPING = ImmutableMap.of(Material.IRON_INGOT, EnumToolMaterial.IRON, Material.GOLD_INGOT, EnumToolMaterial.GOLD, Material.DIAMOND, EnumToolMaterial.DIAMOND);
        this.ITEM_ARMOUR_MAPPING = ImmutableMap.of(Material.IRON_INGOT, EnumArmorMaterial.IRON, Material.GOLD_INGOT, EnumArmorMaterial.GOLD, Material.DIAMOND, EnumArmorMaterial.DIAMOND);
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEnchantItem(final EnchantItemEvent event) {
        final Map<Enchantment, Integer> adding = (Map<Enchantment, Integer>)event.getEnchantsToAdd();
        final Iterator<Map.Entry<Enchantment, Integer>> iterator = adding.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<Enchantment, Integer> entry = iterator.next();
            final Enchantment enchantment = entry.getKey();
            final String ench = enchantment.getName();
            int maxLevel = enchantment.getMaxLevel();
            for (final String s : this.plugin.getConfig().getStringList("settings.enchantmentLimits")) {
                final String[] part = s.split(Pattern.quote(";"));
                if (part[0].equalsIgnoreCase(ench)) {
                    maxLevel = Integer.valueOf(part[1]);
                }
            }
            if (entry.getValue() > maxLevel) {
                if (maxLevel > 0) {
                    adding.put(enchantment, maxLevel);
                }
                else {
                    iterator.remove();
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityDeath(final EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            for (final ItemStack drop : event.getDrops()) {
                this.validateIllegalEnchants(drop);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerFishEvent(final PlayerFishEvent event) {
        final Entity caught = event.getCaught();
        if (caught instanceof Item) {
            this.validateIllegalEnchants(((Item)caught).getItemStack());
        }
    }
    
    private boolean validateIllegalEnchants(final ItemStack stack) {
        boolean updated = false;
        if (stack != null && stack.getType() != Material.AIR) {
            final ItemMeta meta = stack.getItemMeta();
            if (meta instanceof EnchantmentStorageMeta) {
                final EnchantmentStorageMeta enchantmentStorageMeta = (EnchantmentStorageMeta)meta;
                final Set<Map.Entry<Enchantment, Integer>> entries = enchantmentStorageMeta.getStoredEnchants().entrySet();
                for (final Map.Entry<Enchantment, Integer> entry : entries) {
                    final Enchantment enchantment = entry.getKey();
                    final String ench = enchantment.getName();
                    int maxLevel = enchantment.getMaxLevel();
                    for (final String s : this.plugin.getConfig().getStringList("settings.enchantmentLimits")) {
                        final String[] part = s.split(Pattern.quote(";"));
                        if (part[0].equalsIgnoreCase(ench)) {
                            maxLevel = Integer.valueOf(part[1]);
                        }
                    }
                    if (entry.getValue() > maxLevel) {
                        updated = true;
                        if (maxLevel > 0) {
                            enchantmentStorageMeta.addStoredEnchant(enchantment, maxLevel, false);
                        }
                        else {
                            enchantmentStorageMeta.removeStoredEnchant(enchantment);
                        }
                    }
                }
                stack.setItemMeta(meta);
            }
            else {
                final Set<Map.Entry<Enchantment, Integer>> entries = stack.getEnchantments().entrySet();
                for (final Map.Entry<Enchantment, Integer> entry2 : entries) {
                    final Enchantment enchantment2 = entry2.getKey();
                    final String ench2 = enchantment2.getName();
                    int maxLevel2 = enchantment2.getMaxLevel();
                    for (final String s2 : this.plugin.getConfig().getStringList("settings.enchantmentLimits")) {
                        final String[] part2 = s2.split(Pattern.quote(";"));
                        if (part2[0].equalsIgnoreCase(ench2)) {
                            maxLevel2 = Integer.valueOf(part2[1]);
                        }
                    }
                    if (entry2.getValue() > maxLevel2) {
                        updated = true;
                        stack.removeEnchantment(enchantment2);
                        if (maxLevel2 <= 0) {
                            continue;
                        }
                        stack.addEnchantment(enchantment2, maxLevel2);
                    }
                }
            }
        }
        return updated;
    }
}
