package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class BookDisenchantListener implements Listener
{
    private final HCF plugin;
    
    public BookDisenchantListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void disenchantBook(final PlayerInteractEvent event) {
        final Player player = event.getPlayer();
        final ItemStack item = player.getItemInHand();
        if (item == null || item.getType() != Material.ENCHANTED_BOOK) {
            return;
        }
        event.setCancelled(true);
        player.setItemInHand(new ItemStack(Material.BOOK, 1));
        player.sendMessage(ChatColor.YELLOW + "You reverted this item to its original form.");
    }
}
