package com.hcrival.hcf.listener;

import com.hcrival.hcf.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.user.*;
import org.bukkit.event.*;
import org.bukkit.command.*;
import java.util.concurrent.*;
import org.bukkit.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.faction.struct.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;

public class DeathListener implements Listener
{
    private final HCF plugin;
    
    public DeathListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onPlayerDeathKillIncrement(final PlayerDeathEvent event) {
        final Player killer = event.getEntity().getKiller();
        if (killer != null) {
            final FactionUser user = this.plugin.getUserManager().getUser(killer.getUniqueId());
            user.setKills(user.getKills() + 1);
            if (this.plugin.getFactionManager().getPlayerFaction(killer) != null) {
                this.plugin.getFactionManager().getPlayerFaction(killer).setPoints(this.plugin.getFactionManager().getPlayerFaction(killer).getPoints() + 1);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        final Player player = event.getEntity();
        final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
        if (HCF.getPlugin().getConfig().getBoolean("server.kitmap")) {
            final Player killer = event.getEntity().getKiller();
            HCF.getPlugin().getServer().dispatchCommand((CommandSender)HCF.getPlugin().getServer().getConsoleSender(), HCF.getPlugin().getConfig().getString("settings.kitmap_kill_reward_command").replace("%player%", killer.getName()));
        }
        this.plugin.getUserManager().getUser(player.getUniqueId()).setDeaths(this.plugin.getUserManager().getUser(player.getUniqueId()).getDeaths() + 1);
        if (playerFaction == null) {
            return;
        }
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(player.getLocation());
        if (HCF.getPlugin().getConfig().getBoolean("server.kitmap")) {
            final double dtrLoss = 0.1 * factionAt.getDtrLossMultiplier();
            final double newDtr = playerFaction.setDeathsUntilRaidable(playerFaction.getDeathsUntilRaidable() - dtrLoss);
            final Role role = playerFaction.getMember(player.getUniqueId()).getRole();
            final long baseDelay = TimeUnit.MINUTES.toMillis(this.plugin.getConfig().getInt("settings.regen"));
            playerFaction.setRemainingRegenerationTime(baseDelay + playerFaction.getOnlinePlayers().size());
            playerFaction.broadcast(ChatColor.GOLD + "Member Death: " + ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + role.getAstrix() + player.getName() + ChatColor.GOLD + ". DTR: (" + ChatColor.WHITE + JavaUtils.format(newDtr, 2) + '/' + JavaUtils.format(playerFaction.getMaximumDeathsUntilRaidable(), 2) + ChatColor.GOLD + ").");
            playerFaction.setPoints(playerFaction.getPoints() - 2);
        }
        else {
            final double dtrLoss = 1.0 * factionAt.getDtrLossMultiplier();
            final double newDtr = playerFaction.setDeathsUntilRaidable(playerFaction.getDeathsUntilRaidable() - dtrLoss);
            final Role role = playerFaction.getMember(player.getUniqueId()).getRole();
            final long baseDelay = TimeUnit.MINUTES.toMillis(this.plugin.getConfig().getInt("settings.regen"));
            playerFaction.setRemainingRegenerationTime(baseDelay + playerFaction.getOnlinePlayers().size());
            playerFaction.broadcast(ChatColor.GOLD + "Member Death: " + ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + role.getAstrix() + player.getName() + ChatColor.GOLD + ". DTR: (" + ChatColor.WHITE + JavaUtils.format(newDtr, 2) + '/' + JavaUtils.format(playerFaction.getMaximumDeathsUntilRaidable(), 2) + ChatColor.GOLD + ").");
            playerFaction.setPoints(playerFaction.getPoints() - 2);
        }
    }
    
    @EventHandler
    public void onDeath(final PlayerDeathEvent e) {
        final Player p = e.getEntity();
        if (HCF.getPlugin().getInventoryRestore().containsKey(p.getUniqueId())) {
            HCF.getPlugin().getInventoryRestore().remove(p.getUniqueId());
        }
        HCF.getPlugin().getInventoryRestore().put(p.getUniqueId(), (Inventory)p.getInventory());
    }
    
    @EventHandler
    public void onRespawn(final PlayerRespawnEvent e) {
        e.getPlayer().getInventory().clear();
        e.getPlayer().getInventory().setHelmet((ItemStack)null);
        e.getPlayer().getInventory().setChestplate((ItemStack)null);
        e.getPlayer().getInventory().setLeggings((ItemStack)null);
        e.getPlayer().getInventory().setBoots((ItemStack)null);
    }
}
