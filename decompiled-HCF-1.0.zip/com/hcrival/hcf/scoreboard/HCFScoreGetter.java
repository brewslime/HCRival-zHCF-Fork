package com.hcrival.hcf.scoreboard;

import net.frozenorb.qlib.scoreboard.*;
import java.text.*;
import org.bukkit.configuration.file.*;
import net.frozenorb.qlib.util.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.events.tracker.*;
import com.hcrival.hcf.classes.bard.*;
import com.hcrival.hcf.classes.archer.*;
import com.google.common.collect.*;
import com.hcrival.hcf.classes.type.*;
import org.bukkit.*;
import com.hcrival.hcf.command.*;
import org.bukkit.potion.*;
import com.hcrival.hcf.timer.*;
import com.hcrival.hcf.timer.custom.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.timer.type.*;
import com.hcrival.hcf.user.*;
import com.hcrival.hcf.faction.type.*;
import com.hcrival.hcf.events.eotw.*;
import com.hcrival.hcf.timer.sotw.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.classes.*;
import java.util.*;
import com.hcrival.hcf.*;
import java.util.function.*;

public class HCFScoreGetter implements ScoreGetter
{
    public static final ThreadLocal<DecimalFormat> CONQUEST_FORMATTER;
    protected String STRAIGHT_LINE;
    private static final Comparator<Map.Entry<UUID, ArcherMark>> ARCHER_MARK_COMPARATOR;
    YamlConfiguration mConfig;
    
    public HCFScoreGetter() {
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
    }
    
    public void getScores(final LinkedList<String> linkedList, final Player player) {
        final LinkedList<String> toReturn = linkedList;
        if (this.mConfig.getBoolean("scoreboard.separator.enabled")) {
            toReturn.add((Object)("&a" + this.mConfig.getString("scoreboard.separator.line")));
        }
        if (HCF.getPlugin() != null && HCF.getPlugin().getTimerManager() != null && HCF.getPlugin().getTimerManager().getAutoRestartTimer() != null) {
            final AutoRestartTimer.AutoRestartRunnable restart = HCF.getPlugin().getTimerManager().getAutoRestartTimer().getAutoRestartRunnable();
            if (restart != null) {
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.restart").replace("%restart%", DurationFormatter.getRemaining(restart.getRemaining(), true)));
            }
        }
        if (HCF.getPlugin().getConfig().getBoolean("server.kitmap")) {
            final FactionUser member = HCF.getPlugin().getUserManager().getUserAsync(player.getUniqueId());
            if (this.mConfig.getBoolean("scoreboard.timers.kitmap.only_in_safezone")) {
                final Faction factionAt = HCF.getPlugin().getFactionManager().getFactionAt(player.getLocation());
                if (factionAt.isSafezone()) {
                    for (final String s : this.mConfig.getStringList("scoreboard.timers.kitmap.lines")) {
                        toReturn.add((Object)s.replace("%kills%", Integer.toString(member.getKills())).replace("%deaths%", Integer.toString(member.getDeaths())));
                    }
                }
            }
            else {
                for (final String s2 : this.mConfig.getStringList("scoreboard.timers.kitmap.lines")) {
                    toReturn.add((Object)s2.replace("%kills%", Integer.toString(member.getKills())).replace("%deaths%", Integer.toString(member.getDeaths())));
                }
            }
        }
        if (HCF.getPlugin().getStaffModeListener().isStaffModeActive(player)) {
            for (final String s3 : this.mConfig.getStringList("scoreboard.staff_mode.lines")) {
                final String formatted = s3.replace("%gamemode%", player.getGameMode().name()).replace("%vanish%", HCF.getPlugin().getStaffModeListener().isVanished(player) ? "&aYes" : "&cNo").replace("%players%", Integer.toString(Bukkit.getServer().getOnlinePlayers().size()));
                toReturn.add((Object)formatted);
            }
        }
        final EotwHandler.EotwRunnable eotwRunnable = HCF.getPlugin().getEotwHandler().getRunnable();
        if (eotwRunnable != null) {
            long remaining = eotwRunnable.getMillisUntilStarting();
            if (remaining > 0L) {
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.eotw.start").replace("%eotw%", DurationFormatter.getRemaining(remaining, true)));
            }
            else if ((remaining = eotwRunnable.getMillisUntilCappable()) > 0L) {
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.eotw.cappable").replace("%eotw%", DurationFormatter.getRemaining(remaining, true)));
            }
        }
        final SotwTimer.SotwRunnable sotwRunnable = HCF.getPlugin().getSotwTimer().getSotwRunnable();
        if (sotwRunnable != null) {
            if (HCF.getPlugin().getUserManager().getUser(player.getUniqueId()).isSOTW()) {
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.sotw.normal").replace("%sotw%", DurationFormatter.getRemaining(sotwRunnable.getRemaining(), true)));
            }
            else {
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.sotw.enabled").replace("%sotw%", DurationFormatter.getRemaining(sotwRunnable.getRemaining(), true)));
            }
        }
        final EventTimer eventTimer = HCF.getPlugin().getTimerManager().getEventTimer();
        final EventFaction eventFaction = eventTimer.getEventFaction();
        if (eventFaction instanceof KothFaction) {
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.koth").replace("%koth%", eventTimer.getName()).replace("%duration%", DurationFormatter.getRemaining(eventTimer.getRemaining(), true)));
        }
        else if (eventFaction instanceof ConquestFaction) {
            final ConquestFaction conquestFaction = (ConquestFaction)eventFaction;
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.conquest.title"));
            toReturn.add((Object)("&dMain: &f" + conquestFaction.getMain().getScoreboardRemaining()));
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.conquest.red").replace("%red%", conquestFaction.getRed().getScoreboardRemaining()));
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.conquest.yellow").replace("%yellow%", conquestFaction.getYellow().getScoreboardRemaining()));
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.conquest.green").replace("%green%", conquestFaction.getGreen().getScoreboardRemaining()));
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.conquest.blue").replace("%blue%", conquestFaction.getBlue().getScoreboardRemaining()));
            final ConquestTracker conquestTracker = (ConquestTracker)conquestFaction.getEventType().getEventTracker();
            int count = 0;
            for (final Map.Entry<PlayerFaction, Integer> entry : conquestTracker.getFactionPointsMap().entrySet()) {
                toReturn.add((Object)"&6&7&m---------------------");
                String factionName = entry.getKey().getName();
                if (factionName.length() > 14) {
                    factionName = factionName.substring(0, 14);
                }
                toReturn.add((Object)"&2Points");
                toReturn.add((Object)("&b" + factionName + " &f[" + entry.getValue().toString() + "]"));
                if (++count == 3) {
                    break;
                }
            }
        }
        final PvpClass pvpClass = HCF.getPlugin().getPvpClassManager().getEquippedClass(player);
        if (pvpClass != null) {
            toReturn.add((Object)this.mConfig.getString("scoreboard.timers.pvp_class.title").replace("%class%", pvpClass.getName()));
            if (pvpClass instanceof BardClass) {
                final BardClass bardClass = (BardClass)pvpClass;
                toReturn.add((Object)this.mConfig.getString("scoreboard.timers.pvp_class.bard.energy").replace("%energy%", this.handleBardFormat(bardClass.getEnergyMillis(player), true)));
                final long remaining2 = bardClass.getRemainingBuffDelay(player);
                if (remaining2 > 0L) {
                    toReturn.add((Object)this.mConfig.getString("scoreboard.timers.pvp_class.bard.buff_delay").replace("%buffdelay%", DurationFormatter.getRemaining(remaining2, true)));
                }
            }
            else if (pvpClass instanceof ArcherClass) {
                final ArcherClass archerClass = (ArcherClass)pvpClass;
                List<Map.Entry<UUID, ArcherMark>> entryList = Ordering.from(HCFScoreGetter.ARCHER_MARK_COMPARATOR).sortedCopy(archerClass.getSentMarks(player).entrySet());
                entryList = entryList.subList(0, Math.min(entryList.size(), 3));
                for (final Map.Entry<UUID, ArcherMark> entry2 : entryList) {
                    final ArcherMark archerMark = entry2.getValue();
                    final Player target = Bukkit.getPlayer((UUID)entry2.getKey());
                    if (target != null) {
                        String targetName = target.getName();
                        targetName = targetName.substring(0, Math.min(targetName.length(), 15));
                        toReturn.add((Object)this.mConfig.getString("scoreboard.timers.pvp_class.archer.mark").replace("%player%", targetName).replace("%level%", Integer.toString(archerMark.currentLevel)));
                    }
                }
            }
            else if (pvpClass instanceof MinerClass) {
                final MinerClass minerClass = (MinerClass)pvpClass;
                final int diamonds = player.getStatistic(Statistic.MINE_BLOCK, Material.DIAMOND_ORE);
                final String cobble = CobbleCommand.disabled.contains(player) ? "&cDisabled" : "&aEnabled";
                final String invis = player.hasPotionEffect(PotionEffectType.INVISIBILITY) ? "&aEnabled" : "&cDisabled";
                for (final String mLine : this.mConfig.getStringList("scoreboard.miner_class.lines")) {
                    final String finished = mLine.replace("%diamonds_mined%", String.valueOf(diamonds)).replace("%cobble_pickup%", cobble).replace("%invisibility_enabled%", invis);
                    toReturn.add((Object)finished);
                }
            }
        }
        final Collection<Timer> timers = HCF.getPlugin().getTimerManager().getTimers();
        for (final Timer timer : timers) {
            if (timer instanceof PlayerTimer) {
                final PlayerTimer playerTimer = (PlayerTimer)timer;
                final long remaining3 = playerTimer.getRemaining(player);
                if (remaining3 <= 0L) {
                    continue;
                }
                final String timerName = playerTimer.getName();
                toReturn.add((Object)HCF.getPlugin().getConfig().getString("timers." + timer.getName()).replace("%remaining%", DurationFormatter.getRemaining(remaining3, true)));
            }
        }
        for (final CustomTimer customTimer : CustomTimer.getCustomTimers()) {
            final String display = Color.translate(customTimer.getDisplay());
            final String time = DurationFormatter.getRemaining(customTimer.getCurrentSecond(), true);
            toReturn.add((Object)(display + "&7: &f" + time));
        }
        toReturn.add((Object)" ");
        toReturn.add((Object)"&7&ohcrival.com");
        if (this.mConfig.getBoolean("scoreboard.separator.enabled")) {
            toReturn.add((Object)this.mConfig.getString("scoreboard.separator.line"));
        }
        if (toReturn.size() <= 4) {
            linkedList.clear();
        }
    }
    
    private String handleBardFormat(final long millis, final boolean trailingZero) {
        return (trailingZero ? DateTimeFormats.REMAINING_SECONDS_TRAILING : DateTimeFormats.REMAINING_SECONDS).get().format(millis * 0.001);
    }
    
    static {
        CONQUEST_FORMATTER = new ThreadLocal<DecimalFormat>() {
            @Override
            protected DecimalFormat initialValue() {
                return new DecimalFormat("00.0");
            }
        };
        ARCHER_MARK_COMPARATOR = Comparator.comparing((Function<? super Map.Entry<UUID, ArcherMark>, ? extends Comparable>)Map.Entry::getValue);
    }
}
