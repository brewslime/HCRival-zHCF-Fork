package com.hcrival.hcf.scoreboard;

import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;
import net.frozenorb.qlib.scoreboard.*;

public class HCFScoreboardConfiguration
{
    public static ScoreboardConfiguration create() {
        final ScoreboardConfiguration configuration = new ScoreboardConfiguration();
        configuration.setTitleGetter(new TitleGetter(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("scoreboard.title"))));
        configuration.setScoreGetter((ScoreGetter)new HCFScoreGetter());
        return configuration;
    }
}
