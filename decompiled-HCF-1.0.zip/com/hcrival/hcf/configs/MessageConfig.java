package com.hcrival.hcf.configs;

import org.bukkit.configuration.file.*;
import com.hcrival.hcf.*;
import org.bukkit.plugin.java.*;

public class MessageConfig
{
    private SecondaryConfigFile root;
    private YamlConfiguration config;
    
    public MessageConfig() {
        this.root = new SecondaryConfigFile(HCF.getPlugin(), "messages", HCF.getPlugin().getDataFolder().getAbsolutePath());
        this.config = this.getRoot().getConfiguration();
    }
    
    public SecondaryConfigFile getRoot() {
        return this.root;
    }
    
    public YamlConfiguration getConfig() {
        return this.config;
    }
}
