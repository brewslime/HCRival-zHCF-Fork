package com.hcrival.hcf.configs;

import com.hcrival.hcf.*;
import org.bukkit.configuration.file.*;
import java.io.*;
import org.bukkit.*;
import java.util.*;

public class ConfigFile
{
    private static Set<ConfigFile> files;
    private final String name;
    private final File file;
    private final FileConfiguration config;
    
    public ConfigFile(final String name) {
        this.name = name;
        this.file = new File(HCF.getPlugin().getDataFolder(), name);
        this.config = (FileConfiguration)YamlConfiguration.loadConfiguration(this.file);
        HCF.getPlugin().getLogger().info("Loaded file " + name);
        ConfigFile.files.add(this);
    }
    
    public void save() {
        try {
            this.config.save(this.file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void saveDefault() {
        HCF.getPlugin().saveResource(this.name, false);
    }
    
    public List<String> getStringList(final String path) {
        final List<String> toReturn = new ArrayList<String>();
        for (final String str : this.config.getStringList(path)) {
            toReturn.add(ChatColor.translateAlternateColorCodes('&', str));
        }
        return toReturn;
    }
    
    public String getString(final String path) {
        return ChatColor.translateAlternateColorCodes('&', this.config.getString(path));
    }
    
    public Double getDouble(final String path) {
        return this.config.getDouble(path);
    }
    
    public int getInt(final String s) {
        return this.config.getInt(s);
    }
    
    public String getName() {
        return this.name;
    }
    
    public File getFile() {
        return this.file;
    }
    
    public FileConfiguration getConfig() {
        return this.config;
    }
    
    public static Set<ConfigFile> getFiles() {
        return ConfigFile.files;
    }
    
    static {
        ConfigFile.files = new HashSet<ConfigFile>();
    }
}
