package com.hcrival.hcf.configs;

import org.bukkit.configuration.file.*;
import org.bukkit.plugin.java.*;
import java.io.*;

public class SecondaryConfigFile
{
    private File file;
    private String name;
    private String directory;
    private YamlConfiguration configuration;
    
    public SecondaryConfigFile(final JavaPlugin plugin, final String name, final String directory) {
        this.setName(name);
        this.setDirectory(directory);
        this.file = new File(directory, name + ".yml");
        if (!this.file.exists()) {
            plugin.saveResource(name + ".yml", false);
        }
        this.configuration = YamlConfiguration.loadConfiguration(this.getFile());
    }
    
    public void save() {
        try {
            this.configuration.save(this.file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public File getFile() {
        return this.file;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDirectory() {
        return this.directory;
    }
    
    public YamlConfiguration getConfiguration() {
        return this.configuration;
    }
    
    public void setFile(final File file) {
        this.file = file;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setDirectory(final String directory) {
        this.directory = directory;
    }
    
    public void setConfiguration(final YamlConfiguration configuration) {
        this.configuration = configuration;
    }
}
