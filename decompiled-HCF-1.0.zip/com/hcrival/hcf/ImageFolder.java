package com.hcrival.hcf;

import java.awt.image.*;
import java.util.logging.*;
import javax.imageio.*;
import com.google.common.io.*;
import java.io.*;

public class ImageFolder
{
    private final File directory;
    private final HCF plugin;
    private BufferedImage gopple;
    
    public ImageFolder(final HCF plugin) {
        this.plugin = plugin;
        this.directory = new File(plugin.getDataFolder(), "imageMessages");
        if (!this.directory.exists() && this.directory.mkdir()) {
            plugin.getLogger().log(Level.INFO, "Created image directory");
        }
        this.gopple = this.load("gapple.png");
    }
    
    public BufferedImage load(final String imageName) {
        final File file = new File(this.directory, imageName);
        if (file.exists()) {
            try {
                return ImageIO.read(file);
            }
            catch (IOException ex2) {}
        }
        this.plugin.getLogger().info("Attempting to copy resource '" + imageName + "' to plugin folder");
        try (final InputStream input = this.plugin.getResource(this.directory.getName() + "/" + file.getName());
             final OutputStream output = new FileOutputStream(file)) {
            ByteStreams.copy(input, output);
            return ImageIO.read(input);
        }
        catch (IOException ex) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to get resource for file '" + imageName + "'", ex);
            return null;
        }
    }
    
    public File getDirectory() {
        return this.directory;
    }
    
    public BufferedImage getGopple() {
        return this.gopple;
    }
}
