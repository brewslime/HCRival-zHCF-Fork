package com.hcrival.hcf.events;

import com.hcrival.hcf.*;
import com.hcrival.hcf.events.tracker.*;
import com.google.common.collect.*;

public enum EventType
{
    CONQUEST("Conquest", (EventTracker)new ConquestTracker(HCF.getPlugin())), 
    KOTH("KOTH", (EventTracker)new KothTracker(HCF.getPlugin()));
    
    private final EventTracker eventTracker;
    private final String displayName;
    private static final ImmutableMap<String, EventType> byDisplayName;
    
    private EventType(final String displayName, final EventTracker eventTracker) {
        this.displayName = displayName;
        this.eventTracker = eventTracker;
    }
    
    public EventTracker getEventTracker() {
        return this.eventTracker;
    }
    
    public String getDisplayName() {
        return this.displayName;
    }
    
    @Deprecated
    public static EventType getByDisplayName(final String name) {
        return EventType.byDisplayName.get(name.toLowerCase());
    }
    
    static {
        final ImmutableMap.Builder<String, EventType> builder = new ImmutableBiMap.Builder<String, EventType>();
        for (final EventType eventType : values()) {
            builder.put(eventType.displayName.toLowerCase(), eventType);
        }
        byDisplayName = builder.build();
    }
}
