package com.hcrival.hcf.events.conquest;

import com.hcrival.hcf.*;
import com.hcrival.util.command.*;

public class ConquestExecutor extends ArgumentExecutor
{
    public ConquestExecutor(final HCF plugin) {
        super("conquest");
        this.addArgument(new ConquestSetpointsArgument(plugin));
    }
}
