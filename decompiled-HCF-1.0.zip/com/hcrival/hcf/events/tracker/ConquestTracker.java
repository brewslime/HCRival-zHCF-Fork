package com.hcrival.hcf.events.tracker;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import com.hcrival.hcf.faction.event.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.event.*;
import com.hcrival.base.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.event.entity.*;
import java.util.concurrent.*;

@Deprecated
public class ConquestTracker implements EventTracker, Listener
{
    private static final long MINIMUM_CONTROL_TIME_ANNOUNCE;
    public static final long DEFAULT_CAP_MILLIS;
    private final ConcurrentValueOrderedMap<PlayerFaction, Integer> factionPointsMap;
    private final HCF plugin;
    
    public ConquestTracker(final HCF plugin) {
        this.factionPointsMap = new ConcurrentValueOrderedMap<PlayerFaction, Integer>();
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFactionRemove(final FactionRemoveEvent event) {
        final Faction faction = event.getFaction();
        if (faction instanceof PlayerFaction) {
            this.factionPointsMap.remove(faction);
        }
    }
    
    public ConcurrentValueOrderedMap<PlayerFaction, Integer> getFactionPointsMap() {
        return this.factionPointsMap;
    }
    
    public int getPoints(final PlayerFaction faction) {
        return GuavaCompat.firstNonNull(this.factionPointsMap.get(faction), 0);
    }
    
    public int setPoints(final PlayerFaction faction, final int amount) {
        this.factionPointsMap.put(faction, amount);
        return amount;
    }
    
    public int takePoints(final PlayerFaction faction, final int amount) {
        return this.setPoints(faction, this.getPoints(faction) - amount);
    }
    
    public int addPoints(final PlayerFaction faction, final int amount) {
        return this.setPoints(faction, this.getPoints(faction) + amount);
    }
    
    @Override
    public EventType getEventType() {
        return EventType.CONQUEST;
    }
    
    @Override
    public void tick(final EventTimer eventTimer, final EventFaction eventFaction) {
        final ConquestFaction conquestFaction = (ConquestFaction)eventFaction;
        final List<CaptureZone> captureZones = conquestFaction.getCaptureZones();
        for (final CaptureZone captureZone : captureZones) {
            captureZone.updateScoreboardRemaining();
            final Player cappingPlayer = captureZone.getCappingPlayer();
            if (cappingPlayer == null) {
                continue;
            }
            if (!captureZone.getCuboid().contains(cappingPlayer)) {
                this.onControlLoss(cappingPlayer, captureZone, eventFaction);
            }
            else {
                final long remainingMillis = captureZone.getRemainingCaptureMillis();
                if (remainingMillis <= 0L) {
                    final UUID uuid = cappingPlayer.getUniqueId();
                    final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(uuid);
                    if (playerFaction != null) {
                        final int newPoints = this.addPoints(playerFaction, 1);
                        if (newPoints >= 250) {
                            this.factionPointsMap.clear();
                            this.plugin.getTimerManager().getEventTimer().handleWinner(cappingPlayer);
                            return;
                        }
                        captureZone.setRemainingCaptureMillis(captureZone.getDefaultCaptureMillis());
                        Bukkit.broadcastMessage(Color.translate("&6[Conquest] &e" + playerFaction.getName() + " &6gained 1 point for capturing &e" + captureZone.getDisplayName() + "&6. &7(" + newPoints + "/250)"));
                    }
                    return;
                }
                final int remainingSeconds = (int)Math.round(remainingMillis / 1000.0);
                if (remainingSeconds % 5 != 0) {
                    continue;
                }
                cappingPlayer.sendMessage(ChatColor.YELLOW + "[" + eventFaction.getName() + "] " + ChatColor.GOLD + "Attempting to control " + ChatColor.YELLOW + captureZone.getDisplayName() + ChatColor.GOLD + ". " + ChatColor.YELLOW + '(' + remainingSeconds + "s)");
            }
        }
    }
    
    @Override
    public void onContest(final EventFaction eventFaction, final EventTimer eventTimer) {
        Bukkit.broadcastMessage(ChatColor.YELLOW + ((eventFaction instanceof ConquestFaction) ? "" : ("[" + eventFaction.getName() + "] ")) + ChatColor.GOLD + eventFaction.getName() + " can now be contested.");
    }
    
    @Override
    public boolean onControlTake(final Player player, final CaptureZone captureZone, final EventFaction eventFaction) {
        if (this.plugin.getFactionManager().getPlayerFaction(player.getUniqueId()) == null) {
            player.sendMessage(ChatColor.RED + "You must be in a faction to capture for Conquest.");
            return false;
        }
        return true;
    }
    
    @Override
    public void onControlLoss(final Player player, final CaptureZone captureZone, final EventFaction eventFaction) {
        final long remainingMillis = captureZone.getRemainingCaptureMillis();
        if (remainingMillis > 0L && captureZone.getDefaultCaptureMillis() - remainingMillis > ConquestTracker.MINIMUM_CONTROL_TIME_ANNOUNCE) {
            Bukkit.broadcastMessage(ChatColor.YELLOW + "[" + eventFaction.getName() + "] " + ChatColor.LIGHT_PURPLE + ChatColor.BOLD + player.getName() + ChatColor.GOLD + " was knocked off " + captureZone.getDisplayName() + ChatColor.GOLD + '.');
        }
    }
    
    @Override
    public void stopTiming() {
        this.factionPointsMap.clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        final Faction currentEventFac = this.plugin.getTimerManager().getEventTimer().getEventFaction();
        if (currentEventFac instanceof ConquestFaction) {
            final Player player = event.getEntity();
            final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
            if (playerFaction != null) {
                final int oldPoints = this.getPoints(playerFaction);
                if (oldPoints == 0) {
                    return;
                }
                final int newPoints = this.takePoints(playerFaction, 20);
                event.setDeathMessage((String)null);
                Bukkit.broadcastMessage(ChatColor.YELLOW + "[" + currentEventFac.getName() + "] " + ChatColor.GOLD + playerFaction.getName() + " lost 20 points because " + player.getName() + " died." + ChatColor.AQUA + " (" + newPoints + '/' + "300" + ')' + ChatColor.YELLOW + '.');
            }
        }
    }
    
    static {
        MINIMUM_CONTROL_TIME_ANNOUNCE = TimeUnit.SECONDS.toMillis(5L);
        DEFAULT_CAP_MILLIS = TimeUnit.SECONDS.toMillis(30L);
    }
}
