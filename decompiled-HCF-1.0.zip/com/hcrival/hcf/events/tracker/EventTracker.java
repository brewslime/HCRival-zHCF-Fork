package com.hcrival.hcf.events.tracker;

import com.hcrival.hcf.events.faction.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.events.*;

@Deprecated
public interface EventTracker
{
    EventType getEventType();
    
    void tick(final EventTimer p0, final EventFaction p1);
    
    void onContest(final EventFaction p0, final EventTimer p1);
    
    boolean onControlTake(final Player p0, final CaptureZone p1, final EventFaction p2);
    
    void onControlLoss(final Player p0, final CaptureZone p1, final EventFaction p2);
    
    void stopTiming();
}
