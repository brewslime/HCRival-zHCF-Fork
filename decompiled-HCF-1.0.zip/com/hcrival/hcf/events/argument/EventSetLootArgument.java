package com.hcrival.hcf.events.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.events.*;
import net.minecraft.util.com.google.common.primitives.*;
import org.bukkit.inventory.*;
import java.util.*;

public class EventSetLootArgument extends CommandArgument
{
    private final HCF plugin;
    
    public EventSetLootArgument(final HCF plugin) {
        super("setloottable", "Sets the loot table of an event key at a specific slot");
        this.plugin = plugin;
        this.aliases = new String[] { "setloot" };
        this.permission = "hcf.command.event.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <eventType> <inventoryNumber>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final EventType eventType = EventType.getByDisplayName(args[1]);
        if (eventType == null) {
            sender.sendMessage(ChatColor.RED + "There is not an event type named " + args[1] + '.');
            return true;
        }
        Integer index = Ints.tryParse(args[2]);
        if (index == null) {
            sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a number.");
            return true;
        }
        final List<Inventory> inventories = this.plugin.getKeyManager().getEventKey().getInventories(eventType);
        final int size = inventories.size();
        if (index < 1) {
            sender.sendMessage(ChatColor.RED + "You cannot edit an inventory less than 1.");
            return true;
        }
        if (index > size) {
            sender.sendMessage(ChatColor.RED + "There are only " + size + " possible loot inventories for " + eventType.getDisplayName() + ChatColor.RED + ". Use " + ChatColor.YELLOW + '/' + label + " addloottable " + eventType.name() + ChatColor.RED + " to add another.");
            return true;
        }
        ((Player)sender).openInventory((Inventory)inventories.get(--index));
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        final EventType[] values = EventType.values();
        final List<String> results = new ArrayList<String>(values.length);
        for (final EventType eventType : values) {
            results.add(eventType.name());
        }
        return results;
    }
}
