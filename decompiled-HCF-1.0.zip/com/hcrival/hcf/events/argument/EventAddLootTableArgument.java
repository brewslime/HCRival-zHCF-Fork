package com.hcrival.hcf.events.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.events.*;
import com.hcrival.util.*;
import org.bukkit.*;
import com.hcrival.hcf.events.crate.*;
import org.bukkit.inventory.*;
import java.util.*;

public class EventAddLootTableArgument extends CommandArgument
{
    private final HCF plugin;
    
    public EventAddLootTableArgument(final HCF plugin) {
        super("addloottable", "Adds another loot table for an event type");
        this.plugin = plugin;
        this.permission = "hcf.command.event.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <eventType> [size (multiple of 9)]";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final EventType eventType = EventType.getByDisplayName(args[1]);
        if (eventType == null) {
            sender.sendMessage(ChatColor.RED + "There is not an event type named " + args[1] + '.');
            return true;
        }
        Integer size = JavaUtils.tryParseInt(args[2]);
        if (size == null) {
            size = 27;
        }
        else {
            if (size % 9 != 0) {
                sender.sendMessage(ChatColor.RED + "Inventory size must be a multiple of " + 9 + '.');
                return true;
            }
            if (size < 9) {
                sender.sendMessage(ChatColor.RED + "Inventory size must be at least " + 9 + '.');
                return true;
            }
            if (size > 54) {
                sender.sendMessage(ChatColor.RED + "Inventory size must be at most " + 54 + '.');
                return true;
            }
        }
        final EventKey eventKey = this.plugin.getKeyManager().getEventKey();
        final Collection<Inventory> inventories = eventKey.getInventories(eventType);
        final int newAmount = inventories.size() + 1;
        inventories.add(Bukkit.createInventory((InventoryHolder)null, (int)size, eventType.getDisplayName() + " Loot " + newAmount));
        sender.sendMessage(ChatColor.YELLOW + "Created a new key inventory of size " + size + " for event " + eventType.getDisplayName() + ". There are now " + newAmount + " inventories.");
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        final EventType[] eventTypes = EventType.values();
        final List<String> results = new ArrayList<String>(eventTypes.length);
        for (final EventType eventType : eventTypes) {
            results.add(eventType.name());
        }
        return results;
    }
}
