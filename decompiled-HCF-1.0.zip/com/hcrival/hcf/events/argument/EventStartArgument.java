package com.hcrival.hcf.events.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.events.faction.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class EventStartArgument extends CommandArgument
{
    private final HCF plugin;
    
    public EventStartArgument(final HCF plugin) {
        super("start", "Starts an event");
        this.plugin = plugin;
        this.aliases = new String[] { "begin" };
        this.permission = "hcf.command.event.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <eventName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Faction faction = this.plugin.getFactionManager().getFaction(args[1]);
        if (!(faction instanceof EventFaction)) {
            sender.sendMessage(ChatColor.RED + "There is not an event faction named '" + args[1] + "'.");
            return true;
        }
        if (this.plugin.getTimerManager().getEventTimer().tryContesting((EventFaction)faction, sender)) {
            sender.sendMessage(ChatColor.YELLOW + "Successfully contested " + faction.getName() + '.');
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        return this.plugin.getFactionManager().getFactions().stream().filter(faction -> faction instanceof EventFaction).map((Function<? super Object, ?>)Faction::getName).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
    }
}
