package com.hcrival.hcf.events.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.faction.type.*;

public class EventCancelArgument extends CommandArgument
{
    private final HCF plugin;
    
    public EventCancelArgument(final HCF plugin) {
        super("cancel", "Cancels a running event", new String[] { "stop", "end" });
        this.plugin = plugin;
        this.permission = "hcf.command.event.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final EventTimer eventTimer = this.plugin.getTimerManager().getEventTimer();
        final Faction eventFaction = eventTimer.getEventFaction();
        if (!eventTimer.clearCooldown()) {
            sender.sendMessage(ChatColor.RED + "There is not a running event.");
            return true;
        }
        Bukkit.broadcastMessage(sender.getName() + ChatColor.YELLOW + " has cancelled " + ((eventFaction == null) ? "the active event" : (eventFaction.getName() + ChatColor.YELLOW)) + ".");
        return true;
    }
}
