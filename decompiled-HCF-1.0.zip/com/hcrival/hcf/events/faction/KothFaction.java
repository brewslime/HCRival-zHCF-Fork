package com.hcrival.hcf.events.faction;

import org.bukkit.configuration.serialization.*;
import com.google.common.collect.*;
import com.hcrival.hcf.events.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.hcrival.hcf.faction.claim.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.hcf.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.type.*;

public class KothFaction extends CapturableFaction implements ConfigurationSerializable
{
    private CaptureZone captureZone;
    
    public KothFaction(final String name) {
        super(name);
    }
    
    public KothFaction(final Map<String, Object> map) {
        super(map);
        this.captureZone = map.get("captureZone");
    }
    
    public Map<String, Object> serialize() {
        final Map<String, Object> map = super.serialize();
        map.put("captureZone", this.captureZone);
        return map;
    }
    
    public List<CaptureZone> getCaptureZones() {
        return (this.captureZone == null) ? ImmutableList.of() : ImmutableList.of(this.captureZone);
    }
    
    public EventType getEventType() {
        return EventType.KOTH;
    }
    
    public void printDetails(final CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(this.getDisplayName(sender));
        for (final Claim claim : this.claims) {
            final Location location = claim.getCenter();
            sender.sendMessage(ChatColor.YELLOW + "  Location " + ChatColor.GOLD + " � " + ChatColor.WHITE + ClaimableFaction.ENVIRONMENT_MAPPINGS.get(location.getWorld().getEnvironment()) + ", " + location.getBlockX() + " | " + location.getBlockZ());
        }
        if (this.captureZone != null) {
            final long remainingCaptureMillis = this.captureZone.getRemainingCaptureMillis();
            final long defaultCaptureMillis = this.captureZone.getDefaultCaptureMillis();
            if (remainingCaptureMillis > 0L && remainingCaptureMillis != defaultCaptureMillis) {
                sender.sendMessage(ChatColor.YELLOW + "  Time Left" + ChatColor.GOLD + " � " + ChatColor.WHITE + DurationFormatUtils.formatDurationWords(remainingCaptureMillis, true, true));
            }
            sender.sendMessage(ChatColor.YELLOW + "  Original Time" + ChatColor.GOLD + " � " + ChatColor.WHITE + this.captureZone.getDefaultCaptureWords());
            if (this.captureZone.getCappingPlayer() != null && sender.hasPermission("hcf.koth.checkcapper")) {
                final Player capping = this.captureZone.getCappingPlayer();
                final PlayerFaction playerFaction = HCF.getPlugin().getFactionManager().getPlayerFaction(capping);
                final String factionTag = "[" + ((playerFaction == null) ? "*" : playerFaction.getName()) + "]";
                sender.sendMessage(ChatColor.YELLOW + "  Current Capper" + ChatColor.GOLD + " � " + ChatColor.WHITE + capping.getName() + ChatColor.DARK_RED + factionTag);
            }
        }
        sender.sendMessage(ChatColor.GOLD + BukkitUtils.STRAIGHT_LINE_DEFAULT);
    }
    
    public CaptureZone getCaptureZone() {
        return this.captureZone;
    }
    
    public void setCaptureZone(final CaptureZone captureZone) {
        this.captureZone = captureZone;
    }
}
