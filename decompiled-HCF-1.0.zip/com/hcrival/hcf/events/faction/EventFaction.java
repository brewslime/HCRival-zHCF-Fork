package com.hcrival.hcf.events.faction;

import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import com.hcrival.util.cuboid.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.*;
import java.util.*;
import com.hcrival.hcf.events.*;

public abstract class EventFaction extends ClaimableFaction
{
    public EventFaction(final String name) {
        super(name);
        this.setDeathban(true);
    }
    
    public EventFaction(final Map<String, Object> map) {
        super(map);
    }
    
    @Override
    public String getDisplayName(final Faction faction) {
        if (this.getName().equalsIgnoreCase("eotw")) {
            return ChatColor.DARK_RED + this.getName();
        }
        if (this.getName().equalsIgnoreCase("end")) {
            return ChatColor.DARK_PURPLE + this.getName();
        }
        if (this.getEventType() == EventType.KOTH) {
            return ChatColor.LIGHT_PURPLE.toString() + this.getName() + ' ' + this.getEventType().getDisplayName();
        }
        if (this.getEventType() == EventType.CONQUEST) {
            return ChatColor.BLUE.toString() + this.getEventType().getDisplayName();
        }
        if (this.getEventType() == EventType.CONQUEST) {
            return ChatColor.BLUE.toString() + this.getEventType().getDisplayName();
        }
        return ChatColor.LIGHT_PURPLE + ChatColor.BOLD.toString() + this.getName();
    }
    
    @Override
    public String getDisplayName(final CommandSender sender) {
        if (this.getName().equalsIgnoreCase("eotw")) {
            return ChatColor.DARK_RED + this.getName();
        }
        if (this.getName().equalsIgnoreCase("end")) {
            return ChatColor.DARK_PURPLE + this.getName();
        }
        if (this.getEventType() == EventType.KOTH) {
            return ChatColor.LIGHT_PURPLE.toString() + this.getName() + ' ' + this.getEventType().getDisplayName();
        }
        if (this.getEventType() == EventType.CONQUEST) {
            return ChatColor.BLUE.toString() + this.getEventType().getDisplayName();
        }
        return ChatColor.LIGHT_PURPLE + ChatColor.BOLD.toString() + this.getName();
    }
    
    public String getScoreboardName() {
        if (this.getName().equalsIgnoreCase("eotw")) {
            return ChatColor.DARK_RED + this.getName();
        }
        if (this.getName().equalsIgnoreCase("end")) {
            return ChatColor.DARK_PURPLE + this.getName();
        }
        if (this.getEventType() == EventType.KOTH) {
            return ChatColor.LIGHT_PURPLE.toString() + this.getName();
        }
        if (this.getEventType() == EventType.CONQUEST) {
            return ChatColor.BLUE.toString() + this.getEventType().getDisplayName();
        }
        return ChatColor.LIGHT_PURPLE + ChatColor.BOLD.toString();
    }
    
    public void setClaim(final Cuboid cuboid, final CommandSender sender) {
        this.removeClaims(this.getClaims(), sender);
        final Location min = cuboid.getMinimumPoint();
        min.setY(0.0);
        final Location max = cuboid.getMaximumPoint();
        max.setY(256.0);
        this.addClaim(new Claim(this, min, max), sender);
    }
    
    public abstract EventType getEventType();
    
    public abstract List<CaptureZone> getCaptureZones();
}
