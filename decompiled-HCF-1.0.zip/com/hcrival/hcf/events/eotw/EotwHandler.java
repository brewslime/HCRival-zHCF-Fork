package com.hcrival.hcf.events.eotw;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import java.util.concurrent.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.scheduler.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;
import com.hcrival.hcf.faction.claim.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.util.*;
import com.google.common.collect.*;

public class EotwHandler
{
    public static final int BORDER_DECREASE_MINIMUM = 1000;
    public static final int BORDER_DECREASE_AMOUNT = 200;
    public static final long BORDER_DECREASE_TIME_MILLIS;
    public static final int BORDER_DECREASE_TIME_SECONDS;
    public static final int BORDER_DECREASE_TIME_SECONDS_HALVED;
    public static final String BORDER_DECREASE_TIME_WORDS;
    public static final String BORDER_DECREASE_TIME_ALERT_WORDS;
    public static final long EOTW_WARMUP_WAIT_MILLIS;
    public static final int EOTW_WARMUP_WAIT_SECONDS;
    private static final long EOTW_CAPPABLE_WAIT_MILLIS;
    private EotwRunnable runnable;
    private final HCF plugin;
    
    public EotwHandler(final HCF plugin) {
        this.plugin = plugin;
    }
    
    public EotwRunnable getRunnable() {
        return this.runnable;
    }
    
    public boolean isEndOfTheWorld() {
        return this.isEndOfTheWorld(true);
    }
    
    public boolean isEndOfTheWorld(final boolean ignoreWarmup) {
        return this.runnable != null && (!ignoreWarmup || this.runnable.getElapsedMilliseconds() > 0L);
    }
    
    public void setEndOfTheWorld(final boolean yes) {
        if (yes == this.isEndOfTheWorld(false)) {
            return;
        }
        if (yes) {
            (this.runnable = new EotwRunnable()).runTaskTimer((Plugin)this.plugin, 20L, 20L);
        }
        else if (this.runnable != null) {
            this.runnable.cancel();
            this.runnable = null;
        }
    }
    
    static {
        BORDER_DECREASE_TIME_MILLIS = TimeUnit.SECONDS.toMillis(20L);
        BORDER_DECREASE_TIME_SECONDS = (int)TimeUnit.MILLISECONDS.toSeconds(EotwHandler.BORDER_DECREASE_TIME_MILLIS);
        BORDER_DECREASE_TIME_SECONDS_HALVED = EotwHandler.BORDER_DECREASE_TIME_SECONDS / 2;
        BORDER_DECREASE_TIME_WORDS = DurationFormatUtils.formatDurationWords(EotwHandler.BORDER_DECREASE_TIME_MILLIS, true, true);
        BORDER_DECREASE_TIME_ALERT_WORDS = DurationFormatUtils.formatDurationWords(EotwHandler.BORDER_DECREASE_TIME_MILLIS / 2L, true, true);
        EOTW_WARMUP_WAIT_MILLIS = TimeUnit.SECONDS.toMillis(30L);
        EOTW_WARMUP_WAIT_SECONDS = (int)TimeUnit.MILLISECONDS.toSeconds(EotwHandler.EOTW_WARMUP_WAIT_MILLIS);
        EOTW_CAPPABLE_WAIT_MILLIS = TimeUnit.SECONDS.toMillis(30L);
    }
    
    public static final class EotwRunnable extends BukkitRunnable
    {
        private long startStamp;
        private int elapsedSeconds;
        
        public EotwRunnable() {
            this.startStamp = System.currentTimeMillis() + EotwHandler.EOTW_WARMUP_WAIT_MILLIS;
            this.elapsedSeconds = -EotwHandler.EOTW_WARMUP_WAIT_SECONDS;
        }
        
        public void handleDisconnect(final Player player) {
        }
        
        public long getMillisUntilStarting() {
            final long difference = System.currentTimeMillis() - this.startStamp;
            return (difference > 0L) ? -1L : Math.abs(difference);
        }
        
        public long getMillisUntilCappable() {
            return EotwHandler.EOTW_CAPPABLE_WAIT_MILLIS - this.getElapsedMilliseconds();
        }
        
        public long getElapsedMilliseconds() {
            return System.currentTimeMillis() - this.startStamp;
        }
        
        public void run() {
            ++this.elapsedSeconds;
            if (this.elapsedSeconds == 0) {
                for (final Faction faction : HCF.getPlugin().getFactionManager().getFactions()) {
                    if (faction instanceof ClaimableFaction) {
                        final ClaimableFaction claimableFaction = (ClaimableFaction)faction;
                        claimableFaction.removeClaims(claimableFaction.getClaims(), (CommandSender)Bukkit.getConsoleSender());
                    }
                }
                Bukkit.broadcastMessage(ChatColor.DARK_RED.toString() + ChatColor.BOLD + "EOTW" + ChatColor.DARK_RED + " has started.");
                this.cancel();
                return;
            }
            if (this.elapsedSeconds < 0 && this.elapsedSeconds >= -EotwHandler.EOTW_WARMUP_WAIT_SECONDS) {
                Bukkit.broadcastMessage(ChatColor.DARK_RED.toString() + ChatColor.BOLD + "EOTW" + ChatColor.DARK_RED + " will commence in " + DurationFormatter.getRemaining(Math.abs(this.elapsedSeconds) * 1000L, true, false) + '.');
            }
        }
    }
}
