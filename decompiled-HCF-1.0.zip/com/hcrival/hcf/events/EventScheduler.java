package com.hcrival.hcf.events;

import java.time.*;
import com.hcrival.hcf.*;
import java.nio.charset.*;
import java.time.format.*;
import java.util.logging.*;
import org.bukkit.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class EventScheduler implements IEventScheduler
{
    private static final DateTimeFormatter DATE_TIME_FORMATTER;
    private static final String FILE_NAME = "event-schedules.txt";
    private static final long QUERY_DELAY;
    private long lastQuery;
    private final LinkedHashMap<LocalDateTime, String> scheduleMap;
    private final HCF plugin;
    
    public EventScheduler(final HCF plugin) {
        this.scheduleMap = new LinkedHashMap<LocalDateTime, String>();
        this.plugin = plugin;
        this.reloadSchedules();
    }
    
    private void reloadSchedules() {
        this.scheduleMap.clear();
        try (final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(this.plugin.getDataFolder(), "event-schedules.txt")), StandardCharsets.UTF_8))) {
            String currentLine;
            while ((currentLine = bufferedReader.readLine()) != null) {
                if (currentLine.startsWith("#")) {
                    continue;
                }
                final String[] args = currentLine.split(":");
                if (args.length != 2) {
                    continue;
                }
                try {
                    this.scheduleMap.put(LocalDateTime.parse(args[0], EventScheduler.DATE_TIME_FORMATTER), args[1]);
                }
                catch (DateTimeParseException ex) {
                    ex.printStackTrace();
                }
            }
        }
        catch (FileNotFoundException ex2) {
            Bukkit.getLogger().log(Level.SEVERE, ChatColor.GREEN + "Could not find file " + "event-schedules.txt" + '.', ex2);
        }
        catch (IOException ex3) {
            ex3.printStackTrace();
        }
    }
    
    @Override
    public Map<LocalDateTime, String> getScheduleMap() {
        final long millis = System.currentTimeMillis();
        if (millis - EventScheduler.QUERY_DELAY > this.lastQuery) {
            this.reloadSchedules();
            this.lastQuery = millis;
        }
        return this.scheduleMap;
    }
    
    static {
        DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy,MM,dd,hh,mm,a", Locale.ENGLISH);
        QUERY_DELAY = TimeUnit.SECONDS.toMillis(60L);
    }
}
