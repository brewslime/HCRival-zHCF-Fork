package com.hcrival.hcf.events.crate;

import com.hcrival.util.*;
import com.hcrival.hcf.*;
import org.bukkit.plugin.java.*;
import com.google.common.collect.*;
import org.bukkit.inventory.*;
import org.bukkit.configuration.*;
import java.util.*;

public class KeyManager
{
    private final EventKey eventKey;
    private final Table<UUID, String, Integer> depositedCrateMap;
    private final Set<Key> keys;
    private final Config config;
    
    public KeyManager(final HCF plugin) {
        this.depositedCrateMap = (Table<UUID, String, Integer>)HashBasedTable.create();
        this.eventKey = new EventKey();
        this.config = new Config(plugin, "key-data");
        this.keys = Sets.newHashSet(this.eventKey);
        this.reloadKeyData();
    }
    
    public Map<String, Integer> getDepositedCrateMap(final UUID uuid) {
        return this.depositedCrateMap.row(uuid);
    }
    
    public Set<Key> getKeys() {
        return this.keys;
    }
    
    public EventKey getEventKey() {
        return this.eventKey;
    }
    
    public Key getKey(final String name) {
        for (final Key key : this.keys) {
            if (key.getName().equalsIgnoreCase(name)) {
                return key;
            }
        }
        return null;
    }
    
    @Deprecated
    public Key getKey(final Class<? extends Key> clazz) {
        for (final Key key : this.keys) {
            if (clazz.isAssignableFrom(key.getClass())) {
                return key;
            }
        }
        return null;
    }
    
    public Key getKey(final ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        for (final Key key : this.keys) {
            final ItemStack item = key.getItemStack();
            if (item.getItemMeta().getDisplayName().equals(stack.getItemMeta().getDisplayName())) {
                return key;
            }
        }
        return null;
    }
    
    public void reloadKeyData() {
        for (final Key key : this.keys) {
            key.load(this.config);
        }
        Object object = this.config.get("deposited-key-map");
        if (object instanceof MemorySection) {
            MemorySection section = (MemorySection)object;
            for (final String id : section.getKeys(false)) {
                object = this.config.get(section.getCurrentPath() + '.' + id);
                if (object instanceof MemorySection) {
                    section = (MemorySection)object;
                    for (final String key2 : section.getKeys(false)) {
                        this.depositedCrateMap.put(UUID.fromString(id), key2, this.config.getInt("deposited-key-map." + id + '.' + key2));
                    }
                }
            }
        }
    }
    
    public void saveKeyData() {
        for (final Key key : this.keys) {
            key.save(this.config);
        }
        final Map<String, Map<String, Integer>> saveMap = new LinkedHashMap<String, Map<String, Integer>>(this.depositedCrateMap.size());
        for (final Map.Entry<UUID, Map<String, Integer>> entry : this.depositedCrateMap.rowMap().entrySet()) {
            saveMap.put(entry.getKey().toString(), entry.getValue());
        }
        this.config.set("deposited-key-map", (Object)saveMap);
        this.config.save();
    }
}
