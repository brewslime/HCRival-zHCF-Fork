package com.hcrival.hcf.events.crate;

import com.hcrival.hcf.events.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import com.google.common.collect.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.configuration.*;
import com.hcrival.util.*;
import java.io.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.*;

public class EventKey extends Key
{
    private final ArrayListMultimap<String, Inventory> inventories;
    
    public EventKey() {
        super("Event");
        this.inventories = ArrayListMultimap.create();
    }
    
    public List<Inventory> getInventories(final EventType eventType) {
        return (List<Inventory>)this.inventories.get((Object)eventType.name());
    }
    
    public EventKeyData getData(final List<String> itemLore) {
        if (itemLore.size() < 2) {
            return null;
        }
        final String first = ChatColor.stripColor((String)itemLore.get(1));
        if (first == null) {
            return null;
        }
        for (final EventType eventType : EventType.values()) {
            if (first.contains(eventType.getDisplayName())) {
                return new EventKeyData(eventType, Character.getNumericValue(first.charAt(first.length() - 1)));
            }
        }
        return null;
    }
    
    @Override
    public ChatColor getColour() {
        return ChatColor.GOLD;
    }
    
    @Override
    public ItemStack getItemStack() {
        final ItemStack stack = new ItemStack(Material.TRIPWIRE_HOOK, 1);
        final ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(this.getColour() + this.getName() + " Key");
        meta.setLore((List)Lists.newArrayList(ChatColor.GRAY + "Right click an empty Chest to use."));
        stack.setItemMeta(meta);
        return stack;
    }
    
    public ItemStack getItemStack(final EventKeyData eventKeyData) {
        final ItemStack stack = new ItemStack(Material.TRIPWIRE_HOOK, 1);
        final ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(this.getColour() + this.getName() + " Key");
        meta.setLore((List)Lists.newArrayList(ChatColor.GRAY + "Right click an empty Chest to use.", ChatColor.GRAY + eventKeyData.getEventType().getDisplayName() + ChatColor.YELLOW + " Inventory " + ChatColor.GOLD + eventKeyData.inventoryNumber));
        stack.setItemMeta(meta);
        return stack;
    }
    
    @Override
    public void load(final Config config) {
        super.load(config);
        final Object object = config.get("event-key-loot");
        if (object instanceof MemorySection) {
            final MemorySection section = (MemorySection)object;
            for (final String key : section.getKeys(false)) {
                try {
                    final Object value = config.get(section.getCurrentPath() + '.' + key);
                    if (!(value instanceof List)) {
                        continue;
                    }
                    final List<?> list = (List<?>)value;
                    for (final Object each : list) {
                        if (each instanceof String) {
                            this.inventories.put((Object)key, (Object)InventorySerialisation.fromBase64((String)each));
                        }
                    }
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    @Override
    public void save(final Config config) {
        super.save(config);
        final Set<Map.Entry<String, Collection<Inventory>>> entrySet = this.inventories.asMap().entrySet();
        final Map<String, List<String>> flushedInventories = new LinkedHashMap<String, List<String>>(entrySet.size());
        for (final Map.Entry<String, Collection<Inventory>> entry : entrySet) {
            flushedInventories.put(entry.getKey(), (List<String>)new ArrayList<Object>(entry.getValue()).stream().map((Function<? super Object, ?>)InventorySerialisation::toBase64).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList()));
        }
        config.set("event-key-loot", (Object)flushedInventories);
        config.save();
    }
    
    public static class EventKeyData
    {
        private final EventType eventType;
        private final int inventoryNumber;
        
        public EventKeyData(final EventType eventType, final int inventoryNumber) {
            this.eventType = eventType;
            this.inventoryNumber = inventoryNumber;
        }
        
        public EventType getEventType() {
            return this.eventType;
        }
        
        public int getInventoryNumber() {
            return this.inventoryNumber;
        }
    }
}
