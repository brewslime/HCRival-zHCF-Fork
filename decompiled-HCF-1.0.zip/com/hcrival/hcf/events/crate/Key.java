package com.hcrival.hcf.events.crate;

import org.bukkit.*;
import org.bukkit.inventory.*;
import com.hcrival.util.*;

public abstract class Key
{
    private String name;
    
    public Key(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public abstract ChatColor getColour();
    
    public String getDisplayName() {
        return this.getColour() + this.name;
    }
    
    public abstract ItemStack getItemStack();
    
    public void load(final Config config) {
    }
    
    public void save(final Config config) {
    }
}
