package com.hcrival.hcf.events;

import java.util.*;
import java.time.*;

public interface IEventScheduler
{
    Map<LocalDateTime, String> getScheduleMap();
}
