package com.hcrival.hcf.events;

import com.hcrival.hcf.*;
import com.hcrival.util.command.*;
import com.hcrival.hcf.events.argument.*;

public class EventExecutor extends ArgumentExecutor
{
    public EventExecutor(final HCF plugin) {
        super("event");
        this.addArgument(new EventCancelArgument(plugin));
        this.addArgument(new EventCreateArgument(plugin));
        this.addArgument(new EventDeleteArgument(plugin));
        this.addArgument(new EventRenameArgument(plugin));
        this.addArgument(new EventSetAreaArgument(plugin));
        this.addArgument(new EventSetCapzoneArgument(plugin));
        this.addArgument(new EventAddLootTableArgument(plugin));
        this.addArgument(new EventDelLootTableArgument(plugin));
        this.addArgument(new EventSetLootArgument(plugin));
        this.addArgument(new EventStartArgument(plugin));
        this.addArgument(new EventUptimeArgument(plugin));
    }
}
