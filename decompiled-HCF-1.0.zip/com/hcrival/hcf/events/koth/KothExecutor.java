package com.hcrival.hcf.events.koth;

import com.hcrival.hcf.*;
import com.hcrival.util.command.*;
import com.hcrival.hcf.events.koth.argument.*;
import org.bukkit.command.*;

public class KothExecutor extends ArgumentExecutor
{
    private final KothScheduleArgument kothScheduleArgument;
    
    public KothExecutor(final HCF plugin) {
        super("koth");
        this.addArgument(new KothHelpArgument(this));
        this.addArgument(new KothNextArgument(plugin));
        this.addArgument(this.kothScheduleArgument = new KothScheduleArgument(plugin));
        this.addArgument(new KothSetCapDelayArgument(plugin));
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 1) {
            this.kothScheduleArgument.onCommand(sender, command, label, args);
            return true;
        }
        return super.onCommand(sender, command, label, args);
    }
}
