package com.hcrival.hcf.events.koth.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import java.util.regex.*;
import org.bukkit.command.*;
import java.time.*;
import java.time.chrono.*;
import org.bukkit.*;
import java.time.temporal.*;
import org.apache.commons.lang3.text.*;
import org.apache.commons.lang3.time.*;
import com.hcrival.util.*;
import java.util.*;

public class KothScheduleArgument extends CommandArgument
{
    private static final String TIME_UNTIL_PATTERN = "d'd' H'h' mm'm'";
    private final FastDateFormat headingTimeFormat;
    private final FastDateFormat eachKothTimeFormat;
    private final HCF plugin;
    
    public KothScheduleArgument(final HCF plugin) {
        super("schedule", "View the schedule for KOTH arenas");
        this.plugin = plugin;
        this.aliases = new String[] { "info", "i", "time" };
        this.permission = "hcf.command.koth.argument." + this.getName();
        final TimeZone timeZone = TimeZone.getTimeZone(plugin.getConfig().getString("settings.timezone"));
        this.headingTimeFormat = FastDateFormat.getInstance("EEE FF h:mma (z)", timeZone, Locale.ENGLISH);
        this.eachKothTimeFormat = FastDateFormat.getInstance("EEE dd '" + Matcher.quoteReplacement("&b") + "'(h:mma)", timeZone, Locale.ENGLISH);
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final LocalDateTime now = LocalDateTime.now(TimeZone.getTimeZone(this.plugin.getConfig().getString("settings.timezone")).toZoneId());
        final int currentDay = now.getDayOfYear();
        final Map<LocalDateTime, String> scheduleMap = this.plugin.getEventScheduler().getScheduleMap();
        final List<String> shownEvents = new ArrayList<String>();
        for (final Map.Entry<LocalDateTime, String> entry : scheduleMap.entrySet()) {
            final LocalDateTime scheduleDateTime = entry.getKey();
            if (scheduleDateTime.isAfter(now)) {
                final int dayDifference = scheduleDateTime.getDayOfYear() - currentDay;
                if (dayDifference > 1) {
                    continue;
                }
                final ChatColor colour = (dayDifference == 0) ? ChatColor.GREEN : ChatColor.AQUA;
                final long remainingMillis = now.until(scheduleDateTime, ChronoUnit.MILLIS);
                shownEvents.add("  " + colour + WordUtils.capitalize(entry.getValue()) + ": " + ChatColor.YELLOW + ChatColor.translateAlternateColorCodes('&', this.eachKothTimeFormat.format(remainingMillis)) + ChatColor.GRAY + " - " + ChatColor.GOLD + DurationFormatUtils.formatDuration(remainingMillis, "d'd' H'h' mm'm'"));
            }
        }
        if (shownEvents.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "There are no event schedules defined.");
            return true;
        }
        sender.sendMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        sender.sendMessage(ChatColor.GRAY + "Server time is currently " + ChatColor.WHITE + this.headingTimeFormat.format(System.currentTimeMillis()) + ChatColor.GRAY + '.');
        sender.sendMessage((String[])shownEvents.toArray(new String[shownEvents.size()]));
        sender.sendMessage(ChatColor.GRAY + "For more info about King of the Hill, use " + ChatColor.WHITE + '/' + label + " help" + ChatColor.GRAY + '.');
        sender.sendMessage(ChatColor.GRAY + BukkitUtils.STRAIGHT_LINE_DEFAULT);
        return true;
    }
}
