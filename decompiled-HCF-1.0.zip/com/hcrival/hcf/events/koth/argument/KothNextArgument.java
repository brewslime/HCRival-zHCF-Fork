package com.hcrival.hcf.events.koth.argument;

import com.hcrival.util.command.*;
import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.hcf.*;
import java.time.*;
import java.time.chrono.*;
import java.time.format.*;
import org.apache.commons.lang3.text.*;
import java.util.concurrent.*;
import java.util.*;

public class KothNextArgument extends CommandArgument
{
    private final HCF plugin;
    
    public KothNextArgument(final HCF plugin) {
        super("next", "View the next scheduled KOTH");
        this.plugin = plugin;
        this.permission = "hcf.command.koth.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final long millis = System.currentTimeMillis();
        sender.sendMessage(ChatColor.GOLD + "The server time is currently " + ChatColor.YELLOW + DateTimeFormats.DAY_MTH_HR_MIN_AMPM.format(millis) + ChatColor.GOLD + '.');
        final Map<LocalDateTime, String> scheduleMap = this.plugin.getEventScheduler().getScheduleMap();
        if (scheduleMap.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "There is not an event schedule for after now.");
            return true;
        }
        final LocalDateTime now = LocalDateTime.now(TimeZone.getTimeZone(this.plugin.getConfig().getString("settings.timezone")).toZoneId());
        for (final Map.Entry<LocalDateTime, String> entry : scheduleMap.entrySet()) {
            final LocalDateTime scheduleDateTime = entry.getKey();
            if (now.isAfter(scheduleDateTime)) {
                continue;
            }
            final String monthName = scheduleDateTime.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
            final String weekName = scheduleDateTime.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            sender.sendMessage(ChatColor.DARK_AQUA + WordUtils.capitalize(entry.getValue()) + ChatColor.GRAY + " is the next event: " + ChatColor.AQUA + weekName + ' ' + scheduleDateTime.getDayOfMonth() + ' ' + monthName + ChatColor.DARK_AQUA + " (" + DateTimeFormats.HR_MIN_AMPM.format(TimeUnit.HOURS.toMillis(scheduleDateTime.getHour()) + TimeUnit.MINUTES.toMillis(scheduleDateTime.getMinute())) + ')');
            return true;
        }
        sender.sendMessage(ChatColor.RED + "There is not an event scheduled after now.");
        return true;
    }
}
