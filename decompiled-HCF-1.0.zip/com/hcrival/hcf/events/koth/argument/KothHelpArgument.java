package com.hcrival.hcf.events.koth.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.events.koth.*;
import org.bukkit.command.*;
import org.bukkit.*;
import java.util.*;

public class KothHelpArgument extends CommandArgument
{
    private final KothExecutor kothExecutor;
    
    public KothHelpArgument(final KothExecutor kothExecutor) {
        super("help", "View help about how KOTH's work");
        this.kothExecutor = kothExecutor;
        this.permission = "hcf.command.koth.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName();
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        sender.sendMessage(ChatColor.AQUA + "*** KotH Help ***");
        for (final CommandArgument argument : this.kothExecutor.getArguments()) {
            if (argument != this) {
                final String permission = argument.getPermission();
                if (permission != null && !sender.hasPermission(permission)) {
                    continue;
                }
                sender.sendMessage(ChatColor.GRAY + argument.getUsage(label) + " - " + argument.getDescription() + '.');
            }
        }
        sender.sendMessage(ChatColor.GRAY + "/fac show <kothName> - View information about a KOTH.");
        return true;
    }
}
