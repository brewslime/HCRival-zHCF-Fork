package com.hcrival.hcf.deathban;

import com.hcrival.hcf.*;
import java.util.*;
import org.bukkit.event.entity.*;
import java.util.concurrent.*;
import com.hcrival.hcf.util.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;

public class DeathbanListener implements Listener
{
    private List<UUID> useLife;
    private HashMap<String, Long> deathBanTime;
    private int defaultDeathbanTime;
    
    public DeathbanListener() {
        this.useLife = new ArrayList<UUID>();
        this.deathBanTime = new HashMap<String, Long>();
        this.defaultDeathbanTime = HCF.getPlugin().getConfig().getInt("settings.deathban.default_deathban_time");
        for (final String s : HCF.getPlugin().getConfig().getConfigurationSection("deathbans").getKeys(false)) {
            final String permission = HCF.getPlugin().getConfig().getString("deathbans." + s + ".permission");
            final long time = HCF.getPlugin().getConfig().getInt("deathbans." + s + ".time");
            this.deathBanTime.put(permission, time);
        }
    }
    
    @EventHandler
    public void onDeath(final PlayerDeathEvent e) {
        final Player p = e.getEntity();
        if (p.hasPermission("hcf.deathban.bypass")) {
            return;
        }
        long time = -1L;
        for (final String permission : this.deathBanTime.keySet()) {
            if (p.hasPermission(permission)) {
                time = TimeUnit.MINUTES.toMillis(this.deathBanTime.get(permission));
            }
        }
        if (time == -1L) {
            time = TimeUnit.MINUTES.toMillis(this.defaultDeathbanTime);
        }
        final long unbanned = System.currentTimeMillis() + time;
        final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(p.getUniqueId());
        deathbanUser.setDeathBanned(unbanned);
        final long unbanTime = deathbanUser.getUnbanLong() - System.currentTimeMillis();
        p.kickPlayer(Color.translate("&cYou are currently deathbanned!\nRemaining: " + DurationFormatter.getRemaining(unbanTime, true, false) + "\nIf you want to use a life, please rejoin! &7&o(You currently have " + deathbanUser.getLives() + "lives)"));
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(p.getUniqueId());
        if (deathbanUser.isDeathbanned()) {
            if (HCF.getPlugin().getEotwHandler().isEndOfTheWorld()) {
                p.kickPlayer(Color.translate("&cYou are currently deathbanned!\nCome back next map!"));
                return;
            }
            if (System.currentTimeMillis() >= deathbanUser.getUnbanLong()) {
                deathbanUser.setUnbanned();
                return;
            }
            if (this.useLife.contains(p.getUniqueId())) {
                if (deathbanUser.getLives() >= 1) {
                    deathbanUser.setUnbanned();
                    deathbanUser.setLives(deathbanUser.getLives() - 1);
                    this.useLife.remove(p.getUniqueId());
                    return;
                }
                final long unbanTime = deathbanUser.getUnbanLong() - System.currentTimeMillis();
                p.kickPlayer(Color.translate("&cYou are currently deathbanned!\nRemaining: " + DurationFormatter.getRemaining(unbanTime, true, false) + "\nIf you want to use a life, please rejoin! &7&o(You currently have " + deathbanUser.getLives() + "lives)"));
                this.useLife.remove(p.getUniqueId());
            }
            else {
                final long unbanTime = deathbanUser.getUnbanLong() - System.currentTimeMillis();
                p.kickPlayer(Color.translate("&cYou are currently deathbanned!\nRemaining: " + DurationFormatter.getRemaining(unbanTime, true, false) + "\nIf you want to use a life, please rejoin! &7&o(You currently have " + deathbanUser.getLives() + "lives)"));
                this.useLife.add(p.getUniqueId());
                new BukkitRunnable() {
                    public void run() {
                        DeathbanListener.this.useLife.remove(p.getUniqueId());
                    }
                }.runTaskLaterAsynchronously((Plugin)HCF.getPlugin(), 600L);
            }
        }
    }
}
