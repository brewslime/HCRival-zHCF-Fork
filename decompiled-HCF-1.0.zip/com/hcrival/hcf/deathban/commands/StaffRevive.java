package com.hcrival.hcf.deathban.commands;

import org.bukkit.command.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.deathban.*;
import org.bukkit.*;
import java.util.*;

public class StaffRevive implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final CommandSender p = sender;
        if (p.hasPermission("hcf.command.staffrevive")) {
            if (args.length != 1) {
                p.sendMessage(ChatColor.RED + "Usage: /staffrevive <player>");
                return true;
            }
            final OfflinePlayer target = Bukkit.getServer().getOfflinePlayer(args[0]);
            if (target == null) {
                p.sendMessage(ChatColor.RED.toString() + args[0] + " not found!");
                return true;
            }
            try {
                final UUID uuid = UUIDFetcher.getUUIDOf(target.getName());
                final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(uuid);
                if (!deathbanUser.isDeathbanned()) {
                    p.sendMessage(ChatColor.RED.toString() + args[0] + " is not deathbanned!");
                    return true;
                }
                deathbanUser.setUnbanned();
                p.sendMessage(ChatColor.GREEN + "Successfully revived " + args[0] + "!");
            }
            catch (Exception e) {
                p.sendMessage(ChatColor.RED.toString() + args[0] + " not found!");
                return true;
            }
        }
        else {
            p.sendMessage(ChatColor.RED + "No permission.");
        }
        return true;
    }
}
