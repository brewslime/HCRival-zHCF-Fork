package com.hcrival.hcf.deathban.commands.lives.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.deathban.*;
import org.bukkit.*;
import java.util.*;

public class LivesGiveArgument extends CommandArgument
{
    private final HCF plugin;
    
    public LivesGiveArgument(final HCF plugin) {
        super("give", "Give lives to a player");
        this.plugin = plugin;
        this.aliases = new String[] { "transfer", "send", "pay", "add" };
        this.permission = "hcf.command.lives.argument." + this.getName() + "give";
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName> <amount>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Integer amount = JavaUtils.tryParseInt(args[2]);
        if (amount == null) {
            sender.sendMessage(ChatColor.RED + "'" + args[2] + "' is not a number.");
            return true;
        }
        if (amount <= 0) {
            sender.sendMessage(ChatColor.RED + "The amount of lives must be positive.");
            return true;
        }
        final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(ChatColor.GOLD + "Player '" + ChatColor.WHITE + args[1] + ChatColor.GOLD + "' not found.");
            return true;
        }
        final Player onlineTarget = target.getPlayer();
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(player.getUniqueId());
            final int ownedLives = deathbanUser.getLives();
            if (amount > ownedLives) {
                sender.sendMessage(ChatColor.RED + "You tried to give " + target.getName() + ' ' + amount + " lives, but you only have " + ownedLives + '.');
                return true;
            }
            deathbanUser.setLives(deathbanUser.getLives() + amount);
        }
        final DeathbanUser deathbanUser2 = DeathbanUser.getDeathbanUserFromUUID(target.getUniqueId());
        deathbanUser2.setLives(deathbanUser2.getLives() + amount);
        sender.sendMessage(ChatColor.YELLOW + "You have sent " + ChatColor.GOLD + target.getName() + ChatColor.YELLOW + ' ' + amount + ' ' + ((amount > 1) ? "lives" : "life") + ChatColor.YELLOW + '.');
        if (onlineTarget != null) {
            onlineTarget.sendMessage(ChatColor.GOLD + sender.getName() + ChatColor.YELLOW + " has sent you " + ChatColor.GOLD + amount + ' ' + ((amount > 1) ? "lives" : "life") + ChatColor.YELLOW + '.');
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 2) ? null : Collections.emptyList();
    }
}
