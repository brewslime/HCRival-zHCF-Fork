package com.hcrival.hcf.deathban.commands.lives.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import com.hcrival.hcf.deathban.*;
import com.hcrival.hcf.faction.struct.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.messaging.*;
import org.bukkit.*;
import java.util.*;
import com.hcrival.hcf.faction.type.*;
import com.google.common.io.*;

public class LivesReviveArgument extends CommandArgument
{
    private static final String REVIVE_BYPASS_PERMISSION = "hcf.revive.bypass";
    private static final String PROXY_CHANNEL_NAME = "BungeeCord";
    private final HCF plugin;
    
    public LivesReviveArgument(final HCF plugin) {
        super("revive", "Revive a death-banned player");
        this.plugin = plugin;
        this.permission = "hcf.command.lives.argument." + this.getName();
        plugin.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)plugin, "BungeeCord");
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(ChatColor.GOLD + "Player '" + ChatColor.WHITE + args[1] + ChatColor.GOLD + "' not found.");
            return true;
        }
        final UUID targetUUID = target.getUniqueId();
        final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(targetUUID);
        if (!deathbanUser.isDeathbanned()) {
            sender.sendMessage(ChatColor.RED + target.getName() + " is not death-banned.");
            return true;
        }
        Relation relation = Relation.ENEMY;
        if (sender instanceof Player) {
            if (!sender.hasPermission("hcf.revive.bypass") && this.plugin.getEotwHandler().isEndOfTheWorld()) {
                sender.sendMessage(ChatColor.RED + "You cannot revive players during EOTW.");
                return true;
            }
            final Player player = (Player)sender;
            final UUID playerUUID = player.getUniqueId();
            final int selfLives = DeathbanUser.getDeathbanUserFromUUID(playerUUID).getLives();
            if (selfLives <= 0) {
                sender.sendMessage(ChatColor.RED + "You do not have any lives.");
                return true;
            }
            DeathbanUser.getDeathbanUserFromUUID(playerUUID).setLives(selfLives - 1);
            final PlayerFaction playerFaction = this.plugin.getFactionManager().getPlayerFaction(player);
            relation = ((playerFaction == null) ? Relation.ENEMY : playerFaction.getFactionRelation(this.plugin.getFactionManager().getPlayerFaction(targetUUID)));
            sender.sendMessage(ChatColor.YELLOW + "You have used a life to revive " + relation.toChatColour() + target.getName() + ChatColor.YELLOW + '.');
        }
        else {
            sender.sendMessage(ChatColor.YELLOW + "You have revived " + ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate")) + target.getName() + ChatColor.YELLOW + '.');
        }
        if (sender instanceof PluginMessageRecipient) {
            final ByteArrayDataOutput out = ByteStreams.newDataOutput();
            out.writeUTF("Message");
            out.writeUTF(args[1]);
            final String serverDisplayName = ChatColor.GREEN + "HCF";
            out.writeUTF(relation.toChatColour() + sender.getName() + ChatColor.GOLD + " has just revived you from " + serverDisplayName + ChatColor.GOLD + '.');
            ((PluginMessageRecipient)sender).sendPluginMessage((Plugin)this.plugin, "BungeeCord", out.toByteArray());
        }
        DeathbanUser.getDeathbanUserFromUUID(targetUUID).setUnbanned();
        return true;
    }
}
