package com.hcrival.hcf.deathban.commands.lives.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import com.hcrival.hcf.deathban.*;
import net.minecraft.util.org.apache.commons.lang3.time.*;
import org.bukkit.*;

public class LivesCheckDeathbanArgument extends CommandArgument
{
    private final HCF plugin;
    
    public LivesCheckDeathbanArgument(final HCF plugin) {
        super("checkdeathban", "Check the deathban cause of player");
        this.plugin = plugin;
        this.permission = "hcf.command.lives.argument." + this.getName();
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <playerName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(ChatColor.GOLD + "Player '" + ChatColor.WHITE + args[1] + ChatColor.GOLD + "' not found.");
            return true;
        }
        final DeathbanUser deathbanUser = DeathbanUser.getDeathbanUserFromUUID(target.getUniqueId());
        if (!deathbanUser.isDeathbanned()) {
            sender.sendMessage(ChatColor.RED + target.getName() + " is not death-banned.");
            return true;
        }
        sender.sendMessage(ChatColor.DARK_AQUA + "Deathban cause of " + target.getName() + '.');
        sender.sendMessage(ChatColor.GRAY + " Duration: " + DurationFormatUtils.formatDurationWords(deathbanUser.getUnbanLong(), true, true));
        return true;
    }
}
