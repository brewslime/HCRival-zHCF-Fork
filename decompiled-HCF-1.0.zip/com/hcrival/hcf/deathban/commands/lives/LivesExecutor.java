package com.hcrival.hcf.deathban.commands.lives;

import com.hcrival.hcf.*;
import com.hcrival.util.command.*;
import com.hcrival.hcf.deathban.commands.lives.argument.*;

public class LivesExecutor extends ArgumentExecutor
{
    public LivesExecutor(final HCF plugin) {
        super("lives");
        this.addArgument(new LivesCheckArgument(plugin));
        this.addArgument(new LivesCheckDeathbanArgument(plugin));
        this.addArgument(new LivesGiveArgument(plugin));
        this.addArgument(new LivesReviveArgument(plugin));
        this.addArgument(new LivesSetArgument(plugin));
    }
}
