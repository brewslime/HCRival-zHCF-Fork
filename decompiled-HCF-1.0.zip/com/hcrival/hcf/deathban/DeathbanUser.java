package com.hcrival.hcf.deathban;

import java.util.*;
import org.bukkit.configuration.file.*;
import com.hcrival.hcf.*;

public class DeathbanUser
{
    private UUID uuid;
    private YamlConfiguration config;
    
    public boolean isDeathbanned() {
        return this.config.getBoolean("data." + this.uuid + ".isbanned");
    }
    
    public long getUnbanLong() {
        return this.config.getLong("data." + this.uuid + ".unban");
    }
    
    public void setDeathBanned(final long unban) {
        this.config.set("data." + this.uuid + ".isbanned", (Object)true);
        this.config.set("data." + this.uuid + ".unban", (Object)unban);
        HCF.getPlugin().getDeathbanConfig().save();
    }
    
    public void setUnbanned() {
        this.config.set("data." + this.uuid + ".isbanned", (Object)false);
        HCF.getPlugin().getDeathbanConfig().save();
    }
    
    public int getLives() {
        return this.config.getInt("data." + this.uuid + ".lives");
    }
    
    public void setLives(final int lives) {
        this.config.set("data." + this.uuid + ".lives", (Object)lives);
        HCF.getPlugin().getDeathbanConfig().save();
    }
    
    public static DeathbanUser getDeathbanUserFromUUID(final UUID uuid) {
        final DeathbanUser deathbanUser = new DeathbanUser();
        deathbanUser.setUuid(uuid);
        return deathbanUser;
    }
    
    public DeathbanUser() {
        this.config = HCF.getPlugin().getDeathbanConfig().getConfiguration();
    }
    
    public UUID getUuid() {
        return this.uuid;
    }
    
    public YamlConfiguration getConfig() {
        return this.config;
    }
    
    public void setUuid(final UUID uuid) {
        this.uuid = uuid;
    }
    
    public void setConfig(final YamlConfiguration config) {
        this.config = config;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof DeathbanUser)) {
            return false;
        }
        final DeathbanUser other = (DeathbanUser)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$uuid = this.getUuid();
        final Object other$uuid = other.getUuid();
        Label_0065: {
            if (this$uuid == null) {
                if (other$uuid == null) {
                    break Label_0065;
                }
            }
            else if (this$uuid.equals(other$uuid)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$config = this.getConfig();
        final Object other$config = other.getConfig();
        if (this$config == null) {
            if (other$config == null) {
                return true;
            }
        }
        else if (this$config.equals(other$config)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof DeathbanUser;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $uuid = this.getUuid();
        result = result * 59 + (($uuid == null) ? 43 : $uuid.hashCode());
        final Object $config = this.getConfig();
        result = result * 59 + (($config == null) ? 43 : $config.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "DeathbanUser(uuid=" + this.getUuid() + ", config=" + this.getConfig() + ")";
    }
}
