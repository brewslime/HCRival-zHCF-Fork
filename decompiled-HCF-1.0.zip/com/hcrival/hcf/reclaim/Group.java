package com.hcrival.hcf.reclaim;

import java.util.*;

public class Group
{
    private String name;
    private List<String> commands;
    
    public String getName() {
        return this.name;
    }
    
    public List<String> getCommands() {
        return this.commands;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setCommands(final List<String> commands) {
        this.commands = commands;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Group)) {
            return false;
        }
        final Group other = (Group)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$name = this.getName();
        final Object other$name = other.getName();
        Label_0065: {
            if (this$name == null) {
                if (other$name == null) {
                    break Label_0065;
                }
            }
            else if (this$name.equals(other$name)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$commands = this.getCommands();
        final Object other$commands = other.getCommands();
        if (this$commands == null) {
            if (other$commands == null) {
                return true;
            }
        }
        else if (this$commands.equals(other$commands)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof Group;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $name = this.getName();
        result = result * 59 + (($name == null) ? 43 : $name.hashCode());
        final Object $commands = this.getCommands();
        result = result * 59 + (($commands == null) ? 43 : $commands.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "Group(name=" + this.getName() + ", commands=" + this.getCommands() + ")";
    }
}
