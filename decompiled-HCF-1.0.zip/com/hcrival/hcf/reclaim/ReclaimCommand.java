package com.hcrival.hcf.reclaim;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import us.hcrealms.chronium.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import java.util.*;

public class ReclaimCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player p = (Player)sender;
            if (p.hasPermission("hcf.command.reclaim")) {
                final String group = ChroniumAPI.getRankOfPlayer(p).getDisplayName();
                boolean needsReclaim = false;
                for (final Group definedGroup : HCF.getPlugin().getReclaim().getGroups()) {
                    if (definedGroup.getName().equalsIgnoreCase(group)) {
                        needsReclaim = true;
                    }
                }
                if (needsReclaim) {
                    if (HCF.getPlugin().getReclaim().hasUsedReclaim(p)) {
                        p.sendMessage(ChatColor.RED + "You have already reclaimed your rank.");
                        return true;
                    }
                    final List<String> commands = new ArrayList<String>();
                    for (final Group definedGroup2 : HCF.getPlugin().getReclaim().getGroups()) {
                        if (definedGroup2.getName().equalsIgnoreCase(group)) {
                            for (final String command2 : definedGroup2.getCommands()) {
                                commands.add(command2);
                            }
                        }
                    }
                    for (final String c : commands) {
                        Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
                    }
                    HCF.getPlugin().getReclaim().setUsedReclaim(p, true);
                }
                else {
                    p.sendMessage(ChatColor.RED + "You have nothing to reclaim.");
                }
            }
            else {
                p.sendMessage(ChatColor.RED + "No permission.");
            }
        }
        return false;
    }
}
