package com.hcrival.hcf.reclaim;

import com.hcrival.hcf.*;
import java.util.*;
import org.bukkit.entity.*;

public class Reclaim
{
    public List<Group> getGroups() {
        final List<Group> groups = new ArrayList<Group>();
        for (final String s : HCF.getPlugin().getReclaimConfig().getConfiguration().getConfigurationSection("groups").getKeys(false)) {
            final Group group = new Group();
            group.setName(s);
            group.setCommands(HCF.getPlugin().getReclaimConfig().getConfiguration().getStringList("groups." + s + ".commands"));
            groups.add(group);
        }
        return groups;
    }
    
    public boolean hasUsedReclaim(final Player player) {
        return HCF.getPlugin().getReclaimConfig().getConfiguration().getBoolean("reclaimed." + player.getUniqueId().toString());
    }
    
    public void setUsedReclaim(final Player p, final boolean used) {
        HCF.getPlugin().getReclaimConfig().getConfiguration().set("reclaimed." + p.getUniqueId().toString(), (Object)used);
        HCF.getPlugin().getReclaimConfig().save();
    }
}
