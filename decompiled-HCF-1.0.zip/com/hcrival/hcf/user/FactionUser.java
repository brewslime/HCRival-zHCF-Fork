package com.hcrival.hcf.user;

import org.bukkit.configuration.serialization.*;
import net.minecraft.util.gnu.trove.map.*;
import net.minecraft.util.gnu.trove.map.hash.*;
import com.hcrival.util.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.*;
import net.minecraft.util.gnu.trove.procedure.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.kit.*;

public class FactionUser implements ConfigurationSerializable
{
    private Set<UUID> factionChatSpying;
    private final TObjectIntMap<UUID> kitUseMap;
    private final TObjectLongMap<UUID> kitCooldownMap;
    private UUID userUUID;
    private boolean capzoneEntryAlerts;
    private boolean showClaimMap;
    private boolean showLightning;
    private boolean messagingSounds;
    private boolean messagesVisible;
    private long lastFactionLeaveMillis;
    private int kills;
    private int balance;
    private int deaths;
    private boolean isSOTW;
    private UUID lastRepliedTo;
    private long lastSpeakTimeMillis;
    private long lastReceivedMessageMillis;
    private long lastSentMessageMillis;
    
    public FactionUser(final UUID userUUID) {
        this.factionChatSpying = new HashSet<UUID>();
        this.showLightning = true;
        this.messagingSounds = true;
        this.messagesVisible = true;
        this.userUUID = userUUID;
        this.kitUseMap = (TObjectIntMap<UUID>)new TObjectIntHashMap();
        this.kitCooldownMap = (TObjectLongMap<UUID>)new TObjectLongHashMap();
        this.isSOTW = true;
    }
    
    public FactionUser(final Map<String, Object> map) {
        this.factionChatSpying = new HashSet<UUID>();
        this.showLightning = true;
        this.messagingSounds = true;
        this.messagesVisible = true;
        this.kitUseMap = (TObjectIntMap<UUID>)new TObjectIntHashMap();
        this.kitCooldownMap = (TObjectLongMap<UUID>)new TObjectLongHashMap();
        this.factionChatSpying.addAll(GenericUtils.createList(map.get("faction-chat-spying"), String.class).stream().map((Function<? super Object, ?>)UUID::fromString).collect((Collector<? super Object, ?, Collection<? extends UUID>>)Collectors.toList()));
        this.userUUID = UUID.fromString(map.get("userUUID"));
        this.capzoneEntryAlerts = map.get("capzoneEntryAlerts");
        this.showLightning = map.get("showLightning");
        this.lastFactionLeaveMillis = Long.parseLong(map.get("lastFactionLeaveMillis"));
        this.kills = map.get("kills");
        this.deaths = map.get("deaths");
        this.balance = map.get("balance");
        this.messagingSounds = map.get("messagingSounds");
        this.messagesVisible = map.get("messages");
        this.isSOTW = map.get("issotw");
        Object object = map.get("lastRepliedTo");
        if (object instanceof String) {
            this.lastRepliedTo = UUID.fromString((String)object);
        }
        if ((object = map.get("lastSpeakTimeMillis")) instanceof String) {
            this.lastSpeakTimeMillis = Long.parseLong((String)object);
        }
        if ((object = map.get("lastReceivedMessageMillis")) instanceof String) {
            this.lastReceivedMessageMillis = Long.parseLong((String)object);
        }
        if ((object = map.get("lastSentMessageMillis")) instanceof String) {
            this.lastSentMessageMillis = Long.parseLong((String)object);
        }
        for (final Map.Entry<String, Integer> entry : GenericUtils.castMap(map.get("kit-use-map"), String.class, Integer.class).entrySet()) {
            this.kitUseMap.put((Object)UUID.fromString(entry.getKey()), (int)entry.getValue());
        }
        for (final Map.Entry<String, String> entry2 : GenericUtils.castMap(map.get("kit-cooldown-map"), String.class, String.class).entrySet()) {
            this.kitCooldownMap.put((Object)UUID.fromString(entry2.getKey()), Long.parseLong(entry2.getValue()));
        }
    }
    
    public Map<String, Object> serialize() {
        final Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("faction-chat-spying", this.factionChatSpying.stream().map((Function<? super Object, ?>)UUID::toString).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        map.put("userUUID", this.userUUID.toString());
        map.put("capzoneEntryAlerts", this.capzoneEntryAlerts);
        map.put("showClaimMap", this.showClaimMap);
        map.put("showLightning", this.showLightning);
        map.put("balance", this.balance);
        map.put("lastFactionLeaveMillis", Long.toString(this.lastFactionLeaveMillis));
        map.put("kills", this.kills);
        map.put("deaths", this.deaths);
        map.put("issotw", this.isSOTW);
        map.put("messagingSounds", this.messagingSounds);
        map.put("messages", this.messagesVisible);
        if (this.lastRepliedTo != null) {
            map.put("lastRepliedTo", this.lastRepliedTo.toString());
        }
        map.put("lastSpeakTimeMillis", Long.toString(this.lastSpeakTimeMillis));
        map.put("lastReceivedMessageMillis", Long.toString(this.lastReceivedMessageMillis));
        map.put("lastSentMessageMillis", Long.toString(this.lastSentMessageMillis));
        final Map<String, Integer> kitUseSaveMap = new HashMap<String, Integer>(this.kitUseMap.size());
        this.kitUseMap.forEachEntry((uuid, value) -> {
            kitUseSaveMap.put(uuid.toString(), value);
            return true;
        });
        new TObjectIntProcedure<UUID>() {
            public boolean execute(final UUID uuid, final int value) {
                kitUseSaveMap.put(uuid.toString(), value);
                return true;
            }
        };
        final Map<String, String> kitCooldownSaveMap = new HashMap<String, String>(this.kitCooldownMap.size());
        this.kitCooldownMap.forEachEntry((uuid, value) -> {
            kitCooldownSaveMap.put(uuid.toString(), Long.toString(value));
            return true;
        });
        new TObjectLongProcedure<UUID>() {
            public boolean execute(final UUID uuid, final long value) {
                kitCooldownSaveMap.put(uuid.toString(), Long.toString(value));
                return true;
            }
        };
        map.put("kit-use-map", kitUseSaveMap);
        map.put("kit-cooldown-map", kitCooldownSaveMap);
        return map;
    }
    
    public Player getPlayer() {
        return Bukkit.getPlayer(this.userUUID);
    }
    
    public long getRemainingKitCooldown(final Kit kit) {
        final long remaining = this.kitCooldownMap.get((Object)kit.getUniqueID());
        if (remaining == this.kitCooldownMap.getNoEntryValue()) {
            return 0L;
        }
        return remaining - System.currentTimeMillis();
    }
    
    public int getBalance() {
        return this.balance;
    }
    
    public int setBalance(final int balance) {
        final int previous = this.balance;
        this.balance = balance;
        return previous;
    }
    
    public void updateKitCooldown(final Kit kit) {
        this.kitCooldownMap.put((Object)kit.getUniqueID(), System.currentTimeMillis() + kit.getDelayMillis());
    }
    
    public int getKitUses(final Kit kit) {
        final int result = this.kitUseMap.get((Object)kit.getUniqueID());
        return (result == this.kitUseMap.getNoEntryValue()) ? 0 : result;
    }
    
    public int incrementKitUses(final Kit kit) {
        return this.kitUseMap.adjustOrPutValue((Object)kit.getUniqueID(), 1, 1);
    }
    
    public Set<UUID> getFactionChatSpying() {
        return this.factionChatSpying;
    }
    
    public TObjectIntMap<UUID> getKitUseMap() {
        return this.kitUseMap;
    }
    
    public TObjectLongMap<UUID> getKitCooldownMap() {
        return this.kitCooldownMap;
    }
    
    public UUID getUserUUID() {
        return this.userUUID;
    }
    
    public boolean isCapzoneEntryAlerts() {
        return this.capzoneEntryAlerts;
    }
    
    public boolean isShowClaimMap() {
        return this.showClaimMap;
    }
    
    public boolean isShowLightning() {
        return this.showLightning;
    }
    
    public boolean isMessagingSounds() {
        return this.messagingSounds;
    }
    
    public boolean isMessagesVisible() {
        return this.messagesVisible;
    }
    
    public long getLastFactionLeaveMillis() {
        return this.lastFactionLeaveMillis;
    }
    
    public int getKills() {
        return this.kills;
    }
    
    public int getDeaths() {
        return this.deaths;
    }
    
    public boolean isSOTW() {
        return this.isSOTW;
    }
    
    public UUID getLastRepliedTo() {
        return this.lastRepliedTo;
    }
    
    public long getLastSpeakTimeMillis() {
        return this.lastSpeakTimeMillis;
    }
    
    public long getLastReceivedMessageMillis() {
        return this.lastReceivedMessageMillis;
    }
    
    public long getLastSentMessageMillis() {
        return this.lastSentMessageMillis;
    }
    
    public void setFactionChatSpying(final Set<UUID> factionChatSpying) {
        this.factionChatSpying = factionChatSpying;
    }
    
    public void setUserUUID(final UUID userUUID) {
        this.userUUID = userUUID;
    }
    
    public void setCapzoneEntryAlerts(final boolean capzoneEntryAlerts) {
        this.capzoneEntryAlerts = capzoneEntryAlerts;
    }
    
    public void setShowClaimMap(final boolean showClaimMap) {
        this.showClaimMap = showClaimMap;
    }
    
    public void setShowLightning(final boolean showLightning) {
        this.showLightning = showLightning;
    }
    
    public void setMessagingSounds(final boolean messagingSounds) {
        this.messagingSounds = messagingSounds;
    }
    
    public void setMessagesVisible(final boolean messagesVisible) {
        this.messagesVisible = messagesVisible;
    }
    
    public void setLastFactionLeaveMillis(final long lastFactionLeaveMillis) {
        this.lastFactionLeaveMillis = lastFactionLeaveMillis;
    }
    
    public void setKills(final int kills) {
        this.kills = kills;
    }
    
    public void setDeaths(final int deaths) {
        this.deaths = deaths;
    }
    
    public void setSOTW(final boolean isSOTW) {
        this.isSOTW = isSOTW;
    }
    
    public void setLastRepliedTo(final UUID lastRepliedTo) {
        this.lastRepliedTo = lastRepliedTo;
    }
    
    public void setLastSpeakTimeMillis(final long lastSpeakTimeMillis) {
        this.lastSpeakTimeMillis = lastSpeakTimeMillis;
    }
    
    public void setLastReceivedMessageMillis(final long lastReceivedMessageMillis) {
        this.lastReceivedMessageMillis = lastReceivedMessageMillis;
    }
    
    public void setLastSentMessageMillis(final long lastSentMessageMillis) {
        this.lastSentMessageMillis = lastSentMessageMillis;
    }
}
