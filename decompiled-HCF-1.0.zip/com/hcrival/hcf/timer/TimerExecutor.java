package com.hcrival.hcf.timer;

import com.hcrival.hcf.*;
import com.hcrival.util.command.*;
import com.hcrival.hcf.timer.argument.*;

public class TimerExecutor extends ArgumentExecutor
{
    public TimerExecutor(final HCF plugin) {
        super("timer");
        this.addArgument(new TimerCheckArgument(plugin));
        this.addArgument(new TimerSetArgument(plugin));
    }
}
