package com.hcrival.hcf.timer.type;

import org.bukkit.configuration.file.*;
import java.util.concurrent.*;
import com.hcrival.hcf.*;
import java.util.*;
import org.bukkit.*;
import javax.annotation.*;
import com.hcrival.hcf.timer.*;
import java.util.function.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.hcf.util.*;

public class StuckTimer extends PlayerTimer implements Listener
{
    public static final int MAX_MOVE_DISTANCE = 5;
    private final Map<UUID, Location> startedLocations;
    YamlConfiguration mConfig;
    private static final int NEAR_SEARCH_DISTANCE_BLOCKS = 24;
    
    public StuckTimer() {
        super("Stuck", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.stuck.length")));
        this.startedLocations = new HashMap<UUID, Location>();
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.DARK_RED.toString() + ChatColor.BOLD;
    }
    
    @Override
    public TimerCooldown clearCooldown(@Nullable final Player player, final UUID uuid) {
        final TimerCooldown runnable = super.clearCooldown(player, uuid);
        if (runnable != null) {
            this.startedLocations.remove(uuid);
        }
        return runnable;
    }
    
    @Override
    public boolean setCooldown(@Nullable final Player player, final UUID playerUUID, final long millis, final boolean force, @Nullable final Predicate<Long> callback) {
        if (player != null && super.setCooldown(player, playerUUID, millis, force, callback)) {
            this.startedLocations.put(playerUUID, player.getLocation());
            return true;
        }
        return false;
    }
    
    private void checkMovement(final Player player, final Location from, final Location to) {
        final UUID uuid = player.getUniqueId();
        if (this.getRemaining(uuid) > 0L) {
            if (from == null) {
                this.clearCooldown(player, uuid);
                return;
            }
            final int xDiff = Math.abs(from.getBlockX() - to.getBlockX());
            final int yDiff = Math.abs(from.getBlockY() - to.getBlockY());
            final int zDiff = Math.abs(from.getBlockZ() - to.getBlockZ());
            if (xDiff > 5 || yDiff > 5 || zDiff > 5) {
                this.clearCooldown(player, uuid);
                player.sendMessage(Color.translate(this.mConfig.getString("messages.stuck_timer_moved")));
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerMove(final PlayerMoveEvent event) {
        final Player player = event.getPlayer();
        final UUID uuid = player.getUniqueId();
        if (this.getRemaining(uuid) > 0L) {
            final Location from = this.startedLocations.get(uuid);
            this.checkMovement(player, from, event.getTo());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerTeleport(final PlayerTeleportEvent event) {
        final Player player = event.getPlayer();
        final UUID uuid = player.getUniqueId();
        if (this.getRemaining(uuid) > 0L) {
            final Location from = this.startedLocations.get(uuid);
            this.checkMovement(player, from, event.getTo());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerKick(final PlayerKickEvent event) {
        final UUID uuid = event.getPlayer().getUniqueId();
        if (this.getRemaining(event.getPlayer().getUniqueId()) > 0L) {
            this.clearCooldown(uuid);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final UUID uuid = event.getPlayer().getUniqueId();
        if (this.getRemaining(event.getPlayer().getUniqueId()) > 0L) {
            this.clearCooldown(uuid);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDamage(final EntityDamageEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Player) {
            final Player player = (Player)entity;
            if (this.getRemaining(player) > 0L) {
                player.sendMessage(Color.translate(this.mConfig.getString("messages.stuck_damaged")));
                this.clearCooldown(player);
            }
        }
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID userUUID) {
        if (player != null) {
            final Location nearest = LandMap.getNearestSafePosition(player, player.getLocation(), 24);
            if (nearest == null) {
                HCF.getPlugin().getCombatLogListener().safelyDisconnect(player, ChatColor.RED + "Unable to find a safe location, you have been safely logged out.");
                player.sendMessage(ChatColor.RED + "No safe-location found.");
                return;
            }
            if (player.teleport(nearest, PlayerTeleportEvent.TeleportCause.PLUGIN)) {
                player.sendMessage(ChatColor.YELLOW + this.getDisplayName() + ChatColor.YELLOW + " timer has teleported you to the nearest safe area.");
                player.sendMessage(Color.translate(this.mConfig.getString("messages.stuck_teleported")));
            }
        }
    }
    
    public void run(final Player player) {
        final long remainingMillis = this.getRemaining(player);
        if (remainingMillis > 0L) {
            player.sendMessage(Color.translate(this.mConfig.getString("messages.stuck_teleporting").replace("%time%", DurationFormatter.getRemaining(remainingMillis, true, false))));
        }
    }
}
