package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.timer.*;
import org.bukkit.configuration.file.*;
import java.util.concurrent.*;
import com.hcrival.hcf.*;
import org.bukkit.*;
import org.bukkit.event.*;
import java.util.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import javax.annotation.*;
import com.hcrival.hcf.util.*;

public class LogoutTimer extends PlayerTimer implements Listener
{
    YamlConfiguration mConfig;
    
    public LogoutTimer() {
        super("Logout", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.logout.length")), false);
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.RED.toString() + ChatColor.BOLD;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerMove(final PlayerMoveEvent event) {
        final Location from = event.getFrom();
        final Location to = event.getTo();
        if (from.getBlockX() == to.getBlockX() && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        final Player player = event.getPlayer();
        if (this.getRemaining(player) > 0L) {
            player.sendMessage(Color.translate(this.mConfig.getString("messages.logout_moved_block")));
            this.clearCooldown(player);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerTeleport(final PlayerTeleportEvent event) {
        this.onPlayerMove((PlayerMoveEvent)event);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerKick(final PlayerKickEvent event) {
        final UUID uuid = event.getPlayer().getUniqueId();
        if (this.getRemaining(event.getPlayer().getUniqueId()) > 0L) {
            this.clearCooldown(event.getPlayer(), uuid);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final UUID uuid = event.getPlayer().getUniqueId();
        if (this.getRemaining(event.getPlayer().getUniqueId()) > 0L) {
            this.clearCooldown(event.getPlayer(), uuid);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onEntityDamage(final EntityDamageEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Player) {
            final Player player = (Player)entity;
            if (this.getRemaining(player) > 0L) {
                player.sendMessage(Color.translate(this.mConfig.getString("messages.logout_damaged")));
                this.clearCooldown(player);
                return;
            }
        }
        if (event instanceof EntityDamageByEntityEvent) {
            final EntityDamageByEntityEvent ede = (EntityDamageByEntityEvent)event;
            final Entity damager = ede.getDamager();
            if (damager instanceof Player && entity instanceof Player) {
                final Player attacker = (Player)damager;
                if (this.getRemaining(attacker) > 0L) {
                    attacker.sendMessage(Color.translate(this.mConfig.getString("messages.logout_damage")));
                    this.clearCooldown(attacker);
                }
            }
        }
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID userUUID) {
        if (player != null) {
            HCF.getPlugin().getCombatLogListener().safelyDisconnect(player, Color.translate("&4&lSafely logged out."));
        }
    }
    
    public void run(final Player player) {
        final long remainingMillis = this.getRemaining(player);
        if (remainingMillis > 0L) {
            player.sendMessage(Color.translate(this.mConfig.getString("messages.logout_timer_logout").replace("%time%", DurationFormatter.getRemaining(remainingMillis, true, true))));
        }
    }
}
