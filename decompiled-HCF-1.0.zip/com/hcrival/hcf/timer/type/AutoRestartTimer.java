package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import org.bukkit.scheduler.*;
import org.bukkit.*;
import org.bukkit.command.*;

public class AutoRestartTimer
{
    private AutoRestartRunnable autoRestartRunnable;
    
    public boolean cancel() {
        if (this.autoRestartRunnable != null) {
            this.autoRestartRunnable.cancel();
            this.autoRestartRunnable = null;
            return true;
        }
        return false;
    }
    
    public void start(final long millis) {
        if (this.autoRestartRunnable == null) {
            (this.autoRestartRunnable = new AutoRestartRunnable(this, millis)).runTaskLater((Plugin)HCF.getPlugin(), millis / 50L);
        }
    }
    
    public AutoRestartRunnable getAutoRestartRunnable() {
        return this.autoRestartRunnable;
    }
    
    public static class AutoRestartRunnable extends BukkitRunnable
    {
        private AutoRestartTimer autoRestartTimer;
        private long startMillis;
        private long endMillis;
        
        public AutoRestartRunnable(final AutoRestartTimer autoRestartTimer, final long duration) {
            this.autoRestartTimer = autoRestartTimer;
            this.startMillis = System.currentTimeMillis();
            this.endMillis = this.startMillis + duration;
        }
        
        public long getRemaining() {
            return this.endMillis - System.currentTimeMillis();
        }
        
        public void run() {
            HCF.getPlugin().saveData();
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), HCF.getPlugin().getConfig().getString("settings.restart_command"));
            this.cancel();
            this.autoRestartTimer.autoRestartRunnable = null;
        }
    }
}
