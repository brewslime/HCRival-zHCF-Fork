package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.timer.*;
import com.hcrival.hcf.*;
import java.util.concurrent.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import java.util.function.*;
import com.hcrival.hcf.util.*;
import org.bukkit.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class AppleTimer extends PlayerTimer implements Listener
{
    public AppleTimer(final HCF plugin) {
        super("Apple", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.apple.length")));
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.YELLOW.toString();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerConsume(final PlayerItemConsumeEvent event) {
        final ItemStack stack = event.getItem();
        if (stack != null && stack.getType() == Material.GOLDEN_APPLE && stack.getDurability() == 0) {
            final Player player = event.getPlayer();
            if (this.setCooldown(player, player.getUniqueId(), this.defaultCooldown, false, new Predicate<Long>() {
                @Override
                public boolean test(final Long arg0) {
                    return false;
                }
            })) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588\u2588\u2588\u2588&c\u2588\u2588\u2588"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588\u2588&e\u2588\u2588&c\u2588\u2588\u2588"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588\u2588&e\u2588&c\u2588\u2588\u2588\u2588 &6&l " + this.name + ": "));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588&6\u2588\u2588\u2588\u2588&c\u2588\u2588 &7  Consumed"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588&6\u2588\u2588&f\u2588&6\u2588&6\u2588\u2588&c\u2588"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588&6\u2588&f\u2588&6\u2588&6\u2588&6\u2588\u2588&c\u2588 &6 Cooldown Remaining:"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588&6\u2588\u2588&6\u2588&6\u2588&6\u2588\u2588&c\u2588 &7  " + DurationFormatter.getRemaining(this.getRemaining(player), true, false)));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588&6\u2588\u2588&6\u2588&6\u2588&6\u2588\u2588&c\u2588"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588&6\u2588\u2588\u2588\u2588&c\u2588\u2588"));
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c\u2588\u2588\u2588\u2588\u2588&c\u2588\u2588\u2588"));
            }
            else {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "You still have cooldown for " + DurationFormatter.getRemaining(this.getRemaining(player), true, false));
            }
        }
    }
}
