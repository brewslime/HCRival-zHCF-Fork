package com.hcrival.hcf.timer.type;

import net.minecraft.util.gnu.trove.map.*;
import com.hcrival.hcf.*;
import org.bukkit.configuration.file.*;
import java.util.concurrent.*;
import net.minecraft.util.gnu.trove.map.hash.*;
import javax.annotation.*;
import java.util.function.*;
import com.hcrival.hcf.visualise.*;
import com.hcrival.hcf.timer.event.*;
import org.bukkit.event.*;
import com.hcrival.hcf.faction.event.cause.*;
import com.hcrival.hcf.faction.claim.*;
import com.hcrival.util.*;
import java.util.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import org.bukkit.event.block.*;
import com.hcrival.hcf.util.*;
import org.bukkit.plugin.*;
import org.bukkit.metadata.*;
import org.bukkit.event.player.*;
import com.hcrival.hcf.timer.*;
import org.spigotmc.event.player.*;
import com.hcrival.hcf.faction.event.*;
import com.hcrival.hcf.faction.type.*;
import org.bukkit.command.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;

public class InvincibilityTimer extends PlayerTimer implements Listener
{
    private static final String PVP_COMMAND = "/pvp enable";
    private static final long ITEM_PICKUP_DELAY;
    private static final long ITEM_PICKUP_MESSAGE_DELAY = 1250L;
    private static final String ITEM_PICKUP_MESSAGE_META_KEY = "pickupMessageDelay";
    private final TObjectLongMap<UUID> itemUUIDPickupDelays;
    private final HCF plugin;
    YamlConfiguration mConfig;
    
    public InvincibilityTimer(final HCF plugin) {
        super("PVP Timer", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.pvptimer.length")));
        this.itemUUIDPickupDelays = (TObjectLongMap<UUID>)new TObjectLongHashMap();
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.GREEN.toString() + ChatColor.BOLD;
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID playerUUID) {
        if (player != null) {
            this.plugin.getVisualiseHandler().clearVisualBlocks(player, VisualType.CLAIM_BORDER, null);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onTimerClear(final TimerClearEvent event) {
        if (event.getTimer() == this) {
            final Optional<Player> playerOptional = event.getPlayer();
            if (playerOptional.isPresent()) {
                this.plugin.getVisualiseHandler().clearVisualBlocks(playerOptional.get(), VisualType.CLAIM_BORDER, null);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onClaimChange(final FactionClaimChangedEvent event) {
        if (event.getCause() == ClaimChangeCause.CLAIM) {
            final Collection<Claim> claims = event.getAffectedClaims();
            for (final Claim claim : claims) {
                final Collection<Player> players = claim.getPlayers();
                if (players.isEmpty()) {
                    continue;
                }
                Location location = new Location(claim.getWorld(), (double)(claim.getMinimumX() - 1), 0.0, (double)(claim.getMinimumZ() - 1));
                location = BukkitUtils.getHighestLocation(location, location);
                for (final Player player : players) {
                    if (this.getRemaining(player) > 0L && player.teleport(location, PlayerTeleportEvent.TeleportCause.PLUGIN)) {
                        player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_claimed")));
                    }
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerRespawn(final PlayerRespawnEvent event) {
        final Player player = event.getPlayer();
        if (!HCF.getPlugin().getConfig().getBoolean("server.kitmap") && this.setCooldown(player, player.getUniqueId(), this.defaultCooldown, true)) {
            this.setPaused(player.getUniqueId(), true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_got")));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        final Player player = event.getEntity();
        final World world = player.getWorld();
        final Location location = player.getLocation();
        final Collection<ItemStack> drops = (Collection<ItemStack>)event.getDrops();
        if (!drops.isEmpty()) {
            final Iterator<ItemStack> iterator = drops.iterator();
            final long stamp = System.currentTimeMillis() + InvincibilityTimer.ITEM_PICKUP_DELAY;
            while (iterator.hasNext()) {
                this.itemUUIDPickupDelays.put((Object)world.dropItemNaturally(location, (ItemStack)iterator.next()).getUniqueId(), stamp);
                iterator.remove();
            }
        }
        this.clearCooldown(player);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBucketEmpty(final PlayerBucketEmptyEvent event) {
        final Player player = event.getPlayer();
        final long remaining = this.getRemaining(player);
        if (remaining > 0L) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_emptybucket")));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBlockIgnite(final BlockIgniteEvent event) {
        final Player player = event.getPlayer();
        if (player == null) {
            return;
        }
        final long remaining = this.getRemaining(player);
        if (remaining > 0L) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_igniteblocks")));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void fishingEvent(final PlayerFishEvent event) {
        final Player player = event.getPlayer();
        if (player == null) {
            return;
        }
        final long remaining = this.getRemaining(player);
        if (remaining > 0L) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_fish")));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onItemPickup(final PlayerPickupItemEvent event) {
        final Player player = event.getPlayer();
        final long remaining = this.getRemaining(player);
        if (remaining > 0L) {
            final UUID itemUUID = event.getItem().getUniqueId();
            final long delay = this.itemUUIDPickupDelays.get((Object)itemUUID);
            if (delay == this.itemUUIDPickupDelays.getNoEntryValue()) {
                return;
            }
            final long millis = System.currentTimeMillis();
            if (delay - millis <= 0L) {
                this.itemUUIDPickupDelays.remove((Object)itemUUID);
                return;
            }
            event.setCancelled(true);
            final MetadataValue value = ReflectionUtils.getPlayerMetadata(player, "pickupMessageDelay", (Plugin)this.plugin);
            if (value != null && value.asLong() - millis <= 0L) {
                player.setMetadata("pickupMessageDelay", (MetadataValue)new FixedMetadataValue((Plugin)this.plugin, (Object)(millis + 1250L)));
                player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_pickup")));
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        final TimerCooldown runnable = this.cooldowns.get(event.getPlayer().getUniqueId());
        if (runnable != null && runnable.getRemaining() > 0L) {
            runnable.setPaused(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerSpawnLocation(final PlayerSpawnLocationEvent event) {
        final Player player = event.getPlayer();
        if (!HCF.getPlugin().getConfig().getBoolean("server.kitmap")) {
            if (!player.hasPlayedBefore()) {
                if (this.canApply() && this.setCooldown(player, player.getUniqueId(), this.defaultCooldown, true)) {
                    this.setPaused(player.getUniqueId(), true);
                    player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_got")));
                }
            }
            else if (this.isPaused(player) && this.getRemaining(player) > 0L && !this.plugin.getFactionManager().getFactionAt(event.getSpawnLocation()).isSafezone()) {
                this.setPaused(player.getUniqueId(), false);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerClaimEnterMonitor(final PlayerClaimEnterEvent event) {
        final Player player = event.getPlayer();
        if (event.getTo().getWorld().getEnvironment() == World.Environment.THE_END) {
            this.clearCooldown(player);
            return;
        }
        final boolean flag = this.getRemaining(player.getUniqueId()) > 0L;
        if (flag) {
            final Faction toFaction = event.getToFaction();
            final Faction fromFaction = event.getFromFaction();
            if (fromFaction.isSafezone() && !toFaction.isSafezone()) {
                this.setPaused(player.getUniqueId(), false);
            }
            else if (!fromFaction.isSafezone() && toFaction.isSafezone()) {
                this.setPaused(player.getUniqueId(), true);
            }
            final PlayerFaction playerFaction;
            if (event.getEnterCause() == PlayerClaimEnterEvent.EnterCause.TELEPORT && toFaction instanceof PlayerFaction && (playerFaction = this.plugin.getFactionManager().getPlayerFaction(player)) != null && playerFaction == toFaction) {
                player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_enter_own_claim")));
                this.clearCooldown(player);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlayerClaimEnter(final PlayerClaimEnterEvent event) {
        final Player player = event.getPlayer();
        final Faction toFaction = event.getToFaction();
        final long remaining;
        if (toFaction instanceof ClaimableFaction && (remaining = this.getRemaining(player)) > 0L && !toFaction.isSafezone() && !(toFaction instanceof RoadFaction)) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_enter_claim").replace("%faction%", toFaction.getDisplayName((CommandSender)player))));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Player) {
            final Player attacker = BukkitUtils.getFinalAttacker((EntityDamageEvent)event, true);
            if (attacker == null) {
                return;
            }
            final Player player = (Player)entity;
            long remaining;
            if ((remaining = this.getRemaining(player)) > 0L) {
                event.setCancelled(true);
                attacker.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_has").replace("%player%", player.getName())));
                return;
            }
            if ((remaining = this.getRemaining(attacker)) > 0L) {
                event.setCancelled(true);
                attacker.sendMessage(Color.translate(this.mConfig.getString("messages.pvptimer_attack")));
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onPotionSplash(final PotionSplashEvent event) {
        final ThrownPotion potion = event.getPotion();
        if (potion.getShooter() instanceof Player && BukkitUtils.isDebuff(potion)) {
            for (final LivingEntity livingEntity : event.getAffectedEntities()) {
                if (livingEntity instanceof Player && this.getRemaining((Player)livingEntity) > 0L) {
                    event.setIntensity(livingEntity, 0.0);
                }
            }
        }
    }
    
    @Override
    public boolean setCooldown(@Nullable final Player player, final UUID playerUUID, final long duration, final boolean overwrite, @Nullable final Predicate<Long> callback) {
        return this.canApply() && super.setCooldown(player, playerUUID, duration, overwrite, callback);
    }
    
    private boolean canApply() {
        return !this.plugin.getEotwHandler().isEndOfTheWorld() && this.plugin.getSotwTimer().getSotwRunnable() == null;
    }
    
    static {
        ITEM_PICKUP_DELAY = TimeUnit.SECONDS.toMillis(30L);
    }
}
