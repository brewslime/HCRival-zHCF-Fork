package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.timer.*;
import org.bukkit.configuration.file.*;
import com.hcrival.hcf.*;
import java.util.concurrent.*;
import com.hcrival.util.imagemessage.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import java.util.function.*;
import javax.annotation.*;
import com.hcrival.hcf.util.*;
import org.bukkit.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class GappleTimer extends PlayerTimer implements Listener
{
    private ImageMessage goppleArtMessage;
    YamlConfiguration mConfig;
    
    public GappleTimer(final HCF plugin) {
        super("Gapple", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.gapple.length")));
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        if (plugin.getImageFolder().getGopple() != null) {
            this.goppleArtMessage = ImageMessage.newInstance(plugin.getImageFolder().getGopple(), 8, ImageChar.BLOCK.getChar()).appendText("", "", ChatColor.YELLOW.toString() + ChatColor.BOLD + ' ' + this.name + ':', ChatColor.GRAY + "  Consumed", ChatColor.GOLD + " Cooldown Remaining:", ChatColor.GRAY + "  " + DurationFormatUtils.formatDurationWords(this.defaultCooldown, true, true));
        }
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.YELLOW.toString() + ChatColor.BOLD;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerConsume(final PlayerItemConsumeEvent event) {
        final ItemStack stack = event.getItem();
        if (stack != null && stack.getType() == Material.GOLDEN_APPLE && stack.getDurability() == 1) {
            final Player player = event.getPlayer();
            if (this.setCooldown(player, player.getUniqueId(), this.defaultCooldown, false, new Predicate<Long>() {
                @Override
                public boolean test(@Nullable final Long value) {
                    return false;
                }
            })) {
                if (this.goppleArtMessage != null) {
                    this.goppleArtMessage.sendToPlayer(player);
                }
                else {
                    player.sendMessage(ChatColor.YELLOW + "Consumed " + ChatColor.GOLD + "Golden Apple" + ChatColor.YELLOW + ", now on a cooldown for " + DurationFormatUtils.formatDurationWords(this.defaultCooldown, true, true));
                }
            }
            else {
                event.setCancelled(true);
                player.sendMessage(Color.translate(this.mConfig.getString("messages.gopple_notover")));
            }
        }
    }
}
