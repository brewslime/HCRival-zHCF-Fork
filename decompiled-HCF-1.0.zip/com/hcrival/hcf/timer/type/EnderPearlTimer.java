package com.hcrival.hcf.timer.type;

import org.bukkit.plugin.java.*;
import org.bukkit.configuration.file.*;
import java.util.concurrent.*;
import com.hcrival.hcf.*;
import com.hcrival.util.*;
import java.util.*;
import org.bukkit.event.*;
import org.bukkit.*;
import org.bukkit.event.entity.*;
import org.bukkit.plugin.*;
import org.bukkit.projectiles.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;
import net.minecraft.server.v1_7_R4.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import javax.annotation.*;
import com.hcrival.hcf.timer.*;
import org.bukkit.scheduler.*;
import com.hcrival.hcf.util.*;

public class EnderPearlTimer extends PlayerTimer implements Listener
{
    private static final long REFRESH_DELAY_TICKS = 2L;
    private static final long REFRESH_DELAY_TICKS_18 = 20L;
    private final Map<UUID, PearlNameFaker> itemNameFakes;
    private final JavaPlugin plugin;
    YamlConfiguration mConfig;
    
    public EnderPearlTimer(final JavaPlugin plugin) {
        super("Enderpearl", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.enderpearl.length")));
        this.itemNameFakes = new HashMap<UUID, PearlNameFaker>();
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.DARK_PURPLE.toString() + ChatColor.BOLD;
    }
    
    @Override
    public void load(final Config config) {
        super.load(config);
    }
    
    @Override
    public void onDisable(final Config config) {
        super.onDisable(config);
        final Iterator<PearlNameFaker> iterator = this.itemNameFakes.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().cancel();
            iterator.remove();
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        this.clearCooldown(event.getPlayer(), event.getPlayer().getUniqueId());
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerKick(final PlayerKickEvent event) {
        this.clearCooldown(event.getPlayer(), event.getPlayer().getUniqueId());
    }
    
    public void refund(final Player player) {
        player.getInventory().addItem(new ItemStack[] { new ItemStack(Material.ENDER_PEARL, 1) });
        this.clearCooldown(player, player.getUniqueId());
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onProjectileLaunch(final ProjectileLaunchEvent event) {
        final Projectile projectile = event.getEntity();
        if (projectile instanceof EnderPearl) {
            final EnderPearl enderPearl = (EnderPearl)projectile;
            final ProjectileSource source = enderPearl.getShooter();
            if (source instanceof Player) {
                final Player shooter = (Player)source;
                final long remaining = this.getRemaining(shooter);
                if (remaining > 0L) {
                    shooter.sendMessage(Color.translate(this.mConfig.getString("messages.enderpearl_notover")));
                    shooter.getInventory().addItem(new ItemStack[] { new ItemStack(Material.ENDER_PEARL, 1) });
                    event.setCancelled(true);
                    return;
                }
                if (this.setCooldown(shooter, shooter.getUniqueId(), this.defaultCooldown, true)) {
                    final PearlNameFaker pearlNameFaker = new PearlNameFaker(this, shooter);
                    this.itemNameFakes.put(shooter.getUniqueId(), pearlNameFaker);
                    final long ticks = (NmsUtils.getProtocolVersion(shooter) >= 47) ? 20L : 2L;
                    pearlNameFaker.runTaskTimerAsynchronously((Plugin)this.plugin, ticks, ticks);
                }
            }
        }
    }
    
    @EventHandler
    public void onPearlInteract(final PlayerInteractEvent event) {
        final Player player = event.getPlayer();
        if ((event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && player.getItemInHand().getType() == Material.ENDER_PEARL && this.getRemaining(player) > 0L) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerItemHeld(final PlayerItemHeldEvent event) {
        final Player player = event.getPlayer();
        final PearlNameFaker pearlNameFaker = this.itemNameFakes.get(player.getUniqueId());
        if (pearlNameFaker != null) {
            final int previousSlot = event.getPreviousSlot();
            final net.minecraft.server.v1_7_R4.ItemStack stack = NmsUtils.getCleanItem(player, previousSlot);
            if (stack != null && stack.getItem() instanceof ItemEnderPearl) {
                NmsUtils.sendItemPacketAtSlot(player, stack, previousSlot);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onInventoryClick(final InventoryClickEvent event) {
        final HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player) {
            final Player player = (Player)humanEntity;
            final PearlNameFaker pearlNameFaker = this.itemNameFakes.get(player.getUniqueId());
            if (pearlNameFaker != null) {
                final Inventory clickedInventory = event.getClickedInventory();
                final int heldSlot = player.getInventory().getHeldItemSlot();
                final int slot = event.getSlot();
                final int hotbarButton = event.getHotbarButton();
                if (hotbarButton != -1) {
                    if (hotbarButton == heldSlot && slot != hotbarButton) {
                        NmsUtils.sendItemPacketAtSlot(player, NmsUtils.getCleanItem(clickedInventory, hotbarButton), slot);
                        NmsUtils.sendItemPacketAtSlot(player, NmsUtils.getCleanItem(clickedInventory, slot), hotbarButton);
                    }
                }
                else if (slot == heldSlot) {
                    NmsUtils.sendItemPacketAtSlot(player, NmsUtils.getCleanItem(clickedInventory, slot), slot);
                }
            }
        }
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID playerUUID) {
        this.clearCooldown(player, playerUUID);
    }
    
    @Override
    public TimerCooldown clearCooldown(@Nullable final Player player, final UUID playerUUID) {
        final TimerCooldown cooldown = super.clearCooldown(player, playerUUID);
        final PearlNameFaker pearlNameFaker = this.itemNameFakes.remove(playerUUID);
        if (pearlNameFaker != null) {
            pearlNameFaker.cancel();
        }
        return cooldown;
    }
    
    public static class PearlNameFaker extends BukkitRunnable
    {
        private final PlayerTimer timer;
        private final Player player;
        
        public PearlNameFaker(final PlayerTimer timer, final Player player) {
            this.timer = timer;
            this.player = player;
        }
        
        public void run() {
            net.minecraft.server.v1_7_R4.ItemStack stack = NmsUtils.getCleanHeldItem(this.player);
            if (stack != null && stack.getItem() instanceof ItemEnderPearl) {
                stack = stack.cloneItemStack();
                stack.c(ChatColor.GOLD + "Enderpearl Cooldown: " + ChatColor.RED + DurationFormatter.getRemaining(this.timer.getRemaining(this.player), true, true));
                NmsUtils.sendItemPacketAtHeldSlot(this.player, stack);
            }
        }
        
        public synchronized void cancel() throws IllegalStateException {
            super.cancel();
            NmsUtils.resendHeldItemPacket(this.player);
        }
    }
}
