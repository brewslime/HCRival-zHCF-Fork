package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.*;
import org.bukkit.configuration.file.*;
import java.util.concurrent.*;
import org.bukkit.*;
import javax.annotation.*;
import com.hcrival.hcf.timer.*;
import java.util.function.*;
import com.hcrival.hcf.visualise.*;
import com.hcrival.hcf.util.*;
import java.util.*;
import org.bukkit.event.*;
import org.bukkit.command.*;
import com.hcrival.hcf.faction.event.*;
import com.hcrival.util.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.timer.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;

public class CombatTimer extends PlayerTimer implements Listener
{
    private final HCF plugin;
    YamlConfiguration mConfig;
    
    public CombatTimer(final HCF plugin) {
        super("Combat", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.combat.length")));
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.DARK_RED + ChatColor.BOLD.toString();
    }
    
    @Override
    public TimerCooldown clearCooldown(@Nullable final Player player, final UUID playerUUID) {
        final TimerCooldown cooldown = super.clearCooldown(player, playerUUID);
        if (cooldown != null && player != null) {
            this.plugin.getVisualiseHandler().clearVisualBlocks(player, VisualType.SPAWN_BORDER, null);
        }
        return cooldown;
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID playerUUID) {
        super.handleExpiry(player, playerUUID);
        if (player != null) {
            this.plugin.getVisualiseHandler().clearVisualBlocks(player, VisualType.SPAWN_BORDER, null);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onFactionJoin(final PlayerJoinFactionEvent event) {
        final Optional<Player> optional = event.getPlayer();
        if (optional.isPresent()) {
            final Player player = optional.get();
            final long remaining = this.getRemaining(player);
            if (remaining > 0L) {
                event.setCancelled(true);
                player.sendMessage(Color.translate(this.mConfig.getString("messages.combat_faction_join")));
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onFactionLeave(final PlayerLeaveFactionEvent event) {
        if (event.isForce()) {
            return;
        }
        final Optional<Player> optional = event.getPlayer();
        if (optional.isPresent()) {
            final Player player = optional.get();
            final long remaining = this.getRemaining(player);
            if (remaining > 0L) {
                event.setCancelled(true);
                final CommandSender sender = event.getSender();
                if (sender == player) {
                    sender.sendMessage(Color.translate(this.mConfig.getString("messages.combat_faction_kick")));
                }
                else {
                    sender.sendMessage(Color.translate(this.mConfig.getString("messages.combat_faction_leave")));
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPreventClaimEnter(final PlayerClaimEnterEvent event) {
        if (event.getEnterCause() == PlayerClaimEnterEvent.EnterCause.TELEPORT) {
            return;
        }
        final Player player = event.getPlayer();
        if (!event.getFromFaction().isSafezone() && event.getToFaction().isSafezone() && this.getRemaining(player) > 0L) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.combat_enter_spawn")));
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        final Player attacker = BukkitUtils.getFinalAttacker((EntityDamageEvent)event, true);
        final Entity entity;
        if (attacker != null && (entity = event.getEntity()) instanceof Player) {
            final Player attacked = (Player)entity;
            this.setCooldown(attacker, attacker.getUniqueId(), this.defaultCooldown, false);
            this.setCooldown(attacked, attacked.getUniqueId(), this.defaultCooldown, false);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onTimerStart(final TimerStartEvent event) {
        if (event.getTimer() == this) {
            final Optional<Player> optional = event.getPlayer();
            if (optional.isPresent()) {
                final Player player = optional.get();
                player.sendMessage(Color.translate(this.mConfig.getString("messages.combat_start")));
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerRespawn(final PlayerRespawnEvent event) {
        this.clearCooldown(event.getPlayer(), event.getPlayer().getUniqueId());
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent event) {
        if (HCF.getPlugin().getConfig().getBoolean("settings.anti_combat_place")) {
            if (this.getRemaining(event.getPlayer()) > 0L && this.plugin.getFactionManager().getPlayerFaction(event.getPlayer()) != null && this.plugin.getFactionManager().getPlayerFaction(event.getPlayer()).equals(this.plugin.getFactionManager().getFactionAt(event.getBlock()))) {
                event.setCancelled(true);
                event.getPlayer().sendMessage(Color.translate(this.mConfig.getString("messages.combat_place_blocks")));
            }
        }
    }
    
    @EventHandler
    public void onPlayerCommandPreprocess(final PlayerCommandPreprocessEvent event) {
        final Player player = event.getPlayer();
        if (this.getRemaining(player) > 0L && (event.getMessage().toLowerCase().startsWith("/gkitz") || event.getMessage().startsWith("/gkit") || (event.getMessage().startsWith("/kit") && HCF.getPlugin().getConfig().getBoolean("settings.anti_kits_in_combat")))) {
            event.setCancelled(true);
            player.sendMessage(Color.translate(this.mConfig.getString("messages.combat_use_kits")));
        }
    }
    
    @Override
    public boolean setCooldown(@Nullable final Player player, final UUID playerUUID, final long duration, final boolean overwrite, @Nullable final Predicate<Long> currentCooldownPredicate) {
        return (player == null || !this.plugin.getFactionManager().getFactionAt(player.getLocation()).isSafezone()) && super.setCooldown(player, playerUUID, duration, overwrite, currentCooldownPredicate);
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPreventClaimEnterMonitor(final PlayerClaimEnterEvent event) {
        if (event.getEnterCause() == PlayerClaimEnterEvent.EnterCause.TELEPORT && !event.getFromFaction().isSafezone() && event.getToFaction().isSafezone()) {
            this.clearCooldown(event.getPlayer(), event.getPlayer().getUniqueId());
        }
    }
}
