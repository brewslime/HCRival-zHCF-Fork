package com.hcrival.hcf.timer.type;

import com.hcrival.hcf.*;
import java.util.concurrent.*;
import javax.annotation.*;
import org.bukkit.*;
import com.hcrival.hcf.timer.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.faction.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;
import java.util.function.*;
import org.bukkit.event.player.*;
import com.hcrival.hcf.util.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;

public class TeleportTimer extends PlayerTimer implements Listener
{
    private final Map<UUID, Location> destinationMap;
    private final HCF plugin;
    
    public TeleportTimer(final HCF plugin) {
        super("Teleport", TimeUnit.SECONDS.toMillis(HCF.getPlugin().getConfig().getInt("timers.teleport.length")), false);
        this.destinationMap = new HashMap<UUID, Location>();
        this.plugin = plugin;
    }
    
    public void handleExpiry(@Nullable final Player player, final UUID userUUID) {
        if (player != null) {
            final Location destination = this.destinationMap.remove(userUUID);
            if (destination != null) {
                destination.getChunk();
                player.teleport(destination, PlayerTeleportEvent.TeleportCause.COMMAND);
            }
        }
    }
    
    public Location getDestination(final Player player) {
        return this.destinationMap.get(player.getUniqueId());
    }
    
    public String getScoreboardPrefix() {
        return ChatColor.DARK_AQUA.toString() + ChatColor.BOLD;
    }
    
    @Override
    public TimerCooldown clearCooldown(final UUID uuid) {
        final TimerCooldown runnable = super.clearCooldown(uuid);
        if (runnable != null) {
            this.destinationMap.remove(uuid);
            return runnable;
        }
        return null;
    }
    
    public int getNearbyEnemies(final Player player, final int distance) {
        final FactionManager factionManager = this.plugin.getFactionManager();
        final Faction playerFaction = factionManager.getPlayerFaction(player.getUniqueId());
        int count = 0;
        final Collection<Entity> nearby = (Collection<Entity>)player.getNearbyEntities((double)distance, (double)distance, (double)distance);
        for (final Entity entity : nearby) {
            if (entity instanceof Player) {
                final Player target = (Player)entity;
                if (!target.canSee(player)) {
                    continue;
                }
                if (!player.canSee(target)) {
                    continue;
                }
                if (playerFaction != null && factionManager.getPlayerFaction(target) == playerFaction) {
                    continue;
                }
                ++count;
            }
        }
        return count;
    }
    
    public boolean teleport(final Player player, final Location location, final long millis, final String warmupMessage, final PlayerTeleportEvent.TeleportCause cause) {
        this.cancelTeleport(player, null);
        boolean result;
        if (millis <= 0L) {
            result = player.teleport(location, cause);
            this.clearCooldown(player.getUniqueId());
        }
        else {
            final UUID uuid = player.getUniqueId();
            player.sendMessage(warmupMessage);
            this.destinationMap.put(uuid, location.clone());
            this.setCooldown(player, uuid, millis, true, null);
            result = true;
        }
        return result;
    }
    
    public void cancelTeleport(final Player player, final String reason) {
        final UUID uuid = player.getUniqueId();
        if (this.getRemaining(uuid) > 0L) {
            this.clearCooldown(uuid);
            if (reason != null && !reason.isEmpty()) {
                player.sendMessage(reason);
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerMove(final PlayerMoveEvent event) {
        final Location from = event.getFrom();
        final Location to = event.getTo();
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        this.cancelTeleport(event.getPlayer(), Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.teleport_move")));
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDamage(final EntityDamageEvent event) {
        final Entity entity = event.getEntity();
        if (entity instanceof Player) {
            this.cancelTeleport((Player)entity, Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.teleport_damage")));
        }
    }
}
