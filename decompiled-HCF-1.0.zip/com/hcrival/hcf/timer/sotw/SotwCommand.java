package com.hcrival.hcf.timer.sotw;

import com.hcrival.hcf.*;
import org.bukkit.configuration.file.*;
import org.bukkit.command.*;
import org.bukkit.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.util.*;
import com.hcrival.hcf.user.*;
import com.hcrival.util.*;
import java.util.*;
import com.google.common.collect.*;

public class SotwCommand implements CommandExecutor, TabCompleter
{
    private static final List<String> COMPLETIONS;
    private final HCF plugin;
    YamlConfiguration mConfig;
    
    public SotwCommand(final HCF plugin) {
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("start")) {
                if (!sender.hasPermission("hcf.command.sotw.admin")) {
                    sender.sendMessage(ChatColor.RED + "No permission");
                }
                else {
                    if (args.length < 2) {
                        sender.sendMessage(ChatColor.RED + "Usage: /" + label + " " + args[0].toLowerCase() + " <duration>");
                        return true;
                    }
                    final long duration = JavaUtils.parse(args[1]);
                    if (duration == -1L) {
                        sender.sendMessage(ChatColor.RED + "'" + args[0] + "' is an invalid duration.");
                        return true;
                    }
                    if (duration < 1000L) {
                        sender.sendMessage(ChatColor.RED + "SOTW protection time must last for at least 20 ticks.");
                        return true;
                    }
                    final SotwTimer.SotwRunnable sotwRunnable = this.plugin.getSotwTimer().getSotwRunnable();
                    if (sotwRunnable != null) {
                        sender.sendMessage(ChatColor.RED + "SOTW protection is already enabled, use /" + label + " cancel to end it.");
                        return true;
                    }
                    this.plugin.getSotwTimer().start(duration);
                    sender.sendMessage(ChatColor.RED + "Started SOTW protection for " + DurationFormatUtils.formatDurationWords(duration, true, true) + ".");
                    return true;
                }
            }
            if (args[0].equalsIgnoreCase("enable")) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("You must be a player to enable SOTW for yourself.");
                    return true;
                }
                if (HCF.getPlugin().getSotwTimer() == null || HCF.getPlugin().getSotwTimer().getSotwRunnable() == null) {
                    sender.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_enable_no_sotw")));
                    return true;
                }
                final FactionUser user = HCF.getPlugin().getUserManager().getUser(((Player)sender).getUniqueId());
                if (user.isSOTW()) {
                    user.setSOTW(false);
                    sender.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_enabled")));
                    return true;
                }
                sender.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_already_enabled")));
                return true;
            }
            else if (args[0].equalsIgnoreCase("end") || args[0].equalsIgnoreCase("cancel")) {
                if (!sender.hasPermission("hcf.command.sotw.admin")) {
                    sender.sendMessage(ChatColor.RED + "No permission");
                }
                else {
                    if (this.plugin.getSotwTimer().cancel()) {
                        sender.sendMessage(ChatColor.RED + "Cancelled SOTW protection.");
                        return true;
                    }
                    sender.sendMessage(ChatColor.RED + "SOTW protection is not active.");
                    return true;
                }
            }
        }
        sender.sendMessage(ChatColor.GREEN + ChatColor.BOLD.toString() + "SOTW Timer Help");
        sender.sendMessage(ChatColor.GREEN + "/sotw enable - Enable your SOTW Timer");
        if (sender.hasPermission("hcf.command.sotw.admin")) {
            sender.sendMessage(ChatColor.GREEN + "/sotw start <time> - Start SOTW");
            sender.sendMessage(ChatColor.GREEN + "/sotw end - End SOTW");
        }
        return true;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        return (args.length == 1) ? BukkitUtils.getCompletions(args, SotwCommand.COMPLETIONS) : Collections.emptyList();
    }
    
    static {
        COMPLETIONS = ImmutableList.of("start", "end", "enable");
    }
}
