package com.hcrival.hcf.timer.sotw;

import com.hcrival.hcf.*;
import org.bukkit.configuration.file.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import com.hcrival.hcf.util.*;
import org.bukkit.event.entity.*;

public class SotwListener implements Listener
{
    private final HCF plugin;
    YamlConfiguration mConfig;
    
    public SotwListener(final HCF plugin) {
        this.mConfig = HCF.getPlugin().getMessageConfig().getConfig();
        this.plugin = plugin;
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onEntityDamage(final EntityDamageEvent event) {
        if (event.getEntity() instanceof Player && event.getCause() != EntityDamageEvent.DamageCause.SUICIDE && this.plugin.getSotwTimer().getSotwRunnable() != null) {
            if (!HCF.getPlugin().getUserManager().getUser(event.getEntity().getUniqueId()).isSOTW()) {
                return;
            }
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void fishingEvent(final PlayerFishEvent event) {
        final Player player = event.getPlayer();
        if (this.plugin.getSotwTimer().getSotwRunnable() != null) {
            if (!HCF.getPlugin().getUserManager().getUser(event.getPlayer().getUniqueId()).isSOTW()) {
                return;
            }
            player.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_cannot_fish")));
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onAttack(final EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player) || event.getCause() == EntityDamageEvent.DamageCause.SUICIDE || this.plugin.getSotwTimer().getSotwRunnable() == null) {
            return;
        }
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) {
            return;
        }
        final Player damager = (Player)event.getDamager();
        if (!HCF.getPlugin().getUserManager().getUser(event.getDamager().getUniqueId()).isSOTW()) {
            return;
        }
        damager.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_cannot_attack")));
        event.setCancelled(true);
    }
    
    @EventHandler
    public void onBraKekekeKoo(final EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player && this.plugin.getSotwTimer().getSotwRunnable() != null) {
            final Player victim = (Player)event.getEntity();
            if (!HCF.getPlugin().getUserManager().getUser(event.getEntity().getUniqueId()).isSOTW()) {
                return;
            }
            victim.sendMessage(Color.translate(this.mConfig.getString("messages.sotw_cannot_shoot")));
            event.setCancelled(true);
        }
    }
}
