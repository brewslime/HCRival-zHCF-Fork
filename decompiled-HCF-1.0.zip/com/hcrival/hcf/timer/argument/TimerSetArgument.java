package com.hcrival.hcf.timer.argument;

import com.hcrival.util.command.*;
import java.util.regex.*;
import com.hcrival.hcf.*;
import org.bukkit.command.*;
import com.hcrival.util.*;
import com.hcrival.hcf.timer.*;
import org.bukkit.entity.*;
import java.util.function.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.*;
import java.util.stream.*;
import java.util.*;

public class TimerSetArgument extends CommandArgument
{
    private static final Pattern WHITESPACE_TRIMMER;
    private final HCF plugin;
    
    public TimerSetArgument(final HCF plugin) {
        super("set", "Set remaining timer time");
        this.plugin = plugin;
    }
    
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <timerName> <all|playerName> <remaining>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final long duration = JavaUtils.parse(args[3]);
        if (duration == -1L) {
            sender.sendMessage(ChatColor.RED + "Invalid duration, use the correct format: 10m 1s");
            return true;
        }
        PlayerTimer playerTimer = null;
        for (final Timer timer : this.plugin.getTimerManager().getTimers()) {
            if (timer instanceof PlayerTimer && TimerSetArgument.WHITESPACE_TRIMMER.matcher(timer.getName()).replaceAll("").equalsIgnoreCase(args[1])) {
                playerTimer = (PlayerTimer)timer;
                break;
            }
        }
        if (playerTimer == null) {
            sender.sendMessage(ChatColor.RED + "Timer '" + args[1] + "' not found.");
            return true;
        }
        if (args[2].equalsIgnoreCase("all")) {
            for (final Player player : Bukkit.getOnlinePlayers()) {
                playerTimer.setCooldown(player, player.getUniqueId(), duration, true, null);
            }
            sender.sendMessage(ChatColor.BLUE + "Set timer " + playerTimer.getName() + " for all to " + DurationFormatUtils.formatDurationWords(duration, true, true) + '.');
        }
        else {
            final OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
            Player targetPlayer = null;
            if (target == null || (sender instanceof Player && (targetPlayer = target.getPlayer()) != null && !((Player)sender).canSee(targetPlayer))) {
                sender.sendMessage(ChatColor.GOLD + "Player '" + ChatColor.WHITE + args[1] + ChatColor.GOLD + "' not found.");
                return true;
            }
            playerTimer.setCooldown(targetPlayer, target.getUniqueId(), duration, true, null);
            sender.sendMessage(ChatColor.BLUE + "Set timer " + playerTimer.getName() + " duration to " + DurationFormatUtils.formatDurationWords(duration, true, true) + " for " + target.getName() + '.');
        }
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length == 2) {
            return this.plugin.getTimerManager().getTimers().stream().filter(timer -> timer instanceof PlayerTimer).map(timer -> timer.getName().replaceAll("\\s", "")).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
        }
        if (args.length == 3) {
            final List<String> list = new ArrayList<String>();
            list.add("ALL");
            final Player player = (sender instanceof Player) ? sender : null;
            for (final Player target : Bukkit.getOnlinePlayers()) {
                if (player == null || player.canSee(target)) {
                    list.add(target.getName());
                }
            }
            return list;
        }
        return Collections.emptyList();
    }
    
    static {
        WHITESPACE_TRIMMER = Pattern.compile("\\s");
    }
}
