package com.hcrival.hcf.timer.event;

import org.bukkit.event.*;
import org.bukkit.entity.*;
import java.util.*;
import com.hcrival.hcf.timer.*;
import javax.annotation.*;

public class TimerStartEvent extends Event
{
    private static final HandlerList handlers;
    private final Optional<Player> player;
    private final Optional<UUID> userUUID;
    private final Timer timer;
    private final long duration;
    
    public TimerStartEvent(final Timer timer, final long duration) {
        this.player = Optional.empty();
        this.userUUID = Optional.empty();
        this.timer = timer;
        this.duration = duration;
    }
    
    public TimerStartEvent(@Nullable final Player player, final UUID uniqueId, final Timer timer, final long duration) {
        this.player = Optional.ofNullable(player);
        this.userUUID = Optional.ofNullable(uniqueId);
        this.timer = timer;
        this.duration = duration;
    }
    
    public Optional<Player> getPlayer() {
        return this.player;
    }
    
    public Optional<UUID> getUserUUID() {
        return this.userUUID;
    }
    
    public Timer getTimer() {
        return this.timer;
    }
    
    public long getDuration() {
        return this.duration;
    }
    
    public static HandlerList getHandlerList() {
        return TimerStartEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return TimerStartEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
