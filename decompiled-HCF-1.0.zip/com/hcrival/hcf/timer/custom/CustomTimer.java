package com.hcrival.hcf.timer.custom;

import java.beans.*;
import java.util.*;

public class CustomTimer
{
    public static List<CustomTimer> customTimers;
    private String name;
    private String display;
    private long currentSecond;
    
    public String getName() {
        return this.name;
    }
    
    public String getDisplay() {
        return this.display;
    }
    
    public long getCurrentSecond() {
        return this.currentSecond;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setDisplay(final String display) {
        this.display = display;
    }
    
    public void setCurrentSecond(final long currentSecond) {
        this.currentSecond = currentSecond;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof CustomTimer)) {
            return false;
        }
        final CustomTimer other = (CustomTimer)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$name = this.getName();
        final Object other$name = other.getName();
        Label_0065: {
            if (this$name == null) {
                if (other$name == null) {
                    break Label_0065;
                }
            }
            else if (this$name.equals(other$name)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$display = this.getDisplay();
        final Object other$display = other.getDisplay();
        if (this$display == null) {
            if (other$display == null) {
                return this.getCurrentSecond() == other.getCurrentSecond();
            }
        }
        else if (this$display.equals(other$display)) {
            return this.getCurrentSecond() == other.getCurrentSecond();
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof CustomTimer;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $name = this.getName();
        result = result * 59 + (($name == null) ? 43 : $name.hashCode());
        final Object $display = this.getDisplay();
        result = result * 59 + (($display == null) ? 43 : $display.hashCode());
        final long $currentSecond = this.getCurrentSecond();
        result = result * 59 + (int)($currentSecond >>> 32 ^ $currentSecond);
        return result;
    }
    
    @Override
    public String toString() {
        return "CustomTimer(name=" + this.getName() + ", display=" + this.getDisplay() + ", currentSecond=" + this.getCurrentSecond() + ")";
    }
    
    @ConstructorProperties({ "name", "display", "currentSecond" })
    public CustomTimer(final String name, final String display, final long currentSecond) {
        this.name = name;
        this.display = display;
        this.currentSecond = currentSecond;
    }
    
    public static List<CustomTimer> getCustomTimers() {
        return CustomTimer.customTimers;
    }
    
    static {
        CustomTimer.customTimers = new ArrayList<CustomTimer>();
    }
}
