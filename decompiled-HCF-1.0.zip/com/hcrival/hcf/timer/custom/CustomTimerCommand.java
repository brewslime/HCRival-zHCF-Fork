package com.hcrival.hcf.timer.custom;

import org.bukkit.command.*;
import org.bukkit.*;
import com.hcrival.util.*;
import com.hcrival.hcf.util.*;
import org.bukkit.scheduler.*;
import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import java.util.*;

public class CustomTimerCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        final CommandSender p = sender;
        if (!p.hasPermission("hcf.command.customtimer")) {
            p.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(ChatColor.RED + "Usage: /customtimer <start/stop/list> <name> <time> <display>");
            return true;
        }
        final String s = args[0];
        switch (s) {
            case "start": {
                final String name = args[1];
                final long time = JavaUtils.parse(args[2]);
                final String display = StringUtils.stringBuilder(args, 3, true);
                final CustomTimer customTimer = new CustomTimer(name, display, time);
                CustomTimer.getCustomTimers().add(customTimer);
                new BukkitRunnable() {
                    public void run() {
                        if (customTimer.getCurrentSecond() == 0L) {
                            this.cancel();
                            CustomTimer.getCustomTimers().remove(customTimer);
                        }
                        else {
                            customTimer.setCurrentSecond(customTimer.getCurrentSecond() - 100L);
                        }
                    }
                }.runTaskTimerAsynchronously((Plugin)HCF.getPlugin(), 0L, 2L);
                return true;
            }
            case "stop": {
                final String timerName = args[1];
                for (final CustomTimer customTimer2 : CustomTimer.getCustomTimers()) {
                    if (customTimer2.getName().equalsIgnoreCase(timerName)) {
                        CustomTimer.getCustomTimers().remove(customTimer2);
                        return true;
                    }
                }
                p.sendMessage(ChatColor.RED + timerName + " is not found!");
                return true;
            }
            case "list": {
                p.sendMessage(ChatColor.YELLOW + "Active Timers:");
                for (final CustomTimer timer : CustomTimer.getCustomTimers()) {
                    p.sendMessage(ChatColor.YELLOW + timer.getName());
                }
                return true;
            }
            default: {
                p.sendMessage(ChatColor.RED + "Usage: /customtimer <start/stop/list> <name> <time> <display>");
                return true;
            }
        }
    }
}
