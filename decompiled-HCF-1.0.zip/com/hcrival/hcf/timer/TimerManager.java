package com.hcrival.hcf.timer;

import org.bukkit.event.*;
import com.hcrival.hcf.events.*;
import com.hcrival.hcf.timer.type.*;
import org.bukkit.plugin.java.*;
import com.hcrival.util.*;
import com.hcrival.hcf.*;
import org.bukkit.plugin.*;
import java.util.*;

public class TimerManager implements Listener
{
    public CombatTimer combatTimer;
    public LogoutTimer logoutTimer;
    public EnderPearlTimer enderPearlTimer;
    public EventTimer eventTimer;
    public GappleTimer gappleTimer;
    private final InvincibilityTimer invincibilityTimer;
    private final PvpClassWarmupTimer pvpClassWarmupTimer;
    private final StuckTimer stuckTimer;
    private final TeleportTimer teleportTimer;
    private final AppleTimer appleTimer;
    private final AutoRestartTimer autoRestartTimer;
    private final Set<Timer> timers;
    private final JavaPlugin plugin;
    private Config config;
    
    public TimerManager(final HCF plugin) {
        this.timers = new LinkedHashSet<Timer>();
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.autoRestartTimer = new AutoRestartTimer();
        this.registerTimer(this.enderPearlTimer = new EnderPearlTimer(plugin));
        this.registerTimer(this.logoutTimer = new LogoutTimer());
        this.registerTimer(this.gappleTimer = new GappleTimer(plugin));
        this.registerTimer(this.stuckTimer = new StuckTimer());
        this.registerTimer(this.invincibilityTimer = new InvincibilityTimer(plugin));
        this.registerTimer(this.combatTimer = new CombatTimer(plugin));
        this.registerTimer(this.teleportTimer = new TeleportTimer(plugin));
        this.registerTimer(this.eventTimer = new EventTimer(plugin));
        this.registerTimer(this.pvpClassWarmupTimer = new PvpClassWarmupTimer(plugin));
        this.registerTimer(this.appleTimer = new AppleTimer(plugin));
        this.reloadTimerData();
    }
    
    public void registerTimer(final Timer timer) {
        this.timers.add(timer);
        if (timer instanceof Listener) {
            this.plugin.getServer().getPluginManager().registerEvents((Listener)timer, (Plugin)this.plugin);
        }
    }
    
    public void unregisterTimer(final Timer timer) {
        this.timers.remove(timer);
    }
    
    public void reloadTimerData() {
        this.config = new Config(this.plugin, "timers");
        for (final Timer timer : this.timers) {
            timer.load(this.config);
        }
    }
    
    public void saveTimerData() {
        for (final Timer timer : this.timers) {
            timer.onDisable(this.config);
        }
        this.config.save();
    }
    
    public CombatTimer getCombatTimer() {
        return this.combatTimer;
    }
    
    public LogoutTimer getLogoutTimer() {
        return this.logoutTimer;
    }
    
    public EnderPearlTimer getEnderPearlTimer() {
        return this.enderPearlTimer;
    }
    
    public EventTimer getEventTimer() {
        return this.eventTimer;
    }
    
    public GappleTimer getGappleTimer() {
        return this.gappleTimer;
    }
    
    public JavaPlugin getPlugin() {
        return this.plugin;
    }
    
    public Config getConfig() {
        return this.config;
    }
    
    public void setCombatTimer(final CombatTimer combatTimer) {
        this.combatTimer = combatTimer;
    }
    
    public void setLogoutTimer(final LogoutTimer logoutTimer) {
        this.logoutTimer = logoutTimer;
    }
    
    public void setEnderPearlTimer(final EnderPearlTimer enderPearlTimer) {
        this.enderPearlTimer = enderPearlTimer;
    }
    
    public void setEventTimer(final EventTimer eventTimer) {
        this.eventTimer = eventTimer;
    }
    
    public void setGappleTimer(final GappleTimer gappleTimer) {
        this.gappleTimer = gappleTimer;
    }
    
    public void setConfig(final Config config) {
        this.config = config;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof TimerManager)) {
            return false;
        }
        final TimerManager other = (TimerManager)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$combatTimer = this.getCombatTimer();
        final Object other$combatTimer = other.getCombatTimer();
        Label_0065: {
            if (this$combatTimer == null) {
                if (other$combatTimer == null) {
                    break Label_0065;
                }
            }
            else if (this$combatTimer.equals(other$combatTimer)) {
                break Label_0065;
            }
            return false;
        }
        final Object this$logoutTimer = this.getLogoutTimer();
        final Object other$logoutTimer = other.getLogoutTimer();
        Label_0102: {
            if (this$logoutTimer == null) {
                if (other$logoutTimer == null) {
                    break Label_0102;
                }
            }
            else if (this$logoutTimer.equals(other$logoutTimer)) {
                break Label_0102;
            }
            return false;
        }
        final Object this$enderPearlTimer = this.getEnderPearlTimer();
        final Object other$enderPearlTimer = other.getEnderPearlTimer();
        Label_0139: {
            if (this$enderPearlTimer == null) {
                if (other$enderPearlTimer == null) {
                    break Label_0139;
                }
            }
            else if (this$enderPearlTimer.equals(other$enderPearlTimer)) {
                break Label_0139;
            }
            return false;
        }
        final Object this$eventTimer = this.getEventTimer();
        final Object other$eventTimer = other.getEventTimer();
        Label_0176: {
            if (this$eventTimer == null) {
                if (other$eventTimer == null) {
                    break Label_0176;
                }
            }
            else if (this$eventTimer.equals(other$eventTimer)) {
                break Label_0176;
            }
            return false;
        }
        final Object this$gappleTimer = this.getGappleTimer();
        final Object other$gappleTimer = other.getGappleTimer();
        Label_0213: {
            if (this$gappleTimer == null) {
                if (other$gappleTimer == null) {
                    break Label_0213;
                }
            }
            else if (this$gappleTimer.equals(other$gappleTimer)) {
                break Label_0213;
            }
            return false;
        }
        final Object this$invincibilityTimer = this.getInvincibilityTimer();
        final Object other$invincibilityTimer = other.getInvincibilityTimer();
        Label_0250: {
            if (this$invincibilityTimer == null) {
                if (other$invincibilityTimer == null) {
                    break Label_0250;
                }
            }
            else if (this$invincibilityTimer.equals(other$invincibilityTimer)) {
                break Label_0250;
            }
            return false;
        }
        final Object this$pvpClassWarmupTimer = this.getPvpClassWarmupTimer();
        final Object other$pvpClassWarmupTimer = other.getPvpClassWarmupTimer();
        Label_0287: {
            if (this$pvpClassWarmupTimer == null) {
                if (other$pvpClassWarmupTimer == null) {
                    break Label_0287;
                }
            }
            else if (this$pvpClassWarmupTimer.equals(other$pvpClassWarmupTimer)) {
                break Label_0287;
            }
            return false;
        }
        final Object this$stuckTimer = this.getStuckTimer();
        final Object other$stuckTimer = other.getStuckTimer();
        Label_0324: {
            if (this$stuckTimer == null) {
                if (other$stuckTimer == null) {
                    break Label_0324;
                }
            }
            else if (this$stuckTimer.equals(other$stuckTimer)) {
                break Label_0324;
            }
            return false;
        }
        final Object this$teleportTimer = this.getTeleportTimer();
        final Object other$teleportTimer = other.getTeleportTimer();
        Label_0361: {
            if (this$teleportTimer == null) {
                if (other$teleportTimer == null) {
                    break Label_0361;
                }
            }
            else if (this$teleportTimer.equals(other$teleportTimer)) {
                break Label_0361;
            }
            return false;
        }
        final Object this$appleTimer = this.getAppleTimer();
        final Object other$appleTimer = other.getAppleTimer();
        Label_0398: {
            if (this$appleTimer == null) {
                if (other$appleTimer == null) {
                    break Label_0398;
                }
            }
            else if (this$appleTimer.equals(other$appleTimer)) {
                break Label_0398;
            }
            return false;
        }
        final Object this$autoRestartTimer = this.getAutoRestartTimer();
        final Object other$autoRestartTimer = other.getAutoRestartTimer();
        Label_0435: {
            if (this$autoRestartTimer == null) {
                if (other$autoRestartTimer == null) {
                    break Label_0435;
                }
            }
            else if (this$autoRestartTimer.equals(other$autoRestartTimer)) {
                break Label_0435;
            }
            return false;
        }
        final Object this$timers = this.getTimers();
        final Object other$timers = other.getTimers();
        Label_0472: {
            if (this$timers == null) {
                if (other$timers == null) {
                    break Label_0472;
                }
            }
            else if (this$timers.equals(other$timers)) {
                break Label_0472;
            }
            return false;
        }
        final Object this$plugin = this.getPlugin();
        final Object other$plugin = other.getPlugin();
        Label_0509: {
            if (this$plugin == null) {
                if (other$plugin == null) {
                    break Label_0509;
                }
            }
            else if (this$plugin.equals(other$plugin)) {
                break Label_0509;
            }
            return false;
        }
        final Object this$config = this.getConfig();
        final Object other$config = other.getConfig();
        if (this$config == null) {
            if (other$config == null) {
                return true;
            }
        }
        else if (this$config.equals(other$config)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof TimerManager;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $combatTimer = this.getCombatTimer();
        result = result * 59 + (($combatTimer == null) ? 43 : $combatTimer.hashCode());
        final Object $logoutTimer = this.getLogoutTimer();
        result = result * 59 + (($logoutTimer == null) ? 43 : $logoutTimer.hashCode());
        final Object $enderPearlTimer = this.getEnderPearlTimer();
        result = result * 59 + (($enderPearlTimer == null) ? 43 : $enderPearlTimer.hashCode());
        final Object $eventTimer = this.getEventTimer();
        result = result * 59 + (($eventTimer == null) ? 43 : $eventTimer.hashCode());
        final Object $gappleTimer = this.getGappleTimer();
        result = result * 59 + (($gappleTimer == null) ? 43 : $gappleTimer.hashCode());
        final Object $invincibilityTimer = this.getInvincibilityTimer();
        result = result * 59 + (($invincibilityTimer == null) ? 43 : $invincibilityTimer.hashCode());
        final Object $pvpClassWarmupTimer = this.getPvpClassWarmupTimer();
        result = result * 59 + (($pvpClassWarmupTimer == null) ? 43 : $pvpClassWarmupTimer.hashCode());
        final Object $stuckTimer = this.getStuckTimer();
        result = result * 59 + (($stuckTimer == null) ? 43 : $stuckTimer.hashCode());
        final Object $teleportTimer = this.getTeleportTimer();
        result = result * 59 + (($teleportTimer == null) ? 43 : $teleportTimer.hashCode());
        final Object $appleTimer = this.getAppleTimer();
        result = result * 59 + (($appleTimer == null) ? 43 : $appleTimer.hashCode());
        final Object $autoRestartTimer = this.getAutoRestartTimer();
        result = result * 59 + (($autoRestartTimer == null) ? 43 : $autoRestartTimer.hashCode());
        final Object $timers = this.getTimers();
        result = result * 59 + (($timers == null) ? 43 : $timers.hashCode());
        final Object $plugin = this.getPlugin();
        result = result * 59 + (($plugin == null) ? 43 : $plugin.hashCode());
        final Object $config = this.getConfig();
        result = result * 59 + (($config == null) ? 43 : $config.hashCode());
        return result;
    }
    
    @Override
    public String toString() {
        return "TimerManager(combatTimer=" + this.getCombatTimer() + ", logoutTimer=" + this.getLogoutTimer() + ", enderPearlTimer=" + this.getEnderPearlTimer() + ", eventTimer=" + this.getEventTimer() + ", gappleTimer=" + this.getGappleTimer() + ", invincibilityTimer=" + this.getInvincibilityTimer() + ", pvpClassWarmupTimer=" + this.getPvpClassWarmupTimer() + ", stuckTimer=" + this.getStuckTimer() + ", teleportTimer=" + this.getTeleportTimer() + ", appleTimer=" + this.getAppleTimer() + ", autoRestartTimer=" + this.getAutoRestartTimer() + ", timers=" + this.getTimers() + ", plugin=" + this.getPlugin() + ", config=" + this.getConfig() + ")";
    }
    
    public InvincibilityTimer getInvincibilityTimer() {
        return this.invincibilityTimer;
    }
    
    public PvpClassWarmupTimer getPvpClassWarmupTimer() {
        return this.pvpClassWarmupTimer;
    }
    
    public StuckTimer getStuckTimer() {
        return this.stuckTimer;
    }
    
    public TeleportTimer getTeleportTimer() {
        return this.teleportTimer;
    }
    
    public AppleTimer getAppleTimer() {
        return this.appleTimer;
    }
    
    public AutoRestartTimer getAutoRestartTimer() {
        return this.autoRestartTimer;
    }
    
    public Set<Timer> getTimers() {
        return this.timers;
    }
}
