package com.hcrival.hcf;

import org.bukkit.*;
import java.util.*;

public final class ConfigurationService
{
    public static final int END_PORTAL_RADIUS = 20;
    public static final int END_PORTAL_CENTER = 500;
    public static final Map<World.Environment, Integer> ROAD_LENGTHS;
    public static final Map<World.Environment, Integer> SPAWN_RADIUS_MAP;
    
    static {
        ROAD_LENGTHS = new EnumMap<World.Environment, Integer>(World.Environment.class);
        SPAWN_RADIUS_MAP = new EnumMap<World.Environment, Integer>(World.Environment.class);
        ConfigurationService.ROAD_LENGTHS.put(World.Environment.NORMAL, 4000);
        ConfigurationService.ROAD_LENGTHS.put(World.Environment.NETHER, 4000);
        ConfigurationService.SPAWN_RADIUS_MAP.put(World.Environment.NORMAL, 50);
        ConfigurationService.SPAWN_RADIUS_MAP.put(World.Environment.NETHER, 25);
        ConfigurationService.SPAWN_RADIUS_MAP.put(World.Environment.THE_END, 15);
    }
}
