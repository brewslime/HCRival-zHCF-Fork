package com.hcrival.hcf.nametags;

import org.bukkit.entity.*;
import net.frozenorb.qlib.nametag.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.faction.type.*;

public class HCFNametagsProvider extends NametagProvider
{
    public HCFNametagsProvider() {
        super("HCF Provider", 5);
    }
    
    public NametagInfo fetchNametag(final Player toRefresh, final Player refreshFor) {
        final PlayerFaction factiontoRefresh = HCF.getPlugin().getFactionManager().getPlayerFaction(toRefresh.getUniqueId());
        final PlayerFaction factionrefreshFor = HCF.getPlugin().getFactionManager().getPlayerFaction(refreshFor.getUniqueId());
        if (factiontoRefresh != null && factionrefreshFor != null) {
            if (factiontoRefresh.getName().equalsIgnoreCase(factionrefreshFor.getName())) {
                return createNametag("�a", "");
            }
            if (factionrefreshFor.getAlliedFactions().contains(factiontoRefresh)) {
                return createNametag("�9", "");
            }
            if (factionrefreshFor.getFocused() != null && factionrefreshFor.getFocused().equals(toRefresh.getUniqueId())) {
                return createNametag("�d", "");
            }
        }
        return createNametag("�c", "");
    }
}
