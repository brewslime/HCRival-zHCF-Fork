package com.hcrival.hcf.tab;

import org.bukkit.configuration.file.*;
import com.hcrival.hcf.*;
import org.bukkit.entity.*;
import net.frozenorb.qlib.tab.*;
import com.hcrival.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import com.hcrival.hcf.user.*;
import com.hcrival.hcf.faction.type.*;

public class HCFTabLayoutProvider implements LayoutProvider
{
    YamlConfiguration config;
    
    public HCFTabLayoutProvider() {
        this.config = HCF.getPlugin().getTabConfig();
    }
    
    public TabLayout provide(final Player player) {
        final TabLayout layout = TabLayout.create(player);
        for (int i = 0; i < 21; ++i) {
            layout.set(0, i, this.translate(this.getTabSlot(i, "left"), player));
            layout.set(2, i, this.translate(this.getTabSlot(i, "right"), player));
            layout.set(1, i, this.translate(this.getTabSlot(i, "middle"), player));
        }
        return layout;
    }
    
    private String getTabSlot(final int slot, final String x) {
        return (this.config.getString("custom." + x + "." + slot) == null) ? " " : this.config.getString("custom." + x + "." + slot);
    }
    
    private String translate(String s, final Player player) {
        final FactionUser user = HCF.getPlugin().getUserManager().getUserAsync(player.getUniqueId());
        s = s.replace("%kills%", String.valueOf(user.getKills()));
        s = s.replace("%deaths%", String.valueOf(user.getDeaths()));
        s = s.replace("%location_x%", String.valueOf(player.getLocation().getBlockX()));
        s = s.replace("%location_y%", String.valueOf(player.getLocation().getBlockY()));
        s = s.replace("%location_z%", String.valueOf(player.getLocation().getBlockZ()));
        s = s.replace("%location_direction%", BukkitUtils.faceToString(BukkitUtils.yawToFace(player.getLocation().getYaw(), true)));
        String loc = ChatColor.valueOf(HCF.getPlugin().getConfig().getString("settings.colors.wilderness")) + "Wilderness";
        if (HCF.getPlugin().getFactionManager().getClaimAt(player.getLocation()) != null && HCF.getPlugin().getFactionManager().getClaimAt(player.getLocation()).getFaction() != null) {
            loc = HCF.getPlugin().getFactionManager().getClaimAt(player.getLocation()).getFaction().getDisplayName((CommandSender)player);
        }
        else if (HCF.getPlugin().getFactionManager().getFactionAt(player.getLocation()) instanceof WarzoneFaction) {
            loc = ChatColor.valueOf(HCF.getPlugin().getConfig().getString("settings.colors.warzone")) + "Warzone";
        }
        s = s.replace("%location_claim%", loc);
        s = s.replace("%online_players%", String.valueOf(HCF.getPlugin().getServer().getOnlinePlayers().size()));
        s = s.replace("%max_players%", String.valueOf(HCF.getPlugin().getServer().getMaxPlayers()));
        s = s.replace("%balance%", String.valueOf(HCF.getPlugin().getEconomyManager().getBalance(player.getUniqueId())));
        if (HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId()) == null) {
            s = s.replace("%faction%", "");
            s = s.replace("%faction_dtr%", "");
            s = s.replace("%faction_online%", "0");
            s = s.replace("%faction_member_count%", "0");
            s = s.replace("%faction_balance%", "0");
            s = s.replace("%faction_home%", "None");
        }
        else {
            final PlayerFaction faction = HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId());
            s = s.replace("%faction%", faction.getName());
            s = s.replace("%faction_dtr%", String.valueOf(faction.getDeathsUntilRaidable()));
            s = s.replace("%faction_online%", String.valueOf(faction.getOnlineMembers().size()));
            s = s.replace("%faction_member_count%", String.valueOf(faction.getMembers().size()));
            s = s.replace("%faction_balance%", String.valueOf(faction.getBalance()));
            if (HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId()).getHome() != null) {
                s = s.replace("%faction_home%", HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId()).getHome().getBlockX() + ", " + HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId()).getHome().getBlockY() + ", " + HCF.getPlugin().getFactionManager().getPlayerFaction(player.getUniqueId()).getHome().getBlockZ());
            }
            else {
                s = s.replace("%faction_home%", "None");
            }
        }
        return s;
    }
}
