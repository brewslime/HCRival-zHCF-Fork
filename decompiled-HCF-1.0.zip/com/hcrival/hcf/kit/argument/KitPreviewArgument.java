package com.hcrival.hcf.kit.argument;

import com.hcrival.util.command.*;
import com.hcrival.hcf.*;
import org.bukkit.event.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.hcf.kit.*;
import org.bukkit.inventory.*;
import java.util.*;

public class KitPreviewArgument extends CommandArgument
{
    private final HCF plugin;
    
    public KitPreviewArgument(final HCF plugin) {
        super("preview", "Preview the items you will get in a kit");
        this.plugin = plugin;
        this.aliases = new String[] { "look", "check", "see" };
        this.permission = "hcf.command.kit." + this.getName();
    }
    
    @EventHandler
    @Override
    public String getUsage(final String label) {
        return '/' + label + ' ' + this.getName() + " <kitName>";
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only executable by players.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: " + this.getUsage(label));
            return true;
        }
        final Kit kit = this.plugin.getKitManager().getKit(args[1]);
        if (kit == null) {
            sender.sendMessage(ChatColor.RED + "There is not a kit named " + args[1] + '.');
            return true;
        }
        final Inventory trackedInventory = kit.getPreview((Player)sender);
        KitListener.previewInventory.add(trackedInventory);
        ((Player)sender).openInventory(trackedInventory);
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 2) {
            return Collections.emptyList();
        }
        final Collection<Kit> kits = this.plugin.getKitManager().getKits();
        final List<String> results = new ArrayList<String>(kits.size());
        for (final Kit kit : kits) {
            results.add(kit.getName());
        }
        return results;
    }
}
