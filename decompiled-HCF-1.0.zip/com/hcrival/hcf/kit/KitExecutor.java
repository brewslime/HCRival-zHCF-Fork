package com.hcrival.hcf.kit;

import com.hcrival.hcf.*;
import com.hcrival.hcf.kit.argument.*;
import org.bukkit.command.*;
import com.hcrival.util.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.hcrival.util.*;
import java.util.*;

public class KitExecutor extends ArgumentExecutor
{
    private final HCF plugin;
    
    public KitExecutor(final HCF plugin) {
        super("kit");
        this.plugin = plugin;
        this.addArgument(new KitApplyArgument(plugin));
        this.addArgument(new KitCreateArgument(plugin));
        this.addArgument(new KitDeleteArgument(plugin));
        this.addArgument(new KitSetDescriptionArgument(plugin));
        this.addArgument(new KitDisableArgument(plugin));
        this.addArgument(new KitGuiArgument(plugin));
        this.addArgument(new KitListArgument(plugin));
        this.addArgument(new KitPreviewArgument(plugin));
        this.addArgument(new KitRenameArgument(plugin));
        this.addArgument(new KitSetDelayArgument(plugin));
        this.addArgument(new KitSetImageArgument(plugin));
        this.addArgument(new KitSetIndexArgument(plugin));
        this.addArgument(new KitSetItemsArgument(plugin));
        this.addArgument(new KitSetMaxUsesArgument(plugin));
        this.addArgument(new KitSetMinPlaytimeArgument(plugin));
    }
    
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length < 1) {
            CommandWrapper.printUsage(sender, label, this.arguments);
            sender.sendMessage(ChatColor.GREEN + "/" + label + " <kitName> " + ChatColor.DARK_GRAY + "- " + ChatColor.GRAY + "Applies a kit.");
            return true;
        }
        final CommandArgument argument = this.getArgument(args[0]);
        final String permission = (argument == null) ? null : argument.getPermission();
        if (argument == null || (permission != null && !sender.hasPermission(permission))) {
            final Kit kit = this.plugin.getKitManager().getKit(args[0]);
            if (sender instanceof Player && kit != null) {
                final String kitPermission = kit.getPermissionNode();
                if (kitPermission == null || sender.hasPermission(kitPermission)) {
                    final Player player = (Player)sender;
                    kit.applyTo(player, false, true);
                    return true;
                }
            }
            sender.sendMessage(ChatColor.RED + "Kit or command " + args[0] + " not found.");
            return true;
        }
        argument.onCommand(sender, command, label, args);
        return true;
    }
    
    @Override
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (args.length != 1) {
            return super.onTabComplete(sender, command, label, args);
        }
        List<String> previous = super.onTabComplete(sender, command, label, args);
        final List<String> kitNames = new ArrayList<String>();
        for (final Kit kit : this.plugin.getKitManager().getKits()) {
            final String permission = kit.getPermissionNode();
            if (permission == null || sender.hasPermission(permission)) {
                kitNames.add(kit.getName());
            }
        }
        if (previous == null || previous.isEmpty()) {
            previous = kitNames;
        }
        else {
            previous = new ArrayList<String>(previous);
            previous.addAll(0, kitNames);
        }
        return BukkitUtils.getCompletions(args, previous);
    }
}
