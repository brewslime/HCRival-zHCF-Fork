package com.hcrival.hcf.kit;

import com.hcrival.hcf.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import com.hcrival.util.*;
import org.bukkit.block.*;
import com.hcrival.hcf.kit.event.*;
import net.minecraft.util.org.apache.commons.lang3.time.*;
import com.hcrival.hcf.user.*;
import org.bukkit.*;
import com.hcrival.hcf.faction.type.*;
import java.util.*;

public class KitListener implements Listener
{
    private final HCF plugin;
    public static List<Inventory> previewInventory;
    
    public KitListener(final HCF plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent e) {
        if (KitListener.previewInventory.contains(e.getInventory())) {
            KitListener.previewInventory.remove(e.getInventory());
            e.getInventory().clear();
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onInventoryClick(final InventoryClickEvent event) {
        if (KitListener.previewInventory.contains(event.getInventory())) {
            event.setCancelled(true);
            return;
        }
        final Inventory inventory = event.getInventory();
        if (inventory == null) {
            return;
        }
        final String title = inventory.getTitle();
        final HumanEntity humanEntity = event.getWhoClicked();
        if (title.contains("Kit Selector") && humanEntity instanceof Player) {
            event.setCancelled(true);
            if (!Objects.equals(event.getView().getTopInventory(), event.getClickedInventory())) {
                return;
            }
            final ItemStack stack = event.getCurrentItem();
            if (stack == null || !stack.hasItemMeta()) {
                return;
            }
            final ItemMeta meta = stack.getItemMeta();
            if (!meta.hasDisplayName()) {
                return;
            }
            final Player player = (Player)humanEntity;
            final String name = ChatColor.stripColor(stack.getItemMeta().getDisplayName());
            final Kit kit = this.plugin.getKitManager().getKit(name);
            if (kit == null) {
                return;
            }
            kit.applyTo(player, false, true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void onKitSign(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            final Block block = event.getClickedBlock();
            final BlockState state = block.getState();
            if (!(state instanceof Sign)) {
                return;
            }
            final Sign sign = (Sign)state;
            final String[] lines = sign.getLines();
            if (lines.length >= 2 && lines[0].contains("[Kit]")) {
                final Kit kit = this.plugin.getKitManager().getKit((lines.length >= 2) ? ChatColor.stripColor(lines[1]) : null);
                if (kit == null) {
                    return;
                }
                event.setCancelled(true);
                final Player player = event.getPlayer();
                final String[] fakeLines = Arrays.copyOf(sign.getLines(), 4);
                final boolean applied = kit.applyTo(player, false, false);
                if (applied) {
                    fakeLines[0] = ChatColor.GREEN + "Successfully";
                    fakeLines[1] = ChatColor.GREEN + "equipped kit";
                    fakeLines[2] = kit.getDisplayName();
                    fakeLines[3] = "";
                    player.updateInventory();
                }
                else {
                    fakeLines[0] = ChatColor.RED + "Failed to";
                    fakeLines[1] = ChatColor.RED + "equip kit";
                    fakeLines[2] = kit.getDisplayName();
                    fakeLines[3] = ChatColor.RED + "Check chat";
                }
                if (HCF.getPlugin().getSignHandler().showLines(player, sign, fakeLines, 100L, false) && applied) {
                    ParticleEffect.SPLASH.display(player, sign.getLocation().clone().add(0.5, 0.5, 0.5), 0.01f, 10);
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onKitApply(final KitApplyEvent event) {
        if (event.isForce()) {
            return;
        }
        final Player player = event.getPlayer();
        final Kit kit = event.getKit();
        if (!player.isOp() && !kit.isEnabled()) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "The " + kit.getDisplayName() + " kit is currently disabled.");
            return;
        }
        final String kitPermission = kit.getPermissionNode();
        if (kitPermission != null && !player.hasPermission(kitPermission)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "No permission.");
            return;
        }
        final UUID uuid = player.getUniqueId();
        final FactionUser baseUser = this.plugin.getUserManager().getUser(uuid);
        final long remaining = baseUser.getRemainingKitCooldown(kit);
        if (remaining > 0L) {
            player.sendMessage(ChatColor.RED + "You cannot use the " + kit.getDisplayName() + " kit for " + DurationFormatUtils.formatDurationWords(remaining, true, true) + '.');
            event.setCancelled(true);
            return;
        }
        final int curUses = baseUser.getKitUses(kit);
        final int maxUses = kit.getMaximumUses();
        if (curUses >= maxUses && maxUses != Integer.MAX_VALUE) {
            player.sendMessage(ChatColor.RED + "You have already used this kit " + curUses + '/' + maxUses + " times.");
            event.setCancelled(true);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onKitApplyMonitor(final KitApplyEvent event) {
        if (!event.isForce()) {
            final Kit kit = event.getKit();
            final FactionUser baseUser = this.plugin.getUserManager().getUser(event.getPlayer().getUniqueId());
            baseUser.incrementKitUses(kit);
            baseUser.updateKitCooldown(kit);
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onKitApplyHigh(final KitApplyEvent event) {
        final Player player = event.getPlayer();
        final Location location = player.getLocation();
        final Faction factionAt = this.plugin.getFactionManager().getFactionAt(location);
    }
    
    static {
        KitListener.previewInventory = new ArrayList<Inventory>();
    }
}
