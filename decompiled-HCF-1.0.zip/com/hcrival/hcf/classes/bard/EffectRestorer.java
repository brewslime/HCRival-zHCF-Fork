package com.hcrival.hcf.classes.bard;

import org.bukkit.potion.*;
import org.bukkit.plugin.java.*;
import com.google.common.collect.*;
import org.bukkit.plugin.*;
import com.hcrival.hcf.classes.event.*;
import org.bukkit.event.*;
import com.hcrival.hcf.classes.*;
import java.util.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;

public class EffectRestorer implements Listener
{
    private final Table<UUID, PotionEffectType, PotionEffect> restores;
    
    public EffectRestorer(final JavaPlugin plugin) {
        this.restores = (Table<UUID, PotionEffectType, PotionEffect>)HashBasedTable.create();
        plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
    }
    
    @EventHandler
    public void onPvpClassUnequip(final PvpClassUnequipEvent event) {
        this.restores.rowKeySet().remove(event.getPlayer().getUniqueId());
    }
    
    public void setRestoreEffect(final Player player, final PotionEffect effect) {
        boolean shouldCancel = true;
        final Collection<PotionEffect> activeList = (Collection<PotionEffect>)player.getActivePotionEffects();
        for (final PotionEffect active : activeList) {
            if (!active.getType().equals((Object)effect.getType())) {
                continue;
            }
            if (effect.getAmplifier() < active.getAmplifier()) {
                return;
            }
            if (effect.getAmplifier() == active.getAmplifier() && effect.getDuration() < active.getDuration()) {
                return;
            }
            this.restores.put(player.getUniqueId(), active.getType(), active);
            shouldCancel = false;
            break;
        }
        player.addPotionEffect(effect, true);
        if (shouldCancel && effect.getDuration() > 100 && effect.getDuration() < PvpClass.DEFAULT_MAX_DURATION) {
            this.restores.remove(player.getUniqueId(), effect.getType());
        }
    }
    
    @EventHandler
    public void onPotionEffectExpire(final PotionEffectExpireEvent event) {
        final LivingEntity livingEntity = event.getEntity();
        if (livingEntity instanceof Player) {
            final Player player = (Player)livingEntity;
            final PotionEffect previous = this.restores.remove(player.getUniqueId(), event.getEffect().getType());
            if (previous != null) {
                event.setCancelled(true);
                player.addPotionEffect(previous, true);
            }
        }
    }
}
