package com.hcrival.hcf.classes.event;

import org.bukkit.event.player.*;
import org.bukkit.event.*;
import com.hcrival.hcf.classes.*;
import org.bukkit.entity.*;

public class PvpClassEquipEvent extends PlayerEvent
{
    private static final HandlerList handlers;
    private final PvpClass pvpClass;
    
    public PvpClassEquipEvent(final Player player, final PvpClass pvpClass) {
        super(player);
        this.pvpClass = pvpClass;
    }
    
    public PvpClass getPvpClass() {
        return this.pvpClass;
    }
    
    public static HandlerList getHandlerList() {
        return PvpClassEquipEvent.handlers;
    }
    
    public HandlerList getHandlers() {
        return PvpClassEquipEvent.handlers;
    }
    
    static {
        handlers = new HandlerList();
    }
}
