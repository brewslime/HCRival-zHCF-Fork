package com.hcrival.hcf.classes;

import com.hcrival.hcf.*;
import com.hcrival.hcf.classes.archer.*;
import com.hcrival.hcf.classes.bard.*;
import com.hcrival.hcf.classes.type.*;
import org.bukkit.*;
import org.bukkit.plugin.*;
import org.bukkit.event.entity.*;
import java.util.*;
import org.bukkit.entity.*;
import javax.annotation.*;
import org.bukkit.event.*;
import com.hcrival.hcf.classes.event.*;
import org.bukkit.potion.*;

public class PvpClassManager implements Listener
{
    private final Map<UUID, PvpClass> equippedClassMap;
    private final List<PvpClass> pvpClasses;
    
    public PvpClassManager(final HCF plugin) {
        this.equippedClassMap = new HashMap<UUID, PvpClass>();
        (this.pvpClasses = new ArrayList<PvpClass>()).add(new ArcherClass(plugin));
        this.pvpClasses.add(new BardClass(plugin));
        this.pvpClasses.add(new MinerClass(plugin));
        this.pvpClasses.add(new RogueClass(plugin));
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        for (final PvpClass pvpClass : this.pvpClasses) {
            if (pvpClass instanceof Listener) {
                plugin.getServer().getPluginManager().registerEvents((Listener)pvpClass, (Plugin)plugin);
            }
        }
    }
    
    public void onDisable() {
        for (final Map.Entry<UUID, PvpClass> entry : new HashMap<UUID, PvpClass>(this.equippedClassMap).entrySet()) {
            this.setEquippedClass(Bukkit.getPlayer((UUID)entry.getKey()), null);
        }
        this.pvpClasses.clear();
        this.equippedClassMap.clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        this.setEquippedClass(event.getEntity(), null);
    }
    
    public Collection<PvpClass> getPvpClasses() {
        return this.pvpClasses;
    }
    
    public PvpClass getEquippedClass(final Player player) {
        synchronized (this.equippedClassMap) {
            return this.equippedClassMap.get(player.getUniqueId());
        }
    }
    
    public boolean hasClassEquipped(final Player player, final PvpClass pvpClass) {
        return this.getEquippedClass(player) == pvpClass;
    }
    
    public void setEquippedClass(final Player player, @Nullable final PvpClass pvpClass) {
        if (pvpClass == null) {
            final PvpClass equipped = this.equippedClassMap.remove(player.getUniqueId());
            if (equipped != null) {
                equipped.onUnequip(player);
                Bukkit.getPluginManager().callEvent((Event)new PvpClassUnequipEvent(player, equipped));
            }
        }
        else if (pvpClass.onEquip(player) && pvpClass != this.getEquippedClass(player)) {
            this.equippedClassMap.put(player.getUniqueId(), pvpClass);
            Bukkit.getPluginManager().callEvent((Event)new PvpClassEquipEvent(player, pvpClass));
        }
    }
    
    @EventHandler
    public void onClassUnequip(final PvpClassUnequipEvent e) {
        for (final PotionEffect potionEffect : e.getPlayer().getActivePotionEffects()) {
            e.getPlayer().removePotionEffect(potionEffect.getType());
        }
    }
}
