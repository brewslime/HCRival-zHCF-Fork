package com.hcrival.hcf.classes.type;

import com.hcrival.hcf.classes.*;
import gnu.trove.map.*;
import java.util.*;
import com.hcrival.hcf.*;
import java.util.concurrent.*;
import gnu.trove.map.hash.*;
import org.bukkit.potion.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import net.md_5.bungee.api.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.inventory.*;

public class AssassinClass extends PvpClass implements Listener
{
    private final TObjectLongMap<UUID> cooldowns;
    private final HCF plugin;
    
    public AssassinClass(final HCF plugin) {
        super("Assassin", TimeUnit.SECONDS.toMillis(10L));
        this.cooldowns = new TObjectLongHashMap<UUID>();
        this.plugin = plugin;
        this.passiveEffects.add(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 0));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0));
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        if (event.hasItem() && event.getItem().getType() == Material.GOLDEN_CARROT) {
            final Player player = event.getPlayer();
            if (this.plugin.getPvpClassManager().getEquippedClass(player) == this) {
                final long timestamp = this.cooldowns.get(player.getUniqueId());
                final long millis = System.currentTimeMillis();
                final long remaining = (timestamp == this.cooldowns.getNoEntryValue()) ? 0L : (timestamp - millis);
                if (remaining > 0L) {
                    player.sendMessage(ChatColor.RED + "Cooldown still for " + DurationFormatUtils.formatDurationWords(remaining, true, true) + ".");
                    return;
                }
                this.cooldowns.put(player.getUniqueId(), millis + 15000L);
                this.plugin.getEffectRestorer().setRestoreEffect(player, new PotionEffect(PotionEffectType.SPEED, 100, 4));
                this.plugin.getEffectRestorer().setRestoreEffect(player, new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0));
            }
        }
    }
    
    @Override
    public boolean isApplicableFor(final Player player) {
        final PlayerInventory playerInventory = player.getInventory();
        final ItemStack helmet = playerInventory.getHelmet();
        if (helmet == null || helmet.getType() != Material.IRON_HELMET || !helmet.getEnchantments().isEmpty()) {
            return false;
        }
        final ItemStack chestplate = playerInventory.getChestplate();
        if (chestplate == null || chestplate.getType() != Material.IRON_CHESTPLATE || !chestplate.getEnchantments().isEmpty()) {
            return false;
        }
        final ItemStack leggings = playerInventory.getLeggings();
        if (leggings == null || leggings.getType() != Material.IRON_LEGGINGS || !leggings.getEnchantments().isEmpty()) {
            return false;
        }
        final ItemStack boots = playerInventory.getBoots();
        return boots != null && boots.getType() == Material.IRON_BOOTS && boots.getEnchantments().isEmpty();
    }
}
