package com.hcrival.hcf.classes.type;

import com.hcrival.hcf.classes.*;
import com.hcrival.hcf.*;
import net.minecraft.util.gnu.trove.map.*;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.util.gnu.trove.map.hash.*;
import org.bukkit.potion.*;
import org.bukkit.event.entity.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.inventory.*;

public class RogueClass extends PvpClass implements Listener
{
    private final HCF plugin;
    private final TObjectLongMap<UUID> archerSpeedCooldowns;
    private static final PotionEffect ARCHER_SPEED_EFFECT;
    private static final long ARCHER_SPEED_COOLDOWN_DELAY;
    
    public RogueClass(final HCF plugin) {
        super("Rogue", TimeUnit.SECONDS.toMillis(2L));
        this.archerSpeedCooldowns = (TObjectLongMap<UUID>)new TObjectLongHashMap();
        this.plugin = plugin;
        this.passiveEffects.add(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 0));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2));
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onEntityDamageByEntity(final EntityDamageByEntityEvent event) {
        final Entity entity = event.getEntity();
        final Entity damager = event.getDamager();
        if (entity instanceof Player && damager instanceof Player) {
            final Player attacker = (Player)damager;
            if (this.plugin.getPvpClassManager().getEquippedClass(attacker) == this) {
                final ItemStack stack = attacker.getItemInHand();
                if (stack != null && stack.getType() == Material.GOLD_SWORD && stack.getEnchantments().isEmpty()) {
                    final ChatColor relationColourEnemy = ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.enemy"));
                    final Player player = (Player)entity;
                    player.sendMessage(relationColourEnemy + attacker.getName() + ChatColor.YELLOW + " has backstabbed you.");
                    player.playSound(player.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
                    attacker.sendMessage(ChatColor.YELLOW + "You have backstabbed " + relationColourEnemy + player.getName() + ChatColor.YELLOW + '.');
                    attacker.setItemInHand(new ItemStack(Material.AIR, 1));
                    attacker.playSound(player.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
                    event.setDamage(8.0);
                }
            }
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.HIGH)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Action action = event.getAction();
        if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && event.hasItem() && event.getItem().getType() == Material.SUGAR) {
            if (this.plugin.getPvpClassManager().getEquippedClass(event.getPlayer()) != this) {
                return;
            }
            final Player player = event.getPlayer();
            final UUID uuid = player.getUniqueId();
            final long timestamp = this.archerSpeedCooldowns.get((Object)uuid);
            final long millis = System.currentTimeMillis();
            final long remaining = (timestamp == this.archerSpeedCooldowns.getNoEntryValue()) ? -1L : (timestamp - millis);
            if (remaining > 0L) {
                player.sendMessage(ChatColor.RED + "Cannot use " + this.getName() + " speed for another " + DurationFormatUtils.formatDurationWords(remaining, true, true) + ".");
            }
            else {
                final ItemStack stack = player.getItemInHand();
                if (stack.getAmount() == 1) {
                    player.setItemInHand(new ItemStack(Material.AIR, 1));
                }
                else {
                    stack.setAmount(stack.getAmount() - 1);
                }
                this.plugin.getEffectRestorer().setRestoreEffect(player, RogueClass.ARCHER_SPEED_EFFECT);
                this.archerSpeedCooldowns.put((Object)event.getPlayer().getUniqueId(), System.currentTimeMillis() + RogueClass.ARCHER_SPEED_COOLDOWN_DELAY);
            }
        }
    }
    
    @Override
    public boolean isApplicableFor(final Player player) {
        final PlayerInventory playerInventory = player.getInventory();
        final ItemStack helmet = playerInventory.getHelmet();
        if (helmet == null || helmet.getType() != Material.CHAINMAIL_HELMET) {
            return false;
        }
        final ItemStack chestplate = playerInventory.getChestplate();
        if (chestplate == null || chestplate.getType() != Material.CHAINMAIL_CHESTPLATE) {
            return false;
        }
        final ItemStack leggings = playerInventory.getLeggings();
        if (leggings == null || leggings.getType() != Material.CHAINMAIL_LEGGINGS) {
            return false;
        }
        final ItemStack boots = playerInventory.getBoots();
        return boots != null && boots.getType() == Material.CHAINMAIL_BOOTS;
    }
    
    static {
        ARCHER_SPEED_EFFECT = new PotionEffect(PotionEffectType.SPEED, 160, 3);
        ARCHER_SPEED_COOLDOWN_DELAY = TimeUnit.MINUTES.toMillis(1L);
    }
}
