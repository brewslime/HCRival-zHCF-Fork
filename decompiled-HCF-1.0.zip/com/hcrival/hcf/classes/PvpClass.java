package com.hcrival.hcf.classes;

import org.bukkit.potion.*;
import org.bukkit.entity.*;
import com.hcrival.hcf.*;
import com.hcrival.hcf.util.*;
import java.util.*;
import java.util.concurrent.*;

public abstract class PvpClass
{
    public static final long DEFAULT_MAX_DURATION;
    protected final Set<PotionEffect> passiveEffects;
    protected final String name;
    protected final long warmupDelay;
    
    public PvpClass(final String name, final long warmupDelay) {
        this.passiveEffects = new HashSet<PotionEffect>();
        this.name = name;
        this.warmupDelay = warmupDelay;
    }
    
    public String getName() {
        return this.name;
    }
    
    public long getWarmupDelay() {
        return this.warmupDelay;
    }
    
    public boolean onEquip(final Player player) {
        for (final PotionEffect effect : this.passiveEffects) {
            player.addPotionEffect(effect, true);
        }
        player.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.pvp_class_equipping")).replace("%class%", this.getName()));
        player.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.pvp_class_equip")).replace("%class%", this.getName()));
        return true;
    }
    
    public void onUnequip(final Player player) {
        for (final PotionEffect effect : this.passiveEffects) {
            for (final PotionEffect active : player.getActivePotionEffects()) {
                if (active.getType() == effect.getType() && active.getAmplifier() == effect.getAmplifier()) {
                    player.removePotionEffect(effect.getType());
                }
            }
        }
        player.sendMessage(Color.translate(HCF.getPlugin().getMessageConfig().getConfig().getString("messages.pvp_class_unequip")).replace("%class%", this.getName()));
    }
    
    public abstract boolean isApplicableFor(final Player p0);
    
    static {
        DEFAULT_MAX_DURATION = TimeUnit.MINUTES.toMillis(8L);
    }
}
