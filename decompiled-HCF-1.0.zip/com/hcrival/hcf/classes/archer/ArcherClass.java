package com.hcrival.hcf.classes.archer;

import com.hcrival.hcf.classes.*;
import gnu.trove.map.*;
import com.hcrival.hcf.*;
import java.util.concurrent.*;
import gnu.trove.map.hash.*;
import com.google.common.collect.*;
import java.util.*;
import org.bukkit.potion.*;
import com.hcrival.hcf.classes.event.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import org.bukkit.entity.*;
import org.bukkit.projectiles.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;
import org.apache.commons.lang3.time.*;
import org.bukkit.inventory.*;

public class ArcherClass extends PvpClass implements Listener
{
    private static final PotionEffect ARCHER_CRITICAL_EFFECT;
    private static final int MARK_TIMEOUT_SECONDS = 15;
    private static final int MARK_EXECUTION_LEVEL = 3;
    private static final double MARK_EXECUTION_DAMAGE_BONUS = 2.0;
    private static final float MINIMUM_FORCE = 0.5f;
    private static final PotionEffect ARCHER_SPEED_EFFECT;
    private static final long ARCHER_SPEED_COOLDOWN_DELAY;
    private final TObjectLongMap<UUID> archerSpeedCooldowns;
    private final Table<UUID, UUID, ArcherMark> marks;
    private final Map<Arrow, Float> arrowForces;
    private final HCF plugin;
    
    public ArcherClass(final HCF plugin) {
        super("Archer", TimeUnit.SECONDS.toMillis(2L));
        this.archerSpeedCooldowns = new TObjectLongHashMap<UUID>();
        this.marks = (Table<UUID, UUID, ArcherMark>)HashBasedTable.create();
        this.arrowForces = new WeakHashMap<Arrow, Float>();
        this.plugin = plugin;
        this.passiveEffects.add(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 1));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0));
        this.passiveEffects.add(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2));
    }
    
    public Map<UUID, ArcherMark> getSentMarks(final Player player) {
        synchronized (this.marks) {
            return this.marks.column(player.getUniqueId());
        }
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerClassUnequip(final PvpClassUnequipEvent event) {
        this.getSentMarks(event.getPlayer()).clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerDeath(final PlayerDeathEvent event) {
        this.getSentMarks(event.getEntity()).clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerQuit(final PlayerQuitEvent event) {
        this.getSentMarks(event.getPlayer()).clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPlayerKick(final PlayerKickEvent event) {
        this.getSentMarks(event.getPlayer()).clear();
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void setArrowForce(final EntityShootBowEvent event) {
        if (!(event.getProjectile() instanceof Arrow)) {
            return;
        }
        this.arrowForces.put((Arrow)event.getProjectile(), event.getForce());
    }
    
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onEntityDamage(final EntityDamageByEntityEvent event) {
        final Entity entity = event.getEntity();
        final Entity damager = event.getDamager();
        if (entity == damager || !(entity instanceof Player) || !(damager instanceof Arrow)) {
            return;
        }
        final Arrow arrow = (Arrow)damager;
        final float force = this.arrowForces.containsKey(arrow) ? this.arrowForces.get(arrow) : -1.0f;
        if (force == -1.0) {
            return;
        }
        final ProjectileSource source = arrow.getShooter();
        if (!(source instanceof Player)) {
            return;
        }
        final Player shooter = (Player)source;
        if (!this.plugin.getPvpClassManager().hasClassEquipped(shooter, this)) {
            return;
        }
        if (force <= 0.5f) {
            shooter.sendMessage(ChatColor.RED + "Mark not applied as arrow was shot with less than " + 0.5f + "% force.");
            return;
        }
        final Player attacked = (Player)entity;
        final UUID attackedUUID = attacked.getUniqueId();
        final Map<UUID, ArcherMark> givenMarks = this.getSentMarks(shooter);
        ArcherMark archerMark = givenMarks.get(attackedUUID);
        if (archerMark != null) {
            archerMark.decrementTask.cancel();
        }
        else {
            givenMarks.put(attackedUUID, archerMark = new ArcherMark());
        }
        final ChatColor enemyColour = ChatColor.valueOf(this.plugin.getConfig().getString("settings.colors.team_mate"));
        final int newLevel = archerMark.incrementMark();
        if (newLevel >= 3) {
            event.setDamage(event.getDamage(EntityDamageEvent.DamageModifier.BASE) + 2.0);
            attacked.addPotionEffect(ArcherClass.ARCHER_CRITICAL_EFFECT);
            this.getSentMarks(shooter).clear();
            archerMark.reset();
            final World world = attacked.getWorld();
            final Location location = attacked.getLocation();
            world.playSound(location, Sound.EXPLODE, 1.0f, 1.0f);
            attacked.sendMessage(ChatColor.GOLD + "Wipeout! " + enemyColour + shooter.getName() + ChatColor.GOLD + " hit you with a level " + ChatColor.WHITE + ChatColor.GOLD + newLevel + " mark.");
            shooter.sendMessage(ChatColor.YELLOW + "Wipeout! Hit " + enemyColour + attacked.getName() + ChatColor.YELLOW + " with a level " + ChatColor.WHITE + newLevel + ChatColor.YELLOW + " mark.");
        }
        else {
            event.setDamage(event.getDamage(EntityDamageEvent.DamageModifier.BASE) + 3.0);
            shooter.sendMessage(ChatColor.YELLOW + "Now have a level " + ChatColor.WHITE + newLevel + ChatColor.YELLOW + " mark on " + enemyColour + attacked.getName() + ChatColor.YELLOW + '.');
            final ArcherMark finalMark = archerMark;
            final long ticks = 300L;
            archerMark.decrementTask = new BukkitRunnable() {
                public void run() {
                    final int newLevel = finalMark.decrementMark();
                    if (newLevel == 0) {
                        attacked.sendMessage(enemyColour + shooter.getName() + ChatColor.YELLOW + "'s mark on you has expired.");
                        shooter.sendMessage(ChatColor.GOLD + "No longer have a mark on " + enemyColour + attacked.getName() + ChatColor.GOLD + '.');
                        ArcherClass.this.getSentMarks(shooter).remove(attacked.getUniqueId());
                        this.cancel();
                    }
                    else {
                        attacked.sendMessage(enemyColour + shooter.getName() + ChatColor.GOLD + "'s mark on you has expired to level " + ChatColor.WHITE + ChatColor.GOLD + newLevel + '.');
                        shooter.sendMessage(ChatColor.YELLOW + "Mark level on " + enemyColour + attacked.getName() + ChatColor.YELLOW + " is now " + ChatColor.WHITE + ChatColor.YELLOW + newLevel + '.');
                    }
                }
            }.runTaskTimer((Plugin)this.plugin, ticks, ticks);
        }
    }
    
    @EventHandler(ignoreCancelled = false, priority = EventPriority.HIGH)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Action action = event.getAction();
        if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) && event.hasItem() && event.getItem().getType() == Material.SUGAR) {
            if (this.plugin.getPvpClassManager().getEquippedClass(event.getPlayer()) != this) {
                return;
            }
            final Player player = event.getPlayer();
            final UUID uuid = player.getUniqueId();
            final long timestamp = this.archerSpeedCooldowns.get(uuid);
            final long millis = System.currentTimeMillis();
            final long remaining = (timestamp == this.archerSpeedCooldowns.getNoEntryValue()) ? -1L : (timestamp - millis);
            if (remaining > 0L) {
                player.sendMessage(ChatColor.RED + "Cannot use " + this.getName() + " speed for another " + DurationFormatUtils.formatDurationWords(remaining, true, true) + ".");
            }
            else {
                final ItemStack stack = player.getItemInHand();
                if (stack.getAmount() == 1) {
                    player.setItemInHand(new ItemStack(Material.AIR, 1));
                }
                else {
                    stack.setAmount(stack.getAmount() - 1);
                }
                this.plugin.getEffectRestorer().setRestoreEffect(player, ArcherClass.ARCHER_SPEED_EFFECT);
                this.archerSpeedCooldowns.put(event.getPlayer().getUniqueId(), System.currentTimeMillis() + ArcherClass.ARCHER_SPEED_COOLDOWN_DELAY);
            }
        }
    }
    
    @Override
    public boolean isApplicableFor(final Player player) {
        final PlayerInventory playerInventory = player.getInventory();
        final ItemStack helmet = playerInventory.getHelmet();
        if (helmet == null || helmet.getType() != Material.LEATHER_HELMET) {
            return false;
        }
        final ItemStack chestplate = playerInventory.getChestplate();
        if (chestplate == null || chestplate.getType() != Material.LEATHER_CHESTPLATE) {
            return false;
        }
        final ItemStack leggings = playerInventory.getLeggings();
        if (leggings == null || leggings.getType() != Material.LEATHER_LEGGINGS) {
            return false;
        }
        final ItemStack boots = playerInventory.getBoots();
        return boots != null && boots.getType() == Material.LEATHER_BOOTS;
    }
    
    static {
        ARCHER_CRITICAL_EFFECT = new PotionEffect(PotionEffectType.WITHER, 60, 0);
        ARCHER_SPEED_EFFECT = new PotionEffect(PotionEffectType.SPEED, 160, 3);
        ARCHER_SPEED_COOLDOWN_DELAY = TimeUnit.MINUTES.toMillis(1L);
    }
}
