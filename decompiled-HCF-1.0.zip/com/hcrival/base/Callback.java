package com.hcrival.base;

public interface Callback<V>
{
    void done(final V p0, final Throwable p1);
}
