package com.hcrival.util.chat;

import java.util.*;
import java.net.*;
import java.nio.charset.*;
import java.io.*;

public class HttpMojangLang extends MojangLang
{
    private static final String HASH_17 = "03f31164d234f10a3230611656332f1756e570a9";
    
    @Override
    public void index(final String minecraftVersion, final Locale locale) throws IllegalArgumentException, IOException {
        super.index(minecraftVersion, locale);
        if ("03f31164d234f10a3230611656332f1756e570a9".length() < 2) {
            return;
        }
        final String url = "http://resources.download.minecraft.net/" + "03f31164d234f10a3230611656332f1756e570a9".substring(0, 2) + "/" + "03f31164d234f10a3230611656332f1756e570a9";
        try (final BufferedReader reader = new BufferedReader(new InputStreamReader(new URL(url).openStream(), StandardCharsets.UTF_8))) {
            this.finallyIndex(locale, reader);
        }
    }
}
