package com.hcrival.util.chat;

import java.util.*;
import javax.annotation.*;
import java.io.*;
import com.google.common.collect.*;
import org.bukkit.inventory.*;
import org.bukkit.craftbukkit.v1_7_R4.inventory.*;
import net.minecraft.server.v1_7_R4.*;
import com.google.common.base.*;
import org.bukkit.enchantments.*;
import com.hcrival.base.*;
import org.bukkit.potion.*;
import org.bukkit.craftbukkit.v1_7_R4.potion.*;

public abstract class MojangLang
{
    protected static final Locale DEFAULT_LOCALE;
    protected static final Splitter SPLITTER;
    protected final Table<Locale, String, String> translations;
    
    public MojangLang() {
        this.translations = (Table<Locale, String, String>)HashBasedTable.create();
    }
    
    public void index(final String minecraftVersion, @Nullable Locale locale) throws IllegalArgumentException, IOException {
        if (locale == null) {
            locale = Locale.ENGLISH;
        }
        Preconditions.checkArgument(!this.translations.contains(locale, minecraftVersion), (Object)("Already indexed Minecraft version '" + minecraftVersion + "' for locale '" + locale.toLanguageTag() + "'."));
    }
    
    void finallyIndex(final Locale locale, final BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains("=")) {
                final Iterable<String> iterable = MojangLang.SPLITTER.split(line.trim());
                if (Iterables.size(iterable) != 2) {
                    continue;
                }
                this.translations.put(locale, Iterables.get(iterable, 0), Iterables.get(iterable, 1));
            }
        }
    }
    
    public String translate(final Locale locale, final String key, final Object... args) {
        Preconditions.checkArgument(this.translations.containsRow(locale), (Object)("Translations for locale " + locale.toLanguageTag() + " not initialised, use #index(String, Locale) to index"));
        return String.format(this.translations.get(locale, key), args);
    }
    
    public String translatableFromStack(final ItemStack stack) {
        final net.minecraft.server.v1_7_R4.ItemStack nms = CraftItemStack.asNMSCopy(stack);
        final Item item = nms.getItem();
        return item.a(nms) + ".name";
    }
    
    public String fromStack(final ItemStack stack) {
        final String node = this.translatableFromStack(stack);
        return MoreObjects.firstNonNull(this.translations.get(MojangLang.DEFAULT_LOCALE, node), node);
    }
    
    public String translatableFromEnchantment(final Enchantment enchantment) {
        final net.minecraft.server.v1_7_R4.Enchantment nms = net.minecraft.server.v1_7_R4.Enchantment.byId[enchantment.getId()];
        return (nms == null) ? enchantment.getName() : nms.a();
    }
    
    public String fromEnchantment(final Enchantment enchantment) {
        final String node = this.translatableFromEnchantment(enchantment);
        return GuavaCompat.firstNonNull(this.translations.get(MojangLang.DEFAULT_LOCALE, node), node);
    }
    
    public static String translatableFromPotionEffectType(final PotionEffectType effectType) {
        final CraftPotionEffectType craftType = (CraftPotionEffectType)PotionEffectType.getById(effectType.getId());
        return craftType.getHandle().a();
    }
    
    public String fromPotionEffectType(final PotionEffectType effectType) {
        final String node = translatableFromPotionEffectType(effectType);
        final String val = this.translations.get(MojangLang.DEFAULT_LOCALE, node);
        return (val == null) ? node : val;
    }
    
    public String translate(final String key, final Object... args) {
        return String.format(this.translations.get(MojangLang.DEFAULT_LOCALE, key), args);
    }
    
    static {
        DEFAULT_LOCALE = Locale.ENGLISH;
        SPLITTER = Splitter.on('=');
    }
}
