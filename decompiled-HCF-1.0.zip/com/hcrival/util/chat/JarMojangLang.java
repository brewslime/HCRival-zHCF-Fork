package com.hcrival.util.chat;

import java.util.*;
import net.minecraft.server.v1_7_R4.*;
import java.nio.charset.*;
import java.io.*;

public class JarMojangLang extends MojangLang
{
    @Override
    public void index(final String minecraftVersion, final Locale locale) throws IllegalArgumentException, IOException {
        super.index(minecraftVersion, locale);
        try (final InputStream stream = Item.class.getResourceAsStream("/assets/minecraft/lang/" + locale.toLanguageTag() + ".lang");
             final BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            this.finallyIndex(locale, reader);
        }
    }
}
