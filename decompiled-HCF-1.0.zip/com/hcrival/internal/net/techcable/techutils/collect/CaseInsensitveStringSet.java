package com.hcrival.internal.net.techcable.techutils.collect;

import com.google.common.collect.*;
import java.util.*;

public class CaseInsensitveStringSet extends ForwardingSet<String>
{
    private final CaseInsensitiveStringMap<Object> backing;
    public static final Object VALUE;
    
    public CaseInsensitveStringSet() {
        this.backing = new CaseInsensitiveStringMap<Object>();
    }
    
    @Override
    protected Set<String> delegate() {
        return this.backing.keySet();
    }
    
    @Override
    public boolean add(final String element) {
        try {
            this.backing.put(element, CaseInsensitveStringSet.VALUE);
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }
    
    @Override
    public boolean addAll(final Collection<? extends String> collection) {
        return this.standardAddAll(collection);
    }
    
    static {
        VALUE = new Object();
    }
}
