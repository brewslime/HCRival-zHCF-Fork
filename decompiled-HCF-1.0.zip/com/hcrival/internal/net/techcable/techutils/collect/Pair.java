package com.hcrival.internal.net.techcable.techutils.collect;

import java.beans.*;

public class Pair<T, U>
{
    private T first;
    private U second;
    
    @ConstructorProperties({ "first", "second" })
    public Pair(final T first, final U second) {
        this.first = first;
        this.second = second;
    }
    
    public T getFirst() {
        return this.first;
    }
    
    public U getSecond() {
        return this.second;
    }
    
    public void setFirst(final T first) {
        this.first = first;
    }
    
    public void setSecond(final U second) {
        this.second = second;
    }
}
