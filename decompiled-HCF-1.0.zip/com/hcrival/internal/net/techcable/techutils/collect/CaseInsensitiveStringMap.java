package com.hcrival.internal.net.techcable.techutils.collect;

import com.google.common.collect.*;
import java.util.concurrent.*;
import java.util.*;

public class CaseInsensitiveStringMap<V> extends ForwardingMap<String, V>
{
    private final ConcurrentHashMap<String, V> delegate;
    
    public CaseInsensitiveStringMap() {
        this.delegate = new ConcurrentHashMap<String, V>();
    }
    
    @Override
    protected Map<String, V> delegate() {
        return this.delegate;
    }
    
    @Override
    public V remove(Object key) {
        if (key instanceof String) {
            key = ((String)key).toLowerCase();
        }
        return this.delegate().remove(key);
    }
    
    @Override
    public V get(Object key) {
        if (key instanceof String) {
            key = ((String)key).toLowerCase();
        }
        return this.delegate().get(key);
    }
    
    @Override
    public V put(String key, final V value) {
        key = key.toLowerCase();
        return this.delegate().put(key, value);
    }
    
    @Override
    public void putAll(final Map<? extends String, ? extends V> map) {
        this.standardPutAll(map);
    }
    
    @Override
    public boolean containsKey(Object key) {
        if (key instanceof String) {
            key = ((String)key).toLowerCase();
        }
        return this.delegate().containsKey(key);
    }
}
