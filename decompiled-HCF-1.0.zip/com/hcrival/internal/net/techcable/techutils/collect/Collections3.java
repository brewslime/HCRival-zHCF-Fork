package com.hcrival.internal.net.techcable.techutils.collect;

import com.google.common.base.*;
import com.google.common.collect.*;
import java.util.*;
import java.util.concurrent.*;

public class Collections3
{
    public static <E> Set<E> newConcurrentHashSet() {
        return Sets.newSetFromMap(new ConcurrentHashMap<E, Boolean>());
    }
    
    public static <K, V> SetMultimap<K, V> newConcurrentMultimap() {
        return Multimaps.newSetMultimap(new ConcurrentHashMap<K, Collection<V>>(), new Supplier<Set<V>>() {
            @Override
            public Set<V> get() {
                return Collections3.newConcurrentHashSet();
            }
        });
    }
    
    public static <K, V> ListMultimap<K, V> newCopyOnWritetListMultimap() {
        return Multimaps.newListMultimap(new ConcurrentHashMap<K, Collection<V>>(), new Supplier<List<V>>() {
            @Override
            public List<V> get() {
                return new CopyOnWriteArrayList<V>();
            }
        });
    }
    
    private Collections3() {
    }
}
