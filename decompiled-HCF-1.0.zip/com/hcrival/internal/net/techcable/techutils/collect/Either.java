package com.hcrival.internal.net.techcable.techutils.collect;

public final class Either<T, U>
{
    private T first;
    private U second;
    
    public static <T, U> Either<T, U> ofFirst(final T first) {
        return new Either<T, U>(first, null);
    }
    
    public static <T, U> Either<T, U> ofSecond(final U second) {
        return new Either<T, U>(null, second);
    }
    
    public T getFirst() {
        return this.first;
    }
    
    public U getSecond() {
        return this.second;
    }
    
    public boolean hasFirst() {
        return this.first != null;
    }
    
    public boolean hasSecond() {
        return this.second != null;
    }
    
    private Either(final T first, final U second) {
        this.first = first;
        this.second = second;
    }
}
