package com.hcrival.internal.net.techcable.techutils.collect;

import com.google.common.collect.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.hcrival.internal.net.techcable.techutils.uuid.*;
import com.hcrival.internal.net.techcable.techutils.entity.*;
import java.util.*;

public class PlayerMap<V> extends ForwardingMap<Player, V>
{
    private WeakHashMap<Player, V> delegate;
    
    public PlayerMap() {
        this.delegate = new WeakHashMap<Player, V>();
    }
    
    public V get(final UUID id) {
        return this.get(Bukkit.getPlayer(id));
    }
    
    public V get(final String name) {
        return this.get(UUIDUtils.getPlayerExact(name));
    }
    
    public V get(final TechPlayer p) {
        return this.get(p.getId());
    }
    
    @Override
    protected Map<Player, V> delegate() {
        return this.delegate;
    }
}
