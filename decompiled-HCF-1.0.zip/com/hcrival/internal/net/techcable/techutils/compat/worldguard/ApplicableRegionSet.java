package com.hcrival.internal.net.techcable.techutils.compat.worldguard;

public interface ApplicableRegionSet
{
    boolean hasPvp();
}
