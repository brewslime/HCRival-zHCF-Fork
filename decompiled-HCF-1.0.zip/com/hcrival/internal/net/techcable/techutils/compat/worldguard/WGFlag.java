package com.hcrival.internal.net.techcable.techutils.compat.worldguard;

public enum WGFlag
{
}
