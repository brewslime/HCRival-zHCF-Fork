package com.hcrival.internal.net.techcable.techutils.compat.worldguard;

import org.bukkit.plugin.*;
import com.hcrival.internal.net.techcable.techutils.*;
import org.bukkit.*;

public class WorldGuardReflection
{
    public static Class<? extends Plugin> PLUGIN_CLASS;
    public static Class<?> REGION_MANAGER_CLASS;
    public static Class<?> DEFAULT_FLAG_CLASS;
    public static Class<?> APPLICABLE_REGION_SET_CLASS;
    public static Class<?> STATE_FLAG_CLASS;
    private static Object PVP_FLAG;
    
    public static Plugin getPlugin() {
        return Bukkit.getPluginManager().getPlugin("WorldGuard");
    }
    
    public static RegionManager getRegionManager(final World world) {
        final Object regionHandle = Reflection.callMethod(Reflection.makeMethod(WorldGuardReflection.PLUGIN_CLASS, "getRegionManager", World.class), getPlugin(), world);
        return new RegionManager() {
            @Override
            public ApplicableRegionSet getApplicableRegionSet(final Location loc) {
                final Object regionSetHandle = Reflection.callMethod(Reflection.makeMethod(WorldGuardReflection.REGION_MANAGER_CLASS, "getApplicableRegions", Location.class), regionHandle, loc);
                return new ApplicableRegionSet() {
                    @Override
                    public boolean hasPvp() {
                        return Reflection.callMethod(Reflection.makeMethod(WorldGuardReflection.APPLICABLE_REGION_SET_CLASS, "allows", WorldGuardReflection.STATE_FLAG_CLASS), regionSetHandle, WorldGuardReflection.PVP_FLAG);
                    }
                };
            }
        };
    }
    
    public static boolean isSupported() {
        if (WorldGuardReflection.PLUGIN_CLASS != null) {}
        final Plugin plugin = Bukkit.getPluginManager().getPlugin("WorldGuard");
        return plugin != null && WorldGuardReflection.PLUGIN_CLASS.isInstance(plugin);
    }
    
    static {
        WorldGuardReflection.PLUGIN_CLASS = Reflection.getClass("com.sk89q.worldguard.bukkit.WorldGuardPlugin", Plugin.class);
        WorldGuardReflection.REGION_MANAGER_CLASS = Reflection.getClass("com.sk89q.worldguard.protection.managers.RegionManager");
        WorldGuardReflection.DEFAULT_FLAG_CLASS = Reflection.getClass("com.sk89q.worldguard.protection.flags.DefaultFlag");
        WorldGuardReflection.APPLICABLE_REGION_SET_CLASS = Reflection.getClass("import com.sk89q.worldguard.protection.ApplicableRegionSet");
        WorldGuardReflection.STATE_FLAG_CLASS = Reflection.getClass("com.sk89q.worldguard.protection.flags.StateFlag");
        WorldGuardReflection.PVP_FLAG = Reflection.callMethod(Reflection.makeMethod(WorldGuardReflection.DEFAULT_FLAG_CLASS, "valueOf", String.class), null, "PVP");
    }
}
