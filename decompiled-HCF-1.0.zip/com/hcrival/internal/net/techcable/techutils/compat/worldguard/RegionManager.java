package com.hcrival.internal.net.techcable.techutils.compat.worldguard;

import org.bukkit.*;

public interface RegionManager
{
    ApplicableRegionSet getApplicableRegionSet(final Location p0);
}
