package com.hcrival.internal.net.techcable.techutils.ui;

import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.packet.*;
import com.hcrival.internal.net.techcable.techutils.entity.fake.*;
import com.hcrival.internal.net.techcable.techutils.scheduler.*;
import org.bukkit.*;
import java.util.*;

public class BossBar implements Runnable
{
    private static final Map<Player, BossBar> bars;
    private final Player player;
    private final FakeEntity entity;
    
    private BossBar(final Player p) {
        this.player = p;
        final int version = Packet.getProtocolVersion(p);
        if (version > 5) {
            this.entity = new FakeWither(p);
        }
        else {
            this.entity = new FakeDragon(p);
        }
        TechScheduler.scheduleSyncTask(this, 0L, 3L);
    }
    
    public static BossBar getBossBar(final Player player) {
        if (!BossBar.bars.containsKey(player)) {
            BossBar.bars.put(player, new BossBar(player));
        }
        return BossBar.bars.get(player);
    }
    
    public void setMessage(final String message) {
        this.entity.setCustomName((message.length() <= 64) ? message : message.substring(0, 63));
        if (this.isShown()) {
            this.entity.update();
        }
        this.trySpawn();
    }
    
    public void setPercentage(int percent) {
        percent = Math.max(Math.min(100, percent), 0);
        this.entity.setHealth(percent / 100.0f * this.entity.getMaxHealth());
        if (this.isShown()) {
            this.entity.update();
        }
        this.trySpawn();
    }
    
    public void stopShowing() {
        if (this.entity.isSpawned()) {
            this.entity.despawn();
        }
    }
    
    public boolean isShown() {
        return this.entity.isSpawned();
    }
    
    private void trySpawn() {
        if (this.entity.isSpawned()) {
            return;
        }
        this.entity.setInvisible(true);
        this.entity.setHealth(this.entity.getMaxHealth());
        this.entity.spawn(this.calculateLoc());
    }
    
    @Override
    public void run() {
        if (!this.entity.isSpawned()) {
            return;
        }
        this.entity.move(this.calculateLoc());
    }
    
    private Location calculateLoc() {
        if (Packet.getProtocolVersion(this.player) >= 47) {
            return this.player.getLocation().add(this.player.getEyeLocation().getDirection().multiply(20));
        }
        return this.player.getLocation().add(0.0, -300.0, 0.0);
    }
    
    static {
        bars = new WeakHashMap<Player, BossBar>();
    }
}
