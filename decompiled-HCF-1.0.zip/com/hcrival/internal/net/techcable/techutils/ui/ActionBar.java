package com.hcrival.internal.net.techcable.techutils.ui;

import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;

public class ActionBar
{
    private final String text;
    private static ActionBarHandler handler;
    private static final Field playerConnectionField;
    private static final Method sendPacketMethod;
    private static final Method addSiblingMethod;
    private static final Method fromStringMethod;
    
    public ActionBar(final String text) {
        this.text = text;
    }
    
    public void sendTo(final Player p) {
        final ActionBarHandler handler = getActionBarHandler();
        if (handler == null) {
            return;
        }
        handler.sendTo(p, this);
    }
    
    private static ActionBarHandler getActionBarHandler() {
        if (ActionBar.handler != null) {
            return ActionBar.handler;
        }
        if (SpigotActionBarHandler.isSupported()) {
            ActionBar.handler = new SpigotActionBarHandler();
        }
        else {
            if (!NMSActionBarHandler.isSupported()) {
                return null;
            }
            ActionBar.handler = new NMSActionBarHandler();
        }
        return ActionBar.handler;
    }
    
    private static void sendPacket(final Player player, final Object packet) {
        final Object handle = Reflection.getHandle(player);
        final Object connection = Reflection.getField(ActionBar.playerConnectionField, handle);
        Reflection.callMethod(ActionBar.sendPacketMethod, connection, packet);
    }
    
    private static Object serialize(final String text) {
        final Object baseComponentArray = Reflection.callMethod(ActionBar.fromStringMethod, null, text);
        Object first = null;
        for (int i = 0; i < Array.getLength(baseComponentArray); ++i) {
            final Object baseComponent = Array.get(baseComponentArray, i);
            if (first == null) {
                first = baseComponent;
            }
            else {
                first = Reflection.callMethod(ActionBar.addSiblingMethod, first, baseComponent);
            }
        }
        return first;
    }
    
    public String getText() {
        return this.text;
    }
    
    static {
        playerConnectionField = Reflection.makeField(Reflection.getNmsClass("EntityPlayer"), "playerConnection");
        sendPacketMethod = Reflection.makeMethod(Reflection.getNmsClass("PlayerConnection"), "sendPacket", Reflection.getNmsClass("Packet"));
        addSiblingMethod = Reflection.makeMethod(Reflection.getNmsClass("IChatBaseComponent"), "addSibling", Reflection.getNmsClass("IChatBaseComponent"));
        fromStringMethod = Reflection.makeMethod(Reflection.getCbClass("util.CraftChatMessage"), "fromString", String.class);
    }
    
    private static class SpigotActionBarHandler implements ActionBarHandler
    {
        private static final Constructor packetConstructor;
        private static final Field playerConnectionField;
        private static final Field networkManagerField;
        private static final Method getVersion;
        
        private SpigotActionBarHandler() {
            assert isSupported() : "Spigot action bar is unsupported!";
        }
        
        @Override
        public void sendTo(final Player p, final ActionBar bar) {
            if (getProtocolVersion(p) < 16) {
                return;
            }
            final Object baseComponent = serialize(bar.getText());
            final Object packet = Reflection.callConstructor((Constructor<Object>)SpigotActionBarHandler.packetConstructor, baseComponent, 2);
            sendPacket(p, packet);
        }
        
        private static int getProtocolVersion(final Player player) {
            final Object handle = Reflection.getHandle(player);
            final Object connection = Reflection.getField(SpigotActionBarHandler.playerConnectionField, handle);
            final Object networkManager = Reflection.getField(SpigotActionBarHandler.networkManagerField, connection);
            assert Reflection.getVersion() != null : "Not Protocol Hack";
            final int version = Reflection.callMethod(SpigotActionBarHandler.getVersion, networkManager, new Object[0]);
            return version;
        }
        
        public static boolean isSupported() {
            return Reflection.getClass("org.spigotmc.ProtocolData") != null;
        }
        
        static {
            packetConstructor = Reflection.makeConstructor(Reflection.getNmsClass("PacketPlayOutChat"), Reflection.getNmsClass("IChatBaseComponent"), Integer.TYPE);
            playerConnectionField = Reflection.makeField(Reflection.getNmsClass("EntityPlayer"), "playerConnection");
            networkManagerField = Reflection.makeField(Reflection.getNmsClass("PlayerConnection"), "networkManager");
            getVersion = Reflection.makeMethod(Reflection.getNmsClass("NetworkManager"), "getVersion", (Class<?>[])new Class[0]);
        }
    }
    
    private static class NMSActionBarHandler implements ActionBarHandler
    {
        private static final Constructor packetConstructor;
        
        private NMSActionBarHandler() {
            assert !SpigotActionBarHandler.isSupported() : "Spigot action bar is supported";
            assert isSupported() : "NMS Action bar isn't supported";
        }
        
        @Override
        public void sendTo(final Player p, final ActionBar bar) {
            final Object baseComponent = serialize(bar.getText());
            final Object packet = Reflection.callConstructor((Constructor<Object>)NMSActionBarHandler.packetConstructor, baseComponent, 2);
            sendPacket(p, packet);
        }
        
        public static boolean isSupported() {
            return NMSActionBarHandler.packetConstructor != null;
        }
        
        static {
            packetConstructor = Reflection.makeConstructor(Reflection.getNmsClass("PacketPlayOutChat"), Reflection.getNmsClass("IChatBaseComponent"), Integer.TYPE);
        }
    }
    
    private interface ActionBarHandler
    {
        void sendTo(final Player p0, final ActionBar p1);
    }
}
