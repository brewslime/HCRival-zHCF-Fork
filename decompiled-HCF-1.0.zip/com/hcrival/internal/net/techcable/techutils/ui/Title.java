package com.hcrival.internal.net.techcable.techutils.ui;

import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.packet.*;
import java.beans.*;

public class Title
{
    private String title;
    private String subtitle;
    private int fadeIn;
    private int stay;
    private int fadeOut;
    
    public Title(final String title, final String subtitle) {
        this.fadeIn = 20;
        this.stay = 200;
        this.fadeOut = 20;
        this.setTitle(title);
        this.setSubtitle(subtitle);
    }
    
    public void sendTo(final Player... players) {
        for (final Player player : players) {
            PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.RESET).sendTo(player);
            boolean shouldSend = false;
            if (this.title != null && !this.title.isEmpty()) {
                PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.SET_TITLE, this.getTitle()).sendTo(player);
                shouldSend = true;
            }
            if (this.subtitle != null && !this.subtitle.isEmpty()) {
                PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.SET_SUBTITLE, this.getSubtitle()).sendTo(player);
                shouldSend = false;
            }
            if (shouldSend) {
                PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.DISPLAY, this.getFadeIn(), this.getStay(), this.getFadeOut()).sendTo(player);
            }
        }
    }
    
    public void hide(final Player p) {
        PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.HIDE).sendTo(p);
    }
    
    public static void unHide(final Player p) {
        PacketPlayOutTitle.create(PacketPlayOutTitle.TitleAction.DISPLAY, 20, 100, 20);
    }
    
    @ConstructorProperties({ "title", "subtitle", "fadeIn", "stay", "fadeOut" })
    public Title(final String title, final String subtitle, final int fadeIn, final int stay, final int fadeOut) {
        this.fadeIn = 20;
        this.stay = 200;
        this.fadeOut = 20;
        this.title = title;
        this.subtitle = subtitle;
        this.fadeIn = fadeIn;
        this.stay = stay;
        this.fadeOut = fadeOut;
    }
    
    public Title() {
        this.fadeIn = 20;
        this.stay = 200;
        this.fadeOut = 20;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public String getSubtitle() {
        return this.subtitle;
    }
    
    public int getFadeIn() {
        return this.fadeIn;
    }
    
    public int getStay() {
        return this.stay;
    }
    
    public int getFadeOut() {
        return this.fadeOut;
    }
    
    public void setTitle(final String title) {
        this.title = title;
    }
    
    public void setSubtitle(final String subtitle) {
        this.subtitle = subtitle;
    }
    
    public void setFadeIn(final int fadeIn) {
        this.fadeIn = fadeIn;
    }
    
    public void setStay(final int stay) {
        this.stay = stay;
    }
    
    public void setFadeOut(final int fadeOut) {
        this.fadeOut = fadeOut;
    }
}
