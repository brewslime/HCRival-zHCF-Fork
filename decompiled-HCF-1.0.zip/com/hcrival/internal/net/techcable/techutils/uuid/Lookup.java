package com.hcrival.internal.net.techcable.techutils.uuid;

import java.util.*;

public interface Lookup
{
    PlayerProfile lookup(final String p0);
    
    Collection<PlayerProfile> lookup(final Collection<String> p0);
    
    PlayerProfile lookup(final UUID p0);
    
    void lookupProperties(final PlayerProfile p0);
}
