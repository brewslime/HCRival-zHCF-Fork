package com.hcrival.internal.net.techcable.techutils.uuid;

import com.hcrival.internal.net.techcable.techutils.*;
import java.util.*;
import org.json.simple.*;

public class MCPlayerIndexLookup implements Lookup
{
    @Override
    public PlayerProfile lookup(final String name) {
        final JSONObject json = (JSONObject)HttpUtils.getJson("http://api.mcplayerindex.com/uuid/" + name);
        return this.deserializeProfile(json);
    }
    
    @Override
    public Collection<PlayerProfile> lookup(final Collection<String> names) {
        final Set<PlayerProfile> profiles = new HashSet<PlayerProfile>();
        for (final String name : names) {
            final PlayerProfile profile = this.lookup(name);
            if (profile == null) {
                continue;
            }
            profiles.add(profile);
        }
        return profiles;
    }
    
    @Override
    public PlayerProfile lookup(final UUID id) {
        return this.lookupProperties(id);
    }
    
    @Override
    public void lookupProperties(final PlayerProfile profile) {
        if (profile.getProperties() != null) {
            return;
        }
        final JSONArray properties = this.lookupProperties(profile.getId()).getProperties();
        profile.setProperties(properties);
    }
    
    private PlayerProfile lookupProperties(final UUID id) {
        final JSONObject json = (JSONObject)HttpUtils.getJson("http://api.mcplayerindex.com/raw/" + id.toString());
        return this.deserializeProfile(json);
    }
    
    private PlayerProfile deserializeProfile(final JSONObject json) {
        if (!json.containsKey((Object)"name") || !json.containsKey((Object)"id")) {
            return null;
        }
        if (!(json.get((Object)"name") instanceof String) || !(json.get((Object)"id") instanceof String)) {
            return null;
        }
        final String name = (String)json.get((Object)"name");
        final UUID id = toUUID((String)json.get((Object)"id"));
        if (id == null) {
            return null;
        }
        final PlayerProfile profile = new PlayerProfile(id, name);
        if (json.containsKey((Object)"properties") && json.get((Object)"properties") instanceof JSONArray) {
            profile.setProperties((JSONArray)json.get((Object)"properties"));
        }
        return profile;
    }
    
    private static String toString(final UUID id) {
        return id.toString().replace("-", "");
    }
    
    private static UUID toUUID(String s) {
        if (s.length() == 32) {
            s = s.substring(0, 8) + "-" + s.substring(8, 12) + "-" + s.substring(12, 16) + "-" + s.substring(16, 20) + "-" + s.substring(20, 32);
        }
        return UUID.fromString(s);
    }
}
