package com.hcrival.internal.net.techcable.techutils.uuid;

import org.json.simple.*;
import com.google.common.collect.*;
import java.beans.*;
import java.util.*;
import java.lang.ref.*;

public class CachingLookup implements Lookup
{
    private final Lookup backing;
    private final Cache<UUID, PlayerProfile> idCache;
    private final Cache<String, PlayerProfile> nameCache;
    private final Cache<PlayerProfile, JSONArray> propertyCache;
    
    @Override
    public PlayerProfile lookup(final String name) {
        final Iterator<PlayerProfile> iterator = this.lookup(Lists.newArrayList(name)).iterator();
        return iterator.hasNext() ? iterator.next() : null;
    }
    
    @Override
    public Collection<PlayerProfile> lookup(final Collection<String> names) {
        final Set<PlayerProfile> profiles = new HashSet<PlayerProfile>();
        final Set<String> toLookup = new HashSet<String>();
        for (final String name : names) {
            if (this.nameCache.contains(name)) {
                profiles.add(this.nameCache.get(name));
            }
            else {
                toLookup.add(name);
            }
        }
        for (final PlayerProfile profile : this.backing.lookup(toLookup)) {
            this.addToCache(profile);
            profiles.add(profile);
        }
        return profiles;
    }
    
    @Override
    public PlayerProfile lookup(final UUID id) {
        if (this.idCache.contains(id)) {
            return this.idCache.get(id);
        }
        final PlayerProfile profile = this.backing.lookup(id);
        if (profile == null) {
            return null;
        }
        this.addToCache(profile);
        return profile;
    }
    
    @Override
    public void lookupProperties(final PlayerProfile profile) {
        if (profile == null) {
            return;
        }
        if (profile.getProperties() != null) {
            return;
        }
        if (this.propertyCache.contains(profile)) {
            final JSONArray properties = this.propertyCache.get(profile);
            profile.setProperties(properties);
        }
        this.backing.lookupProperties(profile);
        this.addToCache(profile);
    }
    
    public void addToCache(final PlayerProfile profile) {
        this.nameCache.put(profile.getName(), profile);
        this.idCache.put(profile.getId(), profile);
        if (profile.getProperties() != null) {
            this.propertyCache.put(profile, profile.getProperties());
        }
    }
    
    public PlayerProfile getIfCached(final String name) {
        if (!this.nameCache.contains(name)) {
            return null;
        }
        return this.nameCache.get(name);
    }
    
    public PlayerProfile getIfCached(final UUID id) {
        if (!this.idCache.contains(id)) {
            return null;
        }
        return this.idCache.get(id);
    }
    
    @ConstructorProperties({ "backing" })
    public CachingLookup(final Lookup backing) {
        this.idCache = new Cache<UUID, PlayerProfile>();
        this.nameCache = new Cache<String, PlayerProfile>();
        this.propertyCache = new Cache<PlayerProfile, JSONArray>();
        this.backing = backing;
    }
    
    private static class Cache<K, V>
    {
        private long expireTime;
        private Map<K, CachedEntry<V>> map;
        
        private Cache() {
            this.expireTime = 300000L;
            this.map = new HashMap<K, CachedEntry<V>>();
        }
        
        public boolean contains(final K key) {
            return this.map.containsKey(key) && this.get(key) != null;
        }
        
        public V get(final K key) {
            final CachedEntry<V> entry = this.map.get(key);
            if (entry == null) {
                return null;
            }
            if (entry.isExpired()) {
                this.map.remove(key);
                return null;
            }
            return entry.getValue();
        }
        
        public void put(final K key, final V value) {
            this.map.put(key, new CachedEntry<V>(value, this.expireTime));
        }
        
        private static class CachedEntry<V>
        {
            private final SoftReference<V> value;
            private final long expires;
            
            public CachedEntry(final V value, final long expireTime) {
                this.value = new SoftReference<V>(value);
                this.expires = expireTime + System.currentTimeMillis();
            }
            
            public V getValue() {
                if (this.isExpired()) {
                    return null;
                }
                return this.value.get();
            }
            
            public boolean isExpired() {
                return this.value.get() == null || (this.expires != -1L && this.expires > System.currentTimeMillis());
            }
        }
    }
}
