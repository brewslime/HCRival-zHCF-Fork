package com.hcrival.internal.net.techcable.techutils.uuid;

import com.google.common.collect.*;
import java.util.*;
import java.beans.*;

public class BackupLookup implements Lookup
{
    private final Lookup primary;
    private final Lookup backup;
    private boolean treatNullsAsError;
    
    @Override
    public PlayerProfile lookup(final String name) {
        PlayerProfile profile = null;
        try {
            profile = this.primary.lookup(name);
            if (!this.treatNullsAsError && profile == null) {
                return profile;
            }
        }
        catch (Throwable t) {}
        if (profile == null) {
            profile = this.backup.lookup(name);
        }
        return profile;
    }
    
    @Override
    public Collection<PlayerProfile> lookup(final Collection<String> names) {
        final Set<String> failures = (Set<String>)Sets.newHashSet((Iterable<?>)names);
        boolean errored = false;
        Collection<PlayerProfile> results;
        try {
            results = this.primary.lookup(names);
        }
        catch (Throwable t) {
            errored = true;
            results = new HashSet<PlayerProfile>();
        }
        for (final PlayerProfile result : results) {
            failures.remove(result.getName());
        }
        if (errored || (!failures.isEmpty() && this.treatNullsAsError)) {
            results.addAll(this.backup.lookup(failures));
        }
        return results;
    }
    
    @Override
    public PlayerProfile lookup(final UUID id) {
        PlayerProfile profile = null;
        try {
            profile = this.primary.lookup(id);
            if (!this.treatNullsAsError && profile == null) {
                return profile;
            }
        }
        catch (Throwable t) {}
        if (profile == null) {
            profile = this.backup.lookup(id);
        }
        return profile;
    }
    
    @Override
    public void lookupProperties(final PlayerProfile profile) {
        if (profile.getProperties() != null) {
            return;
        }
        boolean errored = false;
        try {
            this.primary.lookupProperties(profile);
        }
        catch (Throwable t) {
            errored = true;
        }
        if (errored || (profile.getProperties() == null && this.treatNullsAsError)) {
            this.backup.lookupProperties(profile);
        }
    }
    
    @ConstructorProperties({ "primary", "backup" })
    public BackupLookup(final Lookup primary, final Lookup backup) {
        this.treatNullsAsError = true;
        this.primary = primary;
        this.backup = backup;
    }
    
    @ConstructorProperties({ "primary", "backup", "treatNullsAsError" })
    public BackupLookup(final Lookup primary, final Lookup backup, final boolean treatNullsAsError) {
        this.treatNullsAsError = true;
        this.primary = primary;
        this.backup = backup;
        this.treatNullsAsError = treatNullsAsError;
    }
}
