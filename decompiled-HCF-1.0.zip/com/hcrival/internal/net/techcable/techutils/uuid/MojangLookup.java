package com.hcrival.internal.net.techcable.techutils.uuid;

import com.hcrival.internal.net.techcable.techutils.*;
import org.json.simple.*;
import java.util.*;
import com.google.common.collect.*;

public class MojangLookup implements Lookup
{
    private List<PlayerProfile> postNames(final Collection<String> names) {
        final JSONArray request = new JSONArray();
        for (final String name : names) {
            request.add((Object)name);
        }
        final Object rawResponse = HttpUtils.postJson("https://api.mojang.com/profiles/minecraft", request);
        if (!(rawResponse instanceof JSONArray)) {
            return null;
        }
        final JSONArray response = (JSONArray)rawResponse;
        final List<PlayerProfile> profiles = new ArrayList<PlayerProfile>();
        for (final Object rawEntry : response) {
            if (!(rawEntry instanceof JSONObject)) {
                return null;
            }
            final JSONObject entry = (JSONObject)rawEntry;
            final PlayerProfile profile = this.deserializeProfile(entry);
            if (profile == null) {
                continue;
            }
            profiles.add(profile);
        }
        return profiles;
    }
    
    private PlayerProfile lookupProperties(final UUID id) {
        final Object rawResponse = HttpUtils.getJson("https://sessionserver.mojang.com/session/minecraft/profile/" + id.toString().replace("-", ""));
        if (rawResponse == null || !(rawResponse instanceof JSONObject)) {
            return null;
        }
        final JSONObject response = (JSONObject)rawResponse;
        final PlayerProfile profile = this.deserializeProfile(response);
        if (profile == null) {
            return null;
        }
        return profile;
    }
    
    private PlayerProfile deserializeProfile(final JSONObject json) {
        if (!json.containsKey((Object)"name") || !json.containsKey((Object)"id")) {
            return null;
        }
        if (!(json.get((Object)"name") instanceof String) || !(json.get((Object)"id") instanceof String)) {
            return null;
        }
        final String name = (String)json.get((Object)"name");
        final UUID id = toUUID((String)json.get((Object)"id"));
        if (id == null) {
            return null;
        }
        final PlayerProfile profile = new PlayerProfile(id, name);
        if (json.containsKey((Object)"properties") && json.get((Object)"properties") instanceof JSONArray) {
            profile.setProperties((JSONArray)json.get((Object)"properties"));
        }
        return profile;
    }
    
    private static String toString(final UUID id) {
        return id.toString().replace("-", "");
    }
    
    private static UUID toUUID(String s) {
        if (s.length() == 32) {
            s = s.substring(0, 8) + "-" + s.substring(8, 12) + "-" + s.substring(12, 16) + "-" + s.substring(16, 20) + "-" + s.substring(20, 32);
        }
        return UUID.fromString(s);
    }
    
    @Override
    public PlayerProfile lookup(final String name) {
        final Iterator<PlayerProfile> iterator = this.postNames(Lists.newArrayList(name)).iterator();
        return iterator.hasNext() ? iterator.next() : null;
    }
    
    @Override
    public Collection<PlayerProfile> lookup(final Collection<String> names) {
        return this.postNames(names);
    }
    
    @Override
    public PlayerProfile lookup(final UUID id) {
        return this.lookupProperties(id);
    }
    
    @Override
    public void lookupProperties(final PlayerProfile profile) {
        if (profile.getProperties() != null) {
            return;
        }
    }
}
