package com.hcrival.internal.net.techcable.techutils.uuid;

import java.util.*;
import com.google.common.base.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.*;

public class UUIDUtils
{
    private static final CachingLookup lookup;
    
    private UUIDUtils() {
    }
    
    public static UUID getId(final String name) {
        if (UUIDUtils.lookup.getIfCached(name) != null) {
            return UUIDUtils.lookup.getIfCached(name).getId();
        }
        if (getPlayerExact(name) != null) {
            return getPlayerExact(name).getUniqueId();
        }
        if (!Bukkit.getOnlineMode()) {
            return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(Charsets.UTF_8));
        }
        final PlayerProfile profile = UUIDUtils.lookup.lookup(name);
        if (profile == null) {
            return null;
        }
        return profile.getId();
    }
    
    public static String getName(final UUID id) {
        if (UUIDUtils.lookup.getIfCached(id) != null) {
            return UUIDUtils.lookup.getIfCached(id).getName();
        }
        if (hasBukkit() && Bukkit.getPlayer(id) != null) {
            final String name = Bukkit.getPlayer(id).getName();
            UUIDUtils.lookup.addToCache(new PlayerProfile(id, name));
            return name;
        }
        if (hasBukkit() && !Bukkit.getOnlineMode()) {
            final OfflinePlayer player = Bukkit.getOfflinePlayer(id);
            return player.getName();
        }
        final PlayerProfile profile = UUIDUtils.lookup.lookup(id);
        if (profile == null) {
            return null;
        }
        return profile.getName();
    }
    
    public static Player getPlayerExact(final String name) {
        if (UUIDUtils.lookup.getIfCached(name) != null) {
            return Bukkit.getPlayer(UUIDUtils.lookup.getIfCached(name).getId());
        }
        if (Bukkit.getPlayerExact(name) != null) {
            final UUID id = Bukkit.getPlayerExact(name).getUniqueId();
            UUIDUtils.lookup.addToCache(new PlayerProfile(id, name));
            return Bukkit.getPlayer(id);
        }
        return null;
    }
    
    public static boolean hasBukkit() {
        return Reflection.getClass("org.bukkit.Bukkit") != null && Bukkit.getServer() != null;
    }
    
    public static CachingLookup getLookup() {
        return UUIDUtils.lookup;
    }
    
    static {
        lookup = new CachingLookup(new BackupLookup(new MCPlayerIndexLookup(), new MojangLookup()));
    }
}
