package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.*;
import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public abstract class AbstractArrayPropertyNode extends AbstractPropertyNode implements IArrayPropertyNode
{
    public AbstractArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode, name);
    }
    
    @Nonnull
    @Override
    public AbstractArrayPropertyNode ensureItemType(@Nonnull final NodeValueType valueType) throws IllegalStateException {
        if (this.itemType() != valueType) {
            throw new IllegalStateException("Expected value node representing items of type " + valueType + " but found " + this.itemType());
        }
        return this;
    }
    
    @Override
    public String toString() {
        return String.format("%s,length=%d", super.toString(), this.length());
    }
}
