package com.hcrival.internal.net.techcable.techutils.libs.candle.node;

import java.util.function.*;
import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.stream.*;
import java.util.*;

public class ObjectNode extends AbstractNamedNode implements IObjectNode
{
    private final LinkedList<INode> children;
    
    public ObjectNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode, name);
        this.children = new LinkedList<INode>();
    }
    
    protected ObjectNode() {
        this.children = new LinkedList<INode>();
    }
    
    @Nonnull
    @Override
    public IObjectNode append(@Nonnull final INode node) {
        if (node instanceof INamedNode && this.isPresent(((INamedNode)node).name())) {
            this.replace(((INamedNode)node).name(), node);
            return this;
        }
        this.children.add(node);
        return this;
    }
    
    @Nonnull
    @Override
    public List<INode> children() {
        return Collections.unmodifiableList((List<? extends INode>)this.children);
    }
    
    @Nonnull
    @Override
    public <T extends INode> List<T> children(@Nonnull final Class<T> nodeType) {
        return this.stream(nodeType).collect((Collector<? super T, ?, List<T>>)Collectors.toList());
    }
    
    @Nonnull
    @Override
    public IObjectNode clear() {
        this.children.clear();
        return this;
    }
    
    @Nonnull
    @Override
    public INode get(@Nonnull final String name) throws NoSuchElementException {
        final String closestNode = (name.indexOf(46) == -1) ? name : name.substring(0, name.indexOf(46));
        final String s;
        final String s2;
        String string;
        final Object o;
        final StringBuilder sb;
        final INode node = this.stream().filter(n -> n instanceof INamedNode && s.equalsIgnoreCase(n.name())).findFirst().orElseThrow(() -> {
            // new(java.util.NoSuchElementException.class)
            new StringBuilder().append("Could not locate element with name \"").append(name).append("\"");
            if (!s2.equals(name)) {
                string = " (failed to locate closest node \"" + s2 + "\")";
            }
            else {
                string = "";
            }
            new NoSuchElementException(sb.append(string).toString());
            return o;
        });
        if (name.indexOf(46) == -1) {
            return node;
        }
        if (!(node instanceof IObjectNode)) {
            throw new NoSuchElementException("Node with name \"" + closestNode + "\" is not a container node");
        }
        return ((IObjectNode)node).get(name.substring(closestNode.length() + 1));
    }
    
    @Nonnull
    @Override
    public <T extends INode> T get(@Nonnull final String name, @Nonnull final Class<T> nodeType) throws IllegalStateException, NoSuchElementException {
        final INode node = this.get(name);
        if (!nodeType.isAssignableFrom(node.getClass())) {
            throw new IllegalStateException("Expected node of type " + nodeType.getCanonicalName() + " but got " + node.getClass().getName());
        }
        return (T)node;
    }
    
    @Nonnull
    @Override
    public IPropertyNode getProperty(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.get(name, IPropertyNode.class);
    }
    
    @Nullable
    @Override
    public <T extends IPropertyNode, R> R getPropertyValue(@Nonnull final String name, @Nonnull final Class<T> nodeType, @Nonnull final Function<T, R> ifPresent) {
        return this.getPropertyValue(name, nodeType, ifPresent, () -> null);
    }
    
    @Nonnull
    @Override
    public <T extends IPropertyNode, R> R getPropertyValue(@Nonnull final String name, @Nonnull final Class<T> nodeType, @Nonnull final Function<T, R> ifPresent, @Nonnull final Supplier<R> ifNull) {
        if (this.isNull(name)) {
            return ifNull.get();
        }
        return ifPresent.apply(this.get(name, nodeType));
    }
    
    @Override
    public boolean getBoolean(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, BooleanPropertyNode.class, BooleanPropertyNode::value, () -> false);
    }
    
    @Override
    public boolean getBoolean(@Nonnull final String name, final boolean defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getBoolean(name);
    }
    
    @Nullable
    @Override
    public boolean[] getBooleanArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, BooleanArrayPropertyNode.class, BooleanArrayPropertyNode::array);
    }
    
    @Nullable
    @Override
    public boolean[] getBooleanArray(@Nonnull final String name, @Nullable final boolean[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getBooleanArray(name);
    }
    
    @Nullable
    @Override
    public String getEnum(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, EnumPropertyNode.class, EnumPropertyNode::value);
    }
    
    @Nullable
    @Override
    public String getEnum(@Nonnull final String name, @Nullable final String defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getEnum(name);
    }
    
    @Nullable
    @Override
    public <T extends Enum> T getEnum(@Nonnull final String name, @Nonnull final Class<T> enumType) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, EnumPropertyNode.class, n -> n.value(enumType));
    }
    
    @Nullable
    @Override
    public <T extends Enum> T getEnum(@Nonnull final String name, @Nonnull final T defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getEnum(name, (Class<T>)defaultValue.getClass());
    }
    
    @Nullable
    @Override
    public <T extends Enum> T getEnum(@Nonnull final String name, @Nullable final T defaultValue, @Nonnull final Class<T> enumType) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getEnum(name, enumType);
    }
    
    @Nullable
    @Override
    public String[] getEnumArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, EnumArrayPropertyNode.class, EnumArrayPropertyNode::array);
    }
    
    @Nullable
    @Override
    public String[] getEnumArray(@Nonnull final String name, @Nullable final String[] defaultValue) throws IllegalStateException, NoSuchElementException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getEnumArray(name);
    }
    
    @Nullable
    @Override
    public <T extends Enum> T[] getEnumArray(@Nonnull final String name, @Nullable final Class<T> enumType) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, EnumArrayPropertyNode.class, n -> n.array(enumType));
    }
    
    @Nullable
    @Override
    public <T extends Enum> T[] getEnumArray(@Nonnull final String name, @Nullable final T[] defaultValue, @Nonnull final Class<T> enumType) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getEnumArray(name, enumType);
    }
    
    @Override
    public float getFloat(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, FloatPropertyNode.class, FloatPropertyNode::value, () -> 0.0f);
    }
    
    @Override
    public float getFloat(@Nonnull final String name, final float defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getFloat(name);
    }
    
    @Nullable
    @Override
    public float[] getFloatArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, FloatArrayPropertyNode.class, FloatArrayPropertyNode::array);
    }
    
    @Nullable
    @Override
    public float[] getFloatArray(@Nonnegative final String name, @Nullable final float[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getFloatArray(name);
    }
    
    @Override
    public int getInteger(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, IntegerPropertyNode.class, IntegerPropertyNode::value, () -> 0);
    }
    
    @Override
    public int getInteger(@Nonnull final String name, final int defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getInteger(name);
    }
    
    @Nullable
    @Override
    public int[] getIntegerArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, IntegerArrayPropertyNode.class, IntegerArrayPropertyNode::array);
    }
    
    @Nullable
    @Override
    public int[] getIntegerArray(@Nonnull final String name, @Nullable final int[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getIntegerArray(name);
    }
    
    @Nullable
    @Override
    public String getString(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, StringPropertyNode.class, StringPropertyNode::value);
    }
    
    @Nullable
    @Override
    public String getString(@Nonnegative final String name, @Nullable final String defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getString(name);
    }
    
    @Nullable
    @Override
    public String[] getStringArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, StringArrayPropertyNode.class, StringArrayPropertyNode::array);
    }
    
    @Nullable
    @Override
    public String[] getStringArray(@Nonnull final String name, @Nullable final String[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getStringArray(name);
    }
    
    @Override
    public float getUnsignedFloat(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, FloatPropertyNode.class, FloatPropertyNode::valueUnsigned, () -> 0.0f);
    }
    
    @Override
    public float getUnsignedFloat(@Nonnull final String name, @Nonnegative final float defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getUnsignedFloat(name);
    }
    
    @Nullable
    @Override
    public float[] getUnsignedFloatArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, FloatArrayPropertyNode.class, FloatArrayPropertyNode::arrayUnsigned);
    }
    
    @Nullable
    @Override
    public float[] getUnsignedFloatArray(@Nonnull final String name, @Nullable @Nonnegative final float[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getUnsignedFloatArray(name);
    }
    
    @Override
    public int getUnsignedInteger(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, IntegerPropertyNode.class, IntegerPropertyNode::valueUnsigned, () -> 0);
    }
    
    @Override
    public int getUnsignedInteger(@Nonnegative final String name, @Nonnegative final int defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getUnsignedInteger(name);
    }
    
    @Nullable
    @Override
    public int[] getUnsignedIntegerArray(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        return this.getPropertyValue(name, IntegerArrayPropertyNode.class, IntegerArrayPropertyNode::arrayUnsigned);
    }
    
    @Nullable
    @Override
    public int[] getUnsignedIntegerArray(@Nonnull final String name, @Nullable @Nonnegative final int[] defaultValue) throws IllegalStateException {
        if (!this.isPresent(name)) {
            return defaultValue;
        }
        return this.getUnsignedIntegerArray(name);
    }
    
    @Nonnull
    @Override
    public IObjectNode insertAfter(@Nonnull final String after, @Nonnull final INode node) throws NoSuchElementException {
        final int index = after.lastIndexOf(46);
        if (index != -1) {
            final IObjectNode closestNode = this.get(after.substring(0, index), IObjectNode.class);
            closestNode.insertAfter(after.substring(index + 1), node);
            return this;
        }
        return this.insertAfter(this.get(after), node);
    }
    
    @Nonnull
    @Override
    public IObjectNode insertAfter(@Nonnull final INode after, @Nonnull final INode node) throws NoSuchElementException {
        final int index = this.children.indexOf(after) + 1;
        if (index == 0) {
            throw new NoSuchElementException("Cannot locate element to insert after within tree");
        }
        this.children.add(index, node);
        return this;
    }
    
    @Nonnull
    @Override
    public IObjectNode insertBefore(@Nonnull final String before, @Nonnull final INode node) throws NoSuchElementException {
        final int index = before.lastIndexOf(46);
        if (index != -1) {
            final IObjectNode closestNode = this.get(before.substring(0, index), IObjectNode.class);
            closestNode.insertAfter(before.substring(index + 1), node);
            return this;
        }
        return this.insertBefore(this.get(before), node);
    }
    
    @Nonnull
    @Override
    public IObjectNode insertBefore(@Nonnull final INode before, @Nonnull final INode node) throws NoSuchElementException {
        final int index = this.children.indexOf(before);
        if (index == -1) {
            throw new NoSuchElementException("Cannot locate element to insert before within tree");
        }
        this.children.add(index, node);
        return this;
    }
    
    @Override
    public boolean isNull(@Nonnull final String name) throws IllegalStateException, NoSuchElementException {
        final INode node = this.get(name);
        node.ensureType(NodeType.PROPERTY);
        return ((IPropertyNode)node).valueType() == NodeValueType.NULL;
    }
    
    @Override
    public boolean isPresent(@Nonnull final String name) {
        try {
            final int index = name.lastIndexOf(46);
            if (index != -1) {
                final IObjectNode closestNode = this.get(name.substring(0, index), IObjectNode.class);
                return closestNode.isPresent(name.substring(index + 1));
            }
            return this.stream().parallel().filter(n -> n instanceof INamedNode && name.equalsIgnoreCase(n.name())).findAny().isPresent();
        }
        catch (IllegalStateException | NoSuchElementException ex3) {
            final RuntimeException ex2;
            final RuntimeException ex = ex2;
            return false;
        }
    }
    
    @Override
    public boolean isPresent(@Nonnull final String name, @Nonnull final Class<? extends INode> nodeType) {
        try {
            final int index = name.lastIndexOf(46);
            if (index != -1) {
                final IObjectNode closestNode = this.get(name.substring(0, index), IObjectNode.class);
                return closestNode.isPresent(name.substring(index + 1), nodeType);
            }
            return this.stream(nodeType).parallel().filter(n -> n instanceof INamedNode && name.equalsIgnoreCase(n.name())).findAny().isPresent();
        }
        catch (IllegalStateException | NoSuchElementException ex3) {
            final RuntimeException ex2;
            final RuntimeException ex = ex2;
            return false;
        }
    }
    
    @Nonnull
    @Override
    public <T extends INode> Iterator<T> iterator(@Nonnull final Class<T> nodeType) {
        return this.stream(nodeType).iterator();
    }
    
    @Nonnull
    @Override
    public IObjectNode remove(@Nonnull final String name) throws NoSuchElementException {
        final int index = name.lastIndexOf(46);
        if (index != -1) {
            final IObjectNode node = this.get(name.substring(0, index), IObjectNode.class);
            node.remove(name.substring(index + 1));
            return this;
        }
        return this.remove(this.get(name));
    }
    
    @Nonnull
    @Override
    public IObjectNode remove(@Nonnull final INode node) throws NoSuchElementException {
        if (!this.children.remove(node)) {
            throw new NoSuchElementException("Cannot locate element to remove within tree");
        }
        return this;
    }
    
    @Nonnull
    @Override
    public IObjectNode replace(@Nonnull final String name, @Nonnull final INode replacement) throws NoSuchElementException {
        final int index = name.indexOf(46);
        if (index != -1) {
            final IObjectNode closestNode = this.get(name.substring(0, index), IObjectNode.class);
            closestNode.replace(name.substring(index + 1), replacement);
            return this;
        }
        return this.replace(this.get(name), replacement);
    }
    
    @Nonnull
    @Override
    public IObjectNode replace(@Nonnull final INode node, @Nonnull final INode replacement) throws NoSuchElementException {
        final int index = this.children.indexOf(node);
        if (index == -1) {
            throw new NoSuchElementException("Cannot locate element to replace within tree");
        }
        this.children.remove(node);
        this.children.add(index, replacement);
        return this;
    }
    
    @Override
    public int size() {
        return this.children.size();
    }
    
    @Nonnull
    @Override
    public Stream<INode> stream() {
        return this.children.stream();
    }
    
    @Nonnull
    @Override
    public <T extends INode> Stream<T> stream(@Nonnull final Class<T> nodeType) {
        return (Stream<T>)this.stream().parallel().filter(n -> nodeType.isAssignableFrom(n.getClass())).sequential();
    }
    
    @Override
    public Iterator<INode> iterator() {
        return this.children().iterator();
    }
    
    @Override
    public String toString() {
        return String.format("ObjectNode{%s,children=[%s]}", super.toString(), this.children());
    }
}
