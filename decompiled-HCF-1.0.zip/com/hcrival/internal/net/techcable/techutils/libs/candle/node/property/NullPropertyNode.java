package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class NullPropertyNode extends AbstractPropertyNode
{
    public NullPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode, name);
    }
    
    @Nonnull
    @Override
    public NullPropertyNode ensureValueType(@Nonnull final NodeValueType valueType) throws IllegalStateException {
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.NULL;
    }
    
    @Override
    public String toString() {
        return String.format("NullPropertyNode{%s}", super.toString());
    }
}
