package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.*;

public class BooleanArrayPropertyNode extends AbstractArrayPropertyNode
{
    private boolean[] array;
    
    public BooleanArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final boolean[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    public BooleanArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final Boolean[] array) {
        super(documentNode, name);
        final boolean[] primitiveArray = new boolean[array.length];
        for (int i = 0; i < primitiveArray.length; ++i) {
            primitiveArray[i] = array[i];
        }
        this.array(primitiveArray);
    }
    
    @Nonnull
    public boolean[] array() {
        return this.array;
    }
    
    @Nonnull
    public BooleanArrayPropertyNode array(@Nonnull final boolean[] array) {
        this.array = array;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.BOOLEAN;
    }
    
    @Override
    public int length() {
        return this.array.length;
    }
    
    @Override
    public String toString() {
        return String.format("BooleanArrayPropertyNode{%s,array=%s}", super.toString(), Arrays.toString(this.array()));
    }
}
