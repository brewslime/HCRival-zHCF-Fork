package com.hcrival.internal.net.techcable.techutils.libs.candle.node;

import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import javax.annotation.*;

public class CommentNode extends AbstractNode implements ICommentNode
{
    private String content;
    private boolean multiline;
    
    public CommentNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String content) {
        super(documentNode);
        this.text(content);
    }
    
    @Override
    public boolean isMultiline() {
        return this.multiline;
    }
    
    @Nonnull
    @Override
    public ICommentNode text(@Nonnull final String text) {
        this.content = text;
        this.multiline = text.contains("\n");
        return this;
    }
    
    @Nonnull
    @Override
    public String text() {
        return this.content;
    }
    
    @Override
    public String toString() {
        return String.format("CommentNode{text=\"%s\",multiline=%b}", this.text(), this.isMultiline());
    }
}
