package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class FloatPropertyNode extends AbstractPropertyNode
{
    private float value;
    
    public FloatPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, final float value) {
        super(documentNode, name);
        this.value(value);
    }
    
    public float value() {
        return this.value;
    }
    
    @Nonnegative
    public float valueUnsigned() throws IllegalStateException {
        if (this.value() < 0.0f) {
            throw new IllegalStateException("Expected an unsigned value but got " + this.value());
        }
        return this.value();
    }
    
    @Nonnull
    public FloatPropertyNode value(final float value) {
        this.value = value;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.FLOAT;
    }
    
    @Override
    public String toString() {
        return String.format("FloatPropertyNode{%s,value=%f}", super.toString(), this.value());
    }
}
