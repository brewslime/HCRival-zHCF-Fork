package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class BooleanPropertyNode extends AbstractPropertyNode
{
    private boolean value;
    
    public BooleanPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, final boolean value) {
        super(documentNode, name);
        this.value(value);
    }
    
    public boolean value() {
        return this.value;
    }
    
    @Nonnull
    public BooleanPropertyNode value(final boolean value) {
        this.value = value;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.BOOLEAN;
    }
    
    @Override
    public String toString() {
        return String.format("BooleanPropertyNode{%s,value=%b}", super.toString(), this.value());
    }
}
