package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.*;

public class IntegerArrayPropertyNode extends AbstractArrayPropertyNode
{
    private int[] array;
    
    public IntegerArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final int[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    public IntegerArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final Integer[] array) {
        super(documentNode, name);
        final int[] primitiveArray = new int[array.length];
        for (int i = 0; i < primitiveArray.length; ++i) {
            primitiveArray[i] = array[i];
        }
        this.array(primitiveArray);
    }
    
    @Nonnull
    public int[] array() {
        return this.array;
    }
    
    @Nonnull
    @Nonnegative
    public int[] arrayUnsigned() {
        for (final int current : this.array) {
            if (current < 0) {
                throw new IllegalStateException("Expected an unsigned value but got " + current);
            }
        }
        return this.array;
    }
    
    @Nonnull
    public IntegerArrayPropertyNode array(@Nonnull final int[] array) {
        this.array = array;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.INTEGER;
    }
    
    @Override
    public int length() {
        return this.array.length;
    }
    
    @Override
    public String toString() {
        return String.format("IntegerArrayPropertyNode{%s,array=%s}", super.toString(), Arrays.toString(this.array()));
    }
}
