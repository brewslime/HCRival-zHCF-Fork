package com.hcrival.internal.net.techcable.techutils.libs.candle.node;

import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import javax.annotation.*;

public abstract class AbstractNamedNode extends AbstractNode implements INamedNode
{
    private String name;
    
    public AbstractNamedNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode);
        this.name(name);
    }
    
    protected AbstractNamedNode() {
    }
    
    @Nonnull
    @Override
    public String name() {
        return this.name;
    }
    
    @Nonnull
    @Override
    public INamedNode name(@Nonnull final String name) {
        this.name = name;
        return this;
    }
    
    @Override
    public String toString() {
        return String.format("name=\"%s\"", this.name());
    }
}
