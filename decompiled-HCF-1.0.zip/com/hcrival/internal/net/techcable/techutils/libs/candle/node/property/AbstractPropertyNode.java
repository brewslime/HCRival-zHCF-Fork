package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import com.hcrival.internal.net.techcable.techutils.libs.candle.node.*;
import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public abstract class AbstractPropertyNode extends AbstractNamedNode implements IPropertyNode
{
    public AbstractPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode, name);
    }
    
    @Nonnull
    @Override
    public IPropertyNode ensureValueType(@Nonnull final NodeValueType valueType) throws IllegalStateException {
        if (this.valueType() != valueType) {
            throw new IllegalStateException("Expected value node representing type " + valueType + " but found " + this.valueType());
        }
        return this;
    }
}
