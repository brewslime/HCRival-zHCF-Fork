package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class IntegerPropertyNode extends AbstractPropertyNode
{
    private int value;
    
    public IntegerPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, final int value) {
        super(documentNode, name);
        this.value(value);
    }
    
    public int value() {
        return this.value;
    }
    
    @Nonnegative
    public int valueUnsigned() {
        if (this.value() < 0) {
            throw new IllegalStateException("Expected an unsigned value but got " + this.value());
        }
        return this.value();
    }
    
    @Nonnull
    public IntegerPropertyNode value(final int value) {
        this.value = value;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.INTEGER;
    }
    
    @Override
    public String toString() {
        return String.format("IntegerPropertyNode{%s,value=%d}", super.toString(), this.value());
    }
}
