package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.antlr.dfa.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.atn.*;
import java.util.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.tree.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;

public class CandleParser extends Parser
{
    protected static final DFA[] _decisionToDFA;
    protected static final PredictionContextCache _sharedContextCache;
    public static final int COMMENT = 1;
    public static final int COMMENT_LINE = 2;
    public static final int STRING_LITERAL_START = 3;
    public static final int NUMBER_FLOAT = 4;
    public static final int NUMBER_INTEGER = 5;
    public static final int COPY = 6;
    public static final int FALSE = 7;
    public static final int INCLUDE = 8;
    public static final int NULL = 9;
    public static final int OBJECT = 10;
    public static final int PROPERTY = 11;
    public static final int TRUE = 12;
    public static final int TRY = 13;
    public static final int IDENTIFIER = 14;
    public static final int BRACE_OPEN = 15;
    public static final int BRACE_CLOSE = 16;
    public static final int BRACKET_OPEN = 17;
    public static final int BRACKET_CLOSE = 18;
    public static final int COLON = 19;
    public static final int COMMA = 20;
    public static final int DOT = 21;
    public static final int EQUALS = 22;
    public static final int SEMICOLON = 23;
    public static final int WHITESPACE = 24;
    public static final int STRING_LITERAL_QUOTE = 25;
    public static final int STRING_LITERAL_BACKSLASH = 26;
    public static final int STRING_LITERAL_BACKSPACE = 27;
    public static final int STRING_LITERAL_FORMFILL = 28;
    public static final int STRING_LITERAL_NEWLINE = 29;
    public static final int STRING_LITERAL_CARRIAGE_RETURN = 30;
    public static final int STRING_LITERAL_HORIZONTAL_TAB = 31;
    public static final int STRING_LITERAL_ESCAPE_UNICODE = 32;
    public static final int STRING_LITERAL_TEXT = 33;
    public static final int STRING_LITERAL_END = 34;
    public static final int RULE_candle = 0;
    public static final int RULE_expression = 1;
    public static final int RULE_assignment = 2;
    public static final int RULE_comment = 3;
    public static final int RULE_commentMultiline = 4;
    public static final int RULE_commentSingleline = 5;
    public static final int RULE_object = 6;
    public static final int RULE_objectIdentifier = 7;
    public static final int RULE_property = 8;
    public static final int RULE_propertyIdentifier = 9;
    public static final int RULE_propertyValue = 10;
    public static final int RULE_propertyValueBoolean = 11;
    public static final int RULE_propertyValueEnum = 12;
    public static final int RULE_propertyValueFloat = 13;
    public static final int RULE_propertyValueInteger = 14;
    public static final int RULE_propertyValueNull = 15;
    public static final int RULE_propertyValueString = 16;
    public static final int RULE_propertyValueArray = 17;
    public static final int RULE_propertyValueArrayElementList = 18;
    public static final int RULE_propertyValueArrayElement = 19;
    public static final String[] ruleNames;
    private static final String[] _LITERAL_NAMES;
    private static final String[] _SYMBOLIC_NAMES;
    public static final Vocabulary VOCABULARY;
    @Deprecated
    public static final String[] tokenNames;
    public static final String _serializedATN = "\u0003\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\u0003$\u0084\u0004\u0002\t\u0002\u0004\u0003\t\u0003\u0004\u0004\t\u0004\u0004\u0005\t\u0005\u0004\u0006\t\u0006\u0004\u0007\t\u0007\u0004\b\t\b\u0004\t\t\t\u0004\n\t\n\u0004\u000b\t\u000b\u0004\f\t\f\u0004\r\t\r\u0004\u000e\t\u000e\u0004\u000f\t\u000f\u0004\u0010\t\u0010\u0004\u0011\t\u0011\u0004\u0012\t\u0012\u0004\u0013\t\u0013\u0004\u0014\t\u0014\u0004\u0015\t\u0015\u0003\u0002\u0007\u0002,\n\u0002\f\u0002\u000e\u0002/\u000b\u0002\u0003\u0003\u0003\u0003\u0005\u00033\n\u0003\u0003\u0004\u0003\u0004\u0005\u00047\n\u0004\u0003\u0005\u0003\u0005\u0005\u0005;\n\u0005\u0003\u0006\u0003\u0006\u0003\u0007\u0003\u0007\u0003\b\u0003\b\u0003\b\u0007\bD\n\b\f\b\u000e\bG\u000b\b\u0003\b\u0003\b\u0003\t\u0003\t\u0003\n\u0003\n\u0003\n\u0003\n\u0003\u000b\u0003\u000b\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0005\fZ\n\f\u0003\r\u0003\r\u0003\u000e\u0003\u000e\u0003\u000f\u0003\u000f\u0003\u0010\u0003\u0010\u0003\u0011\u0003\u0011\u0003\u0012\u0003\u0012\u0007\u0012h\n\u0012\f\u0012\u000e\u0012k\u000b\u0012\u0003\u0012\u0003\u0012\u0003\u0013\u0003\u0013\u0005\u0013q\n\u0013\u0003\u0013\u0003\u0013\u0003\u0014\u0003\u0014\u0003\u0014\u0005\u0014x\n\u0014\u0005\u0014z\n\u0014\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0005\u0015\u0082\n\u0015\u0003\u0015\u0002\u0002\u0016\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(\u0002\u0004\u0004\u0002\t\t\u000e\u000e\u0003\u0002\u001b#\u0083\u0002-\u0003\u0002\u0002\u0002\u00042\u0003\u0002\u0002\u0002\u00066\u0003\u0002\u0002\u0002\b:\u0003\u0002\u0002\u0002\n<\u0003\u0002\u0002\u0002\f>\u0003\u0002\u0002\u0002\u000e@\u0003\u0002\u0002\u0002\u0010J\u0003\u0002\u0002\u0002\u0012L\u0003\u0002\u0002\u0002\u0014P\u0003\u0002\u0002\u0002\u0016Y\u0003\u0002\u0002\u0002\u0018[\u0003\u0002\u0002\u0002\u001a]\u0003\u0002\u0002\u0002\u001c_\u0003\u0002\u0002\u0002\u001ea\u0003\u0002\u0002\u0002 c\u0003\u0002\u0002\u0002\"e\u0003\u0002\u0002\u0002$n\u0003\u0002\u0002\u0002&t\u0003\u0002\u0002\u0002(\u0081\u0003\u0002\u0002\u0002*,\u0005\u0004\u0003\u0002+*\u0003\u0002\u0002\u0002,/\u0003\u0002\u0002\u0002-+\u0003\u0002\u0002\u0002-.\u0003\u0002\u0002\u0002.\u0003\u0003\u0002\u0002\u0002/-\u0003\u0002\u0002\u000203\u0005\b\u0005\u000213\u0005\u0006\u0004\u000220\u0003\u0002\u0002\u000221\u0003\u0002\u0002\u00023\u0005\u0003\u0002\u0002\u000247\u0005\u000e\b\u000257\u0005\u0012\n\u000264\u0003\u0002\u0002\u000265\u0003\u0002\u0002\u00027\u0007\u0003\u0002\u0002\u00028;\u0005\n\u0006\u00029;\u0005\f\u0007\u0002:8\u0003\u0002\u0002\u0002:9\u0003\u0002\u0002\u0002;\t\u0003\u0002\u0002\u0002<=\u0007\u0003\u0002\u0002=\u000b\u0003\u0002\u0002\u0002>?\u0007\u0004\u0002\u0002?\r\u0003\u0002\u0002\u0002@A\u0005\u0010\t\u0002AE\u0007\u0011\u0002\u0002BD\u0005\u0004\u0003\u0002CB\u0003\u0002\u0002\u0002DG\u0003\u0002\u0002\u0002EC\u0003\u0002\u0002\u0002EF\u0003\u0002\u0002\u0002FH\u0003\u0002\u0002\u0002GE\u0003\u0002\u0002\u0002HI\u0007\u0012\u0002\u0002I\u000f\u0003\u0002\u0002\u0002JK\u0007\u0010\u0002\u0002K\u0011\u0003\u0002\u0002\u0002LM\u0005\u0014\u000b\u0002MN\u0007\u0018\u0002\u0002NO\u0005\u0016\f\u0002O\u0013\u0003\u0002\u0002\u0002PQ\u0007\u0010\u0002\u0002Q\u0015\u0003\u0002\u0002\u0002RZ\u0005$\u0013\u0002SZ\u0005\u0018\r\u0002TZ\u0005\u001a\u000e\u0002UZ\u0005\u001c\u000f\u0002VZ\u0005\u001e\u0010\u0002WZ\u0005 \u0011\u0002XZ\u0005\"\u0012\u0002YR\u0003\u0002\u0002\u0002YS\u0003\u0002\u0002\u0002YT\u0003\u0002\u0002\u0002YU\u0003\u0002\u0002\u0002YV\u0003\u0002\u0002\u0002YW\u0003\u0002\u0002\u0002YX\u0003\u0002\u0002\u0002Z\u0017\u0003\u0002\u0002\u0002[\\\t\u0002\u0002\u0002\\\u0019\u0003\u0002\u0002\u0002]^\u0007\u0010\u0002\u0002^\u001b\u0003\u0002\u0002\u0002_`\u0007\u0006\u0002\u0002`\u001d\u0003\u0002\u0002\u0002ab\u0007\u0007\u0002\u0002b\u001f\u0003\u0002\u0002\u0002cd\u0007\u000b\u0002\u0002d!\u0003\u0002\u0002\u0002ei\u0007\u0005\u0002\u0002fh\t\u0003\u0002\u0002gf\u0003\u0002\u0002\u0002hk\u0003\u0002\u0002\u0002ig\u0003\u0002\u0002\u0002ij\u0003\u0002\u0002\u0002jl\u0003\u0002\u0002\u0002ki\u0003\u0002\u0002\u0002lm\u0007$\u0002\u0002m#\u0003\u0002\u0002\u0002np\u0007\u0013\u0002\u0002oq\u0005&\u0014\u0002po\u0003\u0002\u0002\u0002pq\u0003\u0002\u0002\u0002qr\u0003\u0002\u0002\u0002rs\u0007\u0014\u0002\u0002s%\u0003\u0002\u0002\u0002ty\u0005(\u0015\u0002uw\u0007\u0016\u0002\u0002vx\u0005&\u0014\u0002wv\u0003\u0002\u0002\u0002wx\u0003\u0002\u0002\u0002xz\u0003\u0002\u0002\u0002yu\u0003\u0002\u0002\u0002yz\u0003\u0002\u0002\u0002z'\u0003\u0002\u0002\u0002{\u0082\u0005\u0018\r\u0002|\u0082\u0005\u001a\u000e\u0002}\u0082\u0005\u001c\u000f\u0002~\u0082\u0005\u001e\u0010\u0002\u007f\u0082\u0005 \u0011\u0002\u0080\u0082\u0005\"\u0012\u0002\u0081{\u0003\u0002\u0002\u0002\u0081|\u0003\u0002\u0002\u0002\u0081}\u0003\u0002\u0002\u0002\u0081~\u0003\u0002\u0002\u0002\u0081\u007f\u0003\u0002\u0002\u0002\u0081\u0080\u0003\u0002\u0002\u0002\u0082)\u0003\u0002\u0002\u0002\r-26:EYipwy\u0081";
    public static final ATN _ATN;
    
    @Deprecated
    @Override
    public String[] getTokenNames() {
        return CandleParser.tokenNames;
    }
    
    @Override
    public Vocabulary getVocabulary() {
        return CandleParser.VOCABULARY;
    }
    
    @Override
    public String getGrammarFileName() {
        return "CandleParser.g4";
    }
    
    @Override
    public String[] getRuleNames() {
        return CandleParser.ruleNames;
    }
    
    @Override
    public String getSerializedATN() {
        return "\u0003\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\u0003$\u0084\u0004\u0002\t\u0002\u0004\u0003\t\u0003\u0004\u0004\t\u0004\u0004\u0005\t\u0005\u0004\u0006\t\u0006\u0004\u0007\t\u0007\u0004\b\t\b\u0004\t\t\t\u0004\n\t\n\u0004\u000b\t\u000b\u0004\f\t\f\u0004\r\t\r\u0004\u000e\t\u000e\u0004\u000f\t\u000f\u0004\u0010\t\u0010\u0004\u0011\t\u0011\u0004\u0012\t\u0012\u0004\u0013\t\u0013\u0004\u0014\t\u0014\u0004\u0015\t\u0015\u0003\u0002\u0007\u0002,\n\u0002\f\u0002\u000e\u0002/\u000b\u0002\u0003\u0003\u0003\u0003\u0005\u00033\n\u0003\u0003\u0004\u0003\u0004\u0005\u00047\n\u0004\u0003\u0005\u0003\u0005\u0005\u0005;\n\u0005\u0003\u0006\u0003\u0006\u0003\u0007\u0003\u0007\u0003\b\u0003\b\u0003\b\u0007\bD\n\b\f\b\u000e\bG\u000b\b\u0003\b\u0003\b\u0003\t\u0003\t\u0003\n\u0003\n\u0003\n\u0003\n\u0003\u000b\u0003\u000b\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0005\fZ\n\f\u0003\r\u0003\r\u0003\u000e\u0003\u000e\u0003\u000f\u0003\u000f\u0003\u0010\u0003\u0010\u0003\u0011\u0003\u0011\u0003\u0012\u0003\u0012\u0007\u0012h\n\u0012\f\u0012\u000e\u0012k\u000b\u0012\u0003\u0012\u0003\u0012\u0003\u0013\u0003\u0013\u0005\u0013q\n\u0013\u0003\u0013\u0003\u0013\u0003\u0014\u0003\u0014\u0003\u0014\u0005\u0014x\n\u0014\u0005\u0014z\n\u0014\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0005\u0015\u0082\n\u0015\u0003\u0015\u0002\u0002\u0016\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(\u0002\u0004\u0004\u0002\t\t\u000e\u000e\u0003\u0002\u001b#\u0083\u0002-\u0003\u0002\u0002\u0002\u00042\u0003\u0002\u0002\u0002\u00066\u0003\u0002\u0002\u0002\b:\u0003\u0002\u0002\u0002\n<\u0003\u0002\u0002\u0002\f>\u0003\u0002\u0002\u0002\u000e@\u0003\u0002\u0002\u0002\u0010J\u0003\u0002\u0002\u0002\u0012L\u0003\u0002\u0002\u0002\u0014P\u0003\u0002\u0002\u0002\u0016Y\u0003\u0002\u0002\u0002\u0018[\u0003\u0002\u0002\u0002\u001a]\u0003\u0002\u0002\u0002\u001c_\u0003\u0002\u0002\u0002\u001ea\u0003\u0002\u0002\u0002 c\u0003\u0002\u0002\u0002\"e\u0003\u0002\u0002\u0002$n\u0003\u0002\u0002\u0002&t\u0003\u0002\u0002\u0002(\u0081\u0003\u0002\u0002\u0002*,\u0005\u0004\u0003\u0002+*\u0003\u0002\u0002\u0002,/\u0003\u0002\u0002\u0002-+\u0003\u0002\u0002\u0002-.\u0003\u0002\u0002\u0002.\u0003\u0003\u0002\u0002\u0002/-\u0003\u0002\u0002\u000203\u0005\b\u0005\u000213\u0005\u0006\u0004\u000220\u0003\u0002\u0002\u000221\u0003\u0002\u0002\u00023\u0005\u0003\u0002\u0002\u000247\u0005\u000e\b\u000257\u0005\u0012\n\u000264\u0003\u0002\u0002\u000265\u0003\u0002\u0002\u00027\u0007\u0003\u0002\u0002\u00028;\u0005\n\u0006\u00029;\u0005\f\u0007\u0002:8\u0003\u0002\u0002\u0002:9\u0003\u0002\u0002\u0002;\t\u0003\u0002\u0002\u0002<=\u0007\u0003\u0002\u0002=\u000b\u0003\u0002\u0002\u0002>?\u0007\u0004\u0002\u0002?\r\u0003\u0002\u0002\u0002@A\u0005\u0010\t\u0002AE\u0007\u0011\u0002\u0002BD\u0005\u0004\u0003\u0002CB\u0003\u0002\u0002\u0002DG\u0003\u0002\u0002\u0002EC\u0003\u0002\u0002\u0002EF\u0003\u0002\u0002\u0002FH\u0003\u0002\u0002\u0002GE\u0003\u0002\u0002\u0002HI\u0007\u0012\u0002\u0002I\u000f\u0003\u0002\u0002\u0002JK\u0007\u0010\u0002\u0002K\u0011\u0003\u0002\u0002\u0002LM\u0005\u0014\u000b\u0002MN\u0007\u0018\u0002\u0002NO\u0005\u0016\f\u0002O\u0013\u0003\u0002\u0002\u0002PQ\u0007\u0010\u0002\u0002Q\u0015\u0003\u0002\u0002\u0002RZ\u0005$\u0013\u0002SZ\u0005\u0018\r\u0002TZ\u0005\u001a\u000e\u0002UZ\u0005\u001c\u000f\u0002VZ\u0005\u001e\u0010\u0002WZ\u0005 \u0011\u0002XZ\u0005\"\u0012\u0002YR\u0003\u0002\u0002\u0002YS\u0003\u0002\u0002\u0002YT\u0003\u0002\u0002\u0002YU\u0003\u0002\u0002\u0002YV\u0003\u0002\u0002\u0002YW\u0003\u0002\u0002\u0002YX\u0003\u0002\u0002\u0002Z\u0017\u0003\u0002\u0002\u0002[\\\t\u0002\u0002\u0002\\\u0019\u0003\u0002\u0002\u0002]^\u0007\u0010\u0002\u0002^\u001b\u0003\u0002\u0002\u0002_`\u0007\u0006\u0002\u0002`\u001d\u0003\u0002\u0002\u0002ab\u0007\u0007\u0002\u0002b\u001f\u0003\u0002\u0002\u0002cd\u0007\u000b\u0002\u0002d!\u0003\u0002\u0002\u0002ei\u0007\u0005\u0002\u0002fh\t\u0003\u0002\u0002gf\u0003\u0002\u0002\u0002hk\u0003\u0002\u0002\u0002ig\u0003\u0002\u0002\u0002ij\u0003\u0002\u0002\u0002jl\u0003\u0002\u0002\u0002ki\u0003\u0002\u0002\u0002lm\u0007$\u0002\u0002m#\u0003\u0002\u0002\u0002np\u0007\u0013\u0002\u0002oq\u0005&\u0014\u0002po\u0003\u0002\u0002\u0002pq\u0003\u0002\u0002\u0002qr\u0003\u0002\u0002\u0002rs\u0007\u0014\u0002\u0002s%\u0003\u0002\u0002\u0002ty\u0005(\u0015\u0002uw\u0007\u0016\u0002\u0002vx\u0005&\u0014\u0002wv\u0003\u0002\u0002\u0002wx\u0003\u0002\u0002\u0002xz\u0003\u0002\u0002\u0002yu\u0003\u0002\u0002\u0002yz\u0003\u0002\u0002\u0002z'\u0003\u0002\u0002\u0002{\u0082\u0005\u0018\r\u0002|\u0082\u0005\u001a\u000e\u0002}\u0082\u0005\u001c\u000f\u0002~\u0082\u0005\u001e\u0010\u0002\u007f\u0082\u0005 \u0011\u0002\u0080\u0082\u0005\"\u0012\u0002\u0081{\u0003\u0002\u0002\u0002\u0081|\u0003\u0002\u0002\u0002\u0081}\u0003\u0002\u0002\u0002\u0081~\u0003\u0002\u0002\u0002\u0081\u007f\u0003\u0002\u0002\u0002\u0081\u0080\u0003\u0002\u0002\u0002\u0082)\u0003\u0002\u0002\u0002\r-26:EYipwy\u0081";
    }
    
    @Override
    public ATN getATN() {
        return CandleParser._ATN;
    }
    
    public CandleParser(final TokenStream input) {
        super(input);
        this._interp = (ATNInterpreter)new ParserATNSimulator(this, CandleParser._ATN, CandleParser._decisionToDFA, CandleParser._sharedContextCache);
    }
    
    public final CandleContext candle() throws RecognitionException {
        final CandleContext _localctx = new CandleContext(this._ctx, this.getState());
        this.enterRule(_localctx, 0, 0);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(43);
            this._errHandler.sync(this);
            for (int _la = this._input.LA(1); (_la & 0xFFFFFFC0) == 0x0 && (1L << _la & 0x4006L) != 0x0L; _la = this._input.LA(1)) {
                this.setState(40);
                this.expression();
                this.setState(45);
                this._errHandler.sync(this);
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final ExpressionContext expression() throws RecognitionException {
        final ExpressionContext _localctx = new ExpressionContext(this._ctx, this.getState());
        this.enterRule(_localctx, 2, 1);
        try {
            this.setState(48);
            switch (this._input.LA(1)) {
                case 1:
                case 2: {
                    this.enterOuterAlt(_localctx, 1);
                    this.setState(46);
                    this.comment();
                    break;
                }
                case 14: {
                    this.enterOuterAlt(_localctx, 2);
                    this.setState(47);
                    this.assignment();
                    break;
                }
                default: {
                    throw new NoViableAltException(this);
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final AssignmentContext assignment() throws RecognitionException {
        final AssignmentContext _localctx = new AssignmentContext(this._ctx, this.getState());
        this.enterRule(_localctx, 4, 2);
        try {
            this.setState(52);
            switch (((Recognizer<Symbol, ParserATNSimulator>)this).getInterpreter().adaptivePredict(this._input, 2, this._ctx)) {
                case 1: {
                    this.enterOuterAlt(_localctx, 1);
                    this.setState(50);
                    this.object();
                    break;
                }
                case 2: {
                    this.enterOuterAlt(_localctx, 2);
                    this.setState(51);
                    this.property();
                    break;
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final CommentContext comment() throws RecognitionException {
        final CommentContext _localctx = new CommentContext(this._ctx, this.getState());
        this.enterRule(_localctx, 6, 3);
        try {
            this.setState(56);
            switch (this._input.LA(1)) {
                case 1: {
                    this.enterOuterAlt(_localctx, 1);
                    this.setState(54);
                    this.commentMultiline();
                    break;
                }
                case 2: {
                    this.enterOuterAlt(_localctx, 2);
                    this.setState(55);
                    this.commentSingleline();
                    break;
                }
                default: {
                    throw new NoViableAltException(this);
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final CommentMultilineContext commentMultiline() throws RecognitionException {
        final CommentMultilineContext _localctx = new CommentMultilineContext(this._ctx, this.getState());
        this.enterRule(_localctx, 8, 4);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(58);
            this.match(1);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final CommentSinglelineContext commentSingleline() throws RecognitionException {
        final CommentSinglelineContext _localctx = new CommentSinglelineContext(this._ctx, this.getState());
        this.enterRule(_localctx, 10, 5);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(60);
            this.match(2);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final ObjectContext object() throws RecognitionException {
        final ObjectContext _localctx = new ObjectContext(this._ctx, this.getState());
        this.enterRule(_localctx, 12, 6);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(62);
            this.objectIdentifier();
            this.setState(63);
            this.match(15);
            this.setState(67);
            this._errHandler.sync(this);
            for (int _la = this._input.LA(1); (_la & 0xFFFFFFC0) == 0x0 && (1L << _la & 0x4006L) != 0x0L; _la = this._input.LA(1)) {
                this.setState(64);
                this.expression();
                this.setState(69);
                this._errHandler.sync(this);
            }
            this.setState(70);
            this.match(16);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final ObjectIdentifierContext objectIdentifier() throws RecognitionException {
        final ObjectIdentifierContext _localctx = new ObjectIdentifierContext(this._ctx, this.getState());
        this.enterRule(_localctx, 14, 7);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(72);
            this.match(14);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyContext property() throws RecognitionException {
        final PropertyContext _localctx = new PropertyContext(this._ctx, this.getState());
        this.enterRule(_localctx, 16, 8);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(74);
            this.propertyIdentifier();
            this.setState(75);
            this.match(22);
            this.setState(76);
            this.propertyValue();
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyIdentifierContext propertyIdentifier() throws RecognitionException {
        final PropertyIdentifierContext _localctx = new PropertyIdentifierContext(this._ctx, this.getState());
        this.enterRule(_localctx, 18, 9);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(78);
            this.match(14);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueContext propertyValue() throws RecognitionException {
        final PropertyValueContext _localctx = new PropertyValueContext(this._ctx, this.getState());
        this.enterRule(_localctx, 20, 10);
        try {
            this.setState(87);
            switch (this._input.LA(1)) {
                case 17: {
                    this.enterOuterAlt(_localctx, 1);
                    this.setState(80);
                    this.propertyValueArray();
                    break;
                }
                case 7:
                case 12: {
                    this.enterOuterAlt(_localctx, 2);
                    this.setState(81);
                    this.propertyValueBoolean();
                    break;
                }
                case 14: {
                    this.enterOuterAlt(_localctx, 3);
                    this.setState(82);
                    this.propertyValueEnum();
                    break;
                }
                case 4: {
                    this.enterOuterAlt(_localctx, 4);
                    this.setState(83);
                    this.propertyValueFloat();
                    break;
                }
                case 5: {
                    this.enterOuterAlt(_localctx, 5);
                    this.setState(84);
                    this.propertyValueInteger();
                    break;
                }
                case 9: {
                    this.enterOuterAlt(_localctx, 6);
                    this.setState(85);
                    this.propertyValueNull();
                    break;
                }
                case 3: {
                    this.enterOuterAlt(_localctx, 7);
                    this.setState(86);
                    this.propertyValueString();
                    break;
                }
                default: {
                    throw new NoViableAltException(this);
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueBooleanContext propertyValueBoolean() throws RecognitionException {
        final PropertyValueBooleanContext _localctx = new PropertyValueBooleanContext(this._ctx, this.getState());
        this.enterRule(_localctx, 22, 11);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(89);
            final int _la = this._input.LA(1);
            if (_la != 7 && _la != 12) {
                this._errHandler.recoverInline(this);
            }
            else {
                this.consume();
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueEnumContext propertyValueEnum() throws RecognitionException {
        final PropertyValueEnumContext _localctx = new PropertyValueEnumContext(this._ctx, this.getState());
        this.enterRule(_localctx, 24, 12);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(91);
            this.match(14);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueFloatContext propertyValueFloat() throws RecognitionException {
        final PropertyValueFloatContext _localctx = new PropertyValueFloatContext(this._ctx, this.getState());
        this.enterRule(_localctx, 26, 13);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(93);
            this.match(4);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueIntegerContext propertyValueInteger() throws RecognitionException {
        final PropertyValueIntegerContext _localctx = new PropertyValueIntegerContext(this._ctx, this.getState());
        this.enterRule(_localctx, 28, 14);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(95);
            this.match(5);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueNullContext propertyValueNull() throws RecognitionException {
        final PropertyValueNullContext _localctx = new PropertyValueNullContext(this._ctx, this.getState());
        this.enterRule(_localctx, 30, 15);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(97);
            this.match(9);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueStringContext propertyValueString() throws RecognitionException {
        final PropertyValueStringContext _localctx = new PropertyValueStringContext(this._ctx, this.getState());
        this.enterRule(_localctx, 32, 16);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(99);
            this.match(3);
            this.setState(103);
            this._errHandler.sync(this);
            for (int _la = this._input.LA(1); (_la & 0xFFFFFFC0) == 0x0 && (1L << _la & 0x3FE000000L) != 0x0L; _la = this._input.LA(1)) {
                this.setState(100);
                _la = this._input.LA(1);
                if ((_la & 0xFFFFFFC0) != 0x0 || (1L << _la & 0x3FE000000L) == 0x0L) {
                    this._errHandler.recoverInline(this);
                }
                else {
                    this.consume();
                }
                this.setState(105);
                this._errHandler.sync(this);
            }
            this.setState(106);
            this.match(34);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueArrayContext propertyValueArray() throws RecognitionException {
        final PropertyValueArrayContext _localctx = new PropertyValueArrayContext(this._ctx, this.getState());
        this.enterRule(_localctx, 34, 17);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(108);
            this.match(17);
            this.setState(110);
            final int _la = this._input.LA(1);
            if ((_la & 0xFFFFFFC0) == 0x0 && (1L << _la & 0x52B8L) != 0x0L) {
                this.setState(109);
                this.propertyValueArrayElementList();
            }
            this.setState(112);
            this.match(18);
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueArrayElementListContext propertyValueArrayElementList() throws RecognitionException {
        final PropertyValueArrayElementListContext _localctx = new PropertyValueArrayElementListContext(this._ctx, this.getState());
        this.enterRule(_localctx, 36, 18);
        try {
            this.enterOuterAlt(_localctx, 1);
            this.setState(114);
            this.propertyValueArrayElement();
            this.setState(119);
            int _la = this._input.LA(1);
            if (_la == 20) {
                this.setState(115);
                this.match(20);
                this.setState(117);
                _la = this._input.LA(1);
                if ((_la & 0xFFFFFFC0) == 0x0 && (1L << _la & 0x52B8L) != 0x0L) {
                    this.setState(116);
                    this.propertyValueArrayElementList();
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    public final PropertyValueArrayElementContext propertyValueArrayElement() throws RecognitionException {
        final PropertyValueArrayElementContext _localctx = new PropertyValueArrayElementContext(this._ctx, this.getState());
        this.enterRule(_localctx, 38, 19);
        try {
            this.setState(127);
            switch (this._input.LA(1)) {
                case 7:
                case 12: {
                    this.enterOuterAlt(_localctx, 1);
                    this.setState(121);
                    this.propertyValueBoolean();
                    break;
                }
                case 14: {
                    this.enterOuterAlt(_localctx, 2);
                    this.setState(122);
                    this.propertyValueEnum();
                    break;
                }
                case 4: {
                    this.enterOuterAlt(_localctx, 3);
                    this.setState(123);
                    this.propertyValueFloat();
                    break;
                }
                case 5: {
                    this.enterOuterAlt(_localctx, 4);
                    this.setState(124);
                    this.propertyValueInteger();
                    break;
                }
                case 9: {
                    this.enterOuterAlt(_localctx, 5);
                    this.setState(125);
                    this.propertyValueNull();
                    break;
                }
                case 3: {
                    this.enterOuterAlt(_localctx, 6);
                    this.setState(126);
                    this.propertyValueString();
                    break;
                }
                default: {
                    throw new NoViableAltException(this);
                }
            }
        }
        catch (RecognitionException re) {
            _localctx.exception = re;
            this._errHandler.reportError(this, re);
            this._errHandler.recover(this, re);
        }
        finally {
            this.exitRule();
        }
        return _localctx;
    }
    
    static {
        RuntimeMetaData.checkVersion("4.5", "4.5");
        _sharedContextCache = new PredictionContextCache();
        ruleNames = new String[] { "candle", "expression", "assignment", "comment", "commentMultiline", "commentSingleline", "object", "objectIdentifier", "property", "propertyIdentifier", "propertyValue", "propertyValueBoolean", "propertyValueEnum", "propertyValueFloat", "propertyValueInteger", "propertyValueNull", "propertyValueString", "propertyValueArray", "propertyValueArrayElementList", "propertyValueArrayElement" };
        _LITERAL_NAMES = new String[] { null, null, null, null, null, null, "'copy'", "'false'", "'include'", null, "'object'", "'property'", "'true'", "'try'", null, "'{'", "'}'", "'['", "']'", "':'", "','", "'.'", "'='", "';'", null, "'\\\"'", "'\\\\'", "'\\b'", "'\\f'", "'\\n'", "'\\r'", "'\\t'" };
        _SYMBOLIC_NAMES = new String[] { null, "COMMENT", "COMMENT_LINE", "STRING_LITERAL_START", "NUMBER_FLOAT", "NUMBER_INTEGER", "COPY", "FALSE", "INCLUDE", "NULL", "OBJECT", "PROPERTY", "TRUE", "TRY", "IDENTIFIER", "BRACE_OPEN", "BRACE_CLOSE", "BRACKET_OPEN", "BRACKET_CLOSE", "COLON", "COMMA", "DOT", "EQUALS", "SEMICOLON", "WHITESPACE", "STRING_LITERAL_QUOTE", "STRING_LITERAL_BACKSLASH", "STRING_LITERAL_BACKSPACE", "STRING_LITERAL_FORMFILL", "STRING_LITERAL_NEWLINE", "STRING_LITERAL_CARRIAGE_RETURN", "STRING_LITERAL_HORIZONTAL_TAB", "STRING_LITERAL_ESCAPE_UNICODE", "STRING_LITERAL_TEXT", "STRING_LITERAL_END" };
        VOCABULARY = new VocabularyImpl(CandleParser._LITERAL_NAMES, CandleParser._SYMBOLIC_NAMES);
        tokenNames = new String[CandleParser._SYMBOLIC_NAMES.length];
        for (int i = 0; i < CandleParser.tokenNames.length; ++i) {
            CandleParser.tokenNames[i] = CandleParser.VOCABULARY.getLiteralName(i);
            if (CandleParser.tokenNames[i] == null) {
                CandleParser.tokenNames[i] = CandleParser.VOCABULARY.getSymbolicName(i);
            }
            if (CandleParser.tokenNames[i] == null) {
                CandleParser.tokenNames[i] = "<INVALID>";
            }
        }
        _ATN = new ATNDeserializer().deserialize("\u0003\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\u0003$\u0084\u0004\u0002\t\u0002\u0004\u0003\t\u0003\u0004\u0004\t\u0004\u0004\u0005\t\u0005\u0004\u0006\t\u0006\u0004\u0007\t\u0007\u0004\b\t\b\u0004\t\t\t\u0004\n\t\n\u0004\u000b\t\u000b\u0004\f\t\f\u0004\r\t\r\u0004\u000e\t\u000e\u0004\u000f\t\u000f\u0004\u0010\t\u0010\u0004\u0011\t\u0011\u0004\u0012\t\u0012\u0004\u0013\t\u0013\u0004\u0014\t\u0014\u0004\u0015\t\u0015\u0003\u0002\u0007\u0002,\n\u0002\f\u0002\u000e\u0002/\u000b\u0002\u0003\u0003\u0003\u0003\u0005\u00033\n\u0003\u0003\u0004\u0003\u0004\u0005\u00047\n\u0004\u0003\u0005\u0003\u0005\u0005\u0005;\n\u0005\u0003\u0006\u0003\u0006\u0003\u0007\u0003\u0007\u0003\b\u0003\b\u0003\b\u0007\bD\n\b\f\b\u000e\bG\u000b\b\u0003\b\u0003\b\u0003\t\u0003\t\u0003\n\u0003\n\u0003\n\u0003\n\u0003\u000b\u0003\u000b\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0003\f\u0005\fZ\n\f\u0003\r\u0003\r\u0003\u000e\u0003\u000e\u0003\u000f\u0003\u000f\u0003\u0010\u0003\u0010\u0003\u0011\u0003\u0011\u0003\u0012\u0003\u0012\u0007\u0012h\n\u0012\f\u0012\u000e\u0012k\u000b\u0012\u0003\u0012\u0003\u0012\u0003\u0013\u0003\u0013\u0005\u0013q\n\u0013\u0003\u0013\u0003\u0013\u0003\u0014\u0003\u0014\u0003\u0014\u0005\u0014x\n\u0014\u0005\u0014z\n\u0014\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0003\u0015\u0005\u0015\u0082\n\u0015\u0003\u0015\u0002\u0002\u0016\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(\u0002\u0004\u0004\u0002\t\t\u000e\u000e\u0003\u0002\u001b#\u0083\u0002-\u0003\u0002\u0002\u0002\u00042\u0003\u0002\u0002\u0002\u00066\u0003\u0002\u0002\u0002\b:\u0003\u0002\u0002\u0002\n<\u0003\u0002\u0002\u0002\f>\u0003\u0002\u0002\u0002\u000e@\u0003\u0002\u0002\u0002\u0010J\u0003\u0002\u0002\u0002\u0012L\u0003\u0002\u0002\u0002\u0014P\u0003\u0002\u0002\u0002\u0016Y\u0003\u0002\u0002\u0002\u0018[\u0003\u0002\u0002\u0002\u001a]\u0003\u0002\u0002\u0002\u001c_\u0003\u0002\u0002\u0002\u001ea\u0003\u0002\u0002\u0002 c\u0003\u0002\u0002\u0002\"e\u0003\u0002\u0002\u0002$n\u0003\u0002\u0002\u0002&t\u0003\u0002\u0002\u0002(\u0081\u0003\u0002\u0002\u0002*,\u0005\u0004\u0003\u0002+*\u0003\u0002\u0002\u0002,/\u0003\u0002\u0002\u0002-+\u0003\u0002\u0002\u0002-.\u0003\u0002\u0002\u0002.\u0003\u0003\u0002\u0002\u0002/-\u0003\u0002\u0002\u000203\u0005\b\u0005\u000213\u0005\u0006\u0004\u000220\u0003\u0002\u0002\u000221\u0003\u0002\u0002\u00023\u0005\u0003\u0002\u0002\u000247\u0005\u000e\b\u000257\u0005\u0012\n\u000264\u0003\u0002\u0002\u000265\u0003\u0002\u0002\u00027\u0007\u0003\u0002\u0002\u00028;\u0005\n\u0006\u00029;\u0005\f\u0007\u0002:8\u0003\u0002\u0002\u0002:9\u0003\u0002\u0002\u0002;\t\u0003\u0002\u0002\u0002<=\u0007\u0003\u0002\u0002=\u000b\u0003\u0002\u0002\u0002>?\u0007\u0004\u0002\u0002?\r\u0003\u0002\u0002\u0002@A\u0005\u0010\t\u0002AE\u0007\u0011\u0002\u0002BD\u0005\u0004\u0003\u0002CB\u0003\u0002\u0002\u0002DG\u0003\u0002\u0002\u0002EC\u0003\u0002\u0002\u0002EF\u0003\u0002\u0002\u0002FH\u0003\u0002\u0002\u0002GE\u0003\u0002\u0002\u0002HI\u0007\u0012\u0002\u0002I\u000f\u0003\u0002\u0002\u0002JK\u0007\u0010\u0002\u0002K\u0011\u0003\u0002\u0002\u0002LM\u0005\u0014\u000b\u0002MN\u0007\u0018\u0002\u0002NO\u0005\u0016\f\u0002O\u0013\u0003\u0002\u0002\u0002PQ\u0007\u0010\u0002\u0002Q\u0015\u0003\u0002\u0002\u0002RZ\u0005$\u0013\u0002SZ\u0005\u0018\r\u0002TZ\u0005\u001a\u000e\u0002UZ\u0005\u001c\u000f\u0002VZ\u0005\u001e\u0010\u0002WZ\u0005 \u0011\u0002XZ\u0005\"\u0012\u0002YR\u0003\u0002\u0002\u0002YS\u0003\u0002\u0002\u0002YT\u0003\u0002\u0002\u0002YU\u0003\u0002\u0002\u0002YV\u0003\u0002\u0002\u0002YW\u0003\u0002\u0002\u0002YX\u0003\u0002\u0002\u0002Z\u0017\u0003\u0002\u0002\u0002[\\\t\u0002\u0002\u0002\\\u0019\u0003\u0002\u0002\u0002]^\u0007\u0010\u0002\u0002^\u001b\u0003\u0002\u0002\u0002_`\u0007\u0006\u0002\u0002`\u001d\u0003\u0002\u0002\u0002ab\u0007\u0007\u0002\u0002b\u001f\u0003\u0002\u0002\u0002cd\u0007\u000b\u0002\u0002d!\u0003\u0002\u0002\u0002ei\u0007\u0005\u0002\u0002fh\t\u0003\u0002\u0002gf\u0003\u0002\u0002\u0002hk\u0003\u0002\u0002\u0002ig\u0003\u0002\u0002\u0002ij\u0003\u0002\u0002\u0002jl\u0003\u0002\u0002\u0002ki\u0003\u0002\u0002\u0002lm\u0007$\u0002\u0002m#\u0003\u0002\u0002\u0002np\u0007\u0013\u0002\u0002oq\u0005&\u0014\u0002po\u0003\u0002\u0002\u0002pq\u0003\u0002\u0002\u0002qr\u0003\u0002\u0002\u0002rs\u0007\u0014\u0002\u0002s%\u0003\u0002\u0002\u0002ty\u0005(\u0015\u0002uw\u0007\u0016\u0002\u0002vx\u0005&\u0014\u0002wv\u0003\u0002\u0002\u0002wx\u0003\u0002\u0002\u0002xz\u0003\u0002\u0002\u0002yu\u0003\u0002\u0002\u0002yz\u0003\u0002\u0002\u0002z'\u0003\u0002\u0002\u0002{\u0082\u0005\u0018\r\u0002|\u0082\u0005\u001a\u000e\u0002}\u0082\u0005\u001c\u000f\u0002~\u0082\u0005\u001e\u0010\u0002\u007f\u0082\u0005 \u0011\u0002\u0080\u0082\u0005\"\u0012\u0002\u0081{\u0003\u0002\u0002\u0002\u0081|\u0003\u0002\u0002\u0002\u0081}\u0003\u0002\u0002\u0002\u0081~\u0003\u0002\u0002\u0002\u0081\u007f\u0003\u0002\u0002\u0002\u0081\u0080\u0003\u0002\u0002\u0002\u0082)\u0003\u0002\u0002\u0002\r-26:EYipwy\u0081".toCharArray());
        _decisionToDFA = new DFA[CandleParser._ATN.getNumberOfDecisions()];
        for (int i = 0; i < CandleParser._ATN.getNumberOfDecisions(); ++i) {
            CandleParser._decisionToDFA[i] = new DFA(CandleParser._ATN.getDecisionState(i), i);
        }
    }
    
    public static class CandleContext extends ParserRuleContext
    {
        public List<ExpressionContext> expression() {
            return this.getRuleContexts((Class<? extends ExpressionContext>)ExpressionContext.class);
        }
        
        public ExpressionContext expression(final int i) {
            return this.getRuleContext((Class<? extends ExpressionContext>)ExpressionContext.class, i);
        }
        
        public CandleContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 0;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterCandle(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitCandle(this);
            }
        }
    }
    
    public static class ExpressionContext extends ParserRuleContext
    {
        public CommentContext comment() {
            return this.getRuleContext((Class<? extends CommentContext>)CommentContext.class, 0);
        }
        
        public AssignmentContext assignment() {
            return this.getRuleContext((Class<? extends AssignmentContext>)AssignmentContext.class, 0);
        }
        
        public ExpressionContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 1;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterExpression(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitExpression(this);
            }
        }
    }
    
    public static class AssignmentContext extends ParserRuleContext
    {
        public ObjectContext object() {
            return this.getRuleContext((Class<? extends ObjectContext>)ObjectContext.class, 0);
        }
        
        public PropertyContext property() {
            return this.getRuleContext((Class<? extends PropertyContext>)PropertyContext.class, 0);
        }
        
        public AssignmentContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 2;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterAssignment(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitAssignment(this);
            }
        }
    }
    
    public static class CommentContext extends ParserRuleContext
    {
        public CommentMultilineContext commentMultiline() {
            return this.getRuleContext((Class<? extends CommentMultilineContext>)CommentMultilineContext.class, 0);
        }
        
        public CommentSinglelineContext commentSingleline() {
            return this.getRuleContext((Class<? extends CommentSinglelineContext>)CommentSinglelineContext.class, 0);
        }
        
        public CommentContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 3;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterComment(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitComment(this);
            }
        }
    }
    
    public static class CommentMultilineContext extends ParserRuleContext
    {
        public TerminalNode COMMENT() {
            return this.getToken(1, 0);
        }
        
        public CommentMultilineContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 4;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterCommentMultiline(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitCommentMultiline(this);
            }
        }
    }
    
    public static class CommentSinglelineContext extends ParserRuleContext
    {
        public TerminalNode COMMENT_LINE() {
            return this.getToken(2, 0);
        }
        
        public CommentSinglelineContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 5;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterCommentSingleline(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitCommentSingleline(this);
            }
        }
    }
    
    public static class ObjectContext extends ParserRuleContext
    {
        public ObjectIdentifierContext objectIdentifier() {
            return this.getRuleContext((Class<? extends ObjectIdentifierContext>)ObjectIdentifierContext.class, 0);
        }
        
        public TerminalNode BRACE_OPEN() {
            return this.getToken(15, 0);
        }
        
        public TerminalNode BRACE_CLOSE() {
            return this.getToken(16, 0);
        }
        
        public List<ExpressionContext> expression() {
            return this.getRuleContexts((Class<? extends ExpressionContext>)ExpressionContext.class);
        }
        
        public ExpressionContext expression(final int i) {
            return this.getRuleContext((Class<? extends ExpressionContext>)ExpressionContext.class, i);
        }
        
        public ObjectContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 6;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterObject(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitObject(this);
            }
        }
    }
    
    public static class ObjectIdentifierContext extends ParserRuleContext
    {
        public TerminalNode IDENTIFIER() {
            return this.getToken(14, 0);
        }
        
        public ObjectIdentifierContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 7;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterObjectIdentifier(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitObjectIdentifier(this);
            }
        }
    }
    
    public static class PropertyContext extends ParserRuleContext
    {
        public PropertyIdentifierContext propertyIdentifier() {
            return this.getRuleContext((Class<? extends PropertyIdentifierContext>)PropertyIdentifierContext.class, 0);
        }
        
        public TerminalNode EQUALS() {
            return this.getToken(22, 0);
        }
        
        public PropertyValueContext propertyValue() {
            return this.getRuleContext((Class<? extends PropertyValueContext>)PropertyValueContext.class, 0);
        }
        
        public PropertyContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 8;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterProperty(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitProperty(this);
            }
        }
    }
    
    public static class PropertyIdentifierContext extends ParserRuleContext
    {
        public TerminalNode IDENTIFIER() {
            return this.getToken(14, 0);
        }
        
        public PropertyIdentifierContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 9;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyIdentifier(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyIdentifier(this);
            }
        }
    }
    
    public static class PropertyValueContext extends ParserRuleContext
    {
        public PropertyValueArrayContext propertyValueArray() {
            return this.getRuleContext((Class<? extends PropertyValueArrayContext>)PropertyValueArrayContext.class, 0);
        }
        
        public PropertyValueBooleanContext propertyValueBoolean() {
            return this.getRuleContext((Class<? extends PropertyValueBooleanContext>)PropertyValueBooleanContext.class, 0);
        }
        
        public PropertyValueEnumContext propertyValueEnum() {
            return this.getRuleContext((Class<? extends PropertyValueEnumContext>)PropertyValueEnumContext.class, 0);
        }
        
        public PropertyValueFloatContext propertyValueFloat() {
            return this.getRuleContext((Class<? extends PropertyValueFloatContext>)PropertyValueFloatContext.class, 0);
        }
        
        public PropertyValueIntegerContext propertyValueInteger() {
            return this.getRuleContext((Class<? extends PropertyValueIntegerContext>)PropertyValueIntegerContext.class, 0);
        }
        
        public PropertyValueNullContext propertyValueNull() {
            return this.getRuleContext((Class<? extends PropertyValueNullContext>)PropertyValueNullContext.class, 0);
        }
        
        public PropertyValueStringContext propertyValueString() {
            return this.getRuleContext((Class<? extends PropertyValueStringContext>)PropertyValueStringContext.class, 0);
        }
        
        public PropertyValueContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 10;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValue(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValue(this);
            }
        }
    }
    
    public static class PropertyValueBooleanContext extends ParserRuleContext
    {
        public TerminalNode TRUE() {
            return this.getToken(12, 0);
        }
        
        public TerminalNode FALSE() {
            return this.getToken(7, 0);
        }
        
        public PropertyValueBooleanContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 11;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueBoolean(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueBoolean(this);
            }
        }
    }
    
    public static class PropertyValueEnumContext extends ParserRuleContext
    {
        public TerminalNode IDENTIFIER() {
            return this.getToken(14, 0);
        }
        
        public PropertyValueEnumContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 12;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueEnum(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueEnum(this);
            }
        }
    }
    
    public static class PropertyValueFloatContext extends ParserRuleContext
    {
        public TerminalNode NUMBER_FLOAT() {
            return this.getToken(4, 0);
        }
        
        public PropertyValueFloatContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 13;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueFloat(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueFloat(this);
            }
        }
    }
    
    public static class PropertyValueIntegerContext extends ParserRuleContext
    {
        public TerminalNode NUMBER_INTEGER() {
            return this.getToken(5, 0);
        }
        
        public PropertyValueIntegerContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 14;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueInteger(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueInteger(this);
            }
        }
    }
    
    public static class PropertyValueNullContext extends ParserRuleContext
    {
        public TerminalNode NULL() {
            return this.getToken(9, 0);
        }
        
        public PropertyValueNullContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 15;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueNull(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueNull(this);
            }
        }
    }
    
    public static class PropertyValueStringContext extends ParserRuleContext
    {
        public TerminalNode STRING_LITERAL_START() {
            return this.getToken(3, 0);
        }
        
        public TerminalNode STRING_LITERAL_END() {
            return this.getToken(34, 0);
        }
        
        public List<TerminalNode> STRING_LITERAL_QUOTE() {
            return this.getTokens(25);
        }
        
        public TerminalNode STRING_LITERAL_QUOTE(final int i) {
            return this.getToken(25, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_BACKSLASH() {
            return this.getTokens(26);
        }
        
        public TerminalNode STRING_LITERAL_BACKSLASH(final int i) {
            return this.getToken(26, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_BACKSPACE() {
            return this.getTokens(27);
        }
        
        public TerminalNode STRING_LITERAL_BACKSPACE(final int i) {
            return this.getToken(27, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_FORMFILL() {
            return this.getTokens(28);
        }
        
        public TerminalNode STRING_LITERAL_FORMFILL(final int i) {
            return this.getToken(28, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_NEWLINE() {
            return this.getTokens(29);
        }
        
        public TerminalNode STRING_LITERAL_NEWLINE(final int i) {
            return this.getToken(29, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_CARRIAGE_RETURN() {
            return this.getTokens(30);
        }
        
        public TerminalNode STRING_LITERAL_CARRIAGE_RETURN(final int i) {
            return this.getToken(30, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_HORIZONTAL_TAB() {
            return this.getTokens(31);
        }
        
        public TerminalNode STRING_LITERAL_HORIZONTAL_TAB(final int i) {
            return this.getToken(31, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_ESCAPE_UNICODE() {
            return this.getTokens(32);
        }
        
        public TerminalNode STRING_LITERAL_ESCAPE_UNICODE(final int i) {
            return this.getToken(32, i);
        }
        
        public List<TerminalNode> STRING_LITERAL_TEXT() {
            return this.getTokens(33);
        }
        
        public TerminalNode STRING_LITERAL_TEXT(final int i) {
            return this.getToken(33, i);
        }
        
        public PropertyValueStringContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 16;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueString(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueString(this);
            }
        }
    }
    
    public static class PropertyValueArrayContext extends ParserRuleContext
    {
        public TerminalNode BRACKET_OPEN() {
            return this.getToken(17, 0);
        }
        
        public TerminalNode BRACKET_CLOSE() {
            return this.getToken(18, 0);
        }
        
        public PropertyValueArrayElementListContext propertyValueArrayElementList() {
            return this.getRuleContext((Class<? extends PropertyValueArrayElementListContext>)PropertyValueArrayElementListContext.class, 0);
        }
        
        public PropertyValueArrayContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 17;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueArray(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueArray(this);
            }
        }
    }
    
    public static class PropertyValueArrayElementListContext extends ParserRuleContext
    {
        public PropertyValueArrayElementContext propertyValueArrayElement() {
            return this.getRuleContext((Class<? extends PropertyValueArrayElementContext>)PropertyValueArrayElementContext.class, 0);
        }
        
        public TerminalNode COMMA() {
            return this.getToken(20, 0);
        }
        
        public PropertyValueArrayElementListContext propertyValueArrayElementList() {
            return this.getRuleContext((Class<? extends PropertyValueArrayElementListContext>)PropertyValueArrayElementListContext.class, 0);
        }
        
        public PropertyValueArrayElementListContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 18;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueArrayElementList(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueArrayElementList(this);
            }
        }
    }
    
    public static class PropertyValueArrayElementContext extends ParserRuleContext
    {
        public PropertyValueBooleanContext propertyValueBoolean() {
            return this.getRuleContext((Class<? extends PropertyValueBooleanContext>)PropertyValueBooleanContext.class, 0);
        }
        
        public PropertyValueEnumContext propertyValueEnum() {
            return this.getRuleContext((Class<? extends PropertyValueEnumContext>)PropertyValueEnumContext.class, 0);
        }
        
        public PropertyValueFloatContext propertyValueFloat() {
            return this.getRuleContext((Class<? extends PropertyValueFloatContext>)PropertyValueFloatContext.class, 0);
        }
        
        public PropertyValueIntegerContext propertyValueInteger() {
            return this.getRuleContext((Class<? extends PropertyValueIntegerContext>)PropertyValueIntegerContext.class, 0);
        }
        
        public PropertyValueNullContext propertyValueNull() {
            return this.getRuleContext((Class<? extends PropertyValueNullContext>)PropertyValueNullContext.class, 0);
        }
        
        public PropertyValueStringContext propertyValueString() {
            return this.getRuleContext((Class<? extends PropertyValueStringContext>)PropertyValueStringContext.class, 0);
        }
        
        public PropertyValueArrayElementContext(final ParserRuleContext parent, final int invokingState) {
            super(parent, invokingState);
        }
        
        @Override
        public int getRuleIndex() {
            return 19;
        }
        
        @Override
        public void enterRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).enterPropertyValueArrayElement(this);
            }
        }
        
        @Override
        public void exitRule(final ParseTreeListener listener) {
            if (listener instanceof CandleParserListener) {
                ((CandleParserListener)listener).exitPropertyValueArrayElement(this);
            }
        }
    }
}
