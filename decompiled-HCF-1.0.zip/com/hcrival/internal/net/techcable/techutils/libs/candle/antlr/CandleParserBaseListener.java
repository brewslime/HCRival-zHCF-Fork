package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.tree.*;

public class CandleParserBaseListener implements CandleParserListener
{
    @Override
    public void enterCandle(final CandleParser.CandleContext ctx) {
    }
    
    @Override
    public void exitCandle(final CandleParser.CandleContext ctx) {
    }
    
    @Override
    public void enterExpression(final CandleParser.ExpressionContext ctx) {
    }
    
    @Override
    public void exitExpression(final CandleParser.ExpressionContext ctx) {
    }
    
    @Override
    public void enterAssignment(final CandleParser.AssignmentContext ctx) {
    }
    
    @Override
    public void exitAssignment(final CandleParser.AssignmentContext ctx) {
    }
    
    @Override
    public void enterComment(final CandleParser.CommentContext ctx) {
    }
    
    @Override
    public void exitComment(final CandleParser.CommentContext ctx) {
    }
    
    @Override
    public void enterCommentMultiline(final CandleParser.CommentMultilineContext ctx) {
    }
    
    @Override
    public void exitCommentMultiline(final CandleParser.CommentMultilineContext ctx) {
    }
    
    @Override
    public void enterCommentSingleline(final CandleParser.CommentSinglelineContext ctx) {
    }
    
    @Override
    public void exitCommentSingleline(final CandleParser.CommentSinglelineContext ctx) {
    }
    
    @Override
    public void enterObject(final CandleParser.ObjectContext ctx) {
    }
    
    @Override
    public void exitObject(final CandleParser.ObjectContext ctx) {
    }
    
    @Override
    public void enterObjectIdentifier(final CandleParser.ObjectIdentifierContext ctx) {
    }
    
    @Override
    public void exitObjectIdentifier(final CandleParser.ObjectIdentifierContext ctx) {
    }
    
    @Override
    public void enterProperty(final CandleParser.PropertyContext ctx) {
    }
    
    @Override
    public void exitProperty(final CandleParser.PropertyContext ctx) {
    }
    
    @Override
    public void enterPropertyIdentifier(final CandleParser.PropertyIdentifierContext ctx) {
    }
    
    @Override
    public void exitPropertyIdentifier(final CandleParser.PropertyIdentifierContext ctx) {
    }
    
    @Override
    public void enterPropertyValue(final CandleParser.PropertyValueContext ctx) {
    }
    
    @Override
    public void exitPropertyValue(final CandleParser.PropertyValueContext ctx) {
    }
    
    @Override
    public void enterPropertyValueBoolean(final CandleParser.PropertyValueBooleanContext ctx) {
    }
    
    @Override
    public void exitPropertyValueBoolean(final CandleParser.PropertyValueBooleanContext ctx) {
    }
    
    @Override
    public void enterPropertyValueEnum(final CandleParser.PropertyValueEnumContext ctx) {
    }
    
    @Override
    public void exitPropertyValueEnum(final CandleParser.PropertyValueEnumContext ctx) {
    }
    
    @Override
    public void enterPropertyValueFloat(final CandleParser.PropertyValueFloatContext ctx) {
    }
    
    @Override
    public void exitPropertyValueFloat(final CandleParser.PropertyValueFloatContext ctx) {
    }
    
    @Override
    public void enterPropertyValueInteger(final CandleParser.PropertyValueIntegerContext ctx) {
    }
    
    @Override
    public void exitPropertyValueInteger(final CandleParser.PropertyValueIntegerContext ctx) {
    }
    
    @Override
    public void enterPropertyValueNull(final CandleParser.PropertyValueNullContext ctx) {
    }
    
    @Override
    public void exitPropertyValueNull(final CandleParser.PropertyValueNullContext ctx) {
    }
    
    @Override
    public void enterPropertyValueString(final CandleParser.PropertyValueStringContext ctx) {
    }
    
    @Override
    public void exitPropertyValueString(final CandleParser.PropertyValueStringContext ctx) {
    }
    
    @Override
    public void enterPropertyValueArray(final CandleParser.PropertyValueArrayContext ctx) {
    }
    
    @Override
    public void exitPropertyValueArray(final CandleParser.PropertyValueArrayContext ctx) {
    }
    
    @Override
    public void enterPropertyValueArrayElementList(final CandleParser.PropertyValueArrayElementListContext ctx) {
    }
    
    @Override
    public void exitPropertyValueArrayElementList(final CandleParser.PropertyValueArrayElementListContext ctx) {
    }
    
    @Override
    public void enterPropertyValueArrayElement(final CandleParser.PropertyValueArrayElementContext ctx) {
    }
    
    @Override
    public void exitPropertyValueArrayElement(final CandleParser.PropertyValueArrayElementContext ctx) {
    }
    
    @Override
    public void enterEveryRule(final ParserRuleContext ctx) {
    }
    
    @Override
    public void exitEveryRule(final ParserRuleContext ctx) {
    }
    
    @Override
    public void visitTerminal(final TerminalNode node) {
    }
    
    @Override
    public void visitErrorNode(final ErrorNode node) {
    }
}
