package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.*;

public class FloatArrayPropertyNode extends AbstractArrayPropertyNode
{
    private float[] array;
    
    public FloatArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final float[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    public FloatArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final Float[] array) {
        super(documentNode, name);
        final float[] primitiveArray = new float[array.length];
        for (int i = 0; i < primitiveArray.length; ++i) {
            primitiveArray[i] = array[i];
        }
        this.array(primitiveArray);
    }
    
    @Nonnull
    public float[] array() {
        return this.array;
    }
    
    @Nonnull
    @Nonnegative
    public float[] arrayUnsigned() {
        for (final float current : this.array) {
            if (current < 0.0f) {
                throw new IllegalStateException("Expected an unsigned value but got " + current);
            }
        }
        return this.array;
    }
    
    @Nonnull
    public FloatArrayPropertyNode array(@Nonnull final float[] array) {
        this.array = array;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.FLOAT;
    }
    
    @Override
    public int length() {
        return this.array.length;
    }
    
    @Override
    public String toString() {
        return String.format("FloatArrayPropertyNode{%s,array=%s}", super.toString(), Arrays.toString(this.array()));
    }
}
