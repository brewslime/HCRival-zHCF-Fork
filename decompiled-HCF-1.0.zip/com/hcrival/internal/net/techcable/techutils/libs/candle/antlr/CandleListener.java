package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.candle.*;
import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.error.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array.*;
import java.util.*;
import java.util.function.*;
import java.lang.reflect.*;

public class CandleListener extends CandleParserBaseListener
{
    private final Candle candle;
    private String lastIdentifier;
    private final Stack<ObjectNode> objectNodeStack;
    private List<Object> arrayContent;
    
    public CandleListener(@Nonnull final Candle candle) {
        this.objectNodeStack = new Stack<ObjectNode>();
        this.arrayContent = null;
        this.candle = candle;
        this.objectNodeStack.push(candle);
    }
    
    @Override
    public void enterCommentMultiline(final CandleParser.CommentMultilineContext ctx) {
        this.objectNodeStack.peek().append(new CommentNode(this.candle, ctx.getText().substring(2, ctx.getText().length() - 2)));
    }
    
    @Override
    public void enterCommentSingleline(final CandleParser.CommentSinglelineContext ctx) {
        this.objectNodeStack.peek().append(new CommentNode(this.candle, ctx.getText().substring(2)));
    }
    
    @Override
    public void exitObject(final CandleParser.ObjectContext ctx) {
        this.objectNodeStack.pop();
    }
    
    @Override
    public void enterObjectIdentifier(final CandleParser.ObjectIdentifierContext ctx) {
        final ObjectNode node = new ObjectNode(this.candle, ctx.getText());
        this.objectNodeStack.peek().append(node);
        this.objectNodeStack.push(node);
    }
    
    @Override
    public void enterPropertyIdentifier(final CandleParser.PropertyIdentifierContext ctx) {
        this.lastIdentifier = ctx.getText();
    }
    
    @Override
    public void enterPropertyValueBoolean(final CandleParser.PropertyValueBooleanContext ctx) {
        final boolean value = Boolean.parseBoolean(ctx.getText());
        if (this.arrayContent != null) {
            this.arrayContent.add(value);
        }
        else {
            this.objectNodeStack.peek().append(new BooleanPropertyNode(this.candle, this.lastIdentifier, value));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueEnum(final CandleParser.PropertyValueEnumContext ctx) {
        final String value = ctx.getText();
        if (this.arrayContent != null) {
            this.arrayContent.add(new EnumWrapper(value));
        }
        else {
            this.objectNodeStack.peek().append(new EnumPropertyNode(this.candle, this.lastIdentifier, value));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueFloat(final CandleParser.PropertyValueFloatContext ctx) {
        final float value = Float.parseFloat(ctx.getText());
        if (this.arrayContent != null) {
            this.arrayContent.add(value);
        }
        else {
            this.objectNodeStack.peek().append(new FloatPropertyNode(this.candle, this.lastIdentifier, value));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueInteger(final CandleParser.PropertyValueIntegerContext ctx) {
        final int value = Integer.decode(ctx.getText());
        if (this.arrayContent != null) {
            this.arrayContent.add(value);
        }
        else {
            this.objectNodeStack.peek().append(new IntegerPropertyNode(this.candle, this.lastIdentifier, value));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueNull(final CandleParser.PropertyValueNullContext ctx) {
        if (this.arrayContent != null) {
            this.arrayContent.add(null);
        }
        else {
            this.objectNodeStack.peek().append(new NullPropertyNode(this.candle, this.lastIdentifier));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueString(final CandleParser.PropertyValueStringContext ctx) {
        String value = ctx.getText().substring(1);
        value = value.substring(0, value.length() - 1);
        if (this.arrayContent != null) {
            this.arrayContent.add(value);
        }
        else {
            this.objectNodeStack.peek().append(new StringPropertyNode(this.candle, this.lastIdentifier, value));
            this.lastIdentifier = null;
        }
    }
    
    @Override
    public void enterPropertyValueArray(final CandleParser.PropertyValueArrayContext ctx) {
        this.arrayContent = new ArrayList<Object>();
    }
    
    @Override
    public void exitPropertyValueArray(final CandleParser.PropertyValueArrayContext ctx) {
        final List<Object> arrayContent = this.arrayContent;
        this.arrayContent = null;
        Object firstSaneValue = null;
        for (Iterator<Object> arrayContentIterator = arrayContent.iterator(); arrayContentIterator.hasNext() && firstSaneValue == null; firstSaneValue = arrayContentIterator.next()) {}
        if (firstSaneValue == null) {
            this.objectNodeStack.peek().append(new NullArrayPropertyNode(this.candle, this.lastIdentifier));
        }
        else if (firstSaneValue.getClass().equals(Boolean.class)) {
            this.objectNodeStack.peek().append(new BooleanArrayPropertyNode(this.candle, this.lastIdentifier, this.getArrayContents(arrayContent, Boolean.class, () -> false)));
        }
        else if (firstSaneValue.getClass().equals(EnumWrapper.class)) {
            final String[] values = Arrays.stream((Object[])this.getArrayContents(arrayContent, (Class<T>)EnumWrapper.class)).map(e -> {
                if (e == null) {
                    return null;
                }
                else {
                    return e.name;
                }
            }).toArray(String[]::new);
            this.objectNodeStack.peek().append(new EnumArrayPropertyNode((IDocumentNode)this.candle, this.lastIdentifier, values));
        }
        else if (firstSaneValue.getClass().equals(Float.class)) {
            this.objectNodeStack.peek().append(new FloatArrayPropertyNode(this.candle, this.lastIdentifier, this.getArrayContents(arrayContent, Float.class, () -> 0.0f)));
        }
        else if (firstSaneValue.getClass().equals(Integer.class)) {
            this.objectNodeStack.peek().append(new IntegerArrayPropertyNode(this.candle, this.lastIdentifier, this.getArrayContents(arrayContent, Integer.class, () -> 0)));
        }
        else {
            if (!firstSaneValue.getClass().equals(String.class)) {
                throw new RuntimeException(new CandleParserException("Cannot handle array element of type " + firstSaneValue.getClass().getCanonicalName()));
            }
            this.objectNodeStack.peek().append(new StringArrayPropertyNode(this.candle, this.lastIdentifier, this.getArrayContents(arrayContent, String.class)));
        }
    }
    
    @Nonnull
    protected <R> R[] getArrayContents(@Nonnull final List<Object> objects, @Nonnull final Class<R> type) {
        return this.getArrayContents(objects, type, () -> null);
    }
    
    @Nonnull
    protected <R> R[] getArrayContents(@Nonnull final List<Object> objects, @Nonnull final Class<R> type, @Nonnull final Supplier<R> ifNull) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokeinterface java/util/List.stream:()Ljava/util/stream/Stream;
        //     6: aload_2         /* type */
        //     7: aload_3         /* ifNull */
        //     8: invokedynamic   BootstrapMethod #6, apply:(Ljava/lang/Class;Ljava/util/function/Supplier;)Ljava/util/function/Function;
        //    13: invokeinterface java/util/stream/Stream.map:(Ljava/util/function/Function;)Ljava/util/stream/Stream;
        //    18: aload_2         /* type */
        //    19: invokedynamic   BootstrapMethod #7, apply:(Ljava/lang/Class;)Ljava/util/function/IntFunction;
        //    24: invokeinterface java/util/stream/Stream.toArray:(Ljava/util/function/IntFunction;)[Ljava/lang/Object;
        //    29: areturn        
        //    Signature:
        //  <R:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/Object;>;Ljava/lang/Class<TR;>;Ljava/util/function/Supplier<TR;>;)[TR;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at us.deathmarine.luyten.FileSaver.doSaveJarDecompiled(FileSaver.java:192)
        //     at us.deathmarine.luyten.FileSaver.access$300(FileSaver.java:45)
        //     at us.deathmarine.luyten.FileSaver$4.run(FileSaver.java:112)
        //     at java.lang.Thread.run(Unknown Source)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static class EnumWrapper
    {
        public String name;
        
        public EnumWrapper(@Nonnull final String name) {
            this.name = name;
        }
    }
}
