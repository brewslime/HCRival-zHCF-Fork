package com.hcrival.internal.net.techcable.techutils.libs.candle.node;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public abstract class AbstractNode implements INode
{
    private IDocumentNode documentNode;
    
    public AbstractNode(@Nonnull final IDocumentNode documentNode) {
        this.documentNode = documentNode;
    }
    
    protected AbstractNode() {
    }
    
    @Nonnull
    @Override
    public IDocumentNode document() {
        return this.documentNode;
    }
    
    @Nonnull
    @Override
    public AbstractNode ensureType(@Nonnull final NodeType type) throws IllegalStateException {
        if (this.type() != type) {
            throw new IllegalStateException("Expected node of type " + type + " but found " + this.type());
        }
        return this;
    }
}
