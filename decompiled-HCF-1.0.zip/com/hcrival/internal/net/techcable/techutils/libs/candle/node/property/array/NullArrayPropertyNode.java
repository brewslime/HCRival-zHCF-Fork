package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class NullArrayPropertyNode extends AbstractArrayPropertyNode
{
    public NullArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name) {
        super(documentNode, name);
    }
    
    @Nonnull
    @Override
    public NullArrayPropertyNode ensureItemType(@Nonnull final NodeValueType valueType) throws IllegalStateException {
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.NULL;
    }
    
    @Override
    public int length() {
        return 0;
    }
    
    @Override
    public String toString() {
        return String.format("NullArrayPropertyNode{%s}", super.toString());
    }
}
