package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.error.*;

public class LexerErrorListener extends BaseErrorListener
{
    @Override
    public void syntaxError(final Recognizer<?, ?> recognizer, final Object offendingSymbol, final int line, final int charPositionInLine, final String msg, final RecognitionException ex) {
        throw new RuntimeException(new CandleLexerException(offendingSymbol, line, charPositionInLine, msg, ex));
    }
}
