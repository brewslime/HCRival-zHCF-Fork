package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.*;

public class StringArrayPropertyNode extends AbstractArrayPropertyNode
{
    private String[] array;
    
    public StringArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final String[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    public String[] array() {
        return this.array;
    }
    
    public StringArrayPropertyNode array(final String[] array) {
        this.array = array;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.STRING;
    }
    
    @Override
    public int length() {
        return this.array.length;
    }
    
    @Override
    public String toString() {
        return String.format("StringArrayPropertyNode{%s,array=%s}", super.toString(), Arrays.toString(this.array()));
    }
}
