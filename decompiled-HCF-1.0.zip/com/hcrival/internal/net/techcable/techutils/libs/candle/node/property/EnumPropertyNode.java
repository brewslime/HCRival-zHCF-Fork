package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class EnumPropertyNode extends AbstractPropertyNode
{
    private String value;
    
    public EnumPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final String value) {
        super(documentNode, name);
        this.value(value);
    }
    
    public EnumPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final Enum value) {
        super(documentNode, name);
        this.value(value);
    }
    
    @Nonnull
    public String value() {
        return this.value;
    }
    
    @Nonnull
    public EnumPropertyNode value(final String value) {
        this.value = value;
        return this;
    }
    
    @Nonnull
    public <T extends Enum> T value(@Nonnull final Class<T> enumType) throws IllegalStateException {
        try {
            return Enum.valueOf(enumType, this.value());
        }
        catch (IllegalArgumentException ex) {
            throw new IllegalStateException("Enum of type " + enumType.getCanonicalName() + " does not contain possible value \"" + this.value() + "\"", ex);
        }
    }
    
    @Nonnull
    public EnumPropertyNode value(@Nonnull final Enum value) {
        this.value(value.name());
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.ENUM;
    }
    
    @Override
    public String toString() {
        return String.format("EnumPropertyNode{%s,value=%s}", super.toString(), this.value());
    }
}
