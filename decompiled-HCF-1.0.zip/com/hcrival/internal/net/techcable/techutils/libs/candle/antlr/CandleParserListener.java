package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.antlr.tree.*;

public interface CandleParserListener extends ParseTreeListener
{
    void enterCandle(final CandleParser.CandleContext p0);
    
    void exitCandle(final CandleParser.CandleContext p0);
    
    void enterExpression(final CandleParser.ExpressionContext p0);
    
    void exitExpression(final CandleParser.ExpressionContext p0);
    
    void enterAssignment(final CandleParser.AssignmentContext p0);
    
    void exitAssignment(final CandleParser.AssignmentContext p0);
    
    void enterComment(final CandleParser.CommentContext p0);
    
    void exitComment(final CandleParser.CommentContext p0);
    
    void enterCommentMultiline(final CandleParser.CommentMultilineContext p0);
    
    void exitCommentMultiline(final CandleParser.CommentMultilineContext p0);
    
    void enterCommentSingleline(final CandleParser.CommentSinglelineContext p0);
    
    void exitCommentSingleline(final CandleParser.CommentSinglelineContext p0);
    
    void enterObject(final CandleParser.ObjectContext p0);
    
    void exitObject(final CandleParser.ObjectContext p0);
    
    void enterObjectIdentifier(final CandleParser.ObjectIdentifierContext p0);
    
    void exitObjectIdentifier(final CandleParser.ObjectIdentifierContext p0);
    
    void enterProperty(final CandleParser.PropertyContext p0);
    
    void exitProperty(final CandleParser.PropertyContext p0);
    
    void enterPropertyIdentifier(final CandleParser.PropertyIdentifierContext p0);
    
    void exitPropertyIdentifier(final CandleParser.PropertyIdentifierContext p0);
    
    void enterPropertyValue(final CandleParser.PropertyValueContext p0);
    
    void exitPropertyValue(final CandleParser.PropertyValueContext p0);
    
    void enterPropertyValueBoolean(final CandleParser.PropertyValueBooleanContext p0);
    
    void exitPropertyValueBoolean(final CandleParser.PropertyValueBooleanContext p0);
    
    void enterPropertyValueEnum(final CandleParser.PropertyValueEnumContext p0);
    
    void exitPropertyValueEnum(final CandleParser.PropertyValueEnumContext p0);
    
    void enterPropertyValueFloat(final CandleParser.PropertyValueFloatContext p0);
    
    void exitPropertyValueFloat(final CandleParser.PropertyValueFloatContext p0);
    
    void enterPropertyValueInteger(final CandleParser.PropertyValueIntegerContext p0);
    
    void exitPropertyValueInteger(final CandleParser.PropertyValueIntegerContext p0);
    
    void enterPropertyValueNull(final CandleParser.PropertyValueNullContext p0);
    
    void exitPropertyValueNull(final CandleParser.PropertyValueNullContext p0);
    
    void enterPropertyValueString(final CandleParser.PropertyValueStringContext p0);
    
    void exitPropertyValueString(final CandleParser.PropertyValueStringContext p0);
    
    void enterPropertyValueArray(final CandleParser.PropertyValueArrayContext p0);
    
    void exitPropertyValueArray(final CandleParser.PropertyValueArrayContext p0);
    
    void enterPropertyValueArrayElementList(final CandleParser.PropertyValueArrayElementListContext p0);
    
    void exitPropertyValueArrayElementList(final CandleParser.PropertyValueArrayElementListContext p0);
    
    void enterPropertyValueArrayElement(final CandleParser.PropertyValueArrayElementContext p0);
    
    void exitPropertyValueArrayElement(final CandleParser.PropertyValueArrayElementContext p0);
}
