package com.hcrival.internal.net.techcable.techutils.libs.candle.antlr;

import com.hcrival.internal.net.techcable.techutils.libs.candle.api.error.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.misc.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;

public class ParserErrorStrategy extends BailErrorStrategy
{
    @Override
    public void recover(final Parser recognizer, final RecognitionException e) {
        try {
            super.recover(recognizer, e);
        }
        catch (ParseCancellationException ex) {
            throw new RuntimeException(new CandleParserException(ex.getMessage(), ex));
        }
    }
    
    @Override
    public Token recoverInline(final Parser recognizer) throws RecognitionException {
        try {
            return super.recoverInline(recognizer);
        }
        catch (ParseCancellationException ex) {
            throw new RuntimeException(new CandleParserException(ex.getMessage(), ex));
        }
    }
}
