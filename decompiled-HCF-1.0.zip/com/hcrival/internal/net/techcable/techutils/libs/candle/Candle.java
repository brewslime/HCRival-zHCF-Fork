package com.hcrival.internal.net.techcable.techutils.libs.candle;

import com.hcrival.internal.net.techcable.techutils.libs.candle.node.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.error.*;
import java.io.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.antlr.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.tree.*;

public class Candle extends ObjectNode implements IDocumentNode
{
    @Nonnull
    public Candle read(@Nonnull final File file) throws CandleException, IOException {
        return this.read(file.getPath());
    }
    
    @Nonnull
    public Candle read(@Nonnull final String fileName) throws CandleException, IOException {
        return this.read(new ANTLRFileStream(fileName));
    }
    
    @Nonnull
    public Candle read(@Nonnull final InputStream inputStream) throws CandleException, IOException {
        return this.read(new ANTLRInputStream(inputStream));
    }
    
    @Nonnull
    protected Candle read(@Nonnull final ANTLRInputStream inputStream) throws CandleException {
        try {
            final CandleLexer lexer = new CandleLexer(inputStream);
            lexer.addErrorListener(new LexerErrorListener());
            final CommonTokenStream tokenStream = new CommonTokenStream(lexer);
            final CandleParser parser = new CandleParser(tokenStream);
            parser.setErrorHandler(new ParserErrorStrategy());
            final ParseTreeWalker walker = new ParseTreeWalker();
            final CandleListener listener = new CandleListener(this);
            this.clear();
            walker.walk(listener, parser.candle());
            return this;
        }
        catch (RuntimeException ex) {
            if (ex.getCause() instanceof CandleException) {
                throw (CandleException)ex.getCause();
            }
            throw ex;
        }
    }
    
    @Override
    public String toString() {
        return String.format("Candle{children=[%s]}", this.children());
    }
}
