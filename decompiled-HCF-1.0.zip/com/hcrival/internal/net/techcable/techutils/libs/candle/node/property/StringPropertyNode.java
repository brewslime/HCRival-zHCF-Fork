package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property;

import javax.annotation.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;

public class StringPropertyNode extends AbstractPropertyNode
{
    private String value;
    
    public StringPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final String value) {
        super(documentNode, name);
        this.value(value);
    }
    
    @Nonnull
    public String value() {
        return this.value;
    }
    
    @Nonnull
    public StringPropertyNode value(@Nonnull final String value) {
        this.value = value;
        return this;
    }
    
    @Nonnull
    @Override
    public NodeValueType valueType() {
        return NodeValueType.STRING;
    }
    
    @Override
    public String toString() {
        return String.format("StringPropertyNode{%s,value=\"%s\"}", super.toString(), this.value());
    }
}
