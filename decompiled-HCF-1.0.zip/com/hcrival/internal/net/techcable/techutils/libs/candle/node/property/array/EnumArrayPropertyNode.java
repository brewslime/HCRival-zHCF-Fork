package com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array;

import javax.annotation.*;
import java.lang.reflect.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import java.util.*;

public class EnumArrayPropertyNode extends AbstractArrayPropertyNode
{
    private String[] array;
    
    public EnumArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final String[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    public <T extends Enum> EnumArrayPropertyNode(@Nonnull final IDocumentNode documentNode, @Nonnull final String name, @Nonnull final T[] array) {
        super(documentNode, name);
        this.array(array);
    }
    
    @Nonnull
    public String[] array() {
        return this.array;
    }
    
    @Nonnull
    public <T extends Enum> T[] array(@Nonnull final Class<T> enumType) {
        try {
            final T[] array = (T[])Array.newInstance(enumType, this.length());
            for (int i = 0; i < this.length(); ++i) {
                final String currentElement = this.array()[i];
                array[i] = (T)((currentElement != null) ? Enum.valueOf(enumType, currentElement) : null);
            }
            return array;
        }
        catch (IllegalArgumentException ex) {
            throw new IllegalStateException("Enum contains one or more values not listed by type " + enumType.getCanonicalName() + ": " + ex.getMessage(), ex);
        }
    }
    
    @Nonnull
    public EnumArrayPropertyNode array(@Nonnull final String[] array) {
        this.array = array;
        return this;
    }
    
    @Nonnull
    public <T extends Enum> EnumArrayPropertyNode array(@Nonnull final T[] array) {
        final String[] convertedArray = new String[array.length];
        for (int i = 0; i < array.length; ++i) {
            convertedArray[i] = ((array[i] != null) ? array[i].name() : null);
        }
        return this.array(convertedArray);
    }
    
    @Nonnull
    @Override
    public NodeValueType itemType() {
        return NodeValueType.STRING;
    }
    
    @Override
    public int length() {
        return this.array.length;
    }
    
    @Override
    public String toString() {
        return String.format("EnumArrayPropertyNode{%s,array=%s}", super.toString(), Arrays.toString(this.array()));
    }
}
