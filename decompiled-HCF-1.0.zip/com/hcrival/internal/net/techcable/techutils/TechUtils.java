package com.hcrival.internal.net.techcable.techutils;

import org.bukkit.*;

public class TechUtils
{
    public static void assertMainThread() {
        if (!Bukkit.isPrimaryThread()) {
            throw new UnsupportedOperationException("Asynchronous access is unsupported");
        }
    }
}
