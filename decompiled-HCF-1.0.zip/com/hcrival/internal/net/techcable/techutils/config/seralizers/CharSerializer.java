package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class CharSerializer implements ConfigSerializer<Character>
{
    @Override
    public Object serialize(final Character character, final Annotation[] annotations) {
        return character;
    }
    
    @Override
    public Character deserialize(final Object yaml, final Class<? extends Character> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Character)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Character.TYPE || type == Character.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
