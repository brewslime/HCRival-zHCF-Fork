package com.hcrival.internal.net.techcable.techutils.config;

import java.lang.annotation.*;
import org.bukkit.configuration.*;

public interface ConfigSerializer<T>
{
    Object serialize(final T p0, final Annotation[] p1);
    
    T deserialize(final Object p0, final Class<? extends T> p1, final Annotation[] p2) throws InvalidConfigurationException;
    
    boolean canDeserialize(final Class<?> p0, final Class<?> p1);
    
    boolean canSerialize(final Class<?> p0);
}
