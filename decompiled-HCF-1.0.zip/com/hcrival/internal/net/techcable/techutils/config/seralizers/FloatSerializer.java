package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class FloatSerializer implements ConfigSerializer<Float>
{
    @Override
    public Object serialize(final Float aFloat, final Annotation[] annotations) {
        return aFloat;
    }
    
    @Override
    public Float deserialize(final Object yaml, final Class<? extends Float> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Float)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Float.TYPE || type == Float.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
