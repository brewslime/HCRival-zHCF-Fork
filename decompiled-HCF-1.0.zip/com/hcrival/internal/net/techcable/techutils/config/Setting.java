package com.hcrival.internal.net.techcable.techutils.config;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface Setting {
    String value();
}
