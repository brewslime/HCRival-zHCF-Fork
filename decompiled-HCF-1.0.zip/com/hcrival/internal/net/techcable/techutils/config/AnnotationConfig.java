package com.hcrival.internal.net.techcable.techutils.config;

import java.lang.annotation.*;
import java.util.concurrent.locks.*;
import java.net.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.*;
import org.bukkit.configuration.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.error.*;
import com.google.common.primitives.*;
import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.function.*;
import java.util.*;
import com.google.common.base.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.array.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.node.property.*;
import org.apache.commons.lang.*;
import com.google.common.collect.*;
import com.hcrival.internal.net.techcable.techutils.libs.candle.api.*;
import com.hcrival.internal.net.techcable.techutils.libs.antlr.*;
import com.hcrival.internal.net.techcable.techutils.collect.*;
import com.hcrival.internal.net.techcable.techutils.config.seralizers.*;

public class AnnotationConfig
{
    private static final ListMultimap<Class<? extends Annotation>, ConfigSerializer> serializers;
    private static final Map<Class<? extends Annotation>, Lock> locks;
    public static final Object EMPTY_COLLECTION_FIRST_OBJECT;
    
    public static void addSerializer(final Class<? extends Annotation> annotation, final ConfigSerializer serializer) {
        final Lock lock = getOrCreateLock(annotation);
        lock.lock();
        try {
            if (hasSerializer(annotation, serializer.getClass())) {
                throw new IllegalStateException("Serializer of type " + serializer.getClass().getSimpleName() + " already exists" + ((Setting.class == annotation) ? "." : (" for annotation " + annotation.getSimpleName() + ".")));
            }
            AnnotationConfig.serializers.put(annotation, serializer);
        }
        finally {
            lock.unlock();
        }
    }
    
    public static Lock getOrCreateLock(final Class<? extends Annotation> annotation) {
        Lock lock = AnnotationConfig.locks.get(annotation);
        if (lock == null) {
            synchronized (AnnotationConfig.locks) {
                lock = AnnotationConfig.locks.get(annotation);
                if (lock == null) {
                    lock = new ReentrantLock();
                    AnnotationConfig.locks.put(annotation, lock);
                }
            }
        }
        return lock;
    }
    
    public static void addSerializerBefore(final ConfigSerializer serializer, final Class<? extends ConfigSerializer> before) {
        addSerializerBefore(Setting.class, serializer, before);
    }
    
    public static void addSerializerBefore(final Class<? extends Annotation> annotation, final ConfigSerializer serializer, final Class<? extends ConfigSerializer> after) {
        final Lock lock = getOrCreateLock(annotation);
        lock.lock();
        try {
            if (hasSerializer(annotation, serializer.getClass())) {
                throw new IllegalStateException("Serializer of type " + serializer.getClass().getSimpleName() + " already exists" + ((Setting.class == annotation) ? "." : (" for annotation " + annotation.getSimpleName() + ".")));
            }
            final List<ConfigSerializer> serializers = (List<ConfigSerializer>)AnnotationConfig.serializers.get(annotation);
            for (int i = 0; i < serializers.size(); ++i) {
                final ConfigSerializer existing = serializers.get(i);
                if (existing.getClass() == after) {
                    serializers.add(i, serializer);
                    return;
                }
            }
            throw new IllegalStateException("Can insert serializer after " + after.getSimpleName());
        }
        finally {
            lock.unlock();
        }
    }
    
    public static void addSerializer(final ConfigSerializer serializer) {
        addSerializer(Setting.class, serializer);
    }
    
    public static boolean hasSerializer(final Class<? extends Annotation> annotation, final Class<? extends ConfigSerializer> serializerType) {
        final Lock lock = getOrCreateLock(annotation);
        lock.lock();
        try {
            for (final ConfigSerializer existing : AnnotationConfig.serializers.get(annotation)) {
                if (existing.getClass() == serializerType) {
                    return true;
                }
            }
            return false;
        }
        finally {
            lock.unlock();
        }
    }
    
    public static ConfigSerializer getDeserializer(final Class<?> candleType, final Class<?> into, final Annotation... annotations) {
        for (final Annotation annotation : annotations) {
            if (!Setting.class.isAssignableFrom(annotation.annotationType())) {
                for (final ConfigSerializer<?> serializer : AnnotationConfig.serializers.get(annotation.annotationType())) {
                    if (serializer.canDeserialize(candleType, into)) {
                        return serializer;
                    }
                }
            }
        }
        for (final ConfigSerializer<?> serializer2 : AnnotationConfig.serializers.get(Setting.class)) {
            if (serializer2.canDeserialize(candleType, into)) {
                return serializer2;
            }
        }
        return null;
    }
    
    public static ConfigSerializer getSerializer(final Class<?> type, final Annotation... annotations) {
        for (final Annotation annotation : annotations) {
            if (!Setting.class.isInstance(annotation)) {
                for (final ConfigSerializer<?> serializer : AnnotationConfig.serializers.get(annotation.getClass())) {
                    if (serializer.canSerialize(type)) {
                        return serializer;
                    }
                }
            }
        }
        for (final ConfigSerializer<?> serializer2 : AnnotationConfig.serializers.get(Setting.class)) {
            if (serializer2.canSerialize(type)) {
                return serializer2;
            }
        }
        return null;
    }
    
    public void load(final File configFile, final URL defaultConfigUrl) throws IOException, InvalidConfigurationException {
        final Candle config = new Candle();
        boolean shouldSave = false;
        Candle defaultConfig = null;
        Label_0111: {
            if (configFile.exists()) {
                try {
                    config.read(configFile);
                    break Label_0111;
                }
                catch (FileNotFoundException e) {
                    throw new RuntimeException("File not found after checked for existence", e);
                }
                catch (CandleException e2) {
                    final String realMsg = getReason(e2);
                    throw new InvalidConfigurationException("Unable to parse config" + ((realMsg != null) ? (": " + realMsg) : ""), (Throwable)e2);
                }
            }
            shouldSave = true;
            try {
                defaultConfig = new Candle().read(defaultConfigUrl.openStream());
            }
            catch (CandleException e3) {
                final String realMsg2 = getReason(e3);
                throw new InvalidConfigurationException("Invalid default config" + ((realMsg2 != null) ? (": " + realMsg2) : ""), (Throwable)e3);
            }
        }
        for (final Field field : this.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(Setting.class)) {
                final String key = field.getAnnotation(Setting.class).value();
                if (!contains(defaultConfig, key)) {
                    throw new InvalidConfigurationException("Unknown key: " + key);
                }
                INamedNode candle;
                if (contains(config, key)) {
                    candle = config.get(key, INamedNode.class);
                }
                else {
                    candle = defaultConfig.get(key, INamedNode.class);
                }
                final Object yaml = this.fromCandle(candle);
                final Class<?> yamlType = Primitives.unwrap(yaml.getClass());
                final ConfigSerializer serializer = getDeserializer(yamlType, field.getType(), field.getDeclaredAnnotations());
                if (serializer == null) {
                    throw new InvalidConfigurationException("No serializer for the type " + field.getType().getSimpleName());
                }
                final Object java = serializer.deserialize(yaml, field.getType(), field.getDeclaredAnnotations());
                final Class<?> javaType = Primitives.unwrap(field.getType());
                if (!Primitives.isWrapperType(java.getClass()) && !javaType.isPrimitive() && !javaType.isInstance(java)) {
                    throw new InvalidConfigurationException(key + " is not instanceof " + field.getType().getSimpleName() + ", it is " + java.getClass().getSimpleName());
                }
                Reflection.setField(field, this, java);
            }
        }
        if (shouldSave) {
            this.save(configFile, defaultConfigUrl);
        }
    }
    
    public void save(final File configFile, final URL defaultConfigUrl) throws IOException, InvalidConfigurationException {
        Candle defaultConfig;
        try {
            defaultConfig = new Candle().read(defaultConfigUrl.openStream());
        }
        catch (CandleException e) {
            final String realMsg = getReason(e);
            throw new InvalidConfigurationException("Invalid default config" + ((realMsg != null) ? (": " + realMsg) : ""), (Throwable)e);
        }
        final Candle config = new Candle();
        final Map<String, INamedNode> newValues = new HashMap<String, INamedNode>();
        for (final Field field : this.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(Setting.class)) {
                final String key = field.getAnnotation(Setting.class).value();
                try {
                    defaultConfig.get(key);
                }
                catch (NoSuchElementException e2) {
                    throw new InvalidConfigurationException("Unknown key: " + key, (Throwable)e2);
                }
                final Object rawValue = Reflection.getField(field, this);
                if (rawValue != null) {
                    final Class<?> javaType = Primitives.unwrap(field.getType());
                    final ConfigSerializer serializer = getSerializer(javaType, field.getDeclaredAnnotations());
                    if (serializer == null) {
                        throw new InvalidConfigurationException("No seralizer for the type " + javaType.getSimpleName());
                    }
                    final Object yamlValue = serializer.serialize(rawValue, field.getDeclaredAnnotations());
                    final INamedNode candleValue = this.toCandle(config, key, yamlValue);
                    newValues.put(key, candleValue);
                }
            }
        }
        final List<INode> ordered = new ArrayList<INode>(defaultConfig.size());
        defaultConfig.forEach(ordered::add);
        final List<INamedNode> list;
        final int index;
        final Map<K, INamedNode> map;
        final INamedNode newValue;
        ordered.stream().filter(INamedNode.class::isInstance).map((Function<? super Object, ?>)INamedNode.class::cast).filter(node -> newValues.containsKey(node.name())).forEach(node -> {
            index = list.indexOf(node);
            newValue = map.get(node.name());
            list.set(index, newValue);
            return;
        });
        config.clear();
    }
    
    private INamedNode toCandle(final IDocumentNode root, String key, final Object yamlValue) throws InvalidConfigurationException {
        key = key.substring(key.lastIndexOf(46) + 1);
        if (yamlValue instanceof Collection) {
            Collection<?> c = (Collection<?>)yamlValue;
            c = new ArrayList<Object>(c);
            c = Collections.unmodifiableCollection(c);
            final Object first = Iterables.getFirst(c, AnnotationConfig.EMPTY_COLLECTION_FIRST_OBJECT);
            if (first instanceof Collection) {
                throw new IllegalStateException("Candle does not support arrays of arrays");
            }
            if (first instanceof Map) {
                throw new IllegalStateException("Candle does not support arrays of objects");
            }
            if (first == null || first == AnnotationConfig.EMPTY_COLLECTION_FIRST_OBJECT) {
                if (first == null) {
                    c.forEach(e -> Preconditions.checkState(e == null, "Not everything in the array is null. One is: %s", new Object[] { e.getClass().getSimpleName() }));
                }
                return new NullArrayPropertyNode(root, key);
            }
            final Object o;
            final String firstName;
            final String elementName;
            final boolean isFirstType;
            c.forEach(e -> {
                firstName = o.getClass().getSimpleName();
                elementName = ((e == null) ? "null" : e.getClass().getSimpleName());
                isFirstType = o.getClass().isInstance(e);
                Preconditions.checkState(isFirstType, "Not everything in the array is a %s. One is: %s", new Object[] { firstName, elementName });
                return;
            });
            if (first instanceof Boolean) {
                final Boolean[] array = c.toArray(new Boolean[c.size()]);
                return new BooleanArrayPropertyNode(root, key, array);
            }
            if (first instanceof Enum) {
                final Enum[] array2 = c.toArray(new Enum[c.size()]);
                return new EnumArrayPropertyNode(root, key, (T[])array2);
            }
            if (first instanceof Float) {
                final Float[] array3 = c.toArray(new Float[c.size()]);
                return new FloatArrayPropertyNode(root, key, array3);
            }
            if (first instanceof Integer) {
                final Integer[] array4 = c.toArray(new Integer[c.size()]);
                return new IntegerArrayPropertyNode(root, key, array4);
            }
            if (first instanceof String) {
                final String[] array5 = c.toArray(new String[c.size()]);
                return new StringArrayPropertyNode(root, key, array5);
            }
            throw new IllegalStateException("Unsupported type: " + first.getClass().getSimpleName());
        }
        else {
            if (yamlValue instanceof Map) {
                throw new UnsupportedOperationException("Cannot currently convert maps to candle");
            }
            if (yamlValue instanceof Boolean) {
                return new BooleanPropertyNode(root, key, (boolean)yamlValue);
            }
            if (yamlValue instanceof Enum) {
                return new EnumPropertyNode(root, key, (Enum)yamlValue);
            }
            if (yamlValue instanceof Float) {
                return new FloatPropertyNode(root, key, (float)yamlValue);
            }
            if (yamlValue instanceof Integer) {
                return new IntegerPropertyNode(root, key, (int)yamlValue);
            }
            if (yamlValue instanceof String) {
                return new StringPropertyNode(root, key, (String)yamlValue);
            }
            throw new UnsupportedOperationException("Cannot convert " + yamlValue.getClass().getSimpleName() + " into candle");
        }
    }
    
    private Object fromCandle(final INamedNode candle) {
        if (candle instanceof IArrayPropertyNode) {
            switch (((IArrayPropertyNode)candle).itemType()) {
                case NULL: {
                    return new ArrayList();
                }
                case BOOLEAN: {
                    final BooleanArrayPropertyNode booleanArray = (BooleanArrayPropertyNode)candle;
                    final boolean[] primitiveBooleans = booleanArray.array();
                    final Boolean[] wrapperBooleans = ArrayUtils.toObject(primitiveBooleans);
                    return Lists.newArrayList(wrapperBooleans);
                }
                case ENUM: {
                    final EnumArrayPropertyNode enumArray = (EnumArrayPropertyNode)candle;
                    final String[] enumNames = enumArray.array();
                    return Lists.newArrayList(enumNames);
                }
                case FLOAT: {
                    final FloatArrayPropertyNode floatArray = (FloatArrayPropertyNode)candle;
                    final float[] primitiveFloats = floatArray.array();
                    final Float[] wrapperFloats = ArrayUtils.toObject(primitiveFloats);
                    return Lists.newArrayList(wrapperFloats);
                }
                case INTEGER: {
                    final IntegerArrayPropertyNode integerArray = (IntegerArrayPropertyNode)candle;
                    final int[] primitiveInts = integerArray.array();
                    final Integer[] wrapperIntegers = ArrayUtils.toObject(primitiveInts);
                    return Lists.newArrayList(wrapperIntegers);
                }
                case STRING: {
                    final StringArrayPropertyNode stringArray = (StringArrayPropertyNode)candle;
                    final String[] strings = stringArray.array();
                    return Lists.newArrayList(strings);
                }
                case ARRAY: {
                    throw new IllegalArgumentException("Cannot have arrays of arrays");
                }
                default: {
                    throw new UnsupportedOperationException("Unknown type: " + ((IArrayPropertyNode)candle).itemType().name());
                }
            }
        }
        else {
            if (candle instanceof IObjectNode) {
                throw new UnsupportedOperationException("Cannot currently deserialize objects");
            }
            if (!(candle instanceof IPropertyNode)) {
                throw new UnsupportedOperationException("Unknown node type: " + candle.getClass().getName());
            }
            switch (((IPropertyNode)candle).valueType()) {
                case NULL: {
                    return null;
                }
                case BOOLEAN: {
                    final BooleanPropertyNode booleanNode = (BooleanPropertyNode)candle;
                    return booleanNode.value();
                }
                case ENUM: {
                    final EnumPropertyNode enumNode = (EnumPropertyNode)candle;
                    return enumNode.value();
                }
                case FLOAT: {
                    final FloatPropertyNode floatNode = (FloatPropertyNode)candle;
                    return floatNode.value();
                }
                case INTEGER: {
                    final IntegerPropertyNode intNode = (IntegerPropertyNode)candle;
                    return intNode.value();
                }
                case STRING: {
                    final StringPropertyNode stringNode = (StringPropertyNode)candle;
                    return stringNode.value();
                }
                case ARRAY: {
                    throw new AssertionError((Object)"Already checked for array");
                }
                default: {
                    throw new UnsupportedOperationException("Unknown type: " + ((IPropertyNode)candle).type().name());
                }
            }
        }
    }
    
    private static boolean contains(final IObjectNode what, final String key) {
        try {
            return what.get(key) != null;
        }
        catch (NoSuchElementException e) {
            return false;
        }
    }
    
    private static void copy(final INamedNode from, final INamedNode to) {
        to.ensureType(from.type());
        if (!(from instanceof IPropertyNode)) {
            if (from instanceof IObjectNode) {
                final IObjectNode fromObj = (IObjectNode)from;
                final IObjectNode toObj = (IObjectNode)to;
                toObj.clear();
                fromObj.forEach(toObj::append);
            }
            return;
        }
        ((IPropertyNode)to).ensureValueType(((IPropertyNode)from).valueType());
        switch (((IPropertyNode)from).valueType()) {
            case NULL: {}
            case BOOLEAN: {
                final boolean b = ((BooleanPropertyNode)from).value();
                ((BooleanPropertyNode)to).value(b);
            }
            case ENUM: {
                final String e = ((EnumPropertyNode)from).value();
                ((EnumPropertyNode)to).value(e);
            }
            case FLOAT: {
                final float f = ((FloatPropertyNode)from).value();
                ((FloatPropertyNode)to).value(f);
            }
            case INTEGER: {
                final int i = ((IntegerPropertyNode)from).value();
                ((IntegerPropertyNode)to).value(i);
            }
            case STRING: {
                final String s = ((StringPropertyNode)from).value();
                ((StringPropertyNode)to).value(s);
            }
            case ARRAY: {
                switch (((IArrayPropertyNode)from).itemType()) {
                    case NULL: {
                        return;
                    }
                    case BOOLEAN: {
                        final boolean[] booleans = ((BooleanArrayPropertyNode)from).array();
                        ((BooleanArrayPropertyNode)to).array(booleans);
                        return;
                    }
                    case ENUM: {
                        final String[] enums = ((StringArrayPropertyNode)from).array();
                        ((StringArrayPropertyNode)to).array(enums);
                        return;
                    }
                    case FLOAT: {
                        final float[] floats = ((FloatArrayPropertyNode)from).array();
                        ((FloatArrayPropertyNode)to).array(floats);
                        return;
                    }
                    case INTEGER: {
                        final int[] ints = ((IntegerArrayPropertyNode)from).array();
                        ((IntegerArrayPropertyNode)to).array(ints);
                        return;
                    }
                    case STRING: {
                        final String[] strings = ((StringArrayPropertyNode)from).array();
                        ((StringArrayPropertyNode)to).array(strings);
                        return;
                    }
                    case ARRAY: {
                        throw new AssertionError((Object)"Candle does not support arrays of arrays");
                    }
                    default: {
                        throw new UnsupportedOperationException("Unsupported type" + ((IArrayPropertyNode)from).itemType());
                    }
                }
                break;
            }
            default: {
                throw new UnsupportedOperationException("Unsupported type" + ((IPropertyNode)from).valueType());
            }
        }
    }
    
    private static String getReason(final Exception e) {
        if (e instanceof RecognitionException) {
            final RecognitionException recognitionException = (RecognitionException)e;
            final Token token = recognitionException.getOffendingToken();
            return "line " + token.getLine() + ':' + token.getCharPositionInLine() + " '" + token.getText() + "'";
        }
        if (e.getCause() != null) {
            Throwable t = e;
            do {
                t = t.getCause();
            } while (!(t instanceof Exception));
            return getReason((Exception)t);
        }
        return e.getMessage();
    }
    
    static {
        serializers = Collections3.newCopyOnWritetListMultimap();
        locks = Collections.synchronizedMap(new HashMap<Class<? extends Annotation>, Lock>());
        addSerializer(new BooleanSerializer());
        addSerializer(new ByteSeralizer());
        addSerializer(new CharSerializer());
        addSerializer(new DoubleSerializer());
        addSerializer(new FloatSerializer());
        addSerializer(new IntSerializer());
        addSerializer(new ListSerializer());
        addSerializer(new LongSerializer());
        addSerializer(new ShortSeralizer());
        addSerializer(new StringSerializer());
        addSerializer(Time.class, new TimeSerializer());
        addSerializerBefore(new EnumSerializer(), StringSerializer.class);
        EMPTY_COLLECTION_FIRST_OBJECT = new Object();
    }
}
