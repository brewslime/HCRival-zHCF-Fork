package com.hcrival.internal.net.techcable.techutils.config;

import java.lang.annotation.*;
import java.util.concurrent.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface Time {
    TimeUnit value() default TimeUnit.SECONDS;
    
    TimeUnit as() default TimeUnit.MILLISECONDS;
}
