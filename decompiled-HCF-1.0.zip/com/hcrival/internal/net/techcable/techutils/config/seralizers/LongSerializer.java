package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class LongSerializer implements ConfigSerializer<Long>
{
    @Override
    public Object serialize(final Long aLong, final Annotation[] annotations) {
        return aLong;
    }
    
    @Override
    public Long deserialize(final Object yaml, final Class<? extends Long> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Long)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Long.TYPE || type == Long.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
