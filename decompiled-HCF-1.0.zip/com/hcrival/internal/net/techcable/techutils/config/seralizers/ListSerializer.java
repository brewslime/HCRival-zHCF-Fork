package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import java.lang.annotation.*;
import com.google.common.base.*;
import com.hcrival.internal.net.techcable.techutils.config.*;
import org.bukkit.configuration.*;
import com.google.common.collect.*;
import java.util.*;

public class ListSerializer implements ConfigSerializer<List<?>>
{
    @Override
    public Object serialize(final List<?> list, final Annotation[] annotations) {
        ListOf annotationTemp = null;
        for (final Annotation a : annotations) {
            if (a instanceof ListOf) {
                annotationTemp = (ListOf)a;
            }
        }
        final ListOf annotation = annotationTemp;
        return Lists.transform(list, (Function<?, ?>)new Function<Object, Object>() {
            @Override
            public Object apply(final Object java) {
                try {
                    final ConfigSerializer serializer = AnnotationConfig.getSerializer(java.getClass(), annotations);
                    if (serializer == null) {
                        throw new InvalidConfigurationException("Unable to serialize: " + java.getClass().getSimpleName());
                    }
                    final Annotation[] annotationsOn = (annotation != null) ? annotation.annotations() : new Annotation[0];
                    return serializer.serialize(java, annotationsOn);
                }
                catch (Throwable $ex) {
                    throw $ex;
                }
            }
        });
    }
    
    @Override
    public List<?> deserialize(final Object yaml, final Class<? extends List<?>> ignored, final Annotation[] annotations) throws InvalidConfigurationException {
        final List<?> yamlList = (List<?>)yaml;
        ListOf annotation = null;
        for (final Annotation a : annotations) {
            if (a instanceof ListOf) {
                annotation = (ListOf)a;
            }
        }
        final Class<?> deserializeTo = (annotation != null) ? annotation.value() : null;
        final Annotation[] annotationsOn = (annotation != null) ? annotation.annotations() : new Annotation[0];
        return this.deserializeList(yamlList, deserializeTo, annotationsOn);
    }
    
    public List<?> deserializeList(final List<?> yamlList, final Class<?> deserializeTo, final Annotation[] annotations) throws InvalidConfigurationException {
        final List java = new ArrayList();
        for (final Object yaml : yamlList) {
            if (yaml instanceof List) {
                final List subList = this.deserializeList(yamlList, deserializeTo, annotations);
                java.add(subList);
            }
            else {
                final ConfigSerializer serializer = AnnotationConfig.getDeserializer(yaml.getClass(), deserializeTo, annotations);
                final Object element = serializer.deserialize(yaml, deserializeTo, annotations);
                java.add(element);
            }
        }
        return (List<?>)java;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return List.class.isAssignableFrom(type);
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return List.class.isAssignableFrom(type);
    }
}
