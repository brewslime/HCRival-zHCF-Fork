package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class ShortSeralizer implements ConfigSerializer<Short>
{
    @Override
    public Object serialize(final Short aShort, final Annotation[] annotations) {
        return aShort;
    }
    
    @Override
    public Short deserialize(final Object yaml, final Class<? extends Short> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Short)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Short.TYPE || type == Short.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
