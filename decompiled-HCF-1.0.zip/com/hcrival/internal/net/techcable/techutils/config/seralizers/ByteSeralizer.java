package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class ByteSeralizer implements ConfigSerializer<Byte>
{
    @Override
    public Object serialize(final Byte o, final Annotation[] annotations) {
        return o;
    }
    
    @Override
    public Byte deserialize(final Object yaml, final Class<? extends Byte> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Byte)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Byte.TYPE || type == Byte.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
