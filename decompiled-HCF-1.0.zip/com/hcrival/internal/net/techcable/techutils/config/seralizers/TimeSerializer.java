package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import java.lang.annotation.*;
import com.hcrival.internal.net.techcable.techutils.config.*;
import com.google.common.primitives.*;
import java.util.concurrent.*;
import org.bukkit.configuration.*;
import java.util.regex.*;
import org.apache.commons.lang.*;
import java.math.*;

public class TimeSerializer implements ConfigSerializer<Object>
{
    public static final Pattern TIME_PATTERN;
    
    @Override
    public Object serialize(final Object java, final Annotation[] annotations) {
        Time annotation = null;
        for (final Annotation declaredAnnotation : annotations) {
            if (declaredAnnotation instanceof Time) {
                annotation = (Time)declaredAnnotation;
                break;
            }
        }
        if (annotation == null) {
            throw new RuntimeException("Unable to serialize types not annotated with @Time");
        }
        Class seraizlieTo = java.getClass();
        seraizlieTo = Primitives.unwrap((Class<Object>)seraizlieTo);
        final long millis = (long)((seraizlieTo == Integer.TYPE) ? ((long)(int)java) : java);
        final TimeUnit defaultUnit = annotation.value();
        return toString(millis, defaultUnit);
    }
    
    @Override
    public Object deserialize(final Object yaml, final Class type, final Annotation[] annotations) throws InvalidConfigurationException {
        Time annotation = null;
        for (final Annotation declaredAnnotation : annotations) {
            if (declaredAnnotation instanceof Time) {
                annotation = (Time)declaredAnnotation;
                break;
            }
        }
        if (annotation == null) {
            throw new InvalidConfigurationException("Unable to serialize types not annotated with @Time");
        }
        final String raw = yaml.toString();
        try {
            long parsed = parse(raw, annotation.value());
            parsed = annotation.as().convert(parsed, TimeUnit.MILLISECONDS);
            if (type == Integer.TYPE) {
                return (int)parsed;
            }
            return parsed;
        }
        catch (IllegalArgumentException e) {
            throw new InvalidConfigurationException(e.getMessage());
        }
    }
    
    @Override
    public boolean canSerialize(Class<?> type) {
        type = Primitives.unwrap(type);
        return type == Integer.TYPE || type == Long.TYPE;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == String.class || this.canSerialize(type);
    }
    
    public static long parse(final String raw, final TimeUnit defaultUnit) {
        long total = 0L;
        final Matcher m = TimeSerializer.TIME_PATTERN.matcher(raw);
        if (!m.find()) {
            throw new IllegalArgumentException("Invalid time: " + raw);
        }
        m.reset();
        while (m.find()) {
            final String rawValue = m.group(1);
            long value = Long.parseLong(rawValue);
            final String rawUnit = m.group(2);
            TimeUnit unit = defaultUnit;
            if (rawUnit != null) {
                final String lowerCase = rawUnit.toLowerCase();
                switch (lowerCase) {
                    case "d":
                    case "days":
                    case "day": {
                        unit = TimeUnit.DAYS;
                        break;
                    }
                    case "h":
                    case "hr":
                    case "hrs":
                    case "hours":
                    case "hour": {
                        unit = TimeUnit.HOURS;
                        break;
                    }
                    case "m":
                    case "min":
                    case "mins":
                    case "minutes":
                    case "minute": {
                        unit = TimeUnit.MINUTES;
                        break;
                    }
                    case "s":
                    case "sec":
                    case "secs":
                    case "seconds":
                    case "second": {
                        unit = TimeUnit.SECONDS;
                        break;
                    }
                }
            }
            value = unit.toMillis(value);
            total += value;
        }
        return total;
    }
    
    public static String toString(final long millis, final TimeUnit defaultUnit) {
        TimeUnit unit = calculateTimeUnit(millis, defaultUnit);
        if (unit == TimeUnit.MILLISECONDS || unit == TimeUnit.MICROSECONDS || unit == TimeUnit.NANOSECONDS) {
            unit = TimeUnit.SECONDS;
        }
        final StringBuilder asString = new StringBuilder();
        final long time = unit.convert(millis, TimeUnit.MILLISECONDS);
        asString.append(time);
        if (unit != defaultUnit) {
            asString.append(' ');
            switch (unit) {
                case DAYS: {
                    asString.append("day");
                    if (time != 1L) {
                        asString.append("s");
                        break;
                    }
                    break;
                }
                case HOURS: {
                    asString.append("hour");
                    if (time != 1L) {
                        asString.append("s");
                        break;
                    }
                    break;
                }
                case MINUTES: {
                    asString.append("minute");
                    if (time != 1L) {
                        asString.append("s");
                        break;
                    }
                    break;
                }
                case SECONDS: {
                    asString.append("second");
                    if (time != 1L) {
                        asString.append("s");
                        break;
                    }
                    break;
                }
                default: {
                    throw new UnsupportedOperationException("Unsupported unit " + unit);
                }
            }
        }
        return asString.toString();
    }
    
    public static TimeUnit calculateTimeUnit(final long millis, final TimeUnit defaultUnit) {
        final TimeUnit[] values = TimeUnit.values();
        ArrayUtils.reverse((Object[])values);
        for (final TimeUnit unit : values) {
            if (fitsUnit(millis, unit)) {
                return unit;
            }
        }
        return defaultUnit;
    }
    
    public static boolean fitsUnit(final long millis, final TimeUnit unit) {
        return equals(fromMillisExact(millis, unit), unit.convert(millis, TimeUnit.MILLISECONDS));
    }
    
    private static BigDecimal fromMillisExact(final long millis, final TimeUnit unit) {
        final BigDecimal time = BigDecimal.valueOf(millis);
        return fromMillisExact(time, unit);
    }
    
    private static BigDecimal fromMillisExact(BigDecimal time, final TimeUnit unit) {
        switch (unit) {
            case SECONDS: {
                return divide(time, 1000L);
            }
            case MINUTES: {
                time = fromMillisExact(time, TimeUnit.SECONDS);
                return divide(time, 60L);
            }
            case HOURS: {
                time = fromMillisExact(time, TimeUnit.MINUTES);
                return divide(time, 60L);
            }
            case DAYS: {
                time = fromMillisExact(time, TimeUnit.HOURS);
                return divide(time, 24L);
            }
            default: {
                return time;
            }
        }
    }
    
    private static BigDecimal divide(final BigDecimal what, final long by) {
        return what.divide(BigDecimal.valueOf(by));
    }
    
    private static boolean equals(final BigDecimal first, final long second) {
        return first.compareTo(BigDecimal.valueOf(second)) == 0;
    }
    
    static {
        TIME_PATTERN = Pattern.compile("(\\d+)(?:\\s*(\\w+))?");
    }
}
