package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class StringSerializer implements ConfigSerializer<String>
{
    @Override
    public Object serialize(final String s, final Annotation[] annotations) {
        return s;
    }
    
    @Override
    public String deserialize(final Object yaml, final Class<? extends String> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (String)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == String.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
