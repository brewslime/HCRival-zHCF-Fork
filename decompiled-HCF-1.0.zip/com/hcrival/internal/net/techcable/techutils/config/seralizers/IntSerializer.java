package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class IntSerializer implements ConfigSerializer<Integer>
{
    @Override
    public Object serialize(final Integer integer, final Annotation[] annotations) {
        return integer;
    }
    
    @Override
    public Integer deserialize(final Object yaml, final Class<? extends Integer> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Integer)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Integer.TYPE || type == Integer.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
