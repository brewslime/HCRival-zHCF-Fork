package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class EnumSerializer implements ConfigSerializer<Enum>
{
    @Override
    public Object serialize(final Enum anEnum, final Annotation[] annotations) {
        return anEnum;
    }
    
    @Override
    public Enum deserialize(final Object yaml, final Class<? extends Enum> type, final Annotation[] annotations) throws InvalidConfigurationException {
        if (yaml.getClass().isEnum()) {
            return (Enum)yaml;
        }
        String raw = yaml.toString();
        raw = raw.replace("-", " ");
        for (final Enum e : (Enum[])type.getEnumConstants()) {
            final String asString = e.toString().replace("_", " ").replace("-", " ");
            if (asString.equalsIgnoreCase(raw)) {
                return e;
            }
        }
        throw new InvalidConfigurationException("Could not find enum " + type.getSimpleName() + " for " + raw);
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return (type == String.class || type.isEnum()) && into != null && into.isEnum();
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return type.isEnum();
    }
}
