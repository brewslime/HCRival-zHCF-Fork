package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class DoubleSerializer implements ConfigSerializer<Double>
{
    @Override
    public Object serialize(final Double aDouble, final Annotation[] annotations) {
        return aDouble;
    }
    
    @Override
    public Double deserialize(final Object yaml, final Class<? extends Double> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Double)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Double.TYPE || type == Double.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
