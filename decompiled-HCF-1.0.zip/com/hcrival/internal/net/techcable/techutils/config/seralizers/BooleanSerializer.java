package com.hcrival.internal.net.techcable.techutils.config.seralizers;

import com.hcrival.internal.net.techcable.techutils.config.*;
import java.lang.annotation.*;
import org.bukkit.configuration.*;

public class BooleanSerializer implements ConfigSerializer<Boolean>
{
    @Override
    public Object serialize(final Boolean aBoolean, final Annotation[] annotations) {
        return aBoolean;
    }
    
    @Override
    public Boolean deserialize(final Object yaml, final Class<? extends Boolean> type, final Annotation[] annotations) throws InvalidConfigurationException {
        return (Boolean)yaml;
    }
    
    @Override
    public boolean canDeserialize(final Class<?> type, final Class<?> into) {
        return type == Boolean.TYPE || type == Boolean.class;
    }
    
    @Override
    public boolean canSerialize(final Class<?> type) {
        return this.canDeserialize(type, null);
    }
}
