package com.hcrival.internal.net.techcable.techutils.command;

import com.hcrival.internal.net.techcable.techutils.entity.*;
import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.uuid.*;
import java.util.regex.*;
import java.util.concurrent.*;
import java.beans.*;

public class Argument<T extends TechPlayer>
{
    private final TechCommand<T, ?> command;
    private final String value;
    public static final Pattern TIME_PATTERN;
    
    public Player getAsPlayerEntity() {
        return UUIDUtils.getPlayerExact(this.getValue());
    }
    
    public T getAsPlayer() {
        return this.command.getPlugin().getPlayer(this.getAsPlayerEntity());
    }
    
    public boolean getAsBoolean() {
        if ("true".equalsIgnoreCase(this.getValue())) {
            return true;
        }
        if ("false".equalsIgnoreCase(this.getValue())) {
            return false;
        }
        throw new IllegalStateException("Not a valid boolean");
    }
    
    public long getAsLong() {
        try {
            return Long.parseLong(this.getValue());
        }
        catch (NumberFormatException e) {
            throw new IllegalStateException("Not a valid long", e);
        }
    }
    
    public int getAsInteger() {
        try {
            return Integer.parseInt(this.getValue());
        }
        catch (NumberFormatException e) {
            throw new IllegalStateException("Not a valid int", e);
        }
    }
    
    public double getAsDouble() {
        try {
            return Double.parseDouble(this.getValue());
        }
        catch (NumberFormatException e) {
            throw new IllegalStateException("Not a valid int", e);
        }
    }
    
    public long getAsTime() {
        long ms = 0L;
        final Matcher m = Argument.TIME_PATTERN.matcher(this.getValue());
        if (!m.find()) {
            throw new IllegalStateException(this.getValue() + " doesn't match the time pattern");
        }
        m.reset();
        while (m.find()) {
            final long value = Long.valueOf(m.group(1));
            final TimeUnit unit = fromName(m.group(2));
            if (unit == null) {
                throw new IllegalStateException(m.group(2) + " isn't a valid time unit");
            }
            ms += unit.toMillis(value);
        }
        return ms;
    }
    
    private static TimeUnit fromName(String name) {
        name = name.toLowerCase();
        for (final TimeUnit value : TimeUnit.values()) {
            final String nameOfUnit = value.name().toLowerCase();
            if (name.startsWith(nameOfUnit.substring(0, 1))) {
                return value;
            }
            if (name.equals(nameOfUnit)) {
                return value;
            }
            if (name.equals(nameOfUnit.substring(0, nameOfUnit.length() - 1))) {
                return value;
            }
        }
        return null;
    }
    
    @ConstructorProperties({ "command", "value" })
    public Argument(final TechCommand<T, ?> command, final String value) {
        this.command = command;
        this.value = value;
    }
    
    public TechCommand<T, ?> getCommand() {
        return this.command;
    }
    
    public String getValue() {
        return this.value;
    }
    
    static {
        TIME_PATTERN = Pattern.compile("(\\d+)(\\w+)");
    }
}
