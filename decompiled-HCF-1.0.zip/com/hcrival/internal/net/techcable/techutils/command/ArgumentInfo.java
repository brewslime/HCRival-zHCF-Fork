package com.hcrival.internal.net.techcable.techutils.command;

import java.util.*;

public class ArgumentInfo<U extends Argument<?>>
{
    private final EnumSet<ArgumentRequirement> requirements;
    private final String def;
    private final String name;
    
    public ArgumentInfo(final String def, final String name, final ArgumentRequirement... requirements) {
        this.requirements = EnumSet.noneOf(ArgumentRequirement.class);
        this.def = def;
        this.name = name;
        for (final ArgumentRequirement requirement : requirements) {
            this.requirements.add(requirement);
        }
    }
    
    public ArgumentInfo(final String name, final ArgumentRequirement... requirements) {
        this(null, name, requirements);
    }
    
    public boolean isValid(final U argument) {
        for (final ArgumentRequirement requirement : this.requirements) {
            switch (requirement) {
                case PLAYER: {
                    if (argument.getAsPlayerEntity() == null) {
                        return false;
                    }
                    continue;
                }
                case BOOLEAN: {
                    try {
                        argument.getAsBoolean();
                        continue;
                    }
                    catch (IllegalStateException e) {
                        return false;
                    }
                }
                case NUMBER: {
                    try {
                        argument.getAsDouble();
                        continue;
                    }
                    catch (IllegalStateException e) {
                        return false;
                    }
                }
                case TIME: {
                    try {
                        argument.getAsTime();
                    }
                    catch (IllegalStateException e) {
                        return false;
                    }
                    continue;
                }
            }
        }
        return true;
    }
    
    public ArgumentRequirement getInvalidatedRequirement(final U argument) {
        for (final ArgumentRequirement requirement : this.requirements) {
            switch (requirement) {
                case PLAYER: {
                    if (argument.getAsPlayerEntity() == null) {
                        return ArgumentRequirement.PLAYER;
                    }
                    continue;
                }
                case BOOLEAN: {
                    try {
                        argument.getAsBoolean();
                        continue;
                    }
                    catch (IllegalStateException e) {
                        return ArgumentRequirement.BOOLEAN;
                    }
                }
                case NUMBER: {
                    try {
                        argument.getAsDouble();
                        continue;
                    }
                    catch (IllegalStateException e) {
                        return ArgumentRequirement.NUMBER;
                    }
                }
                case TIME: {
                    try {
                        argument.getAsTime();
                    }
                    catch (IllegalStateException e) {
                        return ArgumentRequirement.TIME;
                    }
                    continue;
                }
            }
        }
        return null;
    }
    
    public String getInvalidatedRequirementMessage(final U argument) {
        final ArgumentRequirement requirement = this.getInvalidatedRequirement(argument);
        switch (requirement) {
            case PLAYER: {
                return argument.getValue() + " isn't an online player";
            }
            default: {
                return argument.getValue() + " isn't a valid " + requirement.name();
            }
        }
    }
    
    public boolean isRequired() {
        return this.def != null;
    }
    
    public String getDefault() {
        return this.def;
    }
    
    public String getName() {
        return this.name;
    }
    
    public enum ArgumentRequirement
    {
        PLAYER, 
        BOOLEAN, 
        NUMBER, 
        TIME;
    }
}
