package com.hcrival.internal.net.techcable.techutils.command;

import com.hcrival.internal.net.techcable.techutils.entity.*;
import com.hcrival.internal.net.techcable.techutils.*;
import org.bukkit.command.*;
import com.google.common.collect.*;
import java.util.*;
import java.beans.*;

public abstract class TechCommand<T extends TechPlayer, U extends Argument<T>> implements CommandExecutor
{
    private final TechPlugin<T> plugin;
    private List<String> aliases;
    private List<TechCommand<T, U>> subCommands;
    private Set<String> requiredPermissions;
    private List<ArgumentInfo<U>> argumentInfo;
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        return this.onCommand(sender, label, Lists.newArrayList(args));
    }
    
    public boolean onCommand(final CommandSender sender, final String label, final List<String> rawArgs) {
        if (!this.isAlias(label)) {
            return false;
        }
        if (rawArgs.size() > 0) {
            for (final TechCommand<T, U> subCommand : this.subCommands) {
                if (subCommand.isAlias(rawArgs.get(0))) {
                    rawArgs.remove(0);
                    return subCommand.onCommand(sender, rawArgs.get(0), rawArgs);
                }
            }
        }
        final List<U> args = new ArrayList<U>();
        for (int i = 0; i < this.argumentInfo.size(); ++i) {
            final ArgumentInfo<U> argInfo = this.argumentInfo.get(i);
            String value;
            if (i <= rawArgs.size()) {
                if (argInfo.isRequired()) {
                    sender.sendMessage("You must specifiy " + argInfo.getName());
                    return true;
                }
                value = argInfo.getDefault();
            }
            else {
                value = rawArgs.get(i);
            }
            final U argument = this.createArgument(value);
            if (!argInfo.isValid(argument)) {
                sender.sendMessage(argInfo.getInvalidatedRequirementMessage(argument));
                return true;
            }
            args.add(argument);
        }
        return this.execute(sender, label, args);
    }
    
    public abstract boolean execute(final CommandSender p0, final String p1, final List<U> p2);
    
    protected U createArgument(final String value) {
        return (U)new Argument(this, value);
    }
    
    private boolean isAlias(final String other) {
        for (final String label : this.aliases) {
            if (label.equalsIgnoreCase(other)) {
                return true;
            }
        }
        return false;
    }
    
    @ConstructorProperties({ "plugin" })
    public TechCommand(final TechPlugin<T> plugin) {
        this.aliases = new ArrayList<String>();
        this.subCommands = new ArrayList<TechCommand<T, U>>();
        this.requiredPermissions = new HashSet<String>();
        this.argumentInfo = new ArrayList<ArgumentInfo<U>>();
        this.plugin = plugin;
    }
    
    public TechPlugin<T> getPlugin() {
        return this.plugin;
    }
    
    public List<String> getAliases() {
        return this.aliases;
    }
    
    public List<TechCommand<T, U>> getSubCommands() {
        return this.subCommands;
    }
    
    public Set<String> getRequiredPermissions() {
        return this.requiredPermissions;
    }
    
    public List<ArgumentInfo<U>> getArgumentInfo() {
        return this.argumentInfo;
    }
}
