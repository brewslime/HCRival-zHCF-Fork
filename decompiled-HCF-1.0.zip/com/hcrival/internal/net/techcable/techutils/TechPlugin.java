package com.hcrival.internal.net.techcable.techutils;

import org.bukkit.plugin.java.*;
import com.hcrival.internal.net.techcable.techutils.entity.*;
import com.hcrival.internal.net.techcable.techutils.scoreboard.*;
import org.bukkit.plugin.*;
import java.io.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.*;
import java.util.*;

public abstract class TechPlugin<T extends TechPlayer> extends JavaPlugin
{
    private PlayerManager<T> playerManager;
    private MetricsLite metrics;
    private GlobalScoreboard scoreboard;
    
    public GlobalScoreboard getScoreboard() {
        if (this.scoreboard == null) {
            this.scoreboard = new GlobalScoreboard(this);
        }
        return this.scoreboard;
    }
    
    public final void onEnable() {
        this.playerManager = new PlayerManager<T>(this);
        try {
            if (this.metrics == null) {
                this.metrics = new MetricsLite((Plugin)this);
            }
            this.metrics.start();
        }
        catch (IOException e) {
            this.warning("Unable to send metrics for TechUtils", new Object[0]);
        }
        this.startup();
    }
    
    public final void onDisable() {
        this.shutdown();
        this.playerManager.onShutdown();
    }
    
    public T getPlayer(final UUID id) {
        return this.playerManager.getPlayer(id);
    }
    
    public T getPlayer(final Player id) {
        return this.playerManager.getPlayer(id);
    }
    
    public T createPlayer(final UUID id) {
        assert !this.playerManager.isKnown(id) : "This player has already been created!";
        return (T)new TechPlayer(id, this);
    }
    
    protected abstract void startup();
    
    protected abstract void shutdown();
    
    public void registerListener(final Listener listener) {
        this.getServer().getPluginManager().registerEvents(listener, (Plugin)this);
    }
    
    public void severe(final String format, final Object... args) {
        Bukkit.getLogger().severe(this.getPrefix() + String.format(format, args));
    }
    
    public void warning(final String format, final Object... args) {
        Bukkit.getLogger().warning(this.getPrefix() + String.format(format, args));
    }
    
    public void info(final String format, final Object... args) {
        Bukkit.getLogger().info(this.getPrefix() + String.format(format, args));
    }
    
    private String getPrefix() {
        return "[" + this.getName() + "] ";
    }
    
    public Collection<T> getOnlinePlayers() {
        final Set<T> players = new HashSet<T>();
        for (final Player player : Bukkit.getOnlinePlayers()) {
            players.add(this.getPlayer(player));
        }
        return players;
    }
}
