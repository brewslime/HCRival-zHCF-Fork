package com.hcrival.internal.net.techcable.techutils.inventory;

import org.bukkit.inventory.*;
import com.google.common.collect.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.potion.*;

public class PlayerDataSnapshot implements PlayerData
{
    private final ImmutableList<ItemStack> items;
    private final ImmutableList<ItemStack> armor;
    private final float experience;
    private final int xpLevel;
    private final float health;
    private final int food;
    private final float saturation;
    private final float exhaustion;
    private final ImmutableList<ItemStack> enderchest;
    private final int fire;
    private final int air;
    private final Location location;
    private final ImmutableSet<PotionEffect> potions;
    
    public PlayerDataSnapshot(final List<ItemStack> items, final List<ItemStack> armor, final float experience, final int xpLevel, final float health, final int food, final float saturation, final float exhaustion, final List<ItemStack> enderchest, final int fire, final int air, final Location location, final Collection<PotionEffect> potions) {
        this.items = clone(items);
        this.armor = clone(armor);
        this.experience = experience;
        this.xpLevel = xpLevel;
        this.health = health;
        this.food = food;
        this.saturation = saturation;
        this.exhaustion = exhaustion;
        this.enderchest = clone(enderchest);
        this.fire = fire;
        this.air = air;
        this.location = location.clone();
        this.potions = ImmutableSet.copyOf((Collection<? extends PotionEffect>)potions);
    }
    
    protected PlayerDataSnapshot(final PlayerData old) {
        this(old.getItems(), old.getArmor(), old.getExp(), old.getLevel(), old.getHealth(), old.getFoodLevel(), old.getSaturation(), old.getExhaustion(), old.getEnderchest(), old.getFireTicks(), old.getAir(), old.getLocation(), old.getPotionEffects());
    }
    
    private static ImmutableList<ItemStack> clone(final List<ItemStack> originals) {
        final ImmutableList.Builder<ItemStack> builder = ImmutableList.builder();
        for (final ItemStack original : originals) {
            final ItemStack clone = original.clone();
            builder.add(clone);
        }
        return builder.build();
    }
    
    @Override
    public List<ItemStack> getArmor() {
        return clone(this.armor);
    }
    
    @Override
    public ItemStack getHelmet() {
        return this.armor.get(3).clone();
    }
    
    @Override
    public ItemStack getChestplate() {
        return this.armor.get(2).clone();
    }
    
    @Override
    public ItemStack getLeggings() {
        return this.armor.get(1).clone();
    }
    
    @Override
    public ItemStack getBoots() {
        return this.armor.get(0).clone();
    }
    
    @Override
    public float getExp() {
        return this.experience;
    }
    
    @Override
    public int getLevel() {
        return this.xpLevel;
    }
    
    @Override
    public float getHealth() {
        return this.health;
    }
    
    @Override
    public int getFoodLevel() {
        return this.food;
    }
    
    @Override
    public float getSaturation() {
        return this.saturation;
    }
    
    @Override
    public float getExhaustion() {
        return this.exhaustion;
    }
    
    @Override
    public List<ItemStack> getEnderchest() {
        return clone(this.enderchest);
    }
    
    @Override
    public ItemStack getEnderchestItem(final int slot) {
        return this.enderchest.get(slot).clone();
    }
    
    @Override
    public List<ItemStack> getItems() {
        return clone(this.items);
    }
    
    @Override
    public ItemStack getItem(final int slot) {
        return this.items.get(slot).clone();
    }
    
    @Override
    public int getFireTicks() {
        return this.fire;
    }
    
    @Override
    public int getAir() {
        return this.air;
    }
    
    @Override
    public World getWorld() {
        return this.location.getWorld();
    }
    
    @Override
    public Location getLocation() {
        return this.location.clone();
    }
    
    @Override
    public Collection<PotionEffect> getPotionEffects() {
        return this.potions;
    }
    
    @Override
    public PlayerData getSnapshot() {
        return this;
    }
    
    @Override
    public void load() {
    }
    
    @Override
    public void save() {
    }
    
    @Override
    public void setArmor(final List<? extends ItemStack> armor) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setHelmet(final ItemStack helmet) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setChestplate(final ItemStack chestplate) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setLeggings(final ItemStack leggings) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setBoots(final ItemStack boots) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setExp(final float exp) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setLevel(final int level) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setHealth(final float health) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setFoodLevel(final int foodLevel) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setSaturation(final float saturation) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setExhaustion(final float exhaustion) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setEnderchest(final List<ItemStack> enderchest) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setEnderchestItem(final int slot, final ItemStack item) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setItems(final List<ItemStack> items) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setItem(final int slot, final ItemStack item) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setFireTicks(final int ticks) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void setAir(final int air) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void addPotionEffect(final PotionEffect effect) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void addPotionEffects(final Collection<PotionEffect> effects) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
    
    @Override
    public void removePotionEffect(final PotionEffectType type) {
        throw new UnsupportedOperationException("You can't edit immutable objects");
    }
}
