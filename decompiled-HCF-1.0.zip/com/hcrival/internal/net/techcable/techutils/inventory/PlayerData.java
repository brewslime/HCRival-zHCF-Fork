package com.hcrival.internal.net.techcable.techutils.inventory;

import org.bukkit.inventory.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.potion.*;

public interface PlayerData
{
    List<ItemStack> getArmor();
    
    ItemStack getHelmet();
    
    ItemStack getChestplate();
    
    ItemStack getLeggings();
    
    ItemStack getBoots();
    
    void setArmor(final List<? extends ItemStack> p0);
    
    void setHelmet(final ItemStack p0);
    
    void setChestplate(final ItemStack p0);
    
    void setLeggings(final ItemStack p0);
    
    void setBoots(final ItemStack p0);
    
    float getExp();
    
    void setExp(final float p0);
    
    int getLevel();
    
    void setLevel(final int p0);
    
    float getHealth();
    
    void setHealth(final float p0);
    
    int getFoodLevel();
    
    void setFoodLevel(final int p0);
    
    float getSaturation();
    
    void setSaturation(final float p0);
    
    float getExhaustion();
    
    void setExhaustion(final float p0);
    
    List<ItemStack> getEnderchest();
    
    void setEnderchest(final List<ItemStack> p0);
    
    void setEnderchestItem(final int p0, final ItemStack p1);
    
    ItemStack getEnderchestItem(final int p0);
    
    List<ItemStack> getItems();
    
    void setItems(final List<ItemStack> p0);
    
    ItemStack getItem(final int p0);
    
    void setItem(final int p0, final ItemStack p1);
    
    int getFireTicks();
    
    void setFireTicks(final int p0);
    
    int getAir();
    
    void setAir(final int p0);
    
    World getWorld();
    
    Location getLocation();
    
    void load();
    
    void save();
    
    void addPotionEffect(final PotionEffect p0);
    
    void addPotionEffects(final Collection<PotionEffect> p0);
    
    Collection<PotionEffect> getPotionEffects();
    
    void removePotionEffect(final PotionEffectType p0);
    
    PlayerData getSnapshot();
}
