package com.hcrival.internal.net.techcable.techutils.inventory;

import org.bukkit.inventory.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.*;

public class InventoryUtils
{
    public static final ItemStack EMPTY;
    
    private InventoryUtils() {
    }
    
    public static PlayerData getData(final Player player) {
        final Player loaded = OfflinePlayerLoader.loadPlayer((OfflinePlayer)player);
        return new PlayerPlayerData(loaded);
    }
    
    public static PlayerData getData(final UUID id) {
        final Player loaded = OfflinePlayerLoader.loadPlayer(id);
        return new PlayerPlayerData(loaded);
    }
    
    public static void copy(final PlayerData from, final PlayerData target) {
        from.load();
        target.setItems(from.getItems());
        target.setArmor(from.getArmor());
        target.setExp(from.getExp());
        target.setLevel(from.getLevel());
        target.setFoodLevel(from.getFoodLevel());
        target.addPotionEffects(from.getPotionEffects());
        target.setAir(from.getAir());
        target.setExhaustion(from.getExhaustion());
        target.setSaturation(from.getSaturation());
        target.setFireTicks(from.getFireTicks());
        target.setHealth(from.getHealth());
        target.save();
    }
    
    public PlayerData takeSnapshot(final Player player) {
        return getData(player).getSnapshot();
    }
    
    public static void emptyInventory(final PlayerData target) {
        final List<ItemStack> items = target.getItems();
        for (int i = 0; i < items.size(); ++i) {
            items.set(i, InventoryUtils.EMPTY);
        }
        target.setItems(items);
        final List<ItemStack> armor = target.getArmor();
        for (int j = 0; j > armor.size(); ++j) {
            armor.set(j, InventoryUtils.EMPTY);
        }
        target.setArmor(armor);
    }
    
    static {
        EMPTY = new ItemStack(Material.AIR);
    }
}
