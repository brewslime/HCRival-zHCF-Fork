package com.hcrival.internal.net.techcable.techutils.inventory;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.lang.reflect.*;

class OfflinePlayerLoader
{
    public static Player loadPlayer(final String name) {
        return loadPlayer(Bukkit.getOfflinePlayer(name));
    }
    
    public static Player loadPlayer(final UUID id) {
        return loadPlayer(Bukkit.getOfflinePlayer(id));
    }
    
    public static Player loadPlayer(final OfflinePlayer player) {
        if (player == null) {
            return null;
        }
        if (player instanceof Player) {
            return (Player)player;
        }
        return loadPlayer(player.getUniqueId(), player.getName());
    }
    
    private static Player loadPlayer(final UUID id, final String name) {
        final Object server = getHandle(Bukkit.getServer());
        final Object interactManager = newPlayerInteractManager();
        final Object worldServer = getWorldServer();
        final Object profile = newGameProfile(id, name);
        final Class<?> entityPlayerClass = getNmsClass("EntityPlayer");
        final Constructor entityPlayerConstructor = makeConstructor(entityPlayerClass, server.getClass(), worldServer.getClass(), profile.getClass(), interactManager.getClass());
        final Object entityPlayer = callConstructor((Constructor<Object>)entityPlayerConstructor, server, worldServer, profile, interactManager);
        final Player player = (Player)getBukkitEntity(entityPlayer);
        return player;
    }
    
    private static Object newGameProfile(final UUID id, final String name) {
        final Class<?> gameProfileClass = getUtilClass("com.mojang.authlib.GameProfile");
        if (gameProfileClass == null) {
            return name;
        }
        Constructor gameProfileConstructor = null;
        gameProfileConstructor = makeConstructor(gameProfileClass, UUID.class, String.class);
        if (gameProfileConstructor == null) {
            gameProfileConstructor = makeConstructor(gameProfileClass, String.class, String.class);
            return callConstructor((Constructor<Object>)gameProfileConstructor, id.toString(), name);
        }
        return callConstructor((Constructor<Object>)gameProfileConstructor, id, name);
    }
    
    private static Object newPlayerInteractManager() {
        final Object worldServer = getWorldServer();
        final Class<?> playerInteractClass = getNmsClass("PlayerInteractManager");
        final Constructor c = makeConstructor(playerInteractClass, worldServer.getClass());
        return callConstructor((Constructor<Object>)c, worldServer);
    }
    
    private static Object getWorldServer() {
        final Object server = getHandle(Bukkit.getServer());
        final Method getWorldServer = makeMethod(server.getClass(), "getWorldServer", Integer.TYPE);
        return callMethod(getWorldServer, server, 0);
    }
    
    private static Entity getBukkitEntity(final Object o) {
        final Method getBukkitEntity = makeMethod(o.getClass(), "getBukkitEntity", (Class<?>[])new Class[0]);
        return callMethod(getBukkitEntity, o, new Object[0]);
    }
    
    private static Class<?> getNmsClass(final String name) {
        final String className = "net.minecraft.server" + getVersion() + "." + name;
        try {
            return Class.forName(className);
        }
        catch (ClassNotFoundException ex) {
            return null;
        }
    }
    
    private static Class<?> getUtilClass(final String name) {
        try {
            return Class.forName(name);
        }
        catch (ClassNotFoundException ex) {
            try {
                return Class.forName("net.minecraft.util." + name);
            }
            catch (ClassNotFoundException ex2) {
                return null;
            }
        }
    }
    
    private static String getVersion() {
        Bukkit.getServer();
        final String packageName = Bukkit.getServer().getClass().getPackage().getName();
        return packageName.substring(packageName.lastIndexOf(46) + 1);
    }
    
    private static Object getHandle(final Object wrapper) {
        final Method getHandle = makeMethod(wrapper.getClass(), "getHandle", (Class<?>[])new Class[0]);
        return callMethod(getHandle, wrapper, new Object[0]);
    }
    
    private static Method makeMethod(final Class<?> clazz, final String methodName, final Class<?>... paramaters) {
        try {
            return clazz.getDeclaredMethod(methodName, paramaters);
        }
        catch (NoSuchMethodException ex2) {
            return null;
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    
    private static <T> T callMethod(final Method method, final Object instance, final Object... paramaters) {
        if (method == null) {
            throw new RuntimeException("No such method");
        }
        method.setAccessible(true);
        try {
            return (T)method.invoke(instance, paramaters);
        }
        catch (InvocationTargetException ex) {
            throw new RuntimeException(ex.getCause());
        }
        catch (Exception ex2) {
            throw new RuntimeException(ex2);
        }
    }
    
    private static <T> Constructor<T> makeConstructor(final Class<?> clazz, final Class<?>... paramaterTypes) {
        try {
            return (Constructor<T>)clazz.getConstructor(paramaterTypes);
        }
        catch (NoSuchMethodException ex2) {
            return null;
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    
    private static <T> T callConstructor(final Constructor<T> constructor, final Object... paramaters) {
        if (constructor == null) {
            throw new RuntimeException("No such constructor");
        }
        constructor.setAccessible(true);
        try {
            return constructor.newInstance(paramaters);
        }
        catch (InvocationTargetException ex) {
            throw new RuntimeException(ex.getCause());
        }
        catch (Exception ex2) {
            throw new RuntimeException(ex2);
        }
    }
}
