package com.hcrival.internal.net.techcable.techutils.inventory;

import org.bukkit.entity.*;
import java.lang.reflect.*;
import com.hcrival.internal.net.techcable.techutils.*;
import org.bukkit.*;
import org.bukkit.potion.*;
import org.bukkit.inventory.*;
import java.util.*;
import java.beans.*;

class PlayerPlayerData implements PlayerData
{
    private Player player;
    private static final Method setHealthMethod;
    
    @Override
    public ItemStack getHelmet() {
        return this.getInventory().getHelmet();
    }
    
    @Override
    public ItemStack getChestplate() {
        return this.getInventory().getChestplate();
    }
    
    @Override
    public ItemStack getLeggings() {
        return this.getInventory().getLeggings();
    }
    
    @Override
    public ItemStack getBoots() {
        return this.getInventory().getBoots();
    }
    
    @Override
    public void setHelmet(final ItemStack helmet) {
        this.getInventory().setHelmet(helmet);
    }
    
    @Override
    public void setChestplate(final ItemStack chestplate) {
        this.getInventory().setChestplate(chestplate);
    }
    
    @Override
    public void setLeggings(final ItemStack leggings) {
        this.getInventory().setLeggings(leggings);
    }
    
    @Override
    public void setBoots(final ItemStack boots) {
        this.getInventory().setBoots(boots);
    }
    
    @Override
    public float getExp() {
        return this.getPlayer().getExp();
    }
    
    @Override
    public void setExp(final float exp) {
        this.getPlayer().setExp(exp);
    }
    
    @Override
    public int getLevel() {
        return this.getPlayer().getLevel();
    }
    
    @Override
    public void setLevel(final int level) {
        this.getPlayer().setLevel(level);
    }
    
    @Override
    public float getHealth() {
        return (float)this.getPlayer().getHealth();
    }
    
    @Override
    public void setHealth(final float health) {
        Reflection.callMethod(PlayerPlayerData.setHealthMethod, Reflection.getHandle(this.player), health);
    }
    
    @Override
    public int getFoodLevel() {
        return this.getPlayer().getFoodLevel();
    }
    
    @Override
    public void setFoodLevel(final int foodLevel) {
        this.getPlayer().setFoodLevel(foodLevel);
    }
    
    @Override
    public float getSaturation() {
        return this.getPlayer().getSaturation();
    }
    
    @Override
    public void setSaturation(final float saturation) {
        this.getPlayer().setSaturation(saturation);
    }
    
    @Override
    public float getExhaustion() {
        return this.getPlayer().getExhaustion();
    }
    
    @Override
    public void setExhaustion(final float exhaustion) {
        this.getPlayer().setExhaustion(exhaustion);
    }
    
    @Override
    public void setEnderchestItem(final int slot, final ItemStack item) {
        this.getPlayer().getEnderChest().setItem(slot, item);
    }
    
    @Override
    public ItemStack getEnderchestItem(final int slot) {
        return this.getPlayer().getEnderChest().getItem(slot);
    }
    
    @Override
    public ItemStack getItem(final int slot) {
        return this.getInventory().getItem(slot);
    }
    
    @Override
    public void setItem(final int slot, final ItemStack item) {
        this.getInventory().setItem(slot, item);
    }
    
    @Override
    public int getFireTicks() {
        return this.getPlayer().getFireTicks();
    }
    
    @Override
    public void setFireTicks(final int ticks) {
        this.getPlayer().setFireTicks(ticks);
    }
    
    @Override
    public int getAir() {
        return this.getPlayer().getRemainingAir();
    }
    
    @Override
    public void setAir(final int air) {
        this.getPlayer().setRemainingAir(air);
    }
    
    @Override
    public World getWorld() {
        return this.getLocation().getWorld();
    }
    
    @Override
    public Location getLocation() {
        return this.getPlayer().getLocation();
    }
    
    @Override
    public void load() {
    }
    
    @Override
    public void save() {
        this.getPlayer().saveData();
    }
    
    @Override
    public void addPotionEffect(final PotionEffect effect) {
        this.getPlayer().addPotionEffect(effect);
    }
    
    @Override
    public void addPotionEffects(final Collection<PotionEffect> effects) {
        this.getPlayer().addPotionEffects((Collection)effects);
    }
    
    @Override
    public Collection<PotionEffect> getPotionEffects() {
        return (Collection<PotionEffect>)this.getPlayer().getActivePotionEffects();
    }
    
    @Override
    public void removePotionEffect(final PotionEffectType type) {
        this.getPlayer().removePotionEffect(type);
    }
    
    public PlayerInventory getInventory() {
        return this.getPlayer().getInventory();
    }
    
    @Override
    public List<ItemStack> getArmor() {
        return Arrays.asList(this.getPlayer().getInventory().getArmorContents());
    }
    
    @Override
    public void setArmor(final List<? extends ItemStack> armor) {
        this.getPlayer().getInventory().setArmorContents((ItemStack[])armor.toArray(new ItemStack[4]));
    }
    
    @Override
    public List<ItemStack> getEnderchest() {
        return Arrays.asList(this.getPlayer().getEnderChest().getContents());
    }
    
    @Override
    public void setEnderchest(final List<ItemStack> enderchest) {
        this.getPlayer().getEnderChest().setContents((ItemStack[])enderchest.toArray(new ItemStack[enderchest.size()]));
    }
    
    @Override
    public List<ItemStack> getItems() {
        return Arrays.asList(this.getInventory().getContents());
    }
    
    @Override
    public void setItems(final List<ItemStack> items) {
        this.getPlayer().getInventory().setContents((ItemStack[])items.toArray(new ItemStack[items.size()]));
    }
    
    @Override
    public PlayerData getSnapshot() {
        return new PlayerDataSnapshot(this);
    }
    
    @ConstructorProperties({ "player" })
    public PlayerPlayerData(final Player player) {
        this.player = player;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    static {
        setHealthMethod = Reflection.makeMethod(Reflection.getNmsClass("EntityLiving"), "setHealth", Float.TYPE);
    }
}
