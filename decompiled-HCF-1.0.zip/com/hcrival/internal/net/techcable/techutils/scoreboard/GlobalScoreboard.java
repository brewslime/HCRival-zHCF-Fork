package com.hcrival.internal.net.techcable.techutils.scoreboard;

import com.hcrival.internal.net.techcable.techutils.*;
import com.google.common.base.*;
import com.hcrival.internal.net.techcable.techutils.entity.*;
import java.util.*;
import com.google.common.collect.*;
import java.beans.*;

public class GlobalScoreboard extends TechBoard
{
    private final TechPlugin plugin;
    
    public Collection<TechBoard> getAllBoards() {
        return Collections2.transform(this.plugin.getOnlinePlayers(), (Function<? super Object, TechBoard>)new Function<TechPlayer, TechBoard>() {
            @Override
            public TechBoard apply(final TechPlayer player) {
                return player.getScoreboard();
            }
        });
    }
    
    public void display0() {
        for (final TechBoard board : this.getAllBoards()) {
            board.aquireLock();
            this.resynchonyze(board);
            try {
                board.display0();
            }
            finally {
                board.releaseLock();
            }
        }
    }
    
    public void hide0() {
        for (final TechBoard board : this.getAllBoards()) {
            board.aquireLock();
            this.resynchonyze(board);
            try {
                board.display0();
            }
            finally {
                board.releaseLock();
            }
        }
    }
    
    @Override
    protected void setScore(final String name, final int score) {
        for (final TechBoard board : this.getAllBoards()) {
            board.aquireLock();
            try {
                board.setScore(name, score);
            }
            finally {
                board.releaseLock();
            }
        }
    }
    
    @Override
    protected void flush() {
        for (final TechBoard board : this.getAllBoards()) {
            board.aquireLock();
            this.resynchonyze(board);
            try {
                board.flush();
            }
            finally {
                board.releaseLock();
            }
        }
    }
    
    @Override
    protected void removeScore(final String name) {
        for (final TechBoard board : this.getAllBoards()) {
            board.aquireLock();
            this.resynchonyze(board);
            try {
                board.flush();
            }
            finally {
                board.releaseLock();
            }
        }
    }
    
    private void resynchonyze(final TechBoard board) {
        if (this.getElements().equals(board.getElements())) {
            return;
        }
        board.clear();
        for (final ScoreboardElement element : this.getElements()) {
            board.addElement(element.getName(), element.getScore());
        }
    }
    
    @ConstructorProperties({ "plugin" })
    public GlobalScoreboard(final TechPlugin plugin) {
        this.plugin = plugin;
    }
}
