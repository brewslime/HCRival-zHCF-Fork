package com.hcrival.internal.net.techcable.techutils.scoreboard;

import java.util.concurrent.locks.*;
import com.hcrival.internal.net.techcable.techutils.scheduler.*;
import com.google.common.collect.*;
import java.util.*;
import java.beans.*;

public abstract class TechBoard
{
    private final Lock lock;
    private final Map<String, ScoreboardElement> elements;
    private final List<ScoreboardElement> elementList;
    
    protected TechBoard() {
        this.lock = new ReentrantLock();
        this.elements = new HashMap<String, ScoreboardElement>();
        this.elementList = new LinkedList<ScoreboardElement>();
        TechScheduler.scheduleAsyncTask(new Runnable() {
            @Override
            public void run() {
                TechBoard.this.aquireLock();
                try {
                    TechBoard.this.flush();
                }
                finally {
                    TechBoard.this.releaseLock();
                }
            }
        }, 0L, 1L);
    }
    
    public void display() {
        this.aquireLock();
        try {
            this.display0();
        }
        finally {
            this.releaseLock();
        }
    }
    
    public void hide() {
        this.aquireLock();
        try {
            this.hide0();
        }
        finally {
            this.releaseLock();
        }
    }
    
    protected abstract void display0();
    
    protected abstract void hide0();
    
    protected abstract void setScore(final String p0, final int p1);
    
    protected abstract void flush();
    
    protected abstract void removeScore(final String p0);
    
    public ImmutableList<ScoreboardElement> getElements() {
        return ImmutableList.copyOf((Collection<? extends ScoreboardElement>)this.elementList);
    }
    
    public void aquireLock() {
        this.lock.lock();
    }
    
    public void releaseLock() {
        this.lock.unlock();
    }
    
    public void addElement(final String name) {
        this.addElement(name, this.elementList.size() + 1);
    }
    
    public void addElement(final String name, final int value) {
        this.aquireLock();
        try {
            final ScoreboardElement element = new ScoreboardElement(name, value);
            this.elements.put(name, element);
            final int listIndex = this.elementList.size() + 1;
            element.listIndex = listIndex;
            this.elementList.add(listIndex, element);
            this.setScore(name, value);
        }
        finally {
            this.releaseLock();
        }
    }
    
    public void setElement(final String name, final int value) {
        this.aquireLock();
        try {
            ScoreboardElement element = this.elements.get(name);
            if (element == null) {
                this.addElement(name, value);
                return;
            }
            final int listIndex = element.listIndex;
            element = new ScoreboardElement(name, value);
            this.elements.put(name, element);
            this.elementList.set(listIndex, element);
        }
        finally {
            this.releaseLock();
        }
    }
    
    public void clear() {
        this.aquireLock();
        try {
            for (final ScoreboardElement element : this.elementList) {
                this.removeScore(element.name);
            }
            this.elementList.clear();
            this.elements.clear();
        }
        finally {
            this.releaseLock();
        }
    }
    
    public void cleanup() {
    }
    
    public static class ScoreboardElement
    {
        private final String name;
        private final int score;
        private int listIndex;
        
        @ConstructorProperties({ "name", "score" })
        public ScoreboardElement(final String name, final int score) {
            this.name = name;
            this.score = score;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof ScoreboardElement)) {
                return false;
            }
            final ScoreboardElement other = (ScoreboardElement)o;
            if (!other.canEqual(this)) {
                return false;
            }
            final Object this$name = this.getName();
            final Object other$name = other.getName();
            if (this$name == null) {
                if (other$name == null) {
                    return this.getScore() == other.getScore();
                }
            }
            else if (this$name.equals(other$name)) {
                return this.getScore() == other.getScore();
            }
            return false;
        }
        
        protected boolean canEqual(final Object other) {
            return other instanceof ScoreboardElement;
        }
        
        @Override
        public int hashCode() {
            final int PRIME = 59;
            int result = 1;
            final Object $name = this.getName();
            result = result * 59 + (($name == null) ? 0 : $name.hashCode());
            result = result * 59 + this.getScore();
            return result;
        }
        
        public String getName() {
            return this.name;
        }
        
        public int getScore() {
            return this.score;
        }
    }
}
