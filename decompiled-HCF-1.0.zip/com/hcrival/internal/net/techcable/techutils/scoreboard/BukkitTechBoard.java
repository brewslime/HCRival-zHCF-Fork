package com.hcrival.internal.net.techcable.techutils.scoreboard;

import com.hcrival.internal.net.techcable.techutils.entity.*;
import java.util.concurrent.*;
import org.bukkit.scoreboard.*;
import org.bukkit.*;
import com.google.common.collect.*;

public class BukkitTechBoard extends TechBoard
{
    private Objective o;
    private Objective buffer;
    private Objective t;
    private final TechPlayer player;
    private final ConcurrentLinkedQueue<ScoreboardChange> changes;
    
    public BukkitTechBoard(final TechPlayer player) {
        this.changes = new ConcurrentLinkedQueue<ScoreboardChange>();
        this.player = player;
        if (player.getEntity().getScoreboard() == null) {
            player.getEntity().setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
    }
    
    public void display0() {
        Scoreboard board = this.getPlayer().getEntity().getScoreboard();
        if (board == null) {
            board = Bukkit.getScoreboardManager().getNewScoreboard();
            this.getPlayer().getEntity().setScoreboard(board);
        }
        if (this.o == null) {
            this.o = board.registerNewObjective(this.getPlayer().getPlugin().getName() + "-primary", "dummy");
            this.buffer = board.registerNewObjective(this.getPlayer().getPlugin().getName() + "-buffer", "dummy");
        }
        this.o.setDisplaySlot(DisplaySlot.SIDEBAR);
    }
    
    public void hide0() {
        final Scoreboard board = this.getPlayer().getEntity().getScoreboard();
        if (board == null) {
            return;
        }
        this.o.setDisplaySlot(DisplaySlot.SIDEBAR);
    }
    
    @Override
    protected void setScore(final String name, final int score) {
        this.changes.add(new ScoreboardChange() {
            @Override
            public void execute(final Objective o) {
                o.getScore((OfflinePlayer)new FakeOfflinePlayer(name)).setScore(score);
            }
        });
    }
    
    @Override
    protected void removeScore(final String name) {
        this.changes.add(new ScoreboardChange() {
            @Override
            public void execute(final Objective o) {
                o.getScoreboard().resetScores((OfflinePlayer)new FakeOfflinePlayer(name));
            }
        });
    }
    
    @Override
    public void cleanup() {
        super.cleanup();
        this.o.unregister();
        this.t.unregister();
    }
    
    @Override
    protected void flush() {
        if (this.changes.isEmpty()) {
            return;
        }
        final ImmutableSet.Builder<ScoreboardChange> changesBuilder = ImmutableSet.builder();
        ScoreboardChange pending;
        while ((pending = this.changes.poll()) != null) {
            changesBuilder.add(pending);
        }
        final ImmutableSet<ScoreboardChange> changes = changesBuilder.build();
        for (final ScoreboardChange change : changes) {
            change.execute(this.buffer);
        }
        this.swapBuffer();
        for (final ScoreboardChange change : changes) {
            change.execute(this.buffer);
        }
    }
    
    public void swapBuffer() {
        this.buffer.setDisplaySlot(this.o.getDisplaySlot());
        this.buffer.setDisplayName(this.o.getDisplayName());
        this.t = this.o;
        this.o = this.buffer;
        this.buffer = this.t;
    }
    
    public TechPlayer getPlayer() {
        return this.player;
    }
    
    public interface ScoreboardChange
    {
        void execute(final Objective p0);
    }
}
