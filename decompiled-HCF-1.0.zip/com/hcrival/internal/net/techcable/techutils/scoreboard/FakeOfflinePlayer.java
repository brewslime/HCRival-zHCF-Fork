package com.hcrival.internal.net.techcable.techutils.scoreboard;

import com.hcrival.internal.net.techcable.techutils.uuid.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;
import com.google.common.collect.*;
import java.beans.*;

public class FakeOfflinePlayer implements OfflinePlayer
{
    private final String name;
    private UUID id;
    
    public boolean isOnline() {
        return Bukkit.getOfflinePlayer(this.getUniqueId()) != null && Bukkit.getOfflinePlayer(this.getUniqueId()).isOnline();
    }
    
    public String getName() {
        return this.name;
    }
    
    public UUID getUniqueId() {
        if (this.id == null) {
            this.id = UUIDUtils.getId(this.name);
            if (this.id == null) {
                this.id = UUID.randomUUID();
            }
        }
        return this.id;
    }
    
    public boolean isBanned() {
        return Bukkit.getOfflinePlayer(this.getUniqueId()) != null && Bukkit.getOfflinePlayer(this.getUniqueId()).isBanned();
    }
    
    public void setBanned(final boolean b) {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            Bukkit.getOfflinePlayer(this.getUniqueId()).setBanned(false);
        }
    }
    
    public boolean isWhitelisted() {
        return Bukkit.getOfflinePlayer(this.getUniqueId()) == null || Bukkit.getOfflinePlayer(this.getUniqueId()).isWhitelisted();
    }
    
    public void setWhitelisted(final boolean b) {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            Bukkit.getOfflinePlayer(this.getUniqueId()).setWhitelisted(b);
        }
    }
    
    public Player getPlayer() {
        return Bukkit.getPlayer(this.getUniqueId());
    }
    
    public long getFirstPlayed() {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            return Bukkit.getOfflinePlayer(this.getUniqueId()).getFirstPlayed();
        }
        return 0L;
    }
    
    public long getLastPlayed() {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            return Bukkit.getOfflinePlayer(this.getUniqueId()).getLastPlayed();
        }
        return 0L;
    }
    
    public boolean hasPlayedBefore() {
        return Bukkit.getOfflinePlayer(this.getUniqueId()) != null && Bukkit.getOfflinePlayer(this.getUniqueId()).hasPlayedBefore();
    }
    
    public Location getBedSpawnLocation() {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            return Bukkit.getOfflinePlayer(this.getUniqueId()).getBedSpawnLocation();
        }
        return null;
    }
    
    public Map<String, Object> serialize() {
        final Map<String, Object> map = (Map<String, Object>)Maps.newHashMap();
        map.put("name", this.name);
        if (this.id != null) {
            map.put("id", this.id.toString());
        }
        return map;
    }
    
    public static FakeOfflinePlayer deserialize(final Map<String, Object> map) {
        final String name = map.get("name");
        final FakeOfflinePlayer player = new FakeOfflinePlayer(name);
        if (map.containsKey("id")) {
            player.id = UUID.fromString(map.get("id"));
        }
        return player;
    }
    
    public boolean isOp() {
        return Bukkit.getOfflinePlayer(this.getUniqueId()) != null && Bukkit.getOfflinePlayer(this.getUniqueId()).isOp();
    }
    
    public void setOp(final boolean b) {
        if (Bukkit.getOfflinePlayer(this.getUniqueId()) != null) {
            Bukkit.getOfflinePlayer(this.getUniqueId()).setOp(b);
        }
    }
    
    @ConstructorProperties({ "name" })
    public FakeOfflinePlayer(final String name) {
        this.name = name;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof FakeOfflinePlayer)) {
            return false;
        }
        final FakeOfflinePlayer other = (FakeOfflinePlayer)o;
        if (!other.canEqual(this)) {
            return false;
        }
        final Object this$name = this.getName();
        final Object other$name = other.getName();
        if (this$name == null) {
            if (other$name == null) {
                return true;
            }
        }
        else if (this$name.equals(other$name)) {
            return true;
        }
        return false;
    }
    
    protected boolean canEqual(final Object other) {
        return other instanceof FakeOfflinePlayer;
    }
    
    @Override
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $name = this.getName();
        result = result * 59 + (($name == null) ? 0 : $name.hashCode());
        return result;
    }
}
