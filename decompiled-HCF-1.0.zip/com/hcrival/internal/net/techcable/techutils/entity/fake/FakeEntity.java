package com.hcrival.internal.net.techcable.techutils.entity.fake;

import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.packet.wrappers.*;
import org.bukkit.util.*;
import org.bukkit.*;
import com.hcrival.internal.net.techcable.techutils.packet.*;
import java.beans.*;
import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;

public abstract class FakeEntity
{
    private boolean spawned;
    protected static final int fakeEntityId;
    protected final Player player;
    protected final WrappedDataWatcher watcher;
    private final Vector velocity;
    private Location location;
    
    public void spawn(final Location location) {
        if (this.isSpawned()) {
            throw new IllegalStateException("Already spawned");
        }
        if (!location.getWorld().equals(this.player.getWorld())) {
            throw new IllegalArgumentException("Must be in the same world as the player");
        }
        this.location = location;
        final PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving(FakeEntity.fakeEntityId, this.getMobTypeId(), location, this.velocity, this.watcher);
        packet.sendTo(this.player);
        this.spawned = true;
    }
    
    public void despawn() {
        if (!this.isSpawned()) {
            throw new IllegalStateException("Can only despawn a spawned entity");
        }
        final PacketPlayOutEntityDestroy packet = new PacketPlayOutEntityDestroy(new int[] { FakeEntity.fakeEntityId });
        packet.sendTo(this.player);
        this.spawned = false;
    }
    
    public void update() {
        if (!this.isSpawned()) {
            return;
        }
        final PacketPlayOutEntityMetadata packet = new PacketPlayOutEntityMetadata(FakeEntity.fakeEntityId, this.watcher);
        packet.sendTo(this.player);
    }
    
    public void move(final Location location) {
        if (!location.getWorld().equals(this.player.getWorld())) {
            throw new IllegalArgumentException("Must be in the same world as the player");
        }
        this.location = location;
        final boolean onGround = location.getWorld().getBlockAt(location.getBlockX(), location.getBlockY() - 1, location.getBlockZ()).getType().isSolid();
        final PacketPlayOutEntityTeleport packet = new PacketPlayOutEntityTeleport(FakeEntity.fakeEntityId, location, onGround);
        packet.sendTo(this.player);
    }
    
    public void setHealth(float health) {
        if (health < 0.1f) {
            health = 0.1f;
        }
        else if (health > this.getMaxHealth()) {
            health = this.getMaxHealth();
        }
        this.watcher.setFloat(6, health);
    }
    
    public void setCustomName(final String name) {
        if (Packet.getProtocolVersion(this.player) > 5) {
            this.watcher.setString(2, name);
        }
        else {
            this.watcher.setString(10, name);
        }
    }
    
    public void setInvisible(final boolean invisible) {
        this.set0Flag(5, invisible);
    }
    
    private void set0Flag(final int flagIndex, final boolean value) {
        final byte b = (byte)(this.watcher.hasIndex(0) ? this.watcher.getByte(0) : 0);
        if (value) {
            this.watcher.setByte(0, (byte)(b | 1 << flagIndex));
        }
        else {
            this.watcher.setByte(0, (byte)(b & ~(1 << flagIndex)));
        }
    }
    
    public abstract float getMaxHealth();
    
    public abstract byte getMobTypeId();
    
    @ConstructorProperties({ "player" })
    public FakeEntity(final Player player) {
        this.spawned = false;
        this.watcher = new WrappedDataWatcher();
        this.velocity = new Vector(0, 0, 0);
        this.player = player;
    }
    
    public boolean isSpawned() {
        return this.spawned;
    }
    
    static {
        final Field entityCountField = Reflection.makeField(Reflection.getNmsClass("Entity"), "entityCount");
        int entityCount = Reflection.getField(entityCountField, null);
        fakeEntityId = entityCount++;
        Reflection.setField(entityCountField, null, entityCount);
    }
}
