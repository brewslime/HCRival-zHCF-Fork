package com.hcrival.internal.net.techcable.techutils.entity;

import java.util.*;
import com.hcrival.internal.net.techcable.techutils.*;
import com.hcrival.internal.net.techcable.techutils.uuid.*;
import com.hcrival.internal.net.techcable.techutils.scoreboard.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.beans.*;

public class TechPlayer
{
    private final UUID id;
    private final TechPlugin<?> plugin;
    private TechBoard scoreboard;
    
    public TechPlugin<?> getPlugin() {
        return this.plugin;
    }
    
    public UUID getId() {
        return this.id;
    }
    
    public Player getEntity() {
        return Bukkit.getPlayer(this.getId());
    }
    
    public boolean isOnline() {
        return this.getEntity() != null;
    }
    
    public String getName() {
        final String name = UUIDUtils.getName(this.getId());
        assert name != null : "Unable to lookup name";
        return name;
    }
    
    final void destroy() {
        if (this.scoreboard != null) {
            this.scoreboard.cleanup();
        }
        this.cleanup();
    }
    
    public TechBoard getScoreboard() {
        if (this.scoreboard == null) {
            this.scoreboard = new BukkitTechBoard(this);
        }
        return this.scoreboard;
    }
    
    public boolean teleport(final Location to) {
        return this.teleport(to, false);
    }
    
    public boolean teleport(final Location to, final boolean preserveMount) {
        return teleport((Entity)this.getEntity(), to, preserveMount);
    }
    
    private static boolean teleport(final Entity entity, final Location to, final boolean preserveMount) {
        if (entity == null) {
            return false;
        }
        final Entity vehicle = entity.getVehicle();
        final boolean wasRiding = entity.leaveVehicle();
        final boolean success = entity.teleport(to);
        if (wasRiding && preserveMount) {
            teleport(vehicle, to, preserveMount);
            vehicle.setPassenger(entity);
        }
        return success;
    }
    
    protected void cleanup() {
    }
    
    @Override
    public final boolean equals(final Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (other instanceof TechPlayer) {
            final UUID otherId = ((TechPlayer)other).getId();
            return this.getId().equals(otherId);
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        return this.getId().hashCode();
    }
    
    @ConstructorProperties({ "id", "plugin" })
    public TechPlayer(final UUID id, final TechPlugin<?> plugin) {
        this.id = id;
        this.plugin = plugin;
    }
}
