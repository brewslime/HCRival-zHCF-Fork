package com.hcrival.internal.net.techcable.techutils.entity;

import com.hcrival.internal.net.techcable.techutils.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

public class PlayerManager<T extends TechPlayer> implements Listener
{
    private final TechPlugin<T> plugin;
    private final Map<Player, T> players;
    
    public PlayerManager(final TechPlugin<T> plugin) {
        this.players = new WeakHashMap<Player, T>();
        (this.plugin = plugin).registerListener((Listener)this);
    }
    
    public boolean isKnown(final UUID id) {
        return this.isKnown(Bukkit.getPlayer(id));
    }
    
    public boolean isKnown(final Player player) {
        return this.players.containsKey(player);
    }
    
    public T getPlayer(final UUID id) {
        final Player player = Bukkit.getPlayer(id);
        return this.getPlayer(player);
    }
    
    public T getPlayer(final Player player) {
        if (player == null) {
            return null;
        }
        if (!this.isKnown(player)) {
            final T created = this.getPlugin().createPlayer(player.getUniqueId());
            this.players.put(player, created);
        }
        return this.players.get(player);
    }
    
    public void onShutdown() {
        for (final T player : this.players.values()) {
            player.destroy();
        }
        this.players.clear();
    }
    
    @EventHandler
    public void onQuit(final PlayerQuitEvent event) {
        final TechPlayer player = this.getPlayer(event.getPlayer());
        new BukkitRunnable() {
            public void run() {
                player.destroy();
            }
        }.runTaskLater((Plugin)this.plugin, 1L);
    }
    
    @EventHandler
    public void onQuit(final PlayerKickEvent event) {
        final TechPlayer player = this.getPlayer(event.getPlayer());
        new BukkitRunnable() {
            public void run() {
                player.destroy();
            }
        }.runTaskLater((Plugin)this.plugin, 1L);
    }
    
    TechPlugin<T> getPlugin() {
        return this.plugin;
    }
}
