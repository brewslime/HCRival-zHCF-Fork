package com.hcrival.internal.net.techcable.techutils.entity.fake;

import org.bukkit.entity.*;

public class FakeWither extends FakeEntity
{
    public static final int MAX_HEALTH = 300;
    public static final int MOB_ID = 64;
    
    public FakeWither(final Player player) {
        super(player);
    }
    
    @Override
    public float getMaxHealth() {
        return 300.0f;
    }
    
    @Override
    public byte getMobTypeId() {
        return 64;
    }
}
