package com.hcrival.internal.net.techcable.techutils.entity.fake;

import org.bukkit.entity.*;

public class FakeDragon extends FakeEntity
{
    public static final byte ENTITY_TYPE = 63;
    public static final float MAX_HEALTH = 200.0f;
    
    public FakeDragon(final Player player) {
        super(player);
    }
    
    @Override
    public float getMaxHealth() {
        return 200.0f;
    }
    
    @Override
    public byte getMobTypeId() {
        return 63;
    }
}
