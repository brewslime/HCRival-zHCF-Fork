package com.hcrival.internal.net.techcable.techutils;

import org.json.simple.parser.*;
import java.net.*;
import org.json.simple.*;
import java.io.*;

public class HttpUtils
{
    private static JSONParser PARSER;
    
    public static Object getJson(final String rawUrl) {
        BufferedReader reader = null;
        try {
            final URL url = new URL(rawUrl);
            final HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            final StringBuffer result = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            return HttpUtils.PARSER.parse(result.toString());
        }
        catch (Exception ex2) {
            return null;
        }
        finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
                return null;
            }
        }
    }
    
    public static Object postJson(final String url, final JSONArray body) {
        final String rawResponse = post(url, body.toJSONString());
        if (rawResponse == null) {
            return null;
        }
        try {
            return HttpUtils.PARSER.parse(rawResponse);
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static String post(final String rawUrl, final String body) {
        BufferedReader reader = null;
        OutputStream out = null;
        try {
            final URL url = new URL(rawUrl);
            final HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            out = connection.getOutputStream();
            out.write(body.getBytes());
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            final StringBuffer result = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            return result.toString();
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (reader != null) {
                    reader.close();
                }
            }
            catch (IOException ex2) {
                ex2.printStackTrace();
                return null;
            }
        }
    }
    
    static {
        HttpUtils.PARSER = new JSONParser();
    }
}
