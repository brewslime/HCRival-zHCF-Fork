package com.hcrival.internal.net.techcable.techutils.scheduler;

public interface TechTask
{
    void addCompletionListener(final Runnable p0);
    
    boolean isSync();
    
    boolean cancel();
}
