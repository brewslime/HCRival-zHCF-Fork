package com.hcrival.internal.net.techcable.techutils.scheduler;

import java.util.concurrent.*;
import org.bukkit.*;
import com.google.common.base.*;
import java.util.*;

public class TechSchedulerImpl extends TechScheduler
{
    private final Executor executor;
    private final Queue<ListenableFutureTechTask<?>> registerQueue;
    private final Set<ListenableFutureTechTask<?>> tasks;
    
    public TechSchedulerImpl() {
        this.executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() + 4);
        this.registerQueue = new ConcurrentLinkedQueue<ListenableFutureTechTask<?>>();
        this.tasks = new HashSet<ListenableFutureTechTask<?>>();
        TickUtils.addTickListener(new Runnable() {
            @Override
            public void run() {
                TechSchedulerImpl.this.tick();
            }
        });
    }
    
    @Override
    protected void addTask(final ListenableFutureTechTask<?> task) {
        this.registerQueue.add(task);
    }
    
    public void tick() {
        Preconditions.checkState(Bukkit.isPrimaryThread(), (Object)"Must be ticked from main thread");
        for (final ListenableFutureTechTask task : this.registerQueue) {
            this.tasks.add(task);
        }
        for (final ListenableFutureTechTask<?> toTick : this.tasks) {
            toTick.tick(this.executor);
        }
    }
}
