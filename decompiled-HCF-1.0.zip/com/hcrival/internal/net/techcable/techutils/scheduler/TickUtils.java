package com.hcrival.internal.net.techcable.techutils.scheduler;

import com.google.common.annotations.*;
import org.bukkit.scheduler.*;
import java.util.concurrent.*;
import com.google.common.base.*;
import org.bukkit.command.*;
import java.util.*;
import org.bukkit.configuration.file.*;
import java.io.*;
import org.bukkit.plugin.*;
import org.bukkit.*;
import com.avaje.ebean.*;
import org.bukkit.generator.*;
import java.util.logging.*;

@Beta
public class TickUtils
{
    private static final Object $LOCK;
    private static final Class<? extends BukkitScheduler> schedulerClass;
    private static volatile long currentTick;
    private static final Set<Runnable> tickListeners;
    private static boolean setup;
    private static final Executor mainThreadExecutor;
    
    public static long getCurrentTick() {
        return TickUtils.currentTick;
    }
    
    private static void tick() {
        Preconditions.checkState(Bukkit.isPrimaryThread(), (Object)"Not on main thread");
        ++TickUtils.currentTick;
        for (final Runnable tickListener : TickUtils.tickListeners) {
            try {
                tickListener.run();
            }
            catch (Exception ex) {}
        }
    }
    
    private static void injectTicker() {
        Bukkit.getScheduler().runTaskTimer((Plugin)new FakePlugin(), (Runnable)new Runnable() {
            @Override
            public void run() {
                tick();
            }
        }, 0L, 1L);
    }
    
    public static void addTickListener(final Runnable tickListener) {
        synchronized (TickUtils.$LOCK) {
            TickUtils.tickListeners.add(tickListener);
            if (TickUtils.setup) {
                return;
            }
            injectTicker();
            TickUtils.setup = true;
        }
    }
    
    private TickUtils() {
    }
    
    public static Executor getMainThreadExecutor() {
        return TickUtils.mainThreadExecutor;
    }
    
    static {
        $LOCK = new Object[0];
        schedulerClass = Bukkit.getScheduler().getClass();
        tickListeners = new HashSet<Runnable>();
        mainThreadExecutor = new Executor() {
            @Override
            public void execute(final Runnable command) {
                TechScheduler.scheduleSyncTask(command, 0L);
            }
        };
    }
    
    public static class FakePlugin implements Plugin
    {
        public List<String> onTabComplete(final CommandSender sender, final Command command, final String alias, final String[] args) {
            return null;
        }
        
        public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
            return false;
        }
        
        public File getDataFolder() {
            return null;
        }
        
        public PluginDescriptionFile getDescription() {
            return new PluginDescriptionFile("TickUtils", "1.1.0", TickUtils.class.getName());
        }
        
        public FileConfiguration getConfig() {
            return null;
        }
        
        public InputStream getResource(final String filename) {
            return null;
        }
        
        public void saveConfig() {
        }
        
        public void saveDefaultConfig() {
        }
        
        public void saveResource(final String resourcePath, final boolean replace) {
        }
        
        public void reloadConfig() {
        }
        
        public PluginLoader getPluginLoader() {
            return null;
        }
        
        public Server getServer() {
            return Bukkit.getServer();
        }
        
        public boolean isEnabled() {
            return true;
        }
        
        public void onDisable() {
        }
        
        public void onLoad() {
        }
        
        public void onEnable() {
        }
        
        public boolean isNaggable() {
            return false;
        }
        
        public void setNaggable(final boolean canNag) {
        }
        
        public EbeanServer getDatabase() {
            return null;
        }
        
        public ChunkGenerator getDefaultWorldGenerator(final String worldName, final String id) {
            return null;
        }
        
        public Logger getLogger() {
            return null;
        }
        
        public String getName() {
            return null;
        }
    }
}
