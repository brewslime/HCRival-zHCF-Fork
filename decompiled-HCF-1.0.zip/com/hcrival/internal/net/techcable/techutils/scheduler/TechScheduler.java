package com.hcrival.internal.net.techcable.techutils.scheduler;

import com.google.common.annotations.*;
import com.hcrival.internal.net.techcable.techutils.collect.*;
import java.util.concurrent.*;
import com.google.common.util.concurrent.*;

@Beta
public abstract class TechScheduler
{
    private static TechScheduler instance;
    private static final ListeningExecutorService executor;
    
    protected TechScheduler() {
    }
    
    public static TechTask scheduleAsyncTask(final Runnable task, final long delay) {
        final ListenableFutureTechTask techTask = ListenableFutureTechTask.create(Either.ofSecond(task), false, delay);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    public static <T> FutureTechTask<T> scheduleAsyncTask(final Callable<T> task, final long delay) {
        final ListenableFutureTechTask<T> techTask = ListenableFutureTechTask.create((Either<Callable<T>, Runnable>)Either.ofFirst((Callable<V>)task), false, delay);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    public static TechTask scheduleAsyncTask(final Runnable task, final long delay, final long interval) {
        final ListenableFutureTechTask techTask = ListenableFutureTechTask.createRepeating(Either.ofSecond(task), false, delay, interval);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    public static TechTask scheduleSyncTask(final Runnable task, final long delay) {
        final ListenableFutureTechTask techTask = ListenableFutureTechTask.create(Either.ofSecond(task), true, delay);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    public static <V> FutureTechTask<V> scheduleSyncTask(final Callable<V> task, final long delay) {
        final ListenableFutureTechTask<V> techTask = ListenableFutureTechTask.create((Either<Callable<V>, Runnable>)Either.ofFirst((Callable<V>)task), true, delay);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    public static TechTask scheduleSyncTask(final Runnable task, final long delay, final long period) {
        final ListenableFutureTechTask<?> techTask = ListenableFutureTechTask.create(Either.ofSecond(task), true, delay);
        getInstance().addTask(techTask);
        return techTask;
    }
    
    protected abstract void addTask(final ListenableFutureTechTask<?> p0);
    
    public static TechScheduler getInstance() {
        return TechScheduler.instance;
    }
    
    public static void setInstance(final TechScheduler instance) {
        TechScheduler.instance = instance;
    }
    
    static {
        TechScheduler.instance = new TechSchedulerImpl();
        executor = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors()));
    }
}
