package com.hcrival.internal.net.techcable.techutils.scheduler;

public interface FutureTechTask<V> extends TechTask
{
    void addCompletionListener(final CompletionListener<V> p0);
    
    public interface CompletionListener<V>
    {
        void onSuccess(final V p0);
    }
}
