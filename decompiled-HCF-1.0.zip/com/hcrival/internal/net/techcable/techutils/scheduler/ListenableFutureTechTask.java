package com.hcrival.internal.net.techcable.techutils.scheduler;

import com.hcrival.internal.net.techcable.techutils.collect.*;
import com.google.common.util.concurrent.*;
import java.util.concurrent.*;

public class ListenableFutureTechTask<V> extends AbstractFuture<V> implements FutureTechTask<V>
{
    private final Either<Callable<V>, Runnable> task;
    private final boolean sync;
    private boolean repeating;
    private long period;
    private long ticksTillNextExecution;
    
    protected void tick(Executor executor) {
        if (this.ticksTillNextExecution != 0L) {
            --this.ticksTillNextExecution;
            return;
        }
        executor = (this.sync ? MoreExecutors.sameThreadExecutor() : executor);
        final Runnable runnable = this.task.hasFirst() ? new Runnable() {
            @Override
            public void run() {
                try {
                    final V value = ListenableFutureTechTask.this.task.getFirst().call();
                    AbstractFuture.this.set(value);
                }
                catch (Throwable t) {
                    AbstractFuture.this.setException(t);
                }
            }
        } : this.task.getSecond();
        executor.execute(runnable);
        if (this.repeating) {
            this.ticksTillNextExecution = this.period;
        }
    }
    
    @Override
    public void addCompletionListener(final Runnable r) {
        this.addCompletionListener(new CompletionListener<V>() {
            @Override
            public void onSuccess(final V value) {
                r.run();
            }
        });
    }
    
    @Override
    public boolean cancel() {
        return this.cancel(false);
    }
    
    static <V> ListenableFutureTechTask<V> create(final Either<Callable<V>, Runnable> task, final boolean sync, final long delay) {
        final ListenableFutureTechTask<V> techTask = new ListenableFutureTechTask<V>(task, sync);
        techTask.ticksTillNextExecution = delay;
        return techTask;
    }
    
    static <V> ListenableFutureTechTask<V> createRepeating(final Either<Callable<V>, Runnable> task, final boolean sync, final long delay, final long period) {
        final ListenableFutureTechTask<V> techTask = new ListenableFutureTechTask<V>(task, sync);
        techTask.ticksTillNextExecution = delay;
        techTask.repeating = true;
        techTask.period = period;
        return techTask;
    }
    
    @Override
    public void addCompletionListener(final CompletionListener<V> listener) {
        this.addListener(new Runnable() {
            @Override
            public void run() {
                final V value = Futures.getUnchecked((Future<V>)ListenableFutureTechTask.this);
                listener.onSuccess(value);
            }
        }, MoreExecutors.sameThreadExecutor());
    }
    
    private ListenableFutureTechTask(final Either<Callable<V>, Runnable> task, final boolean sync) {
        this.ticksTillNextExecution = 0L;
        this.task = task;
        this.sync = sync;
    }
    
    @Override
    public boolean isSync() {
        return this.sync;
    }
}
