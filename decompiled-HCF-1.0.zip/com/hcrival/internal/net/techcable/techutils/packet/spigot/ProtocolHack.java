package com.hcrival.internal.net.techcable.techutils.packet.spigot;

import com.hcrival.internal.net.techcable.techutils.*;
import org.bukkit.entity.*;
import java.lang.reflect.*;

public class ProtocolHack
{
    public static final Class<?> PACKET_TITLE_ACTION;
    public static final Class<?> PACKET_TITLE;
    
    private ProtocolHack() {
    }
    
    public static boolean isProtocolHack() {
        return Reflection.getClass("org.spigotmc.ProtocolData") != null;
    }
    
    public static boolean is1_8(final Player p) {
        return isProtocolHack() && getProtocolVersion(p) >= 47;
    }
    
    public static int getProtocolVersion(final Player player) {
        final Object handle = Reflection.getHandle(player);
        final Object connection = Reflection.getField(Reflection.makeField(handle.getClass(), "playerConnection"), handle);
        final Object networkManager = Reflection.getField(Reflection.makeField(connection.getClass(), "networkManager"), connection);
        final Method getVersion = Reflection.makeMethod(networkManager.getClass(), "getVersion", (Class<?>[])new Class[0]);
        return Reflection.callMethod(getVersion, networkManager, new Object[0]);
    }
    
    static {
        PACKET_TITLE_ACTION = Reflection.getClass("org.spigotmc.ProtocolInjector$PacketTitle$Action");
        PACKET_TITLE = Reflection.getClass("org.spigotmc.ProtocolInjector$PacketTitle");
    }
}
