package com.hcrival.internal.net.techcable.techutils.packet;

import java.lang.reflect.*;
import com.hcrival.internal.net.techcable.techutils.*;

public class PacketPlayOutEntityDestroy extends Packet
{
    private static final Class<?> PACKET_CLASS;
    private static final Field toDestroy;
    private static final Constructor constructor;
    private final Object handle;
    
    public PacketPlayOutEntityDestroy(final int... idsToDestroy) {
        this.handle = Reflection.callConstructor((Constructor<Object>)PacketPlayOutEntityDestroy.constructor, new Object[0]);
        Reflection.setField(PacketPlayOutEntityDestroy.toDestroy, this.handle, idsToDestroy);
    }
    
    @Override
    public Class<?> getPacketClass() {
        return PacketPlayOutEntityDestroy.PACKET_CLASS;
    }
    
    @Override
    public Object getHandle() {
        return this.handle;
    }
    
    static {
        PACKET_CLASS = Reflection.getNmsClass("PacketPlayOutEntityDestroy");
        toDestroy = PacketPlayOutEntityDestroy.PACKET_CLASS.getDeclaredFields()[0];
        constructor = Reflection.makeConstructor(PacketPlayOutEntityDestroy.PACKET_CLASS, (Class<?>[])new Class[0]);
    }
}
