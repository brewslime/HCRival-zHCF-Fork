package com.hcrival.internal.net.techcable.techutils.packet;

import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;

public class Converters
{
    private Converters() {
    }
    
    public static Converter<String, Object[]> getIChatBaseComponentConverter() {
        return new Converter<String, Object[]>() {
            @Override
            public Object[] toNms(final String chat) {
                if (chat == null) {
                    return null;
                }
                final Class<?> craftChatMessage = Reflection.getCbClass("util.CraftChatMessage");
                final Method fromString = Reflection.makeMethod(craftChatMessage, "fromString", String.class);
                return Reflection.callMethod(fromString, null, chat);
            }
            
            @Override
            public String toWrapper(final Object[] nmsArray) {
                if (nmsArray == null) {
                    return null;
                }
                if (nmsArray.length == 0) {
                    return "";
                }
                final StringBuilder output = new StringBuilder();
                for (final Object nms : nmsArray) {
                    output.append(this.toWrapper0(nms));
                }
                return output.toString();
            }
            
            private String toWrapper0(final Object nms) {
                final Class<?> craftChatMessage = Reflection.getCbClass("util.CraftChatMessage");
                final Method fromString = Reflection.makeMethod(craftChatMessage, "fromString", Reflection.getNmsClass("IChatBaseComponent"));
                return Reflection.callMethod(fromString, null, nms);
            }
        };
    }
    
    public interface Converter<T, U>
    {
        U toNms(final T p0);
        
        T toWrapper(final U p0);
    }
}
