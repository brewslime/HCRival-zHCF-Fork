package com.hcrival.internal.net.techcable.techutils.packet;

import java.lang.reflect.*;
import org.bukkit.*;
import org.bukkit.util.*;
import com.hcrival.internal.net.techcable.techutils.packet.wrappers.*;
import com.hcrival.internal.net.techcable.techutils.*;

public class PacketPlayOutSpawnEntityLiving extends Packet
{
    public static final Class<?> PACKET_CLASS;
    private static Field entityIdField;
    private static Field entityTypeField;
    private static Field entityXField;
    private static Field entityYField;
    private static Field entityZField;
    private static Field entityVelocityXField;
    private static Field entityVelocityYField;
    private static Field entityVelocityZField;
    private static Field entityYawField;
    private static Field entityPitchField;
    private static Field entityHeadPitchField;
    private static Field entityDataWatcherField;
    private static final Constructor constructor;
    private final Object handle;
    
    public PacketPlayOutSpawnEntityLiving(final int entityId, final byte entityType, final Location location, final Vector bukkitVelocity, final WrappedDataWatcher watcher) {
        this.handle = Reflection.callConstructor((Constructor<Object>)PacketPlayOutSpawnEntityLiving.constructor, new Object[0]);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityIdField, this.handle, entityId);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityTypeField, this.handle, (int)entityType);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityXField, this.handle, Packet.toFixedPoint(location.getX()));
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityYField, this.handle, Packet.toFixedPoint(location.getY()));
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityZField, this.handle, Packet.toFixedPoint(location.getZ()));
        final int[] velocity = Packet.doVelocityMagic(bukkitVelocity.getX(), bukkitVelocity.getY(), bukkitVelocity.getZ());
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityVelocityXField, this.handle, velocity[0]);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityVelocityYField, this.handle, velocity[1]);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityVelocityZField, this.handle, velocity[2]);
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityYawField, this.handle, Packet.toByteAngle(location.getYaw()));
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityPitchField, this.handle, Packet.toByteAngle(location.getPitch()));
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityHeadPitchField, this.handle, Packet.toByteAngle(location.getPitch()));
        Reflection.setField(PacketPlayOutSpawnEntityLiving.entityDataWatcherField, this.handle, watcher.getHandle());
    }
    
    @Override
    public Class<?> getPacketClass() {
        return PacketPlayOutSpawnEntityLiving.PACKET_CLASS;
    }
    
    @Override
    public Object getHandle() {
        return this.handle;
    }
    
    static {
        PACKET_CLASS = Reflection.getNmsClass("PacketPlayOutSpawnEntityLiving");
        final Field[] fields = PacketPlayOutSpawnEntityLiving.PACKET_CLASS.getDeclaredFields();
        PacketPlayOutSpawnEntityLiving.entityIdField = fields[0];
        PacketPlayOutSpawnEntityLiving.entityTypeField = fields[1];
        PacketPlayOutSpawnEntityLiving.entityXField = fields[2];
        PacketPlayOutSpawnEntityLiving.entityYField = fields[3];
        PacketPlayOutSpawnEntityLiving.entityZField = fields[4];
        PacketPlayOutSpawnEntityLiving.entityVelocityXField = fields[5];
        PacketPlayOutSpawnEntityLiving.entityVelocityYField = fields[6];
        PacketPlayOutSpawnEntityLiving.entityVelocityZField = fields[7];
        PacketPlayOutSpawnEntityLiving.entityYawField = fields[8];
        PacketPlayOutSpawnEntityLiving.entityPitchField = fields[9];
        PacketPlayOutSpawnEntityLiving.entityHeadPitchField = fields[10];
        PacketPlayOutSpawnEntityLiving.entityDataWatcherField = fields[11];
        constructor = Reflection.makeConstructor(PacketPlayOutSpawnEntityLiving.PACKET_CLASS, (Class<?>[])new Class[0]);
    }
}
