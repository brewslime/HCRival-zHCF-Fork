package com.hcrival.internal.net.techcable.techutils.packet;

import java.lang.reflect.*;
import org.bukkit.entity.*;
import com.hcrival.internal.net.techcable.techutils.*;

public abstract class Packet
{
    private Object handle;
    private static Field playerConnectionField;
    private static Method sendPacketMethod;
    private static Field networkManagerField;
    private static Method getVersionMethod;
    
    public void sendTo(final Player p) {
        if (!this.isCompatible(p)) {}
        final Object handle = Reflection.getHandle(p);
        final Object playerConnection = Reflection.getField(Packet.playerConnectionField, handle);
        Reflection.callMethod(Packet.sendPacketMethod, playerConnection, this.getHandle());
    }
    
    public abstract Class<?> getPacketClass();
    
    public boolean isCompatible(final Player p) {
        return true;
    }
    
    public static int toFixedPoint(final double d) {
        return (int)Math.floor(d * 32.0);
    }
    
    public static byte toByteAngle(final double d) {
        return (byte)(d * 256.0 / 360.0);
    }
    
    public static int getProtocolVersion(final Player player) {
        final Object handle = Reflection.getHandle(player);
        final Object connection = Reflection.getField(Packet.playerConnectionField, handle);
        final Object networkManager = Reflection.getField(Packet.networkManagerField, connection);
        if (Packet.getVersionMethod != null) {
            final int version = Reflection.callMethod(Packet.getVersionMethod, networkManager, new Object[0]);
            return version;
        }
        if (Reflection.getVersion().startsWith("v1_8")) {
            return 47;
        }
        if (Reflection.getVersion().startsWith("v1_7")) {
            return 5;
        }
        throw new RuntimeException("Unsupported server version " + Reflection.getVersion());
    }
    
    public static int[] doVelocityMagic(double velocityX, double velocityY, double velocityZ) {
        final double d0 = 3.9;
        if (velocityX < -d0) {
            velocityX = -d0;
        }
        if (velocityY < -d0) {
            velocityY = -d0;
        }
        if (velocityZ < -d0) {
            velocityZ = -d0;
        }
        if (velocityX > d0) {
            velocityX = d0;
        }
        if (velocityY > d0) {
            velocityY = d0;
        }
        if (velocityZ > d0) {
            velocityZ = d0;
        }
        return new int[] { (int)(velocityX * 8000.0), (int)(velocityY * 8000.0), (int)(velocityZ * 8000.0) };
    }
    
    public Object getHandle() {
        return this.handle;
    }
    
    public void setHandle(final Object handle) {
        this.handle = handle;
    }
    
    static {
        Packet.playerConnectionField = Reflection.makeField(Reflection.getNmsClass("EntityPlayer"), "playerConnection");
        Packet.sendPacketMethod = Reflection.makeMethod(Reflection.getNmsClass("PlayerConnection"), "sendPacket", Reflection.getNmsClass("Packet"));
        Packet.networkManagerField = Reflection.makeField(Reflection.getNmsClass("PlayerConnection"), "networkManager");
        Packet.getVersionMethod = Reflection.makeMethod(Reflection.getNmsClass("NetworkManager"), "getVersion", (Class<?>[])new Class[0]);
    }
}
