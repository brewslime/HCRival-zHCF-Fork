package com.hcrival.internal.net.techcable.techutils.packet.wrappers;

import com.hcrival.internal.net.techcable.techutils.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.concurrent.locks.*;

public class WrappedDataWatcher
{
    private static final Class<?> clazz;
    private static final Constructor constructor;
    private static Field valueMap;
    private static Field typeMap;
    private static Field lockField;
    private final Object handle;
    
    public List<Object> toHandleList() {
        final ReadWriteLock lock = Reflection.getField(WrappedDataWatcher.lockField, this.getHandle());
        lock.readLock().lock();
        final List<Object> handleList = new ArrayList<Object>();
        try {
            final Map<Integer, Object> valueMap = Reflection.getField(WrappedDataWatcher.valueMap, this.getHandle());
            for (final Object handle : valueMap.values()) {
                handleList.add(handle);
            }
            return handleList;
        }
        finally {
            lock.readLock().unlock();
        }
    }
    
    public static int getTypeId(final Class<?> clazz) {
        final Map map = Reflection.getField(WrappedDataWatcher.typeMap, null);
        return map.get(clazz);
    }
    
    public WrappedDataWatcher() {
        this.handle = Reflection.callConstructor((Constructor<Object>)WrappedDataWatcher.constructor, null);
    }
    
    public boolean hasIndex(final int index) {
        return this.getObject(index) != null;
    }
    
    public int getInt(final int index) {
        return (byte)this.getObject(index);
    }
    
    public void setInt(final int index, final int value) {
        this.setObject(index, value);
    }
    
    public byte getByte(final int index) {
        return (byte)this.getObject(index);
    }
    
    public void setByte(final int index, final byte value) {
        this.setObject(index, value);
    }
    
    public void setFloat(final int index, final float value) {
        this.setObject(index, value);
    }
    
    public void setString(final int index, final String value) {
        this.setObject(index, value);
    }
    
    private Object getObject(final int i) {
        final Map valueMap = Reflection.getField(WrappedDataWatcher.valueMap, this.getHandle());
        final Object handle = valueMap.get(i);
        if (handle == null) {
            return null;
        }
        return new WrappedWatchableObject(handle).getValue();
    }
    
    private void setObject(final int i, final Object value) {
        final Map valueMap = Reflection.getField(WrappedDataWatcher.valueMap, this.getHandle());
        final WrappedWatchableObject watcher = new WrappedWatchableObject(i, value);
        valueMap.put(i, watcher.getHandle());
    }
    
    public Object getHandle() {
        return this.handle;
    }
    
    static {
        clazz = Reflection.getNmsClass("DataWatcher");
        constructor = Reflection.makeConstructor(WrappedDataWatcher.clazz, Reflection.getNmsClass("Entity"));
        for (final Field field : WrappedDataWatcher.clazz.getDeclaredFields()) {
            if (field.getType().equals(Map.class)) {
                if (Modifier.isStatic(field.getModifiers())) {
                    WrappedDataWatcher.typeMap = field;
                }
                else {
                    WrappedDataWatcher.valueMap = field;
                }
            }
            else if (field.getType().isAssignableFrom(ReentrantReadWriteLock.class)) {
                WrappedDataWatcher.lockField = field;
            }
        }
    }
    
    private static class WrappedWatchableObject
    {
        private static final Constructor constructor;
        private final Object handle;
        private static Field valueField;
        
        public WrappedWatchableObject(final Object handle) {
            this.handle = handle;
        }
        
        public WrappedWatchableObject(final int index, final Object value) {
            final int typeId = WrappedDataWatcher.getTypeId(value.getClass());
            this.handle = Reflection.callConstructor((Constructor<Object>)WrappedWatchableObject.constructor, typeId, index, value);
        }
        
        public Object getHandle() {
            return this.handle;
        }
        
        public Object getValue() {
            return Reflection.getField(WrappedWatchableObject.valueField, this.getHandle());
        }
        
        public void setValue(final Object value) {
            Reflection.setField(WrappedWatchableObject.valueField, this.getHandle(), value);
        }
        
        public static Class<?> getHandleClass() {
            Class<?> clazz = Reflection.getNmsClass("DataWatcher$WatchableObject");
            if (clazz == null) {
                clazz = Reflection.getNmsClass("WatchableObject");
            }
            return clazz;
        }
        
        static {
            for (final Field field : getHandleClass().getDeclaredFields()) {
                if (field.getType().equals(Object.class)) {
                    WrappedWatchableObject.valueField = field;
                }
            }
            constructor = Reflection.makeConstructor(getHandleClass(), Integer.TYPE, Integer.TYPE, Object.class);
        }
    }
}
