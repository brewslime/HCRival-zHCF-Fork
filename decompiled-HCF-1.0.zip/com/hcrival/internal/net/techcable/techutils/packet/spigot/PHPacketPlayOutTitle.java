package com.hcrival.internal.net.techcable.techutils.packet.spigot;

import com.hcrival.internal.net.techcable.techutils.packet.*;
import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;
import org.bukkit.entity.*;

public class PHPacketPlayOutTitle extends PacketPlayOutTitle
{
    public PHPacketPlayOutTitle(final TitleAction action) {
        final Constructor<?> constructor = Reflection.makeConstructor(this.getPacketClass(), TitleAction.getNmsClass());
        final Object packet = Reflection.callConstructor(constructor, action.asNms());
        this.setHandle(packet);
    }
    
    public PHPacketPlayOutTitle(final TitleAction action, final String rawChat) {
        super(action, rawChat);
    }
    
    public PHPacketPlayOutTitle(final TitleAction action, final int fadeIn, final int stay, final int fadeOut) {
        final Constructor<?> constructor = Reflection.makeConstructor(this.getPacketClass(), TitleAction.getNmsClass(), Integer.TYPE, Integer.TYPE, Integer.TYPE);
        final Object packet = Reflection.callConstructor(constructor, action.asNms(), fadeIn, stay, fadeOut);
        this.setHandle(packet);
    }
    
    @Override
    public void sendTo(final Player p) {
        if (!ProtocolHack.is1_8(p)) {
            return;
        }
        super.sendTo(p);
    }
    
    @Override
    public Class<?> getPacketClass() {
        return Reflection.getClass("org.spigotmc.ProtocolInjector$PacketTitle");
    }
}
