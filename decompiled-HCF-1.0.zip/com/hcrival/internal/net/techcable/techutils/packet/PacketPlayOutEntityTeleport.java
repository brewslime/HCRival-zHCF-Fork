package com.hcrival.internal.net.techcable.techutils.packet;

import java.lang.reflect.*;
import org.bukkit.*;
import com.hcrival.internal.net.techcable.techutils.*;

public class PacketPlayOutEntityTeleport extends Packet
{
    public static final Class<?> PACKET_CLASS;
    private static final Constructor constructor;
    private static Field teleportEntityIdField;
    private static Field teleportXField;
    private static Field teleportYField;
    private static Field teleportZField;
    private static Field teleportYawField;
    private static Field teleportPitchField;
    private static Field teleportOnGroundField;
    private final Object handle;
    
    public PacketPlayOutEntityTeleport(final int entityId, final Location l, final boolean onGround) {
        final Object handle = Reflection.callConstructor((Constructor<Object>)PacketPlayOutEntityTeleport.constructor, new Object[0]);
        this.handle = handle;
        Reflection.setField(PacketPlayOutEntityTeleport.teleportEntityIdField, handle, entityId);
        Reflection.setField(PacketPlayOutEntityTeleport.teleportXField, handle, Packet.toFixedPoint(l.getX()));
        Reflection.setField(PacketPlayOutEntityTeleport.teleportYField, handle, Packet.toFixedPoint(l.getY()));
        Reflection.setField(PacketPlayOutEntityTeleport.teleportZField, handle, Packet.toFixedPoint(l.getZ()));
        Reflection.setField(PacketPlayOutEntityTeleport.teleportYawField, handle, Packet.toByteAngle(l.getYaw()));
        Reflection.setField(PacketPlayOutEntityTeleport.teleportPitchField, handle, Packet.toByteAngle(l.getPitch()));
        if (PacketPlayOutEntityTeleport.teleportOnGroundField != null) {
            Reflection.setField(PacketPlayOutEntityTeleport.teleportOnGroundField, handle, onGround);
        }
    }
    
    @Override
    public Object getHandle() {
        return this.handle;
    }
    
    @Override
    public Class<?> getPacketClass() {
        return PacketPlayOutEntityTeleport.PACKET_CLASS;
    }
    
    static {
        PACKET_CLASS = Reflection.getNmsClass("PacketPlayOutEntityTeleport");
        final Field[] fields = PacketPlayOutEntityTeleport.PACKET_CLASS.getDeclaredFields();
        PacketPlayOutEntityTeleport.teleportEntityIdField = fields[0];
        PacketPlayOutEntityTeleport.teleportXField = fields[1];
        PacketPlayOutEntityTeleport.teleportYField = fields[2];
        PacketPlayOutEntityTeleport.teleportZField = fields[3];
        PacketPlayOutEntityTeleport.teleportYawField = fields[4];
        PacketPlayOutEntityTeleport.teleportPitchField = fields[5];
        PacketPlayOutEntityTeleport.teleportOnGroundField = fields[6];
        constructor = Reflection.makeConstructor(PacketPlayOutEntityTeleport.PACKET_CLASS, (Class<?>[])new Class[0]);
    }
}
