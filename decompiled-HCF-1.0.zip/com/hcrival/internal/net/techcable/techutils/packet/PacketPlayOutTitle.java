package com.hcrival.internal.net.techcable.techutils.packet;

import com.hcrival.internal.net.techcable.techutils.*;
import java.lang.reflect.*;
import com.hcrival.internal.net.techcable.techutils.packet.spigot.*;

public class PacketPlayOutTitle extends Packet
{
    protected PacketPlayOutTitle() {
    }
    
    private PacketPlayOutTitle(final TitleAction action) {
        this(action, null);
    }
    
    public PacketPlayOutTitle(final TitleAction action, final String rawChat) {
        final Object[] chatArray = Converters.getIChatBaseComponentConverter().toNms(rawChat);
        Object chat = null;
        if (chatArray != null && chatArray.length > 0) {
            chat = chatArray[0];
        }
        final Constructor<?> chatConstructor = Reflection.makeConstructor(this.getPacketClass(), TitleAction.getNmsClass(), Reflection.getNmsClass("IChatBaseComponent"));
        final Object packet = Reflection.callConstructor(chatConstructor, action.asNms(), chat);
        this.setHandle(packet);
    }
    
    public PacketPlayOutTitle(final TitleAction action, final int fadeIn, final int stay, final int fadeOut) {
        final Constructor<?> constructor = Reflection.makeConstructor(this.getPacketClass(), Integer.TYPE, Integer.TYPE, Integer.TYPE);
        final Object packet = Reflection.callConstructor(constructor, fadeIn, stay, fadeOut);
        this.setHandle(packet);
    }
    
    public static PacketPlayOutTitle create(final TitleAction action) {
        if (ProtocolHack.isProtocolHack()) {
            return new PHPacketPlayOutTitle(action);
        }
        if (Reflection.getNmsClass("PacketPlayOutTitle") != null) {
            return new PacketPlayOutTitle(action);
        }
        return null;
    }
    
    public static PacketPlayOutTitle create(final TitleAction action, final String chat) {
        if (ProtocolHack.isProtocolHack()) {
            return new PHPacketPlayOutTitle(action, chat);
        }
        if (Reflection.getNmsClass("PacketPlayOutTitle") != null) {
            return new PacketPlayOutTitle(action, chat);
        }
        return null;
    }
    
    public static PacketPlayOutTitle create(final TitleAction action, final int fadeIn, final int stay, final int fadeOut) {
        if (ProtocolHack.isProtocolHack()) {
            return new PHPacketPlayOutTitle(action);
        }
        if (Reflection.getNmsClass("PacketPlayOutTitle") != null) {
            return new PacketPlayOutTitle(action, fadeIn, stay, fadeOut);
        }
        return null;
    }
    
    public static boolean isSupported() {
        return ProtocolHack.isProtocolHack() || Reflection.getNmsClass("PacketPlayOutTitle") != null;
    }
    
    @Override
    public Class<?> getPacketClass() {
        return Reflection.getNmsClass("PacketPlayOutTitle");
    }
    
    public enum TitleAction
    {
        SET_TITLE, 
        SET_SUBTITLE, 
        DISPLAY, 
        HIDE, 
        RESET;
        
        public Object asNms() {
            return getNmsClass().getEnumConstants()[this.ordinal()];
        }
        
        public static Class<?> getNmsClass() {
            return ProtocolHack.isProtocolHack() ? ProtocolHack.PACKET_TITLE_ACTION : Reflection.getNmsClass("EnumTitleAction");
        }
    }
}
