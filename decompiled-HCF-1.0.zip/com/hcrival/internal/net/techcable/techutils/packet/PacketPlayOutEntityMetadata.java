package com.hcrival.internal.net.techcable.techutils.packet;

import java.lang.reflect.*;
import com.hcrival.internal.net.techcable.techutils.packet.wrappers.*;
import com.hcrival.internal.net.techcable.techutils.*;

public class PacketPlayOutEntityMetadata extends Packet
{
    private static final Class<?> PACKET_CLASS;
    private static Field entityIdField;
    private static Field dataWatcherValuesField;
    private static final Constructor constructor;
    private final Object handle;
    
    public PacketPlayOutEntityMetadata(final int entityId, final WrappedDataWatcher watcher) {
        this.handle = Reflection.callConstructor((Constructor<Object>)PacketPlayOutEntityMetadata.constructor, new Object[0]);
        Reflection.setField(PacketPlayOutEntityMetadata.entityIdField, this.handle, entityId);
        Reflection.setField(PacketPlayOutEntityMetadata.dataWatcherValuesField, this.handle, watcher.toHandleList());
    }
    
    @Override
    public Class<?> getPacketClass() {
        return PacketPlayOutEntityMetadata.PACKET_CLASS;
    }
    
    @Override
    public Object getHandle() {
        return this.handle;
    }
    
    static {
        PACKET_CLASS = Reflection.getNmsClass("PacketPlayOutEntityMetadata");
        for (int i = 0; i < PacketPlayOutEntityMetadata.PACKET_CLASS.getDeclaredFields().length; ++i) {
            final Field field = PacketPlayOutEntityMetadata.PACKET_CLASS.getDeclaredFields()[i];
            switch (i) {
                case 0: {
                    PacketPlayOutEntityMetadata.entityIdField = field;
                    break;
                }
                case 1: {
                    PacketPlayOutEntityMetadata.dataWatcherValuesField = field;
                    break;
                }
                default: {
                    throw new RuntimeException("Unknown field index " + i);
                }
            }
        }
        constructor = Reflection.makeConstructor(PacketPlayOutEntityMetadata.PACKET_CLASS, (Class<?>[])new Class[0]);
    }
}
