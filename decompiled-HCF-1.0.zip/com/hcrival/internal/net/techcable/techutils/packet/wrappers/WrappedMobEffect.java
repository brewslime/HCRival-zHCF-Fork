package com.hcrival.internal.net.techcable.techutils.packet.wrappers;

public class WrappedMobEffect
{
    private Object handle;
    
    public Object getHandle() {
        return this.handle;
    }
}
